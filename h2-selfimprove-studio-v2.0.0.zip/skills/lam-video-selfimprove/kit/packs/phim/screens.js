// screens.js — noi dung ve phang (canvas thuan, khong phu thuoc 2D / 3D) dung chung cho bo "phim" (2D) va "cine" (3D):
// man hinh dien thoai (feed cuon co chuan bi -> vuot -> dung nhe, gio nhay theo bang; bao thuc; chat / khoa / email... dung lai ve cua legacy),
// poster / lich (tieu de, luoi o chi tiet khac nhau, X ve tay dan, vet gap). Moi ham la ham thuan cua t.
import { clamp, lerp } from '/engine/core.js';
import { EASE, rng } from '/engine/cine/timeline.js';
import { postArt } from '/packs/dem/art.js';
import { phone as phone2d } from '/packs/dem/phone.js';

const UIF = '"Be Vietnam Pro"', HANDF = '"Caveat"';
function rr(g, x, y, w, h, r) { g.beginPath(); g.roundRect(x, y, w, h, r); }
const ACC = { red: '#ff3b3b', pink: '#ff4fa3', amber: '#ffb03b', teal: '#38d1c4' };
const accentOf = (E) => ACC[E?.cfg?.accent] || E?.cfg?.accent || ACC.red;

// ---------- lich vuot feed: giu `hold` giay -> keo xuong nhe (chuan bi) -> vuot len (cubicOut) -> vuot qua 3% -> dung lai
// tra { n: bai dang hien tai (so thuc), i: so lan da vuot, ph: 'hold' | 'prep' | 'swipe' | 'settle', k: 0..1 trong pha }
export function swipeAt(t, o = {}) {
  const hold = o.hold ?? 1.1, prep = 0.14, sw = 0.3, st = 0.22, per = hold + prep + sw + st;
  const i = Math.floor(Math.max(0, t) / per), u = Math.max(0, t) - i * per;
  if (u < hold) return { n: i, i, ph: 'hold', k: u / hold };
  if (u < hold + prep) { const k = (u - hold) / prep; return { n: i - 0.035 * Math.sin(Math.PI * 0.5 * k), i, ph: 'prep', k }; }
  if (u < hold + prep + sw) { const k = (u - hold - prep) / sw; return { n: i - 0.035 + 1.065 * EASE.cubicOut(k), i, ph: 'swipe', k }; }
  const k = (u - hold - prep - sw) / st; return { n: i + 1 + 0.03 * (1 - EASE.cubic(k)), i, ph: 'settle', k };
}
// gio tren thanh trang thai nhay theo bang: clockAt [[giay, "10:04"], ...] hoac times ["10:04", "10:15", ...] theo so lan vuot
export function clockNow(t, o, i = 0) {
  if (o.clockAt) { let v = o.clockAt[0][1]; for (const [s, c] of o.clockAt) if (t >= s) v = c; return v; }
  if (o.times) return o.times[Math.min(o.times.length - 1, i)];
  return o.clock || '11:43';
}

// ---------- man hinh dien thoai (W x H, ti le ~0.46): feed | alarm | (chat, lock, email, counter, reel, off: ve legacy)
export function drawPhoneScreen(g, W, H, t, o = {}) {
  const sc = o.screen || 'feed';
  g.save();
  if (sc === 'alarm') {   // bao thuc: nen xanh navy, gio to, nhan nho, nut tron (bam: nut sang len)
    const gr = g.createLinearGradient(0, 0, 0, H); gr.addColorStop(0, '#1d2f52'); gr.addColorStop(1, '#162540'); g.fillStyle = gr; g.fillRect(0, 0, W, H);
    g.fillStyle = '#e9eef6'; g.textAlign = 'center'; g.textBaseline = 'middle';
    g.font = `600 ${W * 0.075}px ${UIF}`; g.fillText(o.date || 'Mon, Nov 3', W / 2, H * 0.2);
    g.font = `500 ${W * 0.3}px ${UIF}`; g.fillText(clockNow(t, o), W / 2, H * 0.33);
    g.font = `700 ${W * 0.07}px ${UIF}`; g.fillStyle = 'rgba(233,238,246,0.75)'; g.fillText(o.label || 'WAKE UP', W / 2, H * 0.45);
    const press = o.pressAt !== undefined && t >= o.pressAt ? clamp((t - o.pressAt) / 0.15) : 0;
    g.fillStyle = press ? '#ffffff' : '#e9eef6'; rr(g, W * 0.22, H * 0.56, W * 0.56, H * 0.075, H * 0.0375); g.fill();
    g.fillStyle = '#1a2440'; g.font = `800 ${W * 0.075}px ${UIF}`; g.fillText(o.button || 'SNOOZE', W / 2, H * 0.5975);
    g.strokeStyle = 'rgba(233,238,246,0.6)'; g.lineWidth = W * 0.006; rr(g, W * 0.32, H * 0.67, W * 0.36, H * 0.055, H * 0.0275); g.stroke();
    g.fillStyle = 'rgba(233,238,246,0.75)'; g.font = `600 ${W * 0.055}px ${UIF}`; g.fillText(o.button2 || 'STOP', W / 2, H * 0.6975);
  } else if (sc !== 'feed') {
    const ww = H * 0.49; g.scale(W / ww, 1); phone2d(g, ww / 2, H / 2, H, { ...o, t, clock: clockNow(t, o) });
  } else {
    const S = swipeAt(t, o), posts = o.posts && o.posts.length >= 3 ? o.posts : ['ramen', 'car', 'beach', 'game', 'burger', 'watch'], k = W / 540;
    g.fillStyle = '#0b0b0e'; g.fillRect(0, 0, W, H);
    for (let j = Math.floor(S.n) - 1; j <= Math.floor(S.n) + 1; j++) {
      if (j < 0) continue; const y = (j - S.n) * H, kind = posts[j % posts.length], r = rng(j + 3);
      postArt(g, kind, 0, y + 150 * k, W, W * 1.25, t, o);
      g.fillStyle = ['#e0875a', '#5a7fe0', '#5ac08a', '#c05ab0'][j % 4]; g.beginPath(); g.arc(46 * k, y + 110 * k, 24 * k, 0, 7); g.fill();
      g.fillStyle = '#e8e8ec'; g.font = `700 ${24 * k}px ${UIF}`; g.textAlign = 'left'; g.textBaseline = 'middle'; g.fillText(['@daily.eats', '@roadtrip', '@sunny.days', '@gg.only', '@foodie', '@timepiece'][j % 6], 82 * k, y + 110 * k);
      g.fillStyle = 'rgba(255,255,255,0.55)'; rr(g, 30 * k, y + 150 * k + W * 1.25 + 40 * k, (300 + r() * 120) * k, 18 * k, 9 * k); g.fill(); rr(g, 30 * k, y + 150 * k + W * 1.25 + 74 * k, (180 + r() * 140) * k, 18 * k, 9 * k); g.fill();
      const bx = W - 58 * k, by = y + 520 * k, liked = r() < 0.5, s = 26 * k;
      g.beginPath(); g.moveTo(bx, by + s * 0.35); g.bezierCurveTo(bx - s, by - s * 0.35, bx - s * 0.45, by - s, bx, by - s * 0.45); g.bezierCurveTo(bx + s * 0.45, by - s, bx + s, by - s * 0.35, bx, by + s * 0.35);
      if (liked) { g.fillStyle = '#ff3b5c'; g.fill(); } else { g.lineWidth = 4 * k; g.strokeStyle = '#f2f2f4'; g.stroke(); }
      g.lineWidth = 4 * k; g.strokeStyle = '#f2f2f4'; g.beginPath(); g.ellipse(bx, by + 110 * k, 24 * k, 20 * k, 0, 0, 7); g.stroke(); g.beginPath(); g.moveTo(bx - 10 * k, by + 126 * k); g.lineTo(bx - 18 * k, by + 140 * k); g.lineTo(bx + 2 * k, by + 128 * k); g.stroke();
      g.beginPath(); g.moveTo(bx - 20 * k, by + 230 * k); g.lineTo(bx + 22 * k, by + 210 * k); g.lineTo(bx - 2 * k, by + 250 * k); g.closePath(); g.stroke();
      g.fillStyle = '#e8e8ec'; g.font = `700 ${20 * k}px ${UIF}`; g.textAlign = 'center';
      [`${(r() * 90 + 5).toFixed(1)}K`, `${Math.floor(r() * 900 + 40)}`, 'Share'].forEach((x, i) => g.fillText(x, bx, by + (42 + i * 110) * k));
    }
    g.fillStyle = 'rgba(11,11,14,0.92)'; g.fillRect(0, 0, W, 70 * k);
    g.fillStyle = '#f4f4f6'; g.font = `700 ${28 * k}px ${UIF}`; g.textAlign = 'left'; g.textBaseline = 'middle'; g.fillText(clockNow(t, o, S.i), 34 * k, 38 * k);
    g.strokeStyle = '#f4f4f6'; g.lineWidth = 2.5 * k; rr(g, W - 84 * k, 26 * k, 46 * k, 22 * k, 5 * k); g.stroke(); g.fillStyle = '#f4f4f6'; rr(g, W - 81 * k, 29 * k, 24 * k, 16 * k, 3 * k); g.fill();
  }
  g.restore();
}

// ---------- poster / lich. o: { title, month, from, to, n, mode: 'x' | 'fill', at, dur, reset: { at, to }, color, seed }
export function poster(o = {}, E = null) {
  const cols = 7, rows = 5, R = rng(o.seed ?? 21), detail = Array.from({ length: cols * rows }, () => ({ l1: 0.3 + R() * 0.55, l2: R() < 0.6 ? 0.2 + R() * 0.5 : 0, dot: R() < 0.3, wob: [R(), R(), R(), R()] }));
  const value = (t) => { let v = o.to ?? o.n ?? 0; if (o.to !== undefined && o.from !== undefined) v = lerp(o.from, o.to, clamp((t - (o.at ?? 0.3)) / Math.max(0.1, o.dur ?? 3))); if (o.reset && t >= (o.reset.at ?? 1e9)) v = o.reset.to ?? 0; return v; };
  const grid = (W, H) => { const gx = W * 0.068, gy = H * 0.214; return { gx, gy, cw: (W - 2 * gx) / cols, ch: (H - gy - H * 0.064) / rows }; };
  const draw = (g, W, H, t) => {
    const v = value(t), { gx, gy, cw, ch } = grid(W, H), mark = o.color || accentOf(E), u = W / 1024;
    g.save(); g.fillStyle = o.paper || '#ece6d8'; g.fillRect(0, 0, W, H);
    g.fillStyle = 'rgba(120,100,70,0.06)'; for (let i = 0; i < 40; i++) { const r2 = rng(i + 50); g.fillRect(r2() * W, r2() * H, (2 + r2() * 60) * u, 1); }
    g.fillStyle = '#23252b'; g.font = `700 ${92 * u}px ${UIF}`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillText(o.title || 'EVERY DAY', W / 2, H * 0.086);
    g.font = `700 ${64 * u}px ${HANDF}`; g.fillStyle = '#5b5f6a'; g.fillText(o.month || 'NOV', W / 2, H * 0.154);
    for (let i = 0; i < cols * rows; i++) {
      const cx = gx + (i % cols) * cw, cy = gy + Math.floor(i / cols) * ch, d = detail[i];
      g.strokeStyle = '#b9b2a2'; g.lineWidth = 3 * u; g.strokeRect(cx, cy, cw, ch);
      g.fillStyle = '#6b6f78'; g.font = `700 ${28 * u}px ${UIF}`; g.textAlign = 'left'; g.fillText(String(i + 1), cx + 10 * u, cy + 24 * u);
      g.fillStyle = 'rgba(80,84,96,0.35)'; rr(g, cx + 12 * u, cy + ch * 0.55, (cw - 24 * u) * d.l1, 9 * u, 4 * u); g.fill(); if (d.l2) { rr(g, cx + 12 * u, cy + ch * 0.72, (cw - 24 * u) * d.l2, 9 * u, 4 * u); g.fill(); } if (d.dot) { g.beginPath(); g.arc(cx + cw - 22 * u, cy + 24 * u, 7 * u, 0, 7); g.fill(); }
      const p = clamp(v - i);
      if (p > 0) {
        if (o.mode === 'fill') { g.fillStyle = mark; g.globalAlpha = 0.75; g.fillRect(cx + 4 * u, cy + 4 * u, (cw - 8 * u) * Math.min(1, p * 1.2), ch - 8 * u); g.globalAlpha = 1; }
        else {   // 2 net cheo ve tay, hoi run
          g.strokeStyle = mark; g.lineWidth = 9 * u; g.lineCap = 'round'; const m = 0.18;
          const seg = (x0, y0, x1, y1, q, s) => { if (q <= 0) return; g.beginPath(); g.moveTo(x0, y0); for (let j = 1; j <= 10 * q; j++) { const uu = j / 10; g.lineTo(lerp(x0, x1, uu) + Math.sin(uu * 9 + s * 6) * 2.5 * u, lerp(y0, y1, uu) + Math.cos(uu * 7 + s * 5) * 2.5 * u); } g.stroke(); };
          seg(cx + cw * m, cy + ch * m, cx + cw * (1 - m), cy + ch * (1 - m), clamp(p * 2), d.wob[0]); seg(cx + cw * (1 - m) + d.wob[1] * 4 * u, cy + ch * m, cx + cw * m, cy + ch * (1 - m) - d.wob[2] * 4 * u, clamp(p * 2 - 1), d.wob[3]);
        }
      }
    }
    const fg = g.createLinearGradient(W / 2 - 14 * u, 0, W / 2 + 14 * u, 0); fg.addColorStop(0, 'rgba(0,0,0,0)'); fg.addColorStop(0.45, 'rgba(0,0,0,0.07)'); fg.addColorStop(0.55, 'rgba(255,255,255,0.18)'); fg.addColorStop(1, 'rgba(0,0,0,0)'); g.fillStyle = fg; g.fillRect(W / 2 - 14 * u, 0, 28 * u, H);
    g.restore();
  };
  // diem but dang ve (0..1 cua poster) + dang ve hay khong
  const pen = (t) => {
    const v = value(t), { gx, gy, cw, ch } = grid(1, 1.367), i = Math.min(cols * rows - 1, Math.floor(v)), p = v - i, cx = gx + (i % cols) * cw, cy = gy + Math.floor(i / cols) * ch, m = 0.18;
    const q = p < 0.5 ? p * 2 : p * 2 - 1, a = p < 0.5 ? [cx + cw * m, cy + ch * m, cx + cw * (1 - m), cy + ch * (1 - m)] : [cx + cw * (1 - m), cy + ch * m, cx + cw * m, cy + ch * (1 - m)];
    return [lerp(a[0], a[2], q), lerp(a[1], a[3], q) / 1.367, v];
  };
  return { draw, pen, value, aspect: 1024 / 1400, key: (t) => (Math.round(value(t) * 30) / 30).toFixed(3) };
}
