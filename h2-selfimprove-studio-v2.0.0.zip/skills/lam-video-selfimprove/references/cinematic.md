# Chế độ cinematic (2.0): phim hoạt hình 2D vector, dàn dựng kiểu điện ảnh

Mặc định cho dự án mới (`config.json` → `"mode": "cinematic"`, bộ `phim`). Dự án cũ không có `mode` vẫn dựng y như 1.10 (chế độ **legacy**, luật hình ở `phong-cach.md`). Bản dựng 3D (Three.js 2.5D) vẫn còn làm tuỳ chọn: `"render": "3d"` (bộ `cine`).

Học **phong cách và kỹ thuật** từ phim tham khảo "1-MINUTE An Animated Short Film" (đo bằng ffmpeg ở độ phân giải gốc). Không dựng lại cảnh, thoại, bố cục cụ thể hay nhân vật riêng của phim.

## Nhìn ra sao
- **Minh hoạ vector phẳng.** Phối cảnh một điểm tụ **vẽ tay**: sàn, tường, trần, đồ đạc hội tụ. Mỗi mặt một màu: mặt trước màu gốc, mặt trên sáng hơn, mặt bên tối hơn.
- Không có ánh sáng 3D. Chuyển sắc chỉ ở **vầng sáng gradient tròn** (đèn bàn, cửa sổ, đèn đường) và vũng sáng trên sàn.
- **Vignette mạnh**, hạt nhiễu rất nhẹ.
- **Nhân vật:**
  - Khối **đen đặc**: đầu tròn ~29% chiều cao, thân bo góc, tay chân hình con nhộng, bàn tay tròn.
  - **Viền xám mảnh lệch về phía nguồn sáng.** Mỗi bộ phận có viền riêng, nên thấy cả đường tách tay với thân.
  - Mắt bầu dục **màu kem** có chấm sáng, **lông mày xám** cong mảnh, **không miệng**.
- **Bóng đen cám dỗ:** khối đen, viền và mắt màu nhấn.

## Số đo phim tham khảo
| Chỉ số | Giá trị |
|---|---|
| Cắt cảnh | ~87 lần / 5 phút, shot trung bình ~3,4 s |
| Máy quay | **phần lớn shot đứng yên**; vài shot đẩy vào chậm, gần đều (vd ×1,45 trong 4,6 s), lia / nghiêng nhẹ |
| Chiều sâu | hậu cảnh là **lớp ảnh nhoè**; tiền cảnh là khối đen che một phần khung (qua vai) |
| Animation | **rối 2D mượt 30 hình/giây** (không vẽ mỗi 2 khung), cử động rồi giữ yên; lông mày đổi góc dần, chớp mắt, nghiêng đầu |
| Màu | ngày "chưa động lực" xám lạnh không bão hoà (#dae0e4 #8d9499 #5f6569); đêm xanh than / chì (#171a21 #1c1e23) + cam đèn; kết kem ấm + xanh lá + trời xanh (#ece2cf #94b55b #8fb5d7) |
| Chữ | thoại chữ tròn đậm trên **vệt tối mờ**; narration serif trên nền đen |

## Máy quay và bố cục (tự động, sửa được)
Director chia mỗi cảnh thành 1–3 góc máy. Mã cảnh giữ nguyên. **Mỗi cỡ khung là một bố cục vẽ riêng**, không chỉ phóng to.

| Vai góc máy | Bố cục |
|---|---|
| `wide` | toàn cảnh phòng; máy đứng yên hoặc đẩy chậm đều ≤ 6% |
| `push` | trung → cận người chính, đẩy chậm; hậu cảnh nhoè |
| `ots` | qua vai bóng đen: lưng bóng đen rất to, nhoè, che 1/4 khung bên phải; người hùng nét |
| `face` | cận mặt, cửa sổ / phòng phía sau nhoè mạnh, đẩy rất chậm |
| `top` | cận từ trên xuống người nằm trên gối |
| `pov` | điện thoại nằm trên mặt tủ, tay đen từ mép dưới bấm nút (báo thức) hoặc vuốt đúng nhịp (feed) |
| `otsPoster` | lưng người hùng to bên trái, poster lịch trên tường bên phải |
| `insertPoster` | poster đầy khung, cánh tay đen cầm bút gạch X dần |
| `insertClock` | cận đồng hồ 7 đoạn trên mặt tủ, glow đỏ có giới hạn |
| `void` | màn đen: narration serif, thẻ kết |

- **Luật giữa các cảnh:** không 2 góc liên tiếp cùng cỡ và cùng góc (trừ `matchCut` có chủ ý).
- **Chuyển cảnh có lý do:** vào điện thoại = `zoomIntoProp`, rời điện thoại = `iris`, sang màn đen = `fadeThroughBlack`, trước cú sụp = `smashCut`, cùng bố cục = `matchCut`. Không một kiểu (khác cắt) quá 2 lần liền.
- Sửa tay: `MÁY:` / `CHUYỂN:` trong file 01, hoặc `args.shot`, `args.coverage`, `in: { type, why }` (xem `mau-canh-cinematic.md`).

## Nhân vật và diễn xuất
- Dùng y ngữ pháp legacy: `pose` / `poseAt`, `face` / `faceAt`, `facing`, `hold`, `walk`, `at` / `out`. 37 biểu cảm đều có bản lông mày / mí / cúi đầu.
- Góc nhìn thân: `yaw` (0 chính diện, ±0,4 ba phần tư, ±π/2 nghiêng, π sau lưng), `front: true`, `back: true`.
- **Phụ kiện khoá theo nhân vật** (thân luôn đen): `band` băng đô kem, `friend*` mũ màu, `girl` tóc buộc + khăn vàng, `hoodie` mũ trùm hạ, `dad` kính…
- Đi bộ vào chiều sâu: nhân vật thu nhỏ theo phối cảnh, chân đưa luân phiên theo quãng đường.

## Màu theo câu chuyện
Tông phòng tự chọn:
- **đêm**: xanh than + đèn cam;
- **ngày**: xám lạnh (đoạn sa ngã);
- **hy vọng**: kem ấm + xanh lá, khi ban ngày và nhạc `hope` / `rise` / `resolve`.

`grade` (mất màu / tối theo nhịp nhạc) vẫn chạy như legacy. Ép tông: `args.tone: "night" | "day" | "hope"`.

## Chữ (2 font theo phim tham khảo)
- **Thoại / giọng trong đầu** (`say`, `tempt`, `narr` trong cảnh):
  - Comic Neue đậm, trên vệt tối mờ, gắn trên đầu người nói, tự né đầu / thân / HUD.
  - Màu: người hùng trắng, giọng cám dỗ màu nhấn (gõ từng chữ), bạn bè mỗi người một màu.
- **Màn đen:** Lora nghiêng nhỏ, giữa màn. Dòng `"— Tên"` in hoa nhỏ giãn cách.
- **Thẻ kết:** Lora in hoa giãn cách + dòng phụ nghiêng.
- **Bộ đếm:** Lora in hoa nhỏ góc trái, loé màu nhấn khi đổi số.

## Nhịp
- Màn đen / thẻ kết được giữ yên (phim tham khảo giữ 3–4 s); `--check` không báo đứng hình ở hai mẫu này.
- Cảnh có hình: nhân vật thở, chớp mắt theo seed, lông mày đổi dần, bóng đen hiện dần; đẩy máy chậm ở góc `push` / `face`.

## Bối cảnh của bộ `phim` (cùng một kiểu vẽ)
- `bedroom` (đêm / ngày / hy vọng);
- nội thất: `cafe kitchen classroom gym sofa mirror doorway lockers court stairs`;
- ngoài trời: `street city hill`;
- `void` / `none` / `black` = sân khấu tối (nhiều người đứng hàng, xếp đều theo bề ngang khung).
- `graph` (đồ thị trộn lên phòng mờ) và `cta` đã vẽ kiểu phim. Chỉ mẫu `note` còn vẽ kiểu legacy.

## Chưa có ở bản 2.0
- 9:16 dùng legacy.
- Chưa có: dáng già, nước mắt, `vanish` (bóng đen tan), `fx`, `act` dựng sẵn (tư thế vẫn đổi theo `poseAt`).
