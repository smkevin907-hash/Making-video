---
name: lam-video-selfimprove
description: Dựng phim hoạt hình ngắn KHÔNG LỜI ĐỌC kiểu kênh self-improvement ("An Animated Short Film") 100% bằng code - mặc định kiểu phim hoạt hình 2D vector dàn dựng điện ảnh (minh hoạ phẳng vẽ phối cảnh, nhân vật khối đen viền xám mắt kem, máy phần lớn đứng yên + đẩy chậm, hậu cảnh nhoè theo lớp, vầng sáng gradient, màu theo câu chuyện, bóng đen cám dỗ viền màu nhấn), vẫn giữ chế độ 2D cũ (nền tối nét mảnh, nhân vật đầu tròn màu kem); chữ kể chuyện, giọng cám dỗ, bộ đếm DAY N, điện thoại / đồng hồ / lịch cận cảnh, nhạc piano + SFX tự tạo - từ file kịch bản cảnh 01-PHIM; xuất MP4 16:9 hoặc 9:16 và thumbnail (ảnh AI + chữ code). Dùng khi gọi /lam-video-selfimprove, nói "dựng phim self improvement", "dựng video không lời", "dựng phim DISCIPLINE / TOMORROW...", "làm bản xem trước", "sửa cảnh b0xx", "làm thumbnail".
---

# Dựng phim ngắn không lời (H2 Studio, gói ngách Self-Improvement)

Nói chuyện với người dùng bằng **tiếng Việt**, ngắn gọn, không dùng thuật ngữ lập trình.

Toàn bộ hình **vẽ bằng code**: Chromium chạy ngầm chụp từng khung, ffmpeg ghép video. Không cần voice, không cần ảnh AI trong video. Chỉ thumbnail dùng 1 ảnh AI (`T01`) do người dùng tạo theo `03-THUMB-PROMPT`.

**Hai chế độ** (`config.json` → `"mode"`):
- **cinematic** (mặc định từ 2.0, bộ `phim`): phim hoạt hình **2D vector** dàn dựng kiểu điện ảnh, học từ "1-MINUTE An Animated Short Film".
  - Minh hoạ phẳng vẽ phối cảnh một điểm tụ; rối 2D khối đen viền xám, chuyển động mượt 30 fps.
  - Máy phần lớn đứng yên, có đẩy chậm. Mỗi cảnh tự chia 1–3 góc máy, mỗi cỡ khung là một bố cục riêng.
  - Hậu cảnh nhoè theo lớp, vầng sáng gradient, màu theo câu chuyện. Vẽ bằng CPU, không cần GPU.
  - Bản dựng 3D (Three.js 2.5D) vẫn còn làm tuỳ chọn: `"render": "3d"` (bộ `cine`).
- **legacy**: kiểu sân khấu 2D của bản ≤ 1.10. Dự án cũ không có `mode` tự giữ legacy, dựng y như cũ.

Cả hai dùng **cùng file 01, cùng `phim.py`, cùng `shots.json`** (cùng tên mẫu cảnh, cùng args).

**Tài nguyên trong skill này:**
- `kit/`: bộ dựng dùng chung với các gói H2. Gồm:
  - `render.mjs`, `engine/` (`engine/flat/`: máy 2D, lớp + nhoè, phối cảnh vẽ tay; `engine/cine/`: bản 3D tuỳ chọn)
  - `packs/phim/` (bộ cinematic 2D, mặc định), `packs/cine/` (cinematic 3D, tuỳ chọn), `packs/dem/` (bộ legacy)
  - `tools/` (có `phim.py`), `audio/`
  - `projects/selfimprove-phim/` (dự án mẫu cinematic đủ mọi mẫu cảnh + bối cảnh), `projects/selfimprove-mau/` (cùng nội dung, legacy)
- `references/cai-dat.md`: cài đặt lần đầu.
- `references/cinematic.md`: luật hình chế độ cinematic (2D vector kiểu điện ảnh: nhân vật, bố cục theo góc máy, màu, chữ, chuyển cảnh, số đo phim tham khảo). **Đọc trước khi lên cảnh.**
- `references/mau-canh-cinematic.md`: chỗ khác / thêm của mẫu cảnh ở chế độ cinematic.
- `references/phong-cach.md`: luật hình của ngách ở chế độ legacy (và bảng số đo đối thủ 2D).
- `references/mau-canh.md`: toàn bộ mẫu cảnh, nhân vật, tư thế, bối cảnh và tham số (dùng chung cả hai chế độ).
- `references/am-thanh.md`: nhạc, SFX.
- `references/kiem-tra.md`: xem trước, xuất bản cuối, danh sách kiểm tra.

## Luật vàng
1. **Giữ nguyên chữ và thời lượng trong file 01.** Muốn đổi chữ thì hỏi người dùng.
2. **Dùng mẫu cảnh, không viết code từng cảnh.** Mỗi cảnh là `tpl` + `args` trong `story/shots.json`. Chỉ cảnh đặc biệt mới viết code (`scenes/shots/<id>.js`).
3. **Nhân vật nhất quán:** cùng preset (`hoodie`, `band`, `hero`) và màu nhấn suốt phim, ghi trong `story/bible.md`.
4. **Vẽ nháp, nhìn, sửa, rồi mới xuất.** Luôn mở ảnh tổng hợp ra xem trước khi xuất.
5. **Đạt chuẩn theo chế độ:**
   - **cinematic** (`cinematic.md`): bố cục theo cỡ khung (toàn / trung / cận / qua vai / POV); không 2 góc liền nhau cùng cỡ và cùng góc; hậu cảnh nhoè ở cận; tông màu theo câu chuyện; chuyển cảnh có lý do; chữ không đè người / HUD. Máy đứng yên và giữ khung có chủ đích được phép (phim tham khảo phần lớn shot máy đứng yên).
   - **legacy** (bảng đối thủ ở `phong-cach.md`): 0 giây đứng hình, mở bằng màn đen câu nghịch lý, 3–4 màn đen, phim ≤ 3:20, màu thế giới đổi theo nhịp.
   - `phim.py` và `--check` tự cảnh báo khi lệch.
6. **3 điểm dừng hỏi người dùng:**
   - Lựa chọn ban đầu.
   - Ảnh tổng hợp toàn phim (lô đầu).
   - Bản xem trước 30 giây có tiếng.

   Nếu người dùng vắng: dùng mặc định, ghi rõ đã giả định gì, rồi làm tiếp.

## Bước 1: Nhận đầu vào
Hỏi một lần, bỏ qua câu người dùng đã trả lời:
- **File `01-PHIM-<slug>.txt`** (từ `/kich-ban-selfimprove`). Không có thì đề nghị viết bằng lệnh đó.
- **Chế độ:** cinematic (mặc định, phim 2D vector kiểu điện ảnh) hoặc legacy (sân khấu 2D cũ).
- **Khung:** 16:9 (mặc định, **toàn khung, không dải đen**) hoặc 9:16 (Shorts; bản 2.0 dựng 9:16 bằng legacy).
- **Màu nhấn:** lấy từ dòng `ACCENT` trong file 01; mặc định `red`.
- **Độ phân giải:** 1080p (mặc định) hoặc 720p.
- **Ảnh thumbnail `T01.png`** (không bắt buộc lúc đầu, cần ở bước cuối).
- **Tiêu đề video.**

## Bước 2: Cài hoặc kiểm tra studio
Làm theo `references/cai-dat.md`:
1. Chép `kit/` vào thư mục làm việc thành `h2-2d-studio/`. Đã có thì chỉ chép đè `engine/ packs/ tools/ audio/*.py render.mjs player.html package.json`. **Không** ghi đè `projects/`.
2. Cài gọn (chỉ ngách này, ~290 MB, đã gồm Three.js cho bản 3D tuỳ chọn): `npm install --omit=optional`, `npx playwright install --only-shell chromium`. Thư mục dùng chung với gói H2 khác: cài đầy đủ (`npm install`, `npx playwright install chromium`) — xem `cai-dat.md`.
3. `python tools/doctor.py` → đến khi `SAN SANG` (doctor mở thử Chromium thật; báo THIEU thì xem `cai-dat.md` mục Chromium). Chế độ cinematic 2D vẽ bằng CPU; chỉ bản 3D tuỳ chọn mới cần GPU (xem `cai-dat.md`).
4. `python audio/build_audio.py --gon` (cài gọn: chỉ SFX, nhạc tự sinh riêng từng phim) hoặc `python audio/build_audio.py` (đầy đủ).
5. Tự kiểm bằng `projects/selfimprove-phim` (cinematic) và `projects/selfimprove-mau` (legacy).

## Bước 3: Dự án và bản nháp tự động
Chạy trong `h2-2d-studio/`. Dùng `python3` nếu `python` không phải Python 3.

```bash
python tools/new_project.py --name <slug> --title "<tiêu đề>" --pack dem --style flat --lang en [--mode legacy] [--aspect 9:16] [--resolution 720p]
python tools/phim.py --project projects/<slug> --phim "<01-PHIM-<slug>.txt>"
node render.mjs --project projects/<slug> --sheet --scale 0.5 --at 0.75
```
- Không ghi `--mode`: chế độ cinematic (30 fps, bộ `phim` 2D; `--render 3d` = bộ `cine`). `--aspect 9:16` tự dùng legacy.
- Cinematic: chụp thêm `--at 0.3` để thấy góc máy đầu của mỗi cảnh. Mỗi cảnh thường có 2 góc; `--at 0.75` là góc sau.
- `phim.py` đọc file 01 → `story/shots.json`: thời lượng từng cảnh, chữ (tự xếp giờ hiện), bộ đếm, nhạc, SFX, **đoán sẵn** mẫu cảnh, bối cảnh, nhân vật từ mô tả tiếng Việt, kể cả động tác (quỵ xuống, ngã, ném điện thoại, ngồi dậy, đứng dậy, quay lưng bỏ đi, thở dốc, đấm), bóng đen vỡ / tan thành tro, máy theo người chạy. Có cảnh báo nếu chữ không đủ giờ đọc.
- Bản nháp tự động chỉ là khởi điểm. Bước 4 mới làm cho đẹp.

## Bước 4: Lên hình cho từng cảnh

### Chế độ cinematic
Đọc `references/cinematic.md`, `references/mau-canh-cinematic.md` (và `mau-canh.md` cho args chung), rồi:
1. **Viết `story/bible.md`:** preset nhân vật chính (trang phục khoá suốt phim; đổi `hoodie` → `band` khi tập), bạn bè, màu nhấn, các lần quay lại cùng phòng (cùng `setArgs`: giờ đồng hồ, lịch, đèn, trời), cảnh nào cần giữ khung lặng.
2. **Sửa `args` trong `story/shots.json`**:
   - Bối cảnh, `setArgs`, `actors` (mốc `bed.sit`, `desk.seat`…), tư thế, biểu cảm, `faceAt` / `poseAt`, `bed` + `bed.up`.
   - `phone.times` (giờ nhảy theo mỗi lần vuốt), `calendar` (title, from, to).
   - Máy quay, ánh sáng, chuyển cảnh **tự có** (director). Chỉ ghi khi muốn khác:
     - `shot` (cỡ / góc / chuyển động cho góc chính) hoặc `coverage` (cả danh sách góc);
     - `tone` (tông phòng: night / day / hope);
     - `in: { type, why }` (chuyển cảnh + lý do). Trong file 01 ghi `MÁY: cận cảnh, góc thấp` và `CHUYỂN: iris vì ...`.
3. **Xem ngay:** ảnh tổng hợp `--at 0.3` và `--at 0.75` (2 góc máy mỗi cảnh). Sửa:
   - chữ đè mặt;
   - bóng đen che người hùng;
   - đầu tiền cảnh che chủ thể ở góc qua vai;
   - poster / đồng hồ không đủ khung.
4. Mọi bối cảnh (phòng ngủ, nội thất, phố, đồi, sân khấu tối) và `graph` / `cta` cùng một kiểu vẽ. Chỉ `note` còn vẽ kiểu legacy: báo người dùng nếu phim có cảnh này.
5. Gửi ảnh tổng hợp cho người dùng duyệt (điểm dừng 2).

### Chế độ legacy
Đọc `references/phong-cach.md` và `references/mau-canh.md`, rồi:
1. **Viết `story/bible.md`:** preset nhân vật chính (và lúc nào đổi: hoodie → băng đô khi tập), bạn bè / cô gái / gia đình, màu nhấn, bộ đếm, các bối cảnh lặp lại (cùng phòng ngủ thì cùng `setArgs`: lịch, đèn, laptop), kế hoạch máy quay.
2. **Sửa `args` của mọi cảnh trong `story/shots.json`** theo mô tả `scene`:
   - Bối cảnh + `setArgs` (giờ đồng hồ, lịch tháng mấy tô bao nhiêu ô, đèn, trời).
   - `actors`: ai, ở đâu (`x` số hoặc mốc `bed.sit`, `desk.seat`, `sofa.seat`, `bus.seat`, `bench`, `top`, `mirror.in`...), tư thế, biểu cảm (37 kiểu, cảm xúc rõ: `panic`, `sob`, `grit`, `tempted`, `lonely`… xem `mau-canh.md`), `faceAt`/`poseAt` đổi theo giây (tự chuyển dần, có lấy đà; tới đích sau mốc ~0,4 giây), `facingAt` để quay người, `walk`/`run` (chân bám đất, tự quay theo hướng đi; `back: true` = đi lùi). Cảnh có chữ cám dỗ (`~`) phải có `who: "voice"`.
   - Nằm trong chăn: dùng `bed` (không dùng actor).
   - `act`: động tác kể chuyện dựng sẵn (`collapse`, `fall`, `throwPhone`, `walkAway`, `pant`, `standUp`, `sitDown`); người nằm giường ngồi dậy bằng `bed.up`.
   - `cam`: đẩy chậm vào chủ thể (`from` → `to`, zoom 1.0 → 1.15–1.4). Cảnh cảm xúc đẩy vào mặt. Cảnh chạy / đi dài: `follow` theo người. Máy tự rung tay nhẹ và cảnh tự có chiều sâu; `fg` thêm tiền cảnh mờ.
   - Bóng đen tan biến: `fx: shards` (tự vỡ thật kiểu `burst`) hoặc `vanish` trên actor voice (`burst` / `ash`).
   - `fx`: `shards` khi bóng đen vỡ, `flash` ở bước ngoặt, `pulse` ở cú sụp, `zzz` (hoặc `bed.zzz`, **không ghi cả hai**), `embers`, `rain`.
   - **Tự có từ 1.10, không cần ghi** (chỉ kiểm lại trên ảnh tổng hợp): màu thế giới theo nhạc (`grade`), dáng già khi AGE ≥ 55 (`age`), tay bóng đen nhắm vai người hùng (`aim`), bóng đen quay về người hùng, bộ đếm nảy khi đổi số, màn đen / thẻ kết đẩy máy đều. Câu có số liệu cảm xúc ("cheap high → crash") dùng mẫu `graph`. Vệt tốc độ khi chạy, chớp sáng khi đấm trúng, mồ hôi, bụi chân, ánh màn hình lên mặt, khói bóng đen… **tự có**, không cần ghi.
   - Kiểu vẽ mặc định giống phim mẫu (hạt đậu, mắt chấm mí nặng, nét rung vẽ tay). Phim cũ muốn giữ y như bản 1.4.0: `config.json` `"look": "classic", "anim": "smooth", "details": false`.
   - Chuyển cảnh: `in: {"type": "dip"}` giữa các nhịp lớn, còn lại `cut`.
3. **Xem ngay:** `node render.mjs --project projects/<slug> --sheet --scale 0.5 --at 0.75`, mở từng `build/sheets/sheet_XX.jpg`, sửa cảnh lỗi: chữ đè mặt, nhân vật ra ngoài khung, bóng đen che mất nhân vật chính.
4. Gửi ảnh tổng hợp cho người dùng duyệt (điểm dừng 2).

## Bước 5: Âm thanh
Đọc `references/am-thanh.md`. Phim không lời nên **nhạc và SFX là giọng kể**:
- Nhạc theo nhịp: `sad` (mở, sa ngã) → `dark` (đáy, `gainDb` −3) → `none` 1 cảnh lặng sau câu đau nhất → `hope` (bước ngoặt) → `rise` (đứng lên) → `resolve` (thẻ kết).
- SFX dày hơn ngách có lời: mỗi 1–2 cảnh một tiếng; `tempt_swell` / `tempt_whisper` mỗi lần bóng đen nói; `sting_low` hoặc `boom_deep` ở cú sụp; `vanish_burst` (hoặc `vanish_ash`) đúng giây bóng đen tan biến.
- Nhạc tự sinh riêng theo tên phim, chuyển giữa các đoạn tự hoà dần, quay lại thì phát tiếp. Muốn bản nhạc khác: `"music": { "seed": 2 }` trong `config.json`.
- Nghe thử: `python tools/mix.py --project projects/<slug> --no-video`.

## Bước 6: Xem trước, xuất bản cuối, giao
1. **Quét lỗi:** `node render.mjs --project projects/<slug> --check --scale 0.25` → danh sách lỗi theo mã cảnh + giây (cũng lưu `build/check.txt`): nhân vật sai mốc / ra ngoài khung, chữ đè mặt / người / đồ vật, chữ đè chữ, chữ cắt mép, người bị che, chân trượt, nhạc hụt, đổi tư thế giật, **đứng hình** (đo bằng điểm ảnh, ≥ 1,5 giây). Sửa hết `LOI` trước khi xuất; `CANH BAO` xem có cố ý không.
   - Cinematic: dựng xong `build/preview.mp4` thì đo nhịp `python tools/do_nhip.py build/preview.mp4 --project projects/<slug>` (chuyển động TB ≥ 1,2; thay đổi lớn ≥ 0,6/s; không đứng hình > 1 s ngoài màn chữ; khung gần đen ≤ 10%). Chưa đạt thì xem `kiem-tra.md` mục Cinematic.
2. **Xem trước 30 giây có tiếng:**
   ```bash
   python tools/mix.py --project projects/<slug> --no-video
   node render.mjs --project projects/<slug> --from 0 --to 30 --scale 0.5
   ```
   Gửi `build/preview.mp4` (điểm dừng 3).
3. **Bản cuối:**
   ```bash
   nohup node render.mjs --project projects/<slug> > projects/<slug>/build/render.log 2>&1 &
   ```
   - Legacy: phim 3 phút 1080p mất khoảng 3–5 phút trên máy cloud 2 nhân (bộ `dem` vẽ bằng CPU, không cần GPU).
   - Cinematic 2D (bộ `phim`, CPU): đo được phim 62 giây 1080p mất 81 giây (3 luồng) → phim 3 phút khoảng 4 phút.
   - Bản 3D tuỳ chọn (`"render": "3d"`) cần GPU thật (Windows / macOS tự bật `--gl gpu`); máy không GPU chậm ~9 lần.
   - Đọc log và báo thời gian còn lại.
4. **Trộn âm:** `python tools/mix.py --project projects/<slug>` → `out/<tiêu đề>.mp4`, −14 LUFS.
5. **Thumbnail:** chép `T01.png` vào `projects/<slug>/anh/`, viết `scenes/shots/thumb.js`:
   ```js
   import { thumb } from '/packs/dem/pack.js';
   thumb({ img: 'T01', title: 'WAKE UP.' });
   // 2 dòng, đổi màu 1 từ:   thumb({ img: 'T01', lines: ['JUST ONE', 'MORE.'], accent: ['MORE.'] });
   // gạch xoá số:           thumb({ img: 'T01', title: 'DAY 412 0.', strike: '412', accent: ['0.'] });
   ```
   Chạy `node render.mjs --project projects/<slug> --thumb` → `out/thumbnail.png`. Mở ra kiểm: chữ không che mặt, không cắt mép. Chưa có ảnh AI thì lệnh vẽ cảnh mẫu bằng code để xem bố cục chữ (không dùng làm thumbnail thật).
6. **Kiểm cuối** theo `references/kiem-tra.md`, gửi MP4 + thumbnail, ghi vào thư mục người dùng nếu có.

## Sửa theo góp ý
- **Theo mã cảnh** ("b07: cho bóng đen ngồi trên giường"): sửa `args` cảnh đó, xem lại bằng `--sheet --ids b07`, dựng đoạn đó bằng `--from/--to`.
- **Góc máy / chuyển cảnh (cinematic)** ("b04 quay cận hơn", "vào b05 bằng iris"): `args.shot` / `args.coverage` / `in: { type, why }` của cảnh đó. Xem một khung bất kỳ: `--stills <giây>`. Muốn xem trong trình duyệt: `node render.mjs --project projects/<slug> --serve` rồi mở link `&frame=<số khung>` (1 khung) hoặc `&live=1` (phát trực tiếp).
- **Đổi chữ hoặc thời lượng:** sửa file 01 rồi chạy lại `phim.py --force` **chỉ khi chưa lên hình**; đã lên hình thì sửa trực tiếp `texts` / `start` / `end` trong `shots.json` (cảnh sau phải dời theo, `duration` = `end` cảnh cuối).
- **Làm bản 9:16 từ phim 16:9:** tạo dự án mới `--aspect 9:16`, chép `story/shots.json`, xem tổng hợp và chỉnh `x` nhân vật về giữa.
