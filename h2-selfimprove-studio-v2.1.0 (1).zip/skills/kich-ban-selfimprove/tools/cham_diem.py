"""cham_diem.py — tu cham kich ban truoc khi giao (R16), thang 1-5, may cham theo bang chung trong file 01 (+ thu vien doi thu). Python 3.8+.
  python cham_diem.py --thu-muc <thu muc nguoi dung> --phim <01-PHIM> [--ghi <02-PACKAGE.md>]
6 tieu chi: cau moc, do ro cua uoc mo, cu sup, khoanh khac nguoi that, do moi so voi doi thu, do doc duoc khi khong co tieng.
2.1 them 3 tieu chi HEURISTIC (khong thay the doc lai): do cu the, y nghia dung duoc, giong nguoi. Bat buoc >= 4 voi khung buoc-nho / giai-ma
hoac file co BÀI HỌC; file khung 1-5 khong co BÀI HỌC thi 3 tieu chi nay chi de tham khao (khong chan). 6 tieu chi cu giu nguyen cach tinh.
Moi tieu chi bat dau 5 diem, tru theo tung thieu sot (in ly do). Duoi 4 -> sua truoc khi giao (tra ma 1). --ghi: ghi / thay muc "## Tự chấm" trong 02-PACKAGE
(cot "Cuối" mac dinh = diem may; Claude chi duoc chinh +-1 kem ly do, khong vuot may + 1).
"""
import argparse, os, re, sys
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import doi_thu as DT, kiem_truyen as KT
try: sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except (AttributeError, ValueError): pass
kd = DT.khong_dau
SUP = {"vuc-day": ["Đáy"], "tiec-nuoi": ["Nhận ra", "Cái giá"], "song-song": ["Phân kỳ"], "vong-lap": ["Vòng 1", "Vòng 2"], "thu-gui": ["Điều ước"],
       "buoc-nho": ["Đáy"], "giai-ma": ["Cái giá"]}
NGUOI = {"vuc-day": ["Bước ngoặt", "Đáy"], "tiec-nuoi": ["Nhận ra", "Cái giá"], "song-song": ["Hội tụ", "Phân kỳ"], "vong-lap": ["Lệch vòng", "Vòng 2"], "thu-gui": ["Điều ước", "Trả lời"],
         "buoc-nho": ["Người dẫn đường", "Đáy"], "giai-ma": ["Sự thật", "Cái giá"]}
# 2.1 heuristic do cu the: so, gio, thu / thang, so dem bang chu, ten rieng giua cau, vat cu the. Sao rong: tru diem.
CU_THE = (r"\d|\b(am|pm|a\.m\.|p\.m\.|midnight|noon|tonight|today|yesterday|monday|tuesday|wednesday|thursday|friday|saturday|sunday|mon|tue|wed|thu|fri|sat|sun|"
          r"january|february|march|april|june|july|august|september|october|november|december|jan|feb|mar|apr|jun|jul|aug|sep|sept|oct|nov|dec|"
          r"one|two|three|four|five|six|seven|eight|nine|ten|eleven|twelve|twenty|thirty|forty|fifty|hundred|thousand|first|second|third|half|once|twice)\b|"
          r"\b(phone|alarm|clock|shoes?|books?|pages?|notebook|laptop|lamp|ball|umbrella|bus|door|desk|bed|mirror|coffee|cup|mug|pizza|apron|keys?|headphones|"
          r"calendar|planner|poster|kitchen|gym|court|stairs|hill|quiz|test|exam|email|texts?|messages?|photos?|shift|school|homework|practice|class|drawer|"
          r"charger|screen|feed|videos?|game|match|mile|km|pushups?|birthday|letter|file)\b")
SAO = r"never give up|believe in yourself|you got this|stay strong|no excuses|success is|the journey|chase your dreams|be the best version|hustle|grind never|everything happens|follow your passion|stay consistent"
GIANG = r"\b(he learned|she learned|he realized that|she realized that|the lesson|you should|you must|always remember|the key is|that's when he understood)\b"
def cu_the(x):   # dong chu co chi tiet cu the? (ten rieng: chu hoa khong o dau cau, khong phai "I")
    s = re.sub(r"^\{[\d.,]+\}\s*", "", x)[1:].strip(); s = re.sub(r"^\[[^\]]*\]\s*|^[^:]{1,20}:\s*", "", s) if x[:1] in '"“@' else s
    return bool(re.search(CU_THE, s, re.I) or re.search(r"(?<=[a-z,] )[A-Z][a-z]+", s))
PEOPLE = r"\b(ban|friend\d?|co gai|girl|me|mom|bo|dad|em nho|em be|kid)\b"

def rt(x):   # gio doc (giong phim.py)
    k, t = x[:1], x[1:].strip(); w = len(t.split())
    if k == "~": return 0.9 + len(t) / 16 + 0.6
    if k in ('"', "“"): return 1.6
    if k == "@": return 1.0 + w * 0.22
    return max(1.8, min(4.5, 1.0 + w * 0.32))
def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--thu-muc", default="."); ap.add_argument("--phim", required=True); ap.add_argument("--ghi")
    a = ap.parse_args(); md = os.path.join(HERE, "..", "references", "khung-truyen.md")
    K = KT.doc_khung(md); meta, sc, tot, moc_b, _ = KT.doc_phim(a.phim)
    km = next((m for m, x in K.items() if kd(meta.get("khung", "")) in (m, kd(x["ten"]), kd(x["ten"].split(" / ")[0]))), None)
    if not km: sys.exit("Thieu / sai KHUNG o dau file 01 (chay kiem_truyen.py truoc).")
    pct = lambda c: 100 * c["t"] / tot if tot else 0
    card = [c for c in sc if KT.tag(c, "the ket", "card") is not None or any(k.startswith(("keu goi", "cta")) for k in c["tags"])]; nd = [c for c in sc if c not in card]
    nh = {}   # ten nhip -> (bat dau %, ket thuc %)
    st = [(KT.rest(x, "nhip"), pct(c)) for c in sc for x in KT.tok(c, "nhip")] + ([("Thẻ kết", pct(card[0]))] if card else [])
    for i, (n, p) in enumerate(st): nh[kd(n)] = (p, st[i + 1][1] if i + 1 < len(st) else 100)
    in_nhip = lambda c, names: any(kd(n) in nh and nh[kd(n)][0] - 3 <= pct(c) < nh[kd(n)][1] + 3 for n in names)
    lib = DT.doc_phan_tich(a.thu_muc); R = {}

    # 1 cau moc
    s, why = 5, []; ma_, mb = DT.ma("kieu_cau_moc", meta.get("moc")), DT.ma("kieu_cau_moc", meta.get("moc b"))
    if not ma_ or not mb or ma_ == mb: s -= 2; why.append("thiếu / trùng kiểu MÓC B")
    c0 = nd[0]; tx = next(((c, x) for c in nd for x in c["chu"] if x[:1] in ">!~\"@"), (None, ""))
    hinh = ma_ in ("hinh-manh", "bo-dem-sup") and (KT.tag(c0, "hud") or KT.tag(c0, "dong tac"))   # cau moc bang hinh / bo dem: chu den sau duoc
    if not hinh and (tx[0] is None or tx[0]["t"] + 0.35 > 3): s -= 1; why.append("chữ đầu tiên đến sau 3 giây")
    if len(tx[1][1:].split()) > 9: s -= 1; why.append("câu móc dài hơn 9 từ")
    if c0["dur"] > 7: s -= 1; why.append(f"cảnh mở dài {c0['dur']:g}s (> 7)")
    bad = (ma_ == "chu-man-den" and not re.search(r"man den|black", kd(KT.tag(c0, "nen") or ""))) or (ma_ == "cau-hoi" and not tx[1].rstrip().endswith("?")) \
          or (ma_ == "bo-dem-sup" and not any(re.search(r"->|→", KT.tag(c, "hud") or "") for c in nd if pct(c) <= 12))
    if bad: s -= 1; why.append("cấu trúc câu móc A không khớp kiểu đã khai")
    same = [x for x in lib if x.get("kieu_cau_moc") == ma_]
    if lib and len(same) * 2 >= len(lib): s -= 1; why.append(f"{len(same)}/{len(lib)} video đối thủ đã phân tích cũng mở bằng kiểu này")
    R["Câu móc"] = (s, why or [f"{DT.MOC.get(ma_, '?')}, chữ đầu ở giây {tx[0]['t'] + 0.35:.1f}" if tx[0] else "có câu móc"])
    # 2 uoc mo
    s, why = 5, []; um = [c for c in sc if KT.tok(c, "uoc mo")]; vv = [c for c in sc if KT.tok(c, "vat")]
    if not um: s, why = 1, ["chưa gài ước mơ"]
    else:
        p0 = pct(um[0])
        if p0 > 15: s -= 2; why.append(f"gài muộn ({p0:.0f}%)")
        elif p0 > 10: s -= 1; why.append(f"gài ở {p0:.0f}% (tốt nhất ≤ 10%)")
        if len(meta.get("uoc mo", "").split()) < 4: s -= 1; why.append("ƯỚC MƠ chưa cụ thể (< 4 từ)")
        i0 = sc.index(um[0])
        if not any(c in vv for c in sc[i0:i0 + 3]): s -= 1; why.append("vật biểu tượng không xuất hiện cùng lúc gài ước mơ")
        if any(x[:1] in ">!" and re.search(r"\b(dream|wanted to|goal|wish)", x, re.I) for c in um for x in c["chu"]): s -= 1; why.append("ước mơ bị giải thích bằng chữ")
        if not any(KT.tok(c, "tra") or KT.tok(c, "vat") for c in sc if pct(c) >= 60): s -= 1; why.append("40% cuối không quay lại ước mơ / vật")
    R["Độ rõ của ước mơ"] = (max(1, s), why or [f"gài bằng hình ở {pct(um[0]):.0f}%, đi cùng vật biểu tượng, quay lại ở cuối"])
    # 3 cu sup
    s, why = 5, []; sp = [c for c in sc if KT.tok(c, "sup")]
    if not sp: s, why = 1, ["không có cú sụp"]
    else:
        c = sp[0]; i = sc.index(c); nxt = sc[i:i + 3]; hud_prev = next((KT.tag(x, "hud") for x in reversed(sc[:i]) if KT.tag(x, "hud")), None)
        hud_doi = re.search(r"->|→", KT.tag(c, "hud") or "") or (KT.tag(c, "hud") and KT.tag(c, "hud") != hud_prev)
        dau = any(x[:1] in ">!" and len(x[1:].split()) <= 6 for y in sc[i:i + 2] for x in y["chu"])
        if not (hud_doi or dau): s -= 2; why.append("lúc sụp không có bộ đếm đổi / câu đau ngắn")
        if not any(re.search(r"dark|none|tat", kd(KT.tag(y, "nhac") or "")) for y in nxt): s -= 1; why.append("nhạc không đổi (dark / none) quanh cú sụp")
        if not any(re.search(r"sting|boom|downer|heartbeat|impact", KT.tag(y, "sfx") or "") for y in nxt): s -= 1; why.append("không có SFX nhấn (sting_low / boom_deep / downer)")
        if not in_nhip(c, SUP[km]): s -= 1; why.append(f"sụp ở {pct(c):.0f}%, ngoài nhịp {' / '.join(SUP[km])}")
    R["Cú sụp"] = (max(1, s), why or [f"ở {pct(sp[0]):.0f}%: bộ đếm / câu đau + nhạc + SFX"])
    # 4 khoanh khac nguoi that
    s, why = 5, []; ng = [c for c in sc if KT.tok(c, "nguoi that")]
    if not ng: s, why = 1, ["không có khoảnh khắc người thật"]
    else:
        def co_nguoi(c): return any(re.match(r"^@\s*(?!me\b)", x) or x[:1] in '"“' for x in c["chu"]) or re.search(PEOPLE, kd(KT.tag(c, "ai") or ""))
        tot_ng = [c for c in ng if co_nguoi(c)]
        if not tot_ng: s -= 2; why.append("cảnh đánh dấu người thật không có người (tin nhắn / bong bóng / nhân vật phụ)")
        hit = [c for c in ng if in_nhip(c, NGUOI[km])]
        if not hit: s -= 1; why.append(f"không rơi vào nhịp {' / '.join(NGUOI[km])}")
        c = (hit or ng)[0]; i = sc.index(c)
        if not any(KT.tag(y, "dong tac") or KT.tok(y, "bien co") for y in sc[i:i + 3]): s -= 1; why.append("sau đó không có hành động / biến cố mới của nhân vật")
    R["Khoảnh khắc người thật"] = (max(1, s), why or [f"{len(ng)} lần, có người thật, đúng nhịp, kéo theo hành động"])
    # 5 do moi
    s, why = 5, []; code = {"de_tai": DT.ma("de_tai", meta.get("de tai")), "khung_truyen": km, "kieu_ket": DT.ma("kieu_ket", meta.get("ket")), "vat": DT.vat_chuan(meta.get("vat"))}
    if not lib: s, why = 3, ["thư viện phân tích trống: chưa so được (quét + phân tích đối thủ rồi chấm lại)"]
    else:
        best = max((([k for k in ("de_tai", "khung_truyen", "kieu_ket") if x.get(k) == code[k]] + (["vat"] if code["vat"] and DT.vat_chuan(x.get("vat_bieu_tuong")) == code["vat"] else []), x) for x in lib), key=lambda b: len(b[0]))
        n = len(best[0]); s = {4: 1, 3: 3, 2: 4}.get(n, 5)
        if n: why.append(f"giống nhất: {best[1].get('kenh')} '{best[1].get('tieu_de')}' {n}/4 ({', '.join(best[0])})")
        same_t = [x for x in lib if x.get("de_tai") == code["de_tai"] and x.get("khung_truyen") == km]
        if same_t and s > 3: s -= 1; why.append(f"{len(same_t)} video đối thủ cùng đề tài đã dùng khung này")
        rows = DT.doc_csv(os.path.join(a.thu_muc, "DOI-THU-SELFIMPROVE", "video.csv")); tt = KT.gon_chu(meta.get("title", ""))
        if tt and any(KT.gon_chu(r.get("tieu_de", "").split("|")[0]) == tt for r in rows): s -= 1; why.append("từ khoá tiêu đề trùng video đối thủ")
    R["Độ mới so với đối thủ"] = (max(1, s), why or ["không trùng yếu tố nào với thư viện"])
    # 6 doc duoc khi khong co tieng
    s, why = 5, []; thieu = []
    for c in nd:
        cur = 0.35 + sum(rt(x) for x in c["chu"] if x[:1] in ">!~\"“@")
        if cur > c["dur"] + 0.3: thieu.append(c["id"])
    if thieu: s -= 2; why.append(f"chữ không đủ giờ đọc ở {', '.join(thieu[:5])}")
    dai = [x for c in nd for x in c["chu"] if x[:1] in ">!" and len(x[1:].split()) > 9]
    if dai: s -= 1; why.append(f"{len(dai)} câu kể chuyện > 9 từ")
    co_chu = sum(1 for c in nd if c["chu"]) / max(1, len(nd))
    if co_chu < 0.3: s -= 1; why.append(f"chỉ {co_chu:.0%} cảnh có chữ")
    rong = [n for n, (p0, p1) in nh.items() if n != kd("Thẻ kết") and not any(x[:1] in ">!@" for c in nd if p0 <= pct(c) < p1 for x in c["chu"])]
    if rong: s -= 1; why.append(f"nhịp không có câu kể chuyện / tin nhắn: {', '.join(rong)}")
    R["Độ đọc được khi không có tiếng"] = (max(1, s), why or [f"{co_chu:.0%} cảnh có chữ, mọi chữ đủ giờ đọc, mọi nhịp có câu kể chuyện"])

    # ---- 2.1: 3 tieu chi heuristic. Chan (>= 4) voi khung buoc-nho / giai-ma hoac file co BÀI HỌC; con lai chi tham khao.
    L = K[km]["luat"]; chan = km in ("buoc-nho", "giai-ma") or bool(meta.get("bai hoc")); ten3 = lambda k: k if chan else k + " (tham khảo)"
    dong = [x for c in nd for x in c["chu"] if x[:1] in '>!~"“@' and not x[1:].strip().startswith("—")]
    # 7 do cu the
    s, why = 5, []; ct = [x for x in dong if cu_the(x)]; r = len(ct) / max(1, len(dong)); so = sum(1 for x in dong if re.search(r"\d", x)) / max(1, len(dong))
    s = 5 if r >= 0.45 else 4 if r >= 0.35 else 3 if r >= 0.25 else 2 if r >= 0.15 else 1
    why.append(f"{len(ct)}/{len(dong)} dòng chữ ({r:.0%}) có chi tiết cụ thể (số, giờ, ngày, tên, vật)")
    sao = sorted({m.group(0).lower() for x in dong for m in re.finditer(SAO, x, re.I)})
    if sao: s -= min(2, len(sao)); why.append(f"câu sáo rỗng: {', '.join(sao)}")
    if so > 0.6: s -= 1; why.append(f"{so:.0%} dòng có con số — nhồi số? câu đau nhất thường không cần số")
    canh_rong = [c["id"] for c in nd if c["chu"] and not any(cu_the(x) for x in c["chu"])]
    if canh_rong: why.append(f"cảnh chưa có chi tiết cụ thể: {', '.join(canh_rong[:6])}" + (" …" if len(canh_rong) > 6 else ""))
    R[ten3("Độ cụ thể")] = (max(1, s), why)
    # 8 y nghia dung duoc
    s, why = 5, []; bh, bnh, su = (meta.get("bai hoc") or "").strip(), (meta.get("buoc nho") or "").strip(), (meta.get("su that") or "").strip()
    bn = [c for c in sc if KT.tok(c, "buoc nho")]; the_ = [c for c in sc if KT.tok(c, "trich dan") or KT.tok(c, "khai niem")]
    can_kiem = re.search(r"^#\s*can kiem nguon", kd(open(a.phim, encoding="utf-8-sig").read()), re.M)
    if not bh: s -= 2; why.append("thiếu BÀI HỌC")
    elif re.search(SAO, bh, re.I) or len(bh.split()) < 6: s -= 1; why.append("BÀI HỌC giống khẩu hiệu / quá ngắn (< 6 từ)")
    if not bnh: s -= 2; why.append("thiếu BƯỚC NHỎ")
    elif not re.search(r"\d|minute|hour|tonight|today|tomorrow morning|before bed|phút|giờ|tối nay|hôm nay|\b(one|two|five|ten)\b", bnh, re.I): s -= 1; why.append("BƯỚC NHỎ chưa có thời lượng / thời điểm (1 phút, 10 phút, tối nay…)")
    if bnh and (len(bn) != 1 or pct(bn[0]) < 70): s -= 1; why.append(f"bước nhỏ hiện {len(bn)} lần" + (f" ở {pct(bn[0]):.0f}%" if bn else "") + " (cần đúng 1 lần ở 30% cuối)")
    if the_ and (not su or kd(su) in ("khong", "-", "—", "none") or can_kiem): s -= 2; why.append("có thẻ khái niệm / trích dẫn nhưng nguồn trống hoặc còn CẦN KIỂM NGUỒN")
    elif su and kd(su) not in ("khong", "-", "—", "none") and not re.search(r"—|\(|\d{4}|,", su): s -= 1; why.append("SỰ THẬT chưa ghi nguồn (tác giả / tác phẩm / năm)")
    gi = [x for c in nd if 20 <= pct(c) <= 80 for x in c["chu"] if x[:1] in ">!" and re.search(GIANG, x, re.I)]
    if gi: s -= 1; why.append(f"giảng bài học giữa phim: '{gi[0][1:].strip()}'")
    R[ten3("Ý nghĩa dùng được")] = (max(1, s), why or ["có bài học, bước nhỏ đúng 1 lần ở cuối, nguồn đúng dạng, không giảng giữa phim"])
    # 9 giong nguoi
    s, why = 5, []; noi = KT.nguoi_noi(nd); tho = sum(1 for x in dong if x[:1] in '"“@'); rt_ = tho / max(1, len(dong))
    dan = [c for c in sc if KT.tok(c, "nguoi dan duong")]; c1 = next((c for c in nd if c["chu"]), None)
    if len(noi) < 2: s -= 3; why.append(f"{len(noi)} người nói — chỉ có lời kể")
    elif len(noi) < 3: s -= 1; why.append(f"{len(noi)} người nói (nên ≥ 3)")
    if rt_ < 0.15: s -= 2; why.append(f"thoại / tin nhắn chỉ {rt_:.0%} dòng chữ")
    elif rt_ < 0.25: s -= 1; why.append(f"thoại / tin nhắn {rt_:.0%} dòng chữ (nên ≥ 25%)")
    if L.get("dan") == "1" and not dan: s -= 2; why.append("khung cần người dẫn đường mà chưa có")
    if c1 is None or c1["t"] + 0.35 > 3: s -= 1; why.append("3 giây đầu chưa có giọng người (chữ đến muộn)")
    R[ten3("Giọng người")] = (max(1, s), why or [f"{len(noi)} người nói ({', '.join(noi)}), thoại / tin nhắn {rt_:.0%} dòng chữ" + (", có người dẫn đường" if dan else "")])

    print(f"TU CHAM {os.path.basename(a.phim)} — khung {K[km]['ten']}")
    for k, (v, w) in R.items(): print(f"  {v}/5  {k}: {'; '.join(w)}")
    print("  (3 tiêu chí cuối là heuristic, không thay thế đọc lại" + ("" if chan else "; khung cũ không có BÀI HỌC nên chỉ để tham khảo, không chặn") + ")")
    duoi = [k for k, (v, _) in R.items() if v < 4 and not k.endswith("(tham khảo)")]
    print("=> DAT (moi tieu chi >= 4)." if not duoi else f"=> SUA TRUOC KHI GIAO: {', '.join(duoi)}")
    if a.ghi:
        bang = "## Tự chấm (thang 1–5; dưới 4 thì sửa trước khi giao)\n\n| Tiêu chí | Máy | Cuối | Vì sao |\n|---|---|---|---|\n" + \
               "\n".join(f"| {k} | {v} | {v} | {'; '.join(w).replace('|', '¦')} |" for k, (v, w) in R.items()) + \
               "\n\nĐiểm máy chấm bằng `tools/cham_diem.py`. Cột Cuối chỉ chỉnh ±1 kèm lý do. 3 tiêu chí cuối (Độ cụ thể, Ý nghĩa dùng được, Giọng người) là heuristic, không thay thế đọc lại.\n"
        t = open(a.ghi, encoding="utf-8").read() if os.path.exists(a.ghi) else ""
        m = re.search(r"^## Tự chấm.*?(?=^## |\Z)", t, re.S | re.M)
        t = t[:m.start()] + bang + "\n" + t[m.end():] if m else t.rstrip() + "\n\n" + bang
        open(a.ghi, "w", encoding="utf-8").write(t); print(f"(da ghi muc Tu cham vao {a.ghi})")
    sys.exit(1 if duoi else 0)

if __name__ == "__main__": main()
