"""phan_tich.py — tang 2: phan tich ke chuyen 1 video doi thu (file .mp4 hoac anh chup man hinh). Can ffmpeg + ffprobe, Python 3.8+.
  python phan_tich.py cat --video <file.mp4> --thu-muc <thu muc nguoi dung> [--ten <slug>] [--nguong 0.1 (mac dinh tu dong)]
  python phan_tich.py cat --anh <anh hoac thu muc anh> [...] --thu-muc <..> --ten <slug>
      -> cat canh tu dong (so khung cach 0,25 giay, nguong theo chinh video), lay khung (canh dai lay them moi 2,5 giay de bat chu doi / cat mo dan),
         anh tong hop 4x3 co nhan khung (c07, c07b...) + giay, am luong, khoang im lang, nhip uoc. Ghi DOI-THU-SELFIMPROVE/.tam/<slug>/ (canh.json, doc-mau.json, sheet_XX.jpg).
      Claude mo tung anh tong hop, doc chu tren hinh (OCR bang mat), dien doc.json theo doc-mau.json; sua ranh gioi canh bang "moi_canh" cua tung khung.
  python phan_tich.py ghi --tam <thu muc .tam/<slug>> --doc <doc.json> --thu-muc <..> [--giu]
      -> dung lai canh theo moi_canh, kiem bang phan loai co dinh, tinh so canh / nhip / cu sup % / ti le canh co chu / nhac, noi voi video.csv (luot xem, x trung vi),
         ghi phan-tich/<kenh>-<slug>.md CHI gom bang phan loai + tom tat loi minh + toi da 3 cau trich ngan; kiem khong lot nguyen van chu cua ho;
         in dan canh dung lai (co chu) ra man hinh de xem, KHONG luu; xoa .tam (tru --giu).
"""
import argparse, array, json, math, os, re, shutil, statistics, subprocess, sys, datetime as dt
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
import doi_thu as DT
try: sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except (AttributeError, ValueError): pass
FF, FP = os.environ.get("H2_FFMPEG", "ffmpeg"), os.environ.get("H2_FFPROBE", "ffprobe")
FONTS = ["C:/Windows/Fonts/arialbd.ttf", "C:/Windows/Fonts/arial.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans-Bold.ttf", "/usr/share/fonts/truetype/dejavu/DejaVuSans.ttf",
         "/System/Library/Fonts/Supplemental/Arial Bold.ttf", "/Library/Fonts/Arial.ttf"]
LOAI_CHU = {"narr": "kể chuyện", "tempt": "giọng cám dỗ", "chat": "tin nhắn", "big": "chữ to giữa màn", "hud": "bộ đếm", "say": "bong bóng", "card": "thẻ kết", "cta": "kêu gọi", "khac": "chữ khác"}

def run(cmd):
    r = subprocess.run(cmd, capture_output=True)
    if r.returncode: sys.exit(f"Loi khi chay {os.path.basename(cmd[0])}: {r.stderr.decode('utf-8', 'replace')[-600:]}")
    return r.stderr.decode("utf-8", "replace") + r.stdout.decode("utf-8", "replace")
def font():
    f = next((x for x in FONTS if os.path.exists(x)), None)
    return f.replace(":", "\\:") if f else None
def slug(s): return re.sub(r"[^a-z0-9]+", "-", DT.khong_dau(s)).strip("-")[:40] or "video"
def mm(t): return f"{int(t) // 60}:{t % 60:04.1f}"

# ---------- cat
def cat_canh(v, nguong):
    dur = float(run([FP, "-v", "error", "-show_entries", "format=duration", "-of", "csv=p=0", v]).strip().splitlines()[-1])
    # so khung cach nhau 0,25 giay (fps=4): chuyen canh mo dan qua man den van ra diem du lon
    log = run([FF, "-hide_banner", "-i", v, "-an", "-vf", "fps=4,select='gte(scene,0)',metadata=print:key=lavfi.scene_score", "-f", "null", "-"])
    tt = [float(x) for x in re.findall(r"pts_time:([\d.]+)", log)]; sc = [float(x) for x in re.findall(r"scene_score=([\d.]+)", log)]
    # nguong tu dong theo chinh video: phim nen toi doi canh nhe (diem thap), nen lay ~20 lan diem trung vi, kep 0,04-0,3
    th = nguong if nguong else min(0.3, max(0.04, 20 * statistics.median(sc))) if sc else 0.3
    pts, last = [0.0], 0.0
    for c in [tt[i] for i in range(min(len(tt), len(sc))) if sc[i] >= th]:
        if c - last >= 0.4 and dur - c >= 0.4: pts.append(c); last = c   # bo diem cat sat nhau (chop / mo dan)
    pts.append(dur)
    return dur, th, [{"i": i + 1, "start": round(pts[i], 2), "end": round(pts[i + 1], 2), "dur": round(pts[i + 1] - pts[i], 2)} for i in range(len(pts) - 1)]
def am_thanh(v):   # am luong 10 lan / giay tu PCM 8 kHz: im lang, nhac 10 doan, nhip uoc
    r = subprocess.run([FF, "-v", "error", "-i", v, "-vn", "-ac", "1", "-ar", "8000", "-f", "s16le", "-"], capture_output=True)
    if r.returncode or not r.stdout: return {"co": False}
    a = array.array("h"); a.frombytes(r.stdout[: len(r.stdout) // 2 * 2]); hop = 800; db = []
    for k in range(0, len(a) - hop, hop):
        e = (sum(x * x for x in a[k:k + hop:4]) / (hop / 4)) ** 0.5; db.append(-90.0 if e < 1 else round(20 * math.log10(e / 32768), 1))
    im, s0 = [], None
    for k, x in enumerate(db + [0]):
        if x < -42 and s0 is None: s0 = k
        elif x >= -42 and s0 is not None:
            if (k - s0) / 10 >= 0.7: im.append([round(s0 / 10, 1), round(k / 10, 1)])
            s0 = None
    gop_im = []
    for x in im:   # gop doan im lang sat nhau (< 1,5 giay) thanh 1
        if gop_im and x[0] - gop_im[-1][1] < 1.5: gop_im[-1][1] = x[1]
        else: gop_im.append(list(x))
    im = gop_im
    doan = [round(statistics.mean(db[int(len(db) * j / 10):max(int(len(db) * j / 10) + 1, int(len(db) * (j + 1) / 10))]), 1) for j in range(10)]
    on = [max(0.0, db[k] - db[k - 1]) for k in range(1, len(db))]; best = (0, None)
    for lag in range(3, 11):   # tu tuong quan duong bao tang am: 0,3-1,0 giay / nhip (thô)
        s = sum(on[k] * on[k - lag] for k in range(lag, len(on))) / max(1, len(on) - lag)
        if s > best[0]: best = (s, lag)
    return {"co": True, "db": db, "im_lang": im, "doan_10": doan, "bpm_uoc": round(60 / (best[1] / 10)) if best[1] else None, "tb_db": round(statistics.mean(db), 1)}
def cmd_cat(a):
    T = DT.thu_muc(a.thu_muc); ten = a.ten or slug(os.path.splitext(os.path.basename(a.video or "anh"))[0]); W = os.path.join(T, ".tam", ten)
    if os.path.exists(W): shutil.rmtree(W)
    os.makedirs(os.path.join(W, "khung")); fnt = font(); K = []; files = []
    lab = lambda txt: (f",drawtext=fontfile='{fnt}':text='{txt}':x=6:y=6:fontsize=20:fontcolor=white:box=1:boxcolor=black@0.7:boxborderw=4" if fnt else "")
    if a.video:
        dur, th, canh = cat_canh(a.video, a.nguong)
        for c in canh:
            ts = [c["start"] + c["dur"] / 2] if c["dur"] < 3.2 else [c["start"] + 0.6 + 2.5 * k for k in range(int((c["dur"] - 0.9) / 2.5) + 1)]
            for j, t in enumerate(ts):
                nh = f"c{c['i']:02d}" + (chr(97 + j) if len(ts) > 1 else ""); f = os.path.join(W, "khung", f"k_{len(K) + 1:04d}.jpg")
                run([FF, "-v", "error", "-y", "-ss", f"{t:.2f}", "-i", a.video, "-frames:v", "1", "-vf", "scale=480:-2" + lab(f"{nh}  {t:.1f}s"), "-q:v", "4", f])
                K.append({"nhan": nh, "t": round(t, 2), "canh_goc": c["i"], "dau": j == 0, "start_goc": c["start"]}); files.append(f)
        am = am_thanh(a.video)
    else:
        src = []
        for p in a.anh: src += sorted(os.path.join(p, x) for x in os.listdir(p) if x.lower().endswith((".png", ".jpg", ".jpeg", ".webp"))) if os.path.isdir(p) else [p]
        dur, th, canh, am = None, None, [], {"co": False}
        for k, p in enumerate(src, 1):
            f = os.path.join(W, "khung", f"k_{k:04d}.jpg"); run([FF, "-v", "error", "-y", "-i", p, "-frames:v", "1", "-vf", "scale=480:-2" + lab(f"a{k:02d}"), "-q:v", "4", f])
            K.append({"nhan": f"a{k:02d}", "t": None, "canh_goc": k, "dau": True, "start_goc": None, "anh": os.path.basename(p)}); files.append(f); canh.append({"i": k})
    sheets = []
    for s in range(0, len(files), 12):
        out = os.path.join(W, f"sheet_{s // 12 + 1:02d}.jpg"); n = min(12, len(files) - s)
        run([FF, "-v", "error", "-y", "-start_number", str(s + 1), "-i", os.path.join(W, "khung", "k_%04d.jpg"), "-frames:v", "1",
             "-vf", f"tile=4x{(n + 3) // 4}:padding=4:color=0x333333", "-q:v", "3", out]); sheets.append(out)
    json.dump({"video": a.video, "anh": a.anh, "dur": dur, "nguong": th, "canh_tu_dong": len(canh), "khung": K, "am": am, "sheets": sheets}, open(os.path.join(W, "canh.json"), "w", encoding="utf-8"), ensure_ascii=False)
    mau = {"tieu_de": "", "kenh": "", "video_id": "",
           "khung": [{"nhan": k["nhan"], "giay": k["t"], "moi_canh": k["dau"], "loai": [], "chu": "", "dem": "", "boi_canh": "", "nhip": ""} for k in K],
           "phan_loai": {"de_tai": "|".join(m for m, _, _ in DT.DE_TAI), "khung_truyen": "|".join(DT.KHUNG), "kieu_cau_moc": "|".join(DT.MOC), "kieu_bo_dem": "|".join(DT.DEM),
                         "cu_sup_khung": "nhan khung luc bo dem / cuoc doi sup (vd c14); de trong = khong co", "khoanh_khac_nguoi_that": "|".join(DT.NGUOI), "kieu_ket": "|".join(DT.KET),
                         "vat_bieu_tuong": "vat lap lai >= 2 lan va doi theo truyen, hoac 'khong co'", "chu_thumbnail": "",
                         "nguoi_dan_duong": "co|khong (tuy chon, 2.1)", "the_khai_niem": "ten khai niem tren hinh, hoac de trong (tuy chon, 2.1)",
                         "the_trich_dan": "tac gia cau trich tren man den, hoac de trong (tuy chon, 2.1)"},
           "tom_tat": "3-5 cau LOI CUA MINH (tieng Viet): ke chuyen gi, di nhu the nao, ket ra sao. Khong chep cau cua ho.",
           "vi_sao": "1-3 cau gia thuyet vi sao video nay vuot troi / hut (neu biet so lieu)", "trich": ["toi da 3 cau trich ngan (<= 12 tu) lam vi du phong cach"]}
    json.dump(mau, open(os.path.join(W, "doc-mau.json"), "w", encoding="utf-8"), ensure_ascii=False, indent=1)
    print(f"CAT XONG: {len(canh)} canh tu dong" + (f" (nguong {th:.3f}), dai {mm(dur)}, nhip TB {dur / len(canh):.1f} giay/canh" if dur else " (anh chup, moi anh 1 canh)") + f", {len(K)} khung, {len(sheets)} anh tong hop")
    if am.get("co"): print(f"  Am thanh: TB {am['tb_db']} dB; im lang {['%s-%ss' % tuple(x) for x in am['im_lang']] or 'khong'}; 10 doan (dB): {am['doan_10']}; nhip uoc {am['bpm_uoc']} BPM (tho)")
    print("  Anh tong hop:\n" + "\n".join("    " + s for s in sheets))
    print(f"  Buoc tiep: mo tung anh, doc chu tren hinh, dien {os.path.join(W, 'doc-mau.json')} -> luu {os.path.join(W, 'doc.json')}.\n"
          "  Khung nao bat dau canh moi ma may chua cat (vd c02d) -> moi_canh: true; may cat thua -> moi_canh: false. Roi:\n"
          f"    python phan_tich.py ghi --tam \"{W}\" --doc \"{os.path.join(W, 'doc.json')}\" --thu-muc \"{a.thu_muc}\"")

# ---------- ghi
def norm(s): return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9' ]", " ", DT.khong_dau(s))).strip()
def dung_canh(C, doc):   # gop khung thanh canh theo moi_canh (nguoi doc sua duoc ranh gioi may cat)
    K, dur = C["khung"], C.get("dur"); dk = {x["nhan"]: x for x in doc.get("khung", [])}; canh = []
    for j, k in enumerate(K):
        x = dk.get(k["nhan"], {})
        if j == 0 or x.get("moi_canh", k["dau"]):
            st = None if k["t"] is None else k["start_goc"] if k["dau"] else round((K[j - 1]["t"] + k["t"]) / 2, 2)
            canh.append({"i": len(canh) + 1, "start": st, "khung": [], "loai": [], "chu": [], "dem": [], "boi_canh": "", "nhip": ""})
        c = canh[-1]; c["khung"].append(k["nhan"])
        for l in x.get("loai", []):
            if l not in c["loai"]: c["loai"].append(l)
        for t in [y.strip() for y in re.split(r"\s*/\s*|\n", x.get("chu", "")) if y.strip()]:
            if t not in c["chu"]: c["chu"].append(t)
        if x.get("dem", "").strip() and x["dem"].strip() not in c["dem"]: c["dem"].append(x["dem"].strip())
        c["boi_canh"] = c["boi_canh"] or x.get("boi_canh", "").strip(); c["nhip"] = c["nhip"] or x.get("nhip", "").strip()
    db = C.get("am", {}).get("db")
    for i, c in enumerate(canh):
        c["end"] = canh[i + 1]["start"] if i + 1 < len(canh) else dur; c["dur"] = round(c["end"] - c["start"], 1) if dur else None
        seg = db[int(c["start"] * 10):max(int(c["start"] * 10) + 1, int(c["end"] * 10))] if db and dur else None; c["am_db"] = round(statistics.mean(seg), 1) if seg else ""
    return canh
def cmd_ghi(a):
    C = json.load(open(os.path.join(a.tam, "canh.json"), encoding="utf-8")); doc = json.load(open(a.doc, encoding="utf-8-sig")); T = DT.thu_muc(a.thu_muc); loi = []
    pl = doc.get("phan_loai", {}); code = {}
    for k in ("de_tai", "khung_truyen", "kieu_cau_moc", "kieu_bo_dem", "khoanh_khac_nguoi_that", "kieu_ket"):
        code[k] = DT.ma(k, pl.get(k))
        if not code[k]: loi.append(f"phan_loai.{k} = '{pl.get(k)}' khong co trong bang ({', '.join(DT.NHOM[k])})")
    tuy = {}   # 2.1: truong tuy chon; doc.json cu khong co van ghi duoc; gia tri mau (co "|" / "tuy chon") coi nhu trong
    for k in ("nguoi_dan_duong", "the_khai_niem", "the_trich_dan"):
        v = (pl.get(k) or "").strip(); tuy[k] = "" if "|" in v or "tuy chon" in DT.khong_dau(v) else v
    if tuy["nguoi_dan_duong"] and DT.khong_dau(tuy["nguoi_dan_duong"]) not in ("co", "khong"): loi.append(f"phan_loai.nguoi_dan_duong = '{tuy['nguoi_dan_duong']}': ghi co / khong hoac de trong")
    trich = [q.strip() for q in doc.get("trich", []) if q.strip() and not q.startswith("toi da")]
    if len(trich) > 3: loi.append(f"trich {len(trich)} cau: toi da 3")
    for q in trich:
        if len(q.split()) > 12: loi.append(f"cau trich qua dai (> 12 tu): '{q}'")
    if len((doc.get("tom_tat") or "").split()) < 12: loi.append("tom_tat qua ngan: viet 3-5 cau loi cua minh")
    if loi: sys.exit("CHUA GHI — sua doc.json:\n  " + "\n  ".join(loi))
    canh = dung_canh(C, doc); n = len(canh); dur = C.get("dur"); kt = {k["nhan"]: k["t"] for k in C["khung"]}
    co_chu = [c for c in canh if c["chu"]]; loai_ct = {}
    for c in canh:
        for l in c["loai"]: loai_ct[l] = loai_ct.get(l, 0) + 1
    dem = [d for c in canh for d in c["dem"]]; dem_seq = [x for k, x in enumerate(dem) if k == 0 or x != dem[k - 1]]
    sk = (pl.get("cu_sup_khung") or "").strip(); sup_pct = round(100 * kt[sk] / dur) if sk in kt and kt[sk] is not None and dur else None
    sup_canh = next((c["i"] for c in canh if sk in c["khung"]), None)
    nh = []
    for c in canh:
        if c["nhip"] and (not nh or nh[-1][0] != c["nhip"]): nh.append([c["nhip"], c["start"] if dur else c["i"]])
    dan = " · ".join(f"{t} {round(100 * s / (dur or n))}%" for t, s in nh) if nh else ""
    am = C.get("am", {}); nhac = ""
    if am.get("co") and dur:
        im = list(dict.fromkeys(f"{round(100 * x[0] / dur)}–{round(100 * x[1] / dur)}%" if round(100 * x[1] / dur) > round(100 * x[0] / dur) else f"{round(100 * x[0] / dur)}%" for x in am["im_lang"] if x[0] > 1 and x[1] < dur - 1))
        d10 = am["doan_10"]; up = max(range(1, 10), key=lambda j: d10[j] - d10[j - 1]); dn = min(range(1, 10), key=lambda j: d10[j] - d10[j - 1])
        nhac = (f"im lặng ở {', '.join(im)}; " if im else "không có đoạn im lặng giữa phim; ") + f"to lên rõ nhất quanh {up * 10}%, nhỏ xuống rõ nhất quanh {dn * 10}%; nhịp ước ~{am['bpm_uoc']} BPM (thô)"
    rows = DT.doc_csv(os.path.join(T, "video.csv")); vr = None
    if doc.get("video_id"): vr = next((r for r in rows if r["video_id"] == doc["video_id"]), None)
    if not vr and doc.get("tieu_de"): vr = next((r for r in rows if norm(r["tieu_de"]) == norm(doc["tieu_de"]) and (not doc.get("kenh") or norm(doc["kenh"]) in norm(r["ten_kenh"]))), None)
    kenh = (vr or {}).get("ten_kenh") or doc.get("kenh") or "?"; tit = (vr or {}).get("tieu_de") or doc.get("tieu_de") or "?"
    rec = {"kenh": kenh, "tieu_de": tit, "video_id": (vr or {}).get("video_id") or doc.get("video_id", ""), "luot_xem": (vr or {}).get("luot_xem", ""), "diem_vuot_troi": (vr or {}).get("diem_vuot_troi", ""),
           "ngay_dang": (vr or {}).get("ngay_dang", ""), **code, "vat_bieu_tuong": (pl.get("vat_bieu_tuong") or "không có").strip(), "cu_sup_pct": sup_pct, "so_canh": n,
           "nhip_tb": round(dur / n, 1) if dur else None, "ti_le_chu": round(100 * len(co_chu) / n) if n else 0, "cong_thuc_tieu_de": DT.cong_thuc_of(tit),
           "chu_thumbnail": (pl.get("chu_thumbnail") or "").strip(), "trich": trich, "ngay_phan_tich": dt.date.today().isoformat(), **{k: v for k, v in tuy.items() if v}}
    nhan = lambda B, k: B.get(k, k or "—")
    L = [f"# Phân tích: {tit} — {kenh}", "", f"<!-- phan-loai {json.dumps(rec, ensure_ascii=False)} -->", "",
         f"> Phân tích ngày {rec['ngay_phan_tich']} từ {'video' if C.get('video') else 'ảnh chụp màn hình'}. File chỉ gồm bảng phân loại, tóm tắt bằng lời của mình và tối đa 3 câu trích ngắn; không lưu nguyên văn chữ trên hình của video.", "",
         "| Mục | Giá trị |", "|---|---|",
         f"| Video | {('https://www.youtube.com/watch?v=' + rec['video_id']) if rec['video_id'] else '—'} |",
         f"| Lượt xem | {DT.gon(rec['luot_xem']) if rec['luot_xem'] else '—'}" + (f" (×{rec['diem_vuot_troi']} trung vị kênh)" if rec["diem_vuot_troi"] else "") + (f" · đăng {rec['ngay_dang']}" if rec["ngay_dang"] else "") + " |",
         f"| Độ dài / số cảnh / nhịp | {mm(dur) if dur else '—'} · {n} cảnh · " + (f"{rec['nhip_tb']} giây/cảnh" if dur else "—") + " |",
         f"| Đề tài | {nhan(DT.NHOM['de_tai'], code['de_tai'])} |", f"| Khung truyện | {nhan(DT.KHUNG, code['khung_truyen'])} |", f"| Kiểu câu móc | {nhan(DT.MOC, code['kieu_cau_moc'])} |",
         f"| Kiểu bộ đếm | {nhan(DT.DEM, code['kieu_bo_dem'])}" + (f" (mốc: {' → '.join(dem_seq[:9])}{' …' if len(dem_seq) > 9 else ''})" if dem_seq else "") + " |",
         f"| Cú sụp | " + (f"{sup_pct}% (cảnh {sup_canh})" if sup_pct is not None else f"cảnh {sup_canh}" if sup_canh else "không có") + " |",
         f"| Khoảnh khắc người thật | {nhan(DT.NGUOI, code['khoanh_khac_nguoi_that'])} |", f"| Kiểu kết | {nhan(DT.KET, code['kieu_ket'])} |",
         f"| Vật biểu tượng | {rec['vat_bieu_tuong']} |", f"| Công thức tiêu đề | {DT.CONG_THUC.get(rec['cong_thuc_tieu_de'], '').replace('|', '¦')} |", f"| Chữ thumbnail | {rec['chu_thumbnail'] or 'chưa xem'} |",
         f"| Cảnh có chữ | {rec['ti_le_chu']}% ({', '.join(f'{LOAI_CHU.get(k, k)} {v}' for k, v in sorted(loai_ct.items(), key=lambda kv: -kv[1]))}) |"]
    if tuy["nguoi_dan_duong"]: L.append(f"| Người dẫn đường | {'có' if DT.khong_dau(tuy['nguoi_dan_duong']) == 'co' else 'không'} |")
    if tuy["the_khai_niem"]: L.append(f"| Thẻ khái niệm | {tuy['the_khai_niem']} (không dùng lại) |")
    if tuy["the_trich_dan"]: L.append(f"| Thẻ trích dẫn | {tuy['the_trich_dan']} (không dùng lại) |")
    if dan: L.append(f"| Dàn nhịp | {dan} |")
    if nhac: L.append(f"| Nhạc | {nhac} |")
    L += ["", "## Tóm tắt (lời của mình)", doc["tom_tat"].strip()]
    if (doc.get("vi_sao") or "").strip() and not doc["vi_sao"].startswith("1-3"): L += ["", "## Vì sao vượt trội / hụt (giả thuyết)", doc["vi_sao"].strip()]
    L += ["", "## Trích ví dụ phong cách (tối đa 3)"] + ([f"- \"{q}\"" for q in trich] or ["- (không trích)"])
    md = "\n".join(L) + "\n"
    # kiem khong lot nguyen van: dong chu >= 4 tu va moi cum 6 tu lien tiep cua video khong duoc co ngoai 3 cau trich
    body = norm(re.sub(r"<!--.*?-->", " ", md.split("## Trích")[0], flags=re.S)); ql = [norm(q) for q in trich]
    dong = list(dict.fromkeys(t for c in canh for t in c["chu"] if len(t.split()) >= 4)); lot = []
    for x in dong:
        w = norm(x).split()
        if any(norm(x) in q or q in norm(x) for q in ql if q): continue
        if norm(x) in body or any(" ".join(w[k:k + 6]) in body for k in range(len(w) - 5)): lot.append(x)
    if lot: sys.exit("KHONG GHI — file lot nguyen van chu cua video:\n  " + "\n  ".join(lot) + "\nViet lai tom_tat / vi_sao bang loi cua minh.")
    os.makedirs(os.path.join(T, "phan-tich"), exist_ok=True); out = os.path.join(T, "phan-tich", f"{slug(kenh)}-{slug(tit.split('|')[0])}.md")
    open(out, "w", encoding="utf-8").write(md)
    print(f"DAN CANH DUNG LAI — {tit} ({kenh}) — {n} canh (may cat {C.get('canh_tu_dong')}, nguoi doc sua ranh gioi). Chi hien thi, KHONG luu.")
    print("| Cảnh | Giây | Dài | Bối cảnh | Loại chữ | Chữ trên hình | Bộ đếm | Âm (dB) |\n|---|---|---|---|---|---|---|---|")
    for c in canh:
        print(f"| {c['i']} | {mm(c['start']) if c['start'] is not None else '—'} | {c['dur'] if c['dur'] is not None else '—'} | {c['boi_canh']} | {', '.join(LOAI_CHU.get(l, l) for l in c['loai'])} | "
              f"{' / '.join(c['chu']).replace('|', '¦')} | {' → '.join(c['dem'])} | {c['am_db']} |")
    print(f"\nDa ghi {out}\nKiem chep: {len(dong)} dong chu (>= 4 tu) cua video, 0 dong lot vao file (ngoai {len(trich)} cau trich ngan).")
    if not a.giu: shutil.rmtree(a.tam, ignore_errors=True); print(f"Da xoa thu muc tam (khung hinh + ban chep chu): {a.tam}")

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("lenh", choices=["cat", "ghi"]); ap.add_argument("--thu-muc", default="."); ap.add_argument("--video"); ap.add_argument("--anh", nargs="+")
    ap.add_argument("--ten"); ap.add_argument("--nguong", type=float, default=None, help="nguong doi canh (mac dinh tu dong)"); ap.add_argument("--tam"); ap.add_argument("--doc"); ap.add_argument("--giu", action="store_true")
    a = ap.parse_args()
    if a.lenh == "cat" and not (a.video or a.anh): sys.exit("cat can --video <file> hoac --anh <anh...>")
    if a.lenh == "ghi" and not (a.tam and a.doc): sys.exit("ghi can --tam <thu muc tam> va --doc <doc.json>")
    (cmd_cat if a.lenh == "cat" else cmd_ghi)(a)

if __name__ == "__main__": main()
