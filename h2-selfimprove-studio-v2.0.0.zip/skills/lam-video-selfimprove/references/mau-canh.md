# Mẫu cảnh của bộ `dem`

Mỗi cảnh trong `story/shots.json`: `{ "id", "start", "end", "tpl", "args", "in", "sfx", "notes" }`.
- **Toạ độ** `x`, `y`: số 0..1 = tỉ lệ khung (0.5 = giữa); số > 1.5 = px trên khung 1920×1080. **Cỡ** `h`, `s`: 0..1 = tỉ lệ chiều cao khung.
- **Thời gian** `at`, `dur`, `out`: giây tính từ đầu cảnh.
- Thiếu mẫu / sai tên → khung đỏ "THIEU MAU". Xem mọi mẫu trong `projects/selfimprove-mau`.

### Kiểu vẽ (từ 1.5.0, giống phim mẫu DISCIPLINE)
Mặc định: nhân vật **hạt đậu** (đầu nhỏ dính liền thân, tay chân thon, viền mảnh), mặt **mắt chấm đen + mí nặng + lông mày cong**, bóng đen mắt đỏ xếch không miệng, chữ cám dỗ chữ tròn đỏ, đồng hồ số LED, bối cảnh tối giản, **nét rung 10 lần/giây** (bụi trong cảnh cũng nhảy theo nhịp đó), chi tiết nhỏ tự bật. Ba công tắc (`config.json`, một số ghi được ở cảnh):
- `"look": "classic"` — dáng, mặt, bối cảnh, đồng hồ, thẻ, chữ cám dỗ như bản 1.4.0 (trùng từng điểm ảnh). Actor riêng: `"look": "classic"` (chỉ dáng + mặt).
- `"anim": "smooth"` — bỏ nét rung; nhân vật đung đưa liên tục như cũ. Hạt nhiễu phim: mặc định tắt vì làm dựng chậm ~40% (khâu nén video); muốn bật: `"grain": 7`.
- `"details": false` — tắt chi tiết nhỏ (ánh màn hình hắt lên mặt, mồ hôi văng, bụi chân, hơi thở, khói bóng đen, số đếm khi tập, bụi trong luồng sáng, mưa bắn, đèn chập chờn, kim đồng hồ chạy). Có thể ghi ở cảnh hoặc actor.
- `"temptFont": "hand"` — chữ cám dỗ viết tay như cũ.
Đứng yên thì nhân vật gần như giữ nguyên (chỉ chớp mắt, thở rất nhẹ). **Vẫn thở nhanh và run** khi: chạy, thở dốc (`pant`), mặt `scared worried panic cry sob shock embarrassed`.

## Lớp phủ chung (mọi mẫu)

### `texts` — chữ
```json
"texts": [
  { "kind": "narr", "t": "Tomorrow sounded reasonable.", "at": 0.4, "dur": 4.2 },
  { "kind": "tempt", "t": "start tomorrow.", "at": 0.6 },
  { "kind": "say", "t": "hi.", "who": "girl", "at": 1.0 },
  { "kind": "big", "t": "3 hours later...", "at": 0.3 }
]
```
- **Chữ tự tránh** (mẫu `scene`): chữ không ghi `x`, `y` tự chọn chỗ trống gần chỗ định đặt nhất, không đè đồ vật của bối cảnh (đồng hồ, cửa sổ, lịch, đèn bàn, gương, bảng, cửa neon…), không đè mặt / người / chân (tính cả đường đi suốt cảnh), hết chỗ thì chuyển hẳn lên trên / xuống dưới, **không đè chữ khác hiện cùng lúc** (chữ kể chuyện đặt trước, chữ cám dỗ né sau). Chữ đứng yên cả cảnh. Tắt: `"textAvoid": false` (cảnh hoặc `config.json`). Chữ ghi tay `x`, `y` giữ nguyên chỗ (`--check` báo nếu đè).
- `narr`: chữ kể chuyện trắng, cỡ 58 (dọc 64). `pos`: `top` (mặc định) | `bottom` | `center`; hoặc `x`, `y`. `type: true` = gõ từng chữ. `emph: {"zero": "#ffb03b"}` = tô màu 1 từ. Ở mẫu `phone`, chữ kể chuyện tự đặt bên phải điện thoại.
- `tempt`: giọng cám dỗ, chữ tròn màu nhấn (`temptFont: "hand"` = viết tay), tự gõ từng chữ, tự đặt trên đầu bóng đen (hoặc bên cạnh nếu sát mép trên); cảnh không có bóng đen thì đặt cạnh đầu người hùng như lời thì thầm. Muốn đặt tay: `x`, `y`. `"\n"` để xuống dòng. `size` nhỏ dần ở nhịp "yếu dần" (62 → 44 → 30), `color` mờ dần (`"#ffb03b88"`).
- `say`: bong bóng trắng nhỏ trên đầu người nói (`who`: preset của actor; mặc định người đầu tiên).
- `big`: chữ nhấn to, giữa màn — dùng cho câu chốt trên màn đen. 1.10: trắng đậm sạch, bóng tối mềm, cỡ 92 (= 1,2 lần dòng thường, như đối thủ). Bản cũ (112, viền xám dày, nhòe ở 1080p): `look: "classic"`.
- 1.10: chữ đang gõ giữ **mép trái cố định** (không trượt sang trái theo từng chữ cái); chữ cám dỗ dài hơn nửa khung tự xuống 2 dòng; mọi chữ tự đẩy vào trong khung (không cắt mép).
- `sign`: chữ viết tay tự do (`x`, `y`, `size`, `color`).

### `hud` — bộ đếm góc trái
```json
"hud": { "rows": [ { "label": "DAY", "n": 47 } ] }
"hud": { "rows": [ { "label": "DAY", "from": 3, "to": 30, "at": 0.3, "dur": 4 } ] }          // đếm dần
"hud": { "rows": [ { "label": "DAY", "n": 412, "reset": { "at": 1.5, "to": 0 } } ] }          // gạch về 0, số mới màu nhấn
"hud": { "rows": [ { "label": "SEEN", "n": 1388, "accent": true }, { "label": "KNOWN", "n": 0 } ] }
```
Số tự có dấu phẩy nghìn (`comma: false` để tắt). 1.10: số khác cảnh trước (cùng nhãn, bỏ qua cảnh không có bộ đếm) tự **nảy + lóe màu nhấn + gạch chân 0,8 giây** ở đầu cảnh; tắt: `"hud": { ..., "bump": false }` hoặc từng dòng `"bump": false`. Màn đen và đồ thị không hiện bộ đếm.

### `grade` — màu thế giới theo nhịp (1.10, mẫu `scene` / `phone` / `face`)
`"grade": { "sat": 0.4, "dim": 0.1 }` — bối cảnh còn 40% độ bão hoà, tối thêm 10%; người, bóng đen, màn hình, chữ giữ nguyên màu. Đổi dần: `{ "sat": [0.25, 1], "dim": [0.15, 0], "at": 0.2, "dur": 1.5 }` (màu trở lại). Nhuộm: `"tint": "#3a4a8a", "ta": 0.25`. `phim.py` tự gán theo NHẠC; tắt cả phim: `"colorArc": false`.

### `cam` — máy quay
`"cam": { "from": [x, y, zoom], "to": [x, y, zoom], "at": 0, "dur": <hết cảnh>, "ease": "sine" | "linear", "hand": 1, "follow": "band", "lead": 0.08 }` — `x, y` là điểm nhìn (0..1). Mặc định đẩy rất nhẹ (zoom 1 → 1.05). `"shake": [{ "at": 1.6, "amt": 1, "dur": 0.45 }]` rung máy.
- **Nhiều lớp (tự động):** bối cảnh chia lớp — trời, nhà xa trôi chậm nhất, nhà gần chậm vừa, tường sau hơi chậm, đồ vật và nhân vật đúng tốc độ máy. Máy đẩy / lia / rung là thấy chiều sâu.
- `hand`: máy cầm tay trôi nhẹ liên tục (mặc định 1, cả phim: `config.json` → `"camHand": 1`). `0` = máy đứng yên như bản cũ, `2` = cầm tay rõ (cảnh hoảng loạn).
- `follow`: máy bám theo nhân vật (`who`) đang đi / chạy, trễ nhịp nhẹ; `lead`: đặt người lệch về phía sau khung để chừa chỗ phía trước (0.05–0.12). Chỉ dùng với `x` là số.

### `fg` — tiền cảnh mờ (sát máy)
`"fg": [{ "kind": "figure" | "post" | "plant" | "frame", "x": 0.9, "y": 1.0, "s": 1.0, "blur": 10 }]` — bóng người / cột / lá cây / khung cửa tối, mờ, trôi nhanh hơn cảnh khi máy chuyển động. Dùng cho cảnh nhìn trộm, qua vai, cô đơn.

### `blur` — nhòe chuyển động
Tự bật ở pha nhanh: chạy, rung máy, `fx: speed`, đổi tư thế rất nhanh (`poseAt` giây chuyển ≤ 0.25, vd đấm), ném, đổ sập. `"blur": false` tắt trong cảnh; `"blur": 5` ép bật (3–8 khung phụ). Cả phim: `config.json` → `"motionBlur": false`.

### `fx` — hiệu ứng
`[{ "kind": ..., "at": giây, "dur": giây, "x", "y", "color" }]`
- `shards`: bóng đen vỡ (cùng giây với `out` của actor voice). Từ bản 1.3.0 tự dùng hiệu ứng tan biến thật `vanish` kiểu `burst` (xem bảng actor). `"style": "classic"` = mảnh tam giác như bản cũ.
- `flash`: chớp trắng. `pulse`: viền đập nhịp màu nhấn (`speed`, `a`). `dark`: tối dần (`a`). `glitch`: nhiễu sọc.
- `speed`: vệt tốc độ (chạy, đấm; `dir` 1 / -1). `zzz`: chữ z bay — không ghi `x`/`y` thì bay từ **đầu người đang ngủ** (1.10; trước bay từ đầu bóng đen). Dùng `fx: zzz` HOẶC `bed.zzz`, không cả hai (có cả hai thì bộ dựng chỉ vẽ 1 lần). `embers`: tàn lửa bay lên. `rain`, `dust`: mưa, bụi. `spot`: đốm sáng (`r`, `color`).

### `lights` — đèn thêm
`[{ "x": 0.7, "y": 0.6, "r": 0.3, "color": "#ffc56b", "a": 0.35 }]`

### `vignette`: số 0..1 (mặc định 0.62; `anim: "smooth"` / classic: 0.5) hoặc `false`.

## `scene` — bối cảnh + nhân vật + bóng đen
```json
{ "tpl": "scene", "args": {
  "set": "bedroom",
  "setArgs": { "clock": "5:00", "ring": true, "calendar": { "month": "OCT", "fill": 12, "mode": "x" }, "lamp": true, "laptop": true, "sky": "moon" },
  "bed": { "face": "sleep", "faceAt": [[1.2, "tired"]], "arm": { "at": 1.5 }, "zzz": true },
  "actors": [
    { "who": "hoodie", "x": "bed.sit", "pose": "sitphone", "hold": "phone", "face": "tired", "glowFace": "#9fb6ff" },
    { "who": "voice", "x": 0.62, "pose": "reach", "facing": -1, "at": 0.5, "out": 4.0 }
  ],
  "cam": { "from": [0.5, 0.55, 1.1], "to": [0.45, 0.55, 1.25] },
  "texts": [ { "kind": "tempt", "t": "one more.", "at": 0.8 } ]
} }
```

### Bối cảnh (`set`) và `setArgs`
| set | setArgs | mốc đặt nhân vật |
|---|---|---|
| `bedroom` | `clock` ("3:17", số LED), `ring`, `blink`, `calendar` {month, fill, mode `x`/`fill`, color} hoặc `true` (từ 1.5.0 chỉ hiện khi ghi), `lamp`, `laptop` (true / "off"), `sky` (`moon` `dawn` `rain` `night` `dark` `day`), `window: false`, `desk: true` (từ 1.5.0 bàn học chỉ hiện khi ghi `desk` / `lamp` / `laptop`), `door`, `doorOpen` (0..1), `bedX` | `bed.sit` (mép giường), `bed.head`, `desk.seat` (ghế bàn), `clock` |
| `city` | `time` (`dusk` `night` `dawn` `day`), `birds`, `lamps` [x...], `scroll` (đường, đèn, nhà trôi; `"sync"` = khớp bước chân người chạy / đi tại chỗ `"run": 1.6`) | — |
| `street` | `neonDoor` (x, cửa cám dỗ phát sáng), `busstop: false`, `busX`, `lampX`, `rain: false` | `bus.seat`, `neon` |
| `lockers` | `board: false`, `boardX` | — |
| `classroom` | `sky`, `board` (chữ trên bảng), `desks` [x...] | — |
| `court` | `hoopX`, `benchX` | `bench` |
| `cafe` | `lampX` | `table.left`, `table.right` |
| `gym` | `bag: false`, `bagX`, `swing`, `hits` [giây trúng đòn] (tự lấy từ `poseAt` `punch`: bao cát lõm vào, văng ra rồi dừng dần, chớp sáng + tia ngay chỗ nắm đấm), `barbell`, `barbellX`, `spot` | — |
| `stairs` | `top: false`, `topColor` (bậc bo tròn mềm) | `step:0` … `step:8` |
| `hill` | — | `top` (đỉnh đồi) |
| `mirror` | `mirrorX`, `crack: true` hoặc `crackAt` (giây: gương nứt lan từ tâm). Gương oval trên bệ | `mirror`, `mirror.in` (đứng TRONG gương: actor thêm `"behind": true, "inMirror": true`) |
| `sofa` | `sofaX`, `sofaW`, `sofaColor`, `window: true`, `windowX`, `lamp: true` (đèn cây), `lampX` | `sofa.seat`, `sofa.left`, `sofa.right` (dùng `pose: sit` / `sitphone`) |
| `kitchen` | `sky`, `lamp` | — |
| `doorway` | `doorX`, `doorOpen` | `door` |
| `void` | `spot` (x đèn rọi) | — |
| `black` | — | — |
Chung: `gy` (mặt sàn 0..1), `dim` (0..1 làm tối).

### `bed` — nhân vật nằm trong chăn
`{ "who": "hero", "face": "sleep", "faceAt": [[giây, mặt]], "faceDur", "blink", "look", "rot", "arm": true | { "at", "dur" } (với tay về đồng hồ), "zzz": true, "side": true, "rollAt": [[giây, "side" | "back"]], "at", "out", "up": { "at", "dur": 1.6, "face", "pose": "sit", "h": 0.42 } }`. Chỉ dùng với `set: bedroom`. Biểu cảm chuyển dần như actor (vd `sleep` → `tired`: mắt hé dần).
- Chăn ôm theo thân người bên dưới và phồng nhẹ theo nhịp thở. `side` / `rollAt`: nằm nghiêng co gối ↔ nằm ngửa (trở mình). `at` / `out`: người có / rời khỏi giường (chăn xẹp xuống).
- Đầu người nằm mặc định cùng cỡ đầu nhân vật đứng (`r` để đổi), nên lúc ngồi dậy không lớn dần.
- `up`: **ngồi dậy** — thân nhổm lên trên nệm, chăn tuột về phía chân, rồi trượt ra mép giường ngồi (khớp tư thế actor `x: "bed.sit"`). Cảnh sau nối bằng actor `bed.sit` + `act: standUp`.

### Ví dụ chuyển động
```json
{ "who": "hoodie", "x": 0.3, "pose": "stand", "poseAt": [[1.2, "headhold"], [3.0, "knees", 0.9]], "face": "worried", "faceAt": [[1.2, "cry"]] }
{ "who": "hero", "x": 0.6, "facing": 1, "facingAt": [[1.0, -1]], "walk": { "to": 0.1, "at": 1.4, "dur": 3 } }
{ "who": "band", "x": 0.15, "run": { "to": 0.85, "at": 0.3, "dur": 3, "speed": 1.6 } }
```
Dòng 2 = quay lưng bỏ đi: quay người ở giây 1, giây 1,4 lấy đà rồi bước, chậm dần và dừng hai chân khép ở 0.1.

### `actors` — nhân vật
| khoá | ý nghĩa |
|---|---|
| `who` | `hero` (trần), `band` (băng đô màu nhấn), `hoodie` (hoodie xám, mũ hạ sau cổ, đầu tròn trơn — mặc định), `hooded` (trùm mũ lên đầu, chỉ khi cảnh cần), `friend` `friend2` `friend3` (mũ vàng / xanh / đỏ), `girl` (tóc bob, khăn vàng), `mom`, `dad`, `kid`, `ghost` (mờ), `voice` (bóng đen cám dỗ) |
| `x`, `y` | vị trí chân (số hoặc mốc bối cảnh) |
| `h` | chiều cao (mặc định 0.42; voice 0.48) |
| `pose`, `poseAt` | tư thế; `poseAt: [[1.5, "cheer"]]` đổi theo giây. Tự chuyển dần 0,3–0,75 giây (lấy đà nhẹ → vượt qua → dội về, đầu theo trễ nhịp). Số thứ 3 = giây chuyển: `[[1.5, "knees", 0.9]]` |
| `poseDur` | giây chuyển tư thế cho mọi mốc của actor. `0` = đổi ngay trong 1 khung (như bản cũ) |
| `face`, `faceAt` | biểu cảm (voice mặc định `grin`). Đổi biểu cảm thì mí, mày, miệng chuyển dần ~0,3 giây và nhân vật chớp mắt đúng lúc đổi. `[[2, "cry", 0.6]]` = chuyển chậm 0,6 giây |
| `faceDur` | giây chuyển biểu cảm; `0` = đổi ngay |
| `facing` | 1 nhìn phải, -1 nhìn trái. `look` -1..1 lệch mắt, `lookAt` |
| `facingAt`, `turnDur` | quay người theo giây: `"facingAt": [[2.0, -1]]` — mặt trượt qua chính diện, nhún nhẹ, mất `turnDur` giây (mặc định 0.3; `0` = lật ngay) |
| `walk` / `run` | `{ "to": 0.8, "at": 0, "dur": 4, "speed": 0.9 }`. Chân trụ bám đất (nhịp bước theo quãng đường), tăng tốc lúc đầu, giảm tốc lúc cuối, dừng lại hai chân khép. Có `facing` ngược hướng đi thì tự quay người trước khi bước. `speed` = số nhịp bước / giây mong muốn (bước tự chỉnh dài ngắn cho vừa). `ramp`: giây tăng / giảm tốc (mặc định 0.35, chạy 0.45). `"ease": false` = đều từ đầu đến cuối. `"back": true` = đi lùi (mặt giữ nguyên hướng). `"run": 1.6` (số) = chạy tại chỗ, dùng với `city` + `scroll` |
| `act` | **động tác kể chuyện** dựng sẵn, mỗi động tác 1 dòng (xem bảng dưới) |
| `vanish` | (bóng đen `voice`) **tan biến**: `{ "at": 4.2, "style": "burst" \| "ash", "from": "hero" \| [x, y], "pieces": 44, "flash": true, "words": true, "dur": 1.8, "wind": 1 }`. Xem mục dưới |
| `walk` / `run` (danh sách) | nhiều quãng liên tiếp: `"walk": [{ "to": 0.5, "at": 0.5, "dur": 2 }, { "to": 0.2, "at": 3.5, "dur": 2 }]` — quãng sau đi tiếp từ chỗ quãng trước dừng, tự quay người khi đổi hướng |
| `blink` | `false` = không tự chớp mắt (mặc định chớp ngẫu nhiên 2–6 giây/lần, thỉnh thoảng chớp đôi) |
| `idle` | `false` = tắt chuyển động phụ khi đứng yên (thở không đều, dồn trọng tâm rất nhẹ) |
| `hold` | `phone` (màn hình phát sáng; `screen` màu), `umbrella`, `book`, `ball`, `bag`, `cup` |
| `glowFace` | màu ánh sáng hắt lên mặt (điện thoại `#9fb6ff`, cảm dỗ = màu nhấn) |
| `at`, `out`, `fade` | hiện ở giây, biến mất ở giây (mờ dần trong `fade`) |
| `behind` | vẽ sau giường / nhân vật khác |
| `keepX` | bóng đen giữ đúng chỗ ghi. Mặc định bóng đen che quá 30% thân người hùng sẽ tự đứng sang cạnh, quay mặt về phía người |
| `aim` (1.10, bóng đen) | tay `reach` / `point` tự nhắm vào vai người hùng (hoặc vai người nằm giường), khuỷu tay chùng tự nhiên, không chọc vào mặt. `false` = tay thẳng ngang như cũ |
| `smoke` (1.10, bóng đen) | khói mỏng bay lên từ viền. Mặc định tắt (trông như bong bóng); `true` để bật, cả phim: `"voiceSmoke": true` |
| `age` (1.10) | `"old"`: hơi khom, đầu cúi, lông mày bạc, nếp nhăn trán, vệt tóc bạc. `phim.py` tự gán khi bộ đếm AGE ≥ 55 hoặc CẢNH có "già / tóc bạc". Dùng cả trong `bed` và mẫu `face` |
| `count` | số đếm bật trên đầu mỗi cú đấm / nâng tạ (tự bật khi có ≥ 3 lần; `false` tắt, `true` ép) |
| `speedLines` | `false` = tắt vệt tốc độ sau lưng khi chạy |
| `scale`, `rot`, `z`, `seed` | phóng, nghiêng, thứ tự vẽ, lệch nhịp thở / chớp mắt (mặc định mỗi actor đã lệch nhau theo vị trí) |
| `tears`, `sweat`, `shoes`, `bloodshot` | nước mắt, mồ hôi, màu giày, mắt đỏ gân máu |

**Tư thế (`pose`):** `stand relaxed slump phone reach point wave cheer fist headhold facepalm arms shrug hug guard punch lift sit sitphone sitdesk sitsad knees kneel crouch climb open umbrella carry pant throw release sitfwd lie`.

**Động tác (`act`):** `"act": [{ "do": "collapse", "at": 1.0 }, { "do": "fall", "at": 3.0 }]`
| `do` | làm gì | thêm |
|---|---|---|
| `standUp` | đang ngồi: chồm người ra trước rồi đứng dậy | `dur`, `pose` (tư thế cuối) |
| `sitDown` | ngồi xuống | `dur`, `pose` |
| `collapse` | gục người → ôm đầu → quỵ gối (~1,5 giây) | `dur` |
| `fall` | đổ sập xuống sàn về phía trước, nảy nhẹ, nằm yên (có nhòe) | `dur` (0.45) |
| `throwPhone` | đang cầm điện thoại: hạ tay, vung ra sau, ném — điện thoại bay vòng cung, xoay, rơi xuống sàn, màn hình tắt dần | `to: [x, y]` (chỗ rơi), `fly` (giây bay, 0.6) |
| `walkAway` | quay lưng rồi bỏ đi ra khỏi khung | `dir` (mặc định quay ngược hướng đang nhìn), `dur` (2.6), `to`, `run: true` |
| `pant` | chống tay lên gối thở dốc, rồi đứng thẳng | `dur` (2) |
**Bóng đen tan biến (`vanish` trên actor `voice`):**
- `burst` (mặc định, khoảnh khắc quyết định — người hùng đấm / đứng dậy / quát): 0,35 giây trước mốc vết nứt sáng lan ra từ điểm bị đánh, bóng phồng nhẹ, chữ cám dỗ rung mạnh → đúng mốc: chớp trắng có tâm, tia sáng, vòng sóng, máy rung → chính hình bóng đen vỡ thành mảnh méo, bay ra có lực cản, xoay, hơi bay lên, mép cháy nguội dần, tan thành tàn lửa → **chữ cám dỗ vỡ từng chữ cái** trôi đi → khói mỏng, tàn lửa còn 2–3 giây. Tự nhòe chuyển động.
- `ash` (khoảnh khắc lặng, buông bỏ): rã dần từ chân lên thành tro trong `dur` giây, mép đang rã cháy sáng mềm, tro bay theo gió (`wind` 1 / -1, mặc định thổi ra xa người hùng); chữ cám dỗ trôi theo gió và tàn.
- `from`: điểm bị đánh. `"hero"` (mặc định) = phía người hùng, ngang ngực. `words: false` = giữ chữ như thường. `flash: false` = không chớp.
- Chỉ cần `fx: shards` như kịch bản cũ là ra kiểu `burst`; ghi `vanish` khi muốn chọn kiểu / điểm bị đánh.
- SFX: `vanish_burst` (đặt **đúng giây vỡ**, tiếng nứt tự vào trước 0,35 giây) hoặc `vanish_ash`.
```json
{ "who": "voice", "x": 0.62, "pose": "reach", "facing": -1, "vanish": { "at": 2.0 } }
{ "who": "voice", "x": 0.6, "pose": "stand", "facing": -1, "vanish": { "at": 1.8, "style": "ash", "dur": 2.0 } }
```

Gõ thêm `SFX` cho khớp: `footsteps` (walkAway), `thud_soft` / `impact_heavy` (fall), `whoosh_mid` + `glass_shatter` / `thud_soft` (throwPhone), `breath_in` (pant).
**Biểu cảm (`face`):** `neutral tired sleepy sleep sad cry worried scared shock angry determined effort smile happy smirk empty guilty bloodshot haunted grin`.
Thêm từ 1.5.0 (dạng `classic` không có, ra `neutral`): `hopeful` (mắt sáng nhìn lên) `relieved` (nhẹ nhõm) `proud` (tự hào, ngẩng) `embarrassed` (đỏ má, nhìn xuống) `disgusted` (ghê) `annoyed` (bực, mày giật) `skeptical` (nhướng 1 mày) `exhausted` (kiệt sức, lè lưỡi thở) `yawn` (ngáp) `dazed` (thẫn thờ) `panic` (hoảng, mắt trắng tròn, há miệng, liếc) `sob` (khóc nấc, nước mắt chảy dòng) `shout` (hét) `thinking` (nhìn lên, mím) `tempted` (mắt dại có ánh màn hình) `grit` (nghiến răng) `lonely` (cô đơn).
Cử động nhỏ tự có theo biểu cảm: liếc mắt (`worried scared panic`), chớp chậm (`tired sleepy relieved…`), môi run (`sad cry scared sob`), lông mày giật (`angry annoyed`), đầu nghiêng theo cảm xúc, mắt mở to trước nửa nhịp khi giật mình, dấu "!" (`shock panic`). `bloodshot` / `haunted` = lòng trắng hồng, gân đỏ, quầng thâm (thức đêm, nghiện, kiệt sức). Thêm `"bloodshot": true` vào actor (hoặc mẫu `face`) để giữ mắt đỏ với bất kỳ biểu cảm nào.

## `phone` — điện thoại cận cảnh, 2 tay cầm
Chung: `bg` (bối cảnh mờ phía sau, vd `"bedroom"`), `setArgs`, `grade`, `hands` (1.10 mặc định: tay tự nhiên — 4 ngón ngắn tròn màu kem ôm mép trái, ngón cái phải tự lướt ở feed / video; `"classic"` = tay 1.3.0 ngón xám viền đen (trông như công tắc gạt); `"left"` = 1 tay; `false` = ẩn), `thumb` (ngón cái lướt: chạm → kéo lên → nhấc, khớp nhịp feed; feed / reel tự bật), `tilt`, `clock` (giờ thanh trạng thái), `sleeve` (màu tay áo), `h`, `x`, `y`.
| `screen` | args riêng |
|---|---|
| `feed` | `posts`: danh sách ảnh bài đăng minh hoạ, mỗi lần 1 bài, giữ `hold` giây (1.1; lướt nhanh 0.5–0.7) rồi vuốt lên. Ảnh có sẵn: `ramen car burger pizza sneakers dog cat beach mountain sunset gym watch money game coffee city party selfie girl donut cake` (`girl` = bóng neon kín đáo, `neon` đổi màu). `style: "blocks"` = kiểu khối màu mờ cũ |
| `reel` | `art` (1 ảnh minh hoạ như feed, đặt giữa màn), `from` (giây đang xem), `total` (tổng giây), `speed`, `color` |
| `chat` | `name`, `avatar` (màu), `messages: [{ "text", "me": true/false, "at" }]` (trước tin đến có dấu "đang gõ"), `seen` (giây hiện "Seen"), `keyboard`, `draft` + `draftAt` (gõ dở trong ô nhập) |
| `email` | `rows: [{ "from", "subject", "preview", "hl": true }]` hoặc `from`, `subject`, `preview` |
| `lock` | `time`, `date`, `notes: [{ "app", "text", "at" }]` |
| `counter` | `n`, `label` ("CLEAN STREAK"), `color` |
| `off` | `reflect` (bóng mặt mờ trên màn tắt) |

## `clock` — đồng hồ báo thức to
`{ "time": "11:59", "timeAt": [[1.6, "12:00"]], "ring": true, "blink": true, "color": "#ff3b30", "s": 0.55 }`

## `calendar` — lịch to
`{ "month": "NOV", "from": 0, "to": 24, "mode": "x" | "fill", "at": 0.3, "dur": 3, "reset": { "at": 3.5 }, "color" }`

## `face` — cận mặt (từ ngực lên)
`{ "who": "hoodie", "face": "guilty", "faceAt": [[2, "cry"]], "age": "old", "grade", "bloodshot": true, "look": -0.3, "lookAt", "pose", "poseAt", "facing", "facingAt", "hold", "tears", "sweat", "blink", "idle", "glowFace": "#9fb6ff", "bg": "bedroom", "setArgs", "actors": [voice...], "lights" }` — `poseAt` / `faceAt` / `facingAt` chuyển dần như actor (`poseDur`, `faceDur`, `turnDur`).

## `note` — sổ tay, tay viết chữ
`{ "text": "day 1.\nno phone before noon.", "at": 0.3, "cps": 9, "sleeve" }`

## `black` — nền đen + chữ
`{ "texts": [...], "dust": true, "cy": 0.47, "push": 0.08, "bigSize": 92, "line": false }` — chữ to **giữa màn** (kiểu kênh mẫu): dòng `narr` cỡ 78, dòng `big` cỡ 92 trắng đậm sạch; các dòng không ghi `y` tự xếp dọc quanh `cy`. 1.10: bụi trôi bật sẵn, **đẩy máy đều 8% suốt màn**, chữ hiện dần 0,8 giây (`push`, `false` = đứng im — đừng tắt), **không vạch màu nhấn** (`"line": true` để bật lại), vignette nhẹ 0.35. Giữ 2–5 giây, 3–4 màn mỗi phim. Bộ đếm chỉ hiện nếu ghi `hud`.

## `graph` — đồ thị cảm xúc (1.10, kiểu DOPAMINE)
`{ "kind": "crash" | "spikes" | "climb" | "flat", "pts": [[x, y], ...], "color", "ylabel": "how good you feel", "xlabel": "time", "baseline": true | 0.5 | false, "baseLabel": "baseline", "markers": "phone" | false, "label": { "t": "hard things", "at": 0.12 }, "at": 0.6, "dur": 3.4, "texts": [...] }` — nền đen, trục mảnh, đường vẽ dần có đầu chấm trắng phát sáng (`crash` / `spikes`: màu nhấn, điện thoại nhỏ bật lên ở mỗi đỉnh vượt đường nền; `climb`: vàng ấm, đi lên chậm). Chữ kể chuyện ở trên như cảnh thường. Đẩy máy chậm sẵn. Cần ≥ 4 giây. `phim.py`: CẢNH / NỀN có "đồ thị" / "biểu đồ" (+ "sụp đổ" | "nhiều đỉnh" | "đi lên chậm" | "phẳng", `nhãn "..."`).

## `card` — thẻ kết
`{ "word": "TOMORROW.", "part": "PART 2", "sub": "Tomorrow is a place.", "sub2": "Nobody lives there.", "sub2At": 3.0, "type": true, "typeDur": 1.2, "size", "push": 0.06 }` — từ khoá gõ từng chữ, gạch chân màu nhấn, `sub` trắng, `sub2` màu nhấn. 1.10: đẩy chậm đều (`push: false` = đứng im).

## `cta` — xin like / subscribe
`{ "line": "If this hit, like and subscribe.", "line2": "Day 1 starts tonight.", "who": "hoodie" }` — nút LIKE, SUBSCRIBE có con trỏ bấm, nhân vật vẫy tay (1.10: nhân vật to hơn, bụi trôi, đẩy chậm). Đối thủ **không có** màn này; nếu dùng thì ≤ 4 giây.

## Thumbnail (`scenes/shots/thumb.js`)
`thumb({ img: 'T01', title | lines, accent: [từ], strike: 'số', y: 0.16, size, arc, rot, align: 'left', x, focus: [x, y], crop })` — font tròn cực đậm, trắng, viền đen dày, bóng đổ; từ trong `accent` đổi màu nhấn; `strike` gạch xoá một từ.
