"""audio.py (pack dem) — nhac nen va SFX rieng cho phim ngan khong loi doc. Chay boi audio/build_audio.py (tu tim packs/*/audio.py).
Nhac (ten dung trong shots.json "music": bed):
  sad      piano cham + pad tram (mo dau, sa nga)
  dark     drone thap + nhip tim + chuong xa (day, cam do thang)
  rise     piano rai not + nhip + trong nhe, manh dan (dung len, tap luyen)
  resolve  hop am truong am, piano (ket, the cuoi)
  hope     pad sang + chuong nhe (khoanh khac that, buoc ngoat)
SFX: alarm_beep, alarm_long, glass_shatter, rain_loop, notif_msg, msg_sent, punch_bag, boom_deep, tempt_swell, tempt_whisper,
     clock_tick, footsteps, door_open, breath_in, sting_low, page_flip
"""
import glob, json, os, sys
import numpy as np, soundfile as sf
AUDIO = os.path.join(os.path.dirname(os.path.dirname(os.path.dirname(os.path.abspath(__file__)))), 'audio')
CWD0 = os.getcwd(); sys.path.insert(0, AUDIO); os.chdir(AUDIO)
from synth import SR, t, norm, lp, hp, bp, reverb, save, ding, impact, whoosh, heartbeat, riser, rng
from music import render, piano, pad, sub, place, chord_freqs, pluck, kick, hat, CHORDS

CHORDS.update({'Cm': ('C', [0, 3, 7]), 'Ab': ('G#', [0, 4, 7]), 'Eb': ('D#', [0, 4, 7]), 'Bbs': ('A#', [0, 4, 7]), 'Am9': ('A', [0, 3, 7, 10, 14]), 'Fadd9': ('F', [0, 4, 7, 14])})

def mixp(a, b):
    n = max(len(a), len(b)); return np.pad(a, (0, n - len(a))) + np.pad(b, (0, n - len(b)))

def drone_bed(name, root_hz, d=72.0, beat_bpm=None, bells=True):
    n = int(d * SR); tt = np.arange(n) / SR; x = np.zeros(n)
    for k, a in ((1, 1.0), (1.5, 0.35), (2, 0.5), (3, 0.18)):
        f = root_hz * k; ph = rng.uniform(0, 6)
        x += a * (2 * ((f * (1 + 0.002 * np.sin(2 * np.pi * 0.07 * tt)) * tt + ph) % 1) - 1)
    x = hp(lp(x, 900, 2), 70) * (0.75 + 0.25 * np.sin(2 * np.pi * 0.05 * tt))
    buf = np.stack([x, np.roll(x, 900)], 1) * 0.25
    if beat_bpm:
        hb = heartbeat(beat_bpm, int(d * beat_bpm / 60) - 1)
        L = min(len(hb), n); hb = hp(hb, 45); buf[:L] += np.stack([hb[:L], hb[:L]], 1) * 0.35
    if bells:
        for s in np.arange(4, d - 4, 6.0): place(buf, ding(root_hz * 8 * rng.choice([1, 1.2, 1.5]), 4.0, 0.3), s, 0.12, p=rng.uniform(-0.6, 0.6))
    buf = reverb(buf, 3.5, 0.4, 3000)[:n]
    f = int(2 * SR); buf[:f] *= np.linspace(0, 1, f)[:, None]; buf[-f:] *= np.linspace(1, 0, f)[:, None]
    buf = norm(buf, 0.7); p = os.path.join(AUDIO, 'music', name + '.wav'); sf.write(p, buf.astype(np.float32), SR, subtype='PCM_24'); print(p)

def sad_piano(name, prog, bpm, loops, notes_per_bar=4, oct_=4, drone=True):
    beat = 60 / bpm; bar = beat * 4; total = len(prog) * loops * bar
    buf = np.zeros((int((total + 5) * SR), 2))
    for i, ch in enumerate(prog * loops):
        t0 = i * bar; fr = chord_freqs(ch, 3)
        place(buf, hp(pad(fr, bar + 1.5, 1400), 160), t0, 0.16)
        mel = [fr[0] * 2, fr[2] * 2, fr[1] * 4, fr[2] * 2]
        for k in range(notes_per_bar): place(buf, piano(mel[k % 4] * 2, 3.5, 0.55 if k else 0.7), t0 + k * bar / notes_per_bar, 0.42, p=-0.25 + 0.16 * k)
        place(buf, piano(fr[0], 4.0, 0.5), t0, 0.22)
    buf = reverb(buf, 3.8, 0.42, 4200)[:int((total + 3) * SR)]
    f = int(1.0 * SR); buf[:f] *= np.linspace(0, 1, f)[:, None]; g = int(3 * SR); buf[-g:] *= np.linspace(1, 0, g)[:, None]
    buf = norm(buf, 0.7); p = os.path.join(AUDIO, 'music', name + '.wav'); sf.write(p, buf.astype(np.float32), SR, subtype='PCM_24'); print(p)

def build_music():
    sad_piano('bed_sad_Am_64bpm', ['Am', 'F', 'C', 'G'], 64, 5)
    drone_bed('bed_dark_E_drone', 41.2, 72, beat_bpm=62)
    render('bed_rise_Am_96bpm', ['Am', 'F', 'C', 'G'], 96, 1, 8, ('pad', 'sub', 'arp', 'piano', 'drums'), pad_cut=1800, rev=(2.6, 0.32, 5000))
    sad_piano('bed_resolve_C_70bpm', ['C', 'G', 'Am', 'F'], 70, 4, notes_per_bar=3)
    render('bed_hope_F_76bpm', ['Fadd9', 'C', 'Am9', 'G'], 76, 1, 5, ('pad', 'bell', 'sub'), pad_cut=2400, rev=(4.0, 0.45, 6000))

# ---------------- SFX
def alarm(beeps=4, f=2900):
    one = np.sin(2 * np.pi * f * t(0.11)) * 0.5; one = np.sign(one) * 0.3 + one * 0.5; out = np.zeros(int(SR * (beeps * 0.5 + 0.2)))
    for b in range(beeps):
        for k in range(2): s = int((b * 0.5 + k * 0.15) * SR); out[s:s + len(one)] += one
    return bp(out, 800, 7000)
def shatter(d=1.6):
    n = int(d * SR); tt = t(d); x = hp(rng.standard_normal(n), 2500) * np.exp(-tt * 5)
    for _ in range(40): s = int(rng.uniform(0, 0.9) * SR); L = int(0.05 * SR); x[s:s + L] += np.sin(2 * np.pi * rng.uniform(2500, 7000) * t(0.05)) * np.exp(-t(0.05) * 60)[:len(x[s:s + L])] * 0.6
    return mixp(x, lp(impact(0.6, 140, 50, 0.7, 0.5), 900) * 0.6)
def rain_loop(d=8.0):
    n = int(d * SR); x = bp(rng.standard_normal(n), 400, 9000) * 0.3
    for _ in range(int(d * 60)): s = int(rng.uniform(0, d - 0.05) * SR); L = int(0.01 * SR); x[s:s + L] += hp(rng.standard_normal(L), 3000) * rng.uniform(0.1, 0.5)
    f = int(0.3 * SR); x[:f] *= np.linspace(0, 1, f); x[-f:] *= np.linspace(1, 0, f); return np.stack([x, np.roll(x, 3000)], 1)
def notif():
    a = np.sin(2 * np.pi * 1320 * t(0.09)) * np.exp(-t(0.09) * 30); b = np.sin(2 * np.pi * 1760 * t(0.16)) * np.exp(-t(0.16) * 22)
    out = np.zeros(int(0.3 * SR)); out[:len(a)] += a; s = int(0.08 * SR); out[s:s + len(b)] += b; return out
def sent():
    tt = t(0.25); f = 600 + 1800 * tt / 0.25; return np.sin(2 * np.pi * np.cumsum(f) / SR) * np.exp(-tt * 12) * 0.6 + hp(rng.standard_normal(len(tt)), 3000) * np.exp(-tt * 25) * 0.15
def boom(): return lp(impact(3.0, 70, 28, 1.0, 0.2), 300)
def swell(d=2.2):
    tt = t(d); n = len(tt); x = bp(rng.standard_normal(n), 200, 1800) * (tt / d) ** 2.5
    tone = np.sin(2 * np.pi * 55 * tt) * 0.5 + np.sin(2 * np.pi * 58.3 * tt) * 0.4
    return (x + tone * (tt / d) ** 2) * np.minimum(1, (d - tt) / 0.05)
def whisper(d=1.3):
    tt = t(d); n = len(tt); env = np.abs(np.sin(np.pi * tt / d)) ** 1.5 * (0.6 + 0.4 * np.sin(2 * np.pi * 7 * tt))
    return bp(rng.standard_normal(n), 1800, 6500) * env * 0.6
def clock_tick(d=4.0):
    out = np.zeros(int(d * SR))
    for k in range(int(d)): s = int(k * SR); c = hp(rng.standard_normal(int(0.02 * SR)), 2500) * np.exp(-t(0.02) * 300) * (1 if k % 2 else 0.7); out[s:s + len(c)] += c
    return out
def footsteps(n=6, gap=0.48):
    out = np.zeros(int((n * gap + 0.3) * SR))
    for k in range(n): s = int(k * gap * SR); st = lp(impact(0.18, 160, 80, 0.4, 0.4), 1800) * rng.uniform(0.7, 1); out[s:s + len(st)] += st[:len(out) - s]
    return out
def door():
    tt = t(1.1); f = 300 + 200 * np.sin(2 * np.pi * 1.3 * tt); x = bp(np.sign(np.sin(2 * np.pi * np.cumsum(f) / SR)) * 0.3, 400, 3000) * np.exp(-tt * 2)
    return mixp(x, lp(impact(0.4, 90, 50, 0.5, 0.2), 500) * 0.5)
def breath(): tt = t(0.9); return bp(rng.standard_normal(len(tt)), 500, 3000) * np.sin(np.pi * tt / 0.9) ** 2 * 0.5
def sting():
    tt = t(3.0); x = sum(np.sin(2 * np.pi * f * tt) for f in (55, 58.27, 82.4)) * np.exp(-tt * 0.9)
    return mixp(lp(x, 600), lp(impact(1.2, 80, 35, 1.0, 0.3), 400) * 0.6)
def page():
    tt = t(0.4); return bp(rng.standard_normal(len(tt)), 1500, 8000) * np.exp(-((tt - 0.15) / 0.07) ** 2) * 0.6

# bong den tan bien (vanish): burst = nut lach tach 0,35 s -> no tram + vo vun + duoi hut nguoc + gio; ash = lach tach nho + gio thoi nhe
def crackle(d, rate, lo=2500):
    out = np.zeros(int(d * SR))
    for _ in range(int(d * rate)): s = int(rng.uniform(0, d - 0.02) * SR); L = int(0.004 * SR); out[s:s + L] += hp(rng.standard_normal(L), lo) * np.exp(-t(0.004) * 900) * rng.uniform(0.2, 1)
    return out
def mono(a): return a.mean(1) if a.ndim > 1 else a
def vanish_burst():
    pre = 0.35; n = int(3.2 * SR); x = np.zeros(n)
    c = crackle(pre, 90); x[:len(c)] += c * np.linspace(0.2, 1, len(c)) ** 2
    s = int(pre * SR); b = mono(lp(impact(1.6, 80, 30, 1.0, 0.5), 600)); x[s:s + len(b)] += b[:n - s] * 0.9
    sh = mono(shatter(1.4)) * 0.45; x[s:s + len(sh)] += sh[:n - s]
    w = bp(rng.standard_normal(n - s), 300, 4000) * np.exp(-np.arange(n - s) / SR * 1.6) * 0.25; x[s:] += w
    r = mono(riser(1.2, 1600, 200))[::-1] * 0.25; e = s + int(0.15 * SR); x[e:e + len(r)] += r[:n - e]
    tail = crackle(2.6, 25, 3500) * 0.35; x[s:s + len(tail)] += tail[:n - s] * np.linspace(1, 0, len(tail))
    return x
def vanish_ash():
    d = 3.0; n = int(d * SR); tt = t(d); env = np.sin(np.pi * np.minimum(1, tt / d)) ** 1.2
    wind = bp(rng.standard_normal(n), 400, 2200) * env * 0.35 * (0.8 + 0.2 * np.sin(2 * np.pi * 0.7 * tt))
    return wind + crackle(d, 35, 3000) * env * 0.5

def build_sfx():
    D = 'sfx'; P = []
    P.append(save(f'{D}/alarm_beep', alarm(4), 0.7)); P.append(save(f'{D}/alarm_long', alarm(10), 0.7))
    P.append(save(f'{D}/glass_shatter', shatter(), 0.85, rev=(1.4, 0.2, 7000)))
    P.append(save(f'{D}/rain_loop', rain_loop(), 0.5))
    P.append(save(f'{D}/notif_msg', notif(), 0.6)); P.append(save(f'{D}/msg_sent', sent(), 0.55))
    P.append(save(f'{D}/punch_bag', lp(impact(0.45, 110, 55, 0.9, 0.3), 1200), 0.9))
    P.append(save(f'{D}/boom_deep', boom(), 0.95, rev=(2.5, 0.3, 1500)))
    P.append(save(f'{D}/tempt_swell', swell(), 0.8, rev=(2.0, 0.35, 3000)))
    P.append(save(f'{D}/tempt_whisper', whisper(), 0.55, rev=(1.6, 0.4, 6000)))
    P.append(save(f'{D}/clock_tick', clock_tick(), 0.5)); P.append(save(f'{D}/footsteps', footsteps(), 0.7))
    P.append(save(f'{D}/door_open', door(), 0.6, rev=(1.0, 0.2, 4000))); P.append(save(f'{D}/breath_in', breath(), 0.5))
    P.append(save(f'{D}/sting_low', sting(), 0.9, rev=(3.0, 0.35, 2000))); P.append(save(f'{D}/page_flip', page(), 0.5))
    return P

# ---------------- nhac rieng tung du an: cung khong khi (sad / dark / rise / resolve / hope) nhung khac giong, vong hop am,
# giai dieu, nhip, nhac cu theo ten phim. tools/mix.py goi:  python packs/dem/audio.py --project <du an> --beds sad,dark [--seed N]
# -> <du an>/build/music/bed_<ten>_..bpm.wav + .json (bpm, lap lien). Da co dung seed thi bo qua (tao 1 lan).
POOLS = {
    'sad':     [['Am', 'F', 'C', 'G'], ['Am', 'Em', 'F', 'C'], ['Am', 'F', 'Dm', 'E'], ['Dm', 'Am', 'Bb', 'F'], ['Am', 'C', 'F', 'Em']],
    'resolve': [['C', 'G', 'Am', 'F'], ['F', 'C', 'G', 'C'], ['C', 'Am', 'F', 'G'], ['Fmaj7', 'C', 'Dm', 'G']],
    'hope':    [['Fadd9', 'C', 'Am9', 'G'], ['F', 'Am', 'C', 'G'], ['Fadd9', 'G', 'Am9', 'C'], ['Cadd9', 'G', 'Am7', 'Fmaj7']],
    'rise':    [['Am', 'F', 'C', 'G'], ['Am', 'C', 'G', 'F'], ['F', 'G', 'Am', 'Am'], ['Am', 'F', 'G', 'E']],
}
MEL = [[0, 2, 1, 2], [0, 1, 2, 1], [2, 1, 0, 1], [0, 2, 3, 2], [1, 2, 0, 2], [2, 0, 1, 3]]   # thu tu not giai dieu trong hop am

def loop_write(out_dir, name, buf, total, meta):
    n = int(total * SR); out = buf[:n].copy(); tail = buf[n:]; L = min(len(tail), n); out[:L] += tail[:L]   # duoi vang quan ve dau -> lap lien
    # san deu do to theo o nhip (nhu nhac doi thu, +-3 dB): o qua nho duoc nang toi da +5 dB, o qua to ha toi da -3 dB, doi gain tu tu
    h = int(0.25 * SR); m = len(out) // h; e = np.sqrt(np.mean(out[:m * h].reshape(m, h, -1) ** 2, axis=(1, 2)) + 1e-12)
    w = 8; ee = np.convolve(np.concatenate([e[-w:], e, e[:w]]), np.ones(2 * w + 1) / (2 * w + 1), 'same')[w:-w]
    gdb = np.clip(20 * np.log10(np.median(ee) / ee) * 0.8, -3, 5); gdb = np.convolve(np.concatenate([gdb[-w:], gdb, gdb[:w]]), np.ones(2 * w + 1) / (2 * w + 1), 'same')[w:-w]
    gain = np.interp(np.arange(len(out)), np.arange(m) * h + h / 2, 10 ** (gdb / 20), period=len(out)); out *= gain[:, None]
    out = norm(out, 0.7); p = os.path.join(out_dir, name + '.wav'); sf.write(p, out.astype(np.float32), SR, subtype='PCM_24')
    json.dump(meta, open(p[:-4] + '.json', 'w')); print(p)

def keyed(R, tr, bpm, prog, mel, loops, kind):
    # sad / resolve: piano tung not + pad; hope: pad + chuong; rise: pad + sub + rai not + piano + trong
    beat = 60 / bpm; bar = beat * 4; total = len(prog) * loops * bar; buf = np.zeros((int((total + 5) * SR), 2))
    npb = int(R.choice([3, 4])) if kind in ('sad', 'resolve') else 4; oct_hi = float(R.choice([2, 2, 1])) if kind == 'sad' else 2.0
    for i, ch in enumerate(prog * loops):
        t0 = i * bar; fr = [f * tr for f in chord_freqs(ch, 3)]; nt = [fr[0] * 2, fr[2 % len(fr)] * 2, fr[1] * 4, fr[min(3, len(fr) - 1)] * 2]
        if kind in ('sad', 'resolve'):
            place(buf, hp(pad(fr, bar + 1.5, 1400 if kind == 'sad' else 1800), 160), t0, 0.26)   # dem day hon: giua cac not piano khong bi hut
            for k in range(npb): place(buf, piano(nt[mel[k % 4]] * oct_hi, 3.5, 0.55 if k else 0.7), t0 + k * bar / npb, 0.42, p=-0.25 + 0.16 * k)
            place(buf, piano(fr[0], 4.0, 0.5), t0, 0.22)
        elif kind == 'hope':
            place(buf, pad(fr, bar + 1.0, 2400), t0, 0.55); place(buf, sub(fr[0] / 2, bar), t0, 0.18)
            if i % 2 == 0: place(buf, ding(nt[mel[i % 4]] * 2, 3.0, 0.4), t0, 0.08, p=0.5)
            if R.random() < 0.5: place(buf, ding(nt[mel[(i + 1) % 4]] * 2, 2.5, 0.3), t0 + bar / 2, 0.05, p=-0.4)
        else:  # rise
            place(buf, pad(fr, bar + 1.0, 1800), t0, 0.55); place(buf, sub(fr[0] / 2, bar), t0, 0.18); step = beat / 2
            for k in range(8): place(buf, pluck(nt[mel[k % 4]], 1.4, 0.4), t0 + k * step, 0.22 * (0.85 if k % 2 else 1), p=0.4 * np.sin(k))
            for k in range(4): place(buf, piano(nt[mel[(k + 1) % 4]], 3.5, 0.6), t0 + k * beat, 0.3, p=-0.2 + 0.15 * k)
            for k in range(4):
                if k % 2 == 0 or (k == 3 and i % 2): place(buf, kick(), t0 + k * beat, 0.6)
                place(buf, hat(), t0 + k * beat + beat / 2, 0.1, p=0.2)
    rv = {'sad': (3.8, 0.42, 4200), 'resolve': (3.8, 0.42, 4200), 'hope': (4.0, 0.45, 6000), 'rise': (2.6, 0.32, 5000)}[kind]
    return reverb(buf, *rv), total

def dark_v(R, d=72.0):
    root = float(R.choice([38.9, 41.2, 43.65, 46.25])); bpm = float(R.uniform(56, 66)); gap = float(R.uniform(5, 8))
    n = int(d * SR); tt = np.arange(n) / SR; x = np.zeros(n); lfo = R.uniform(0.04, 0.08)
    for k, a in ((1, 1.0), (1.5, 0.35), (2, 0.5), (3, 0.18)):
        f = root * k; ph = rng.uniform(0, 6); x += a * (2 * ((f * (1 + 0.002 * np.sin(2 * np.pi * 0.07 * tt)) * tt + ph) % 1) - 1)
    x = hp(lp(x, 900, 2), 70) * (0.75 + 0.25 * np.sin(2 * np.pi * lfo * tt)); buf = np.stack([x, np.roll(x, 900)], 1) * 0.25
    hb = heartbeat(bpm, int(d * bpm / 60) - 1); L = min(len(hb), n); hb = hp(hb, 45); buf[:L] += np.stack([hb[:L], hb[:L]], 1) * 0.35
    for s in np.arange(R.uniform(2, 5), d - 4, gap): place(buf, ding(root * 8 * R.choice([1, 1.2, 1.5, 1.33]), 4.0, 0.3), s, 0.12, p=R.uniform(-0.6, 0.6))
    return reverb(buf, 3.5, 0.4, 3000), d, bpm

def project_beds(proj, beds, seed=0):
    import zlib
    cfg =json.load(open(os.path.join(proj, 'config.json'), encoding='utf-8')) if os.path.exists(os.path.join(proj, 'config.json')) else {}
    title = cfg.get('title') or os.path.basename(os.path.normpath(proj)); out = os.path.join(proj, 'build', 'music'); os.makedirs(out, exist_ok=True)
    for kind in beds:
        if kind not in ('sad', 'dark', 'rise', 'resolve', 'hope'): continue
        sd = zlib.crc32(f'{title}|{kind}|{seed}'.encode('utf-8'))
        if any(json.load(open(f)).get('seed') == sd for f in glob.glob(os.path.join(out, f'bed_{kind}_*.json'))): continue
        for f in glob.glob(os.path.join(out, f'bed_{kind}_*')): os.remove(f)
        R = np.random.default_rng(sd); rng.bit_generator.state = np.random.default_rng(sd + 1).bit_generator.state
        if kind == 'dark':
            buf, total, bpm = dark_v(R); loop_write(out, f'bed_dark_{int(bpm)}bpm', buf, total, {'bpm': None, 'trim': [0, 0], 'loop': False, 'seed': sd}); continue
        semi = int(R.choice([-3, -2, -1, 0, 1, 2])); tr = 2 ** (semi / 12)
        base = {'sad': 64, 'resolve': 70, 'hope': 76, 'rise': 96}[kind]; bpm = round(base * float(R.uniform(0.92, 1.08)))
        prog = POOLS[kind][int(R.integers(len(POOLS[kind])))]; mel = MEL[int(R.integers(len(MEL)))]
        loops = max(2, int(round(64 / (len(prog) * 240 / bpm))))
        buf, total = keyed(R, tr, bpm, prog, mel, loops, kind)
        loop_write(out, f'bed_{kind}_{bpm}bpm', buf, total, {'bpm': bpm, 'trim': [0, 0], 'loop': True, 'seed': sd, 'prog': prog, 'semi': semi})

if __name__ == '__main__':
    if '--project' in sys.argv:
        import argparse
        ap = argparse.ArgumentParser(); ap.add_argument('--project'); ap.add_argument('--beds', default='sad,dark,rise,resolve,hope'); ap.add_argument('--seed', type=int, default=0)
        A = ap.parse_args(); project_beds(os.path.join(CWD0, A.project), [b for b in A.beds.split(',') if b], A.seed)
    else:   # --sfx-only (cai gon): chi SFX, khong tao san nhac (nhac sinh rieng tung phim luc tron)
        for p in build_sfx(): print(p)
        if '--sfx-only' not in sys.argv: build_music()
        # tao SAU cung (khong lam doi chuoi ngau nhien -> tieng / nhac cu giu nguyen)
        print(save('sfx/vanish_burst_hitAt350ms', vanish_burst(), 0.9, rev=(2.4, 0.3, 5000))); print(save('sfx/vanish_ash', vanish_ash(), 0.6, rev=(1.8, 0.3, 6000)))
