// pack.js — bo phong cach "phim": che do cinematic mac dinh (2.0) = phim hoat hinh VECTOR 2D dan dung kieu dien anh
// (do tu "1-MINUTE An Animated Short Film"): minh hoa phang ve phoi canh, nhan vat roi den vien xam, mau ke chuyen, may phan lon dung yen.
// config.json: "mode": "cinematic" (mac dinh "render": "2d" -> pack nay; "render": "3d" -> pack cine Three.js, tuy chon).
// 2 font theo phim tham khao: Comic Neue (thoai) + Lora (narration serif, the ket).
import './templates.js';
import { planFilm } from '/packs/cine/director.js';
import { refine } from './director2d.js';
export * from './places.js';
export * from './puppet.js';
export * from './screens.js';
export { SETS2 } from './templates.js';
export * from './sets.js';
export * from '/engine/flat/stage.js';
export { view } from '/engine/flat/persp.js';

function css(href) { return new Promise((r) => { const l = document.createElement('link'); l.rel = 'stylesheet'; l.href = href; l.onload = r; l.onerror = r; document.head.appendChild(l); }); }
export async function init(E) {
  await Promise.all(['comic-neue/700.css', 'comic-neue/400.css', 'lora/400.css', 'lora/400-italic.css', 'lora/700.css', 'caveat/700.css', 'be-vietnam-pro/700.css', 'luckiest-guy/400.css'].map((f) => css('/node_modules/@fontsource/' + f)));
  await Promise.all([document.fonts.load('700 40px "Comic Neue"', 'Tomorrow.'), document.fonts.load('italic 400 40px "Lora"', 'Big plans'), document.fonts.load('400 40px "Lora"', 'ONE MINUTE')]);
  E.cfg.style = 'flat';            // mau / vignette / hat do engine/flat/stage.js post() lam
  if (E.cfg.bars === null || E.cfg.bars === undefined) E.cfg.bars = 'none';
  E.cfg.captionStyle = 'none';
  // dao dien ca phim (dung chung voi ban 3D): goc may tung canh, luat giua cac canh, chuyen canh co ly do
  if (E.cfg.mode === 'cinematic') { planFilm(E.shots, E.story || {}); refine(E.shots); }
}
export function captions() {}
