// persp.js — phoi canh VE TAY cho minh hoa phang (kieu hoa si dung luoi phoi canh 1 diem tu): diem 3D (m) -> diem 2D, roi to phang tung mat.
// Khong co anh sang 3D: moi mat 1 mau (mat truoc = goc, mat tren sang hon, mat ben toi hon), chuyen sac chi o vang sang gradient.
// view: { eye (m, do cao mat), hz (y duong chan troi, px), f (tieu cu px), cx (tam ngang px), x0 (m, vi tri may ngang) }
import { E } from '../core.js';
import { rgba } from './stage.js';

export function view(o = {}) {
  const V = { eye: o.eye ?? 1.2, hz: o.hz ?? E.H * 0.42, f: o.f ?? E.H * 1.05, cx: o.cx ?? E.W / 2, x0: o.x0 ?? 0 };
  V.p = (x, y, z) => [V.cx + V.f * (x - V.x0) / z, V.hz - V.f * (y - V.eye) / z];    // z > 0: xa may
  V.k = (z) => V.f / z;                                                             // px / m o do sau z (de dat nhan vat dung co)
  return V;
}
export function shade(c, k) {   // k > 0 sang hon, < 0 toi hon
  const h = c.replace('#', ''), n = parseInt(h, 16), r = (n >> 16) & 255, gg = (n >> 8) & 255, b = n & 255, t = k > 0 ? 255 : 0, a = Math.abs(k);
  return `rgb(${Math.round(r + (t - r) * a)},${Math.round(gg + (t - gg) * a)},${Math.round(b + (t - b) * a)})`;
}
export function poly(g, pts, fill) { g.beginPath(); pts.forEach(([x, y], i) => (i ? g.lineTo(x, y) : g.moveTo(x, y))); g.closePath(); g.fillStyle = fill; g.fill(); }
export function quad(g, V, P, fill) { poly(g, P.map((q) => V.p(...q)), fill); }

// hop dung tren san (x0..x1 ngang, z0..z1 sau, y0..y1 cao), to cac mat nhin thay. o: { top, side, line: mau net mep (tuy chon), lw }
export function box(g, V, x0, x1, y0, y1, z0, z1, c, o = {}) {
  const P = (x, y, z) => [x, y, z], top = o.top ?? shade(c, 0.12), side = o.side ?? shade(c, -0.18);
  if (V.eye > y1 && o.noTop !== true) quad(g, V, [P(x0, y1, z0), P(x1, y1, z0), P(x1, y1, z1), P(x0, y1, z1)], top);
  if (V.eye < y0) quad(g, V, [P(x0, y0, z0), P(x1, y0, z0), P(x1, y0, z1), P(x0, y0, z1)], side);
  if (V.x0 < x0) quad(g, V, [P(x0, y0, z0), P(x0, y1, z0), P(x0, y1, z1), P(x0, y0, z1)], side);
  if (V.x0 > x1) quad(g, V, [P(x1, y0, z0), P(x1, y1, z0), P(x1, y1, z1), P(x1, y0, z1)], side);
  quad(g, V, [P(x0, y0, z0), P(x1, y0, z0), P(x1, y1, z0), P(x0, y1, z0)], c);
  if (o.line) { g.strokeStyle = o.line; g.lineWidth = o.lw ?? 1.5; g.beginPath(); for (const [a, b] of [[P(x0, y1, z0), P(x1, y1, z0)], [P(x0, y0, z0), P(x0, y1, z0)], [P(x1, y0, z0), P(x1, y1, z0)]]) { g.moveTo(...V.p(...a)); g.lineTo(...V.p(...b)); } g.stroke(); }
}
// mat phang tren tuong sau (z co dinh) hoac tuong ben (x co dinh): poster, cua so, ke...
export const wallRect = (g, V, x0, x1, y0, y1, z, fill) => quad(g, V, [[x0, y0, z], [x1, y0, z], [x1, y1, z], [x0, y1, z]], fill);
export const sideRect = (g, V, x, z0, z1, y0, y1, fill) => quad(g, V, [[x, y0, z0], [x, y0, z1], [x, y1, z1], [x, y1, z0]], fill);
// vung sang tren san (elip theo phoi canh): x, z tam; rx, rz ban kinh (m)
export function floorGlow(g, V, x, z, rx, rz, color, a) {
  const [sx, sy] = V.p(x, 0, z), ax = V.k(z) * rx, ay = Math.abs(V.p(x, 0, z - rz)[1] - V.p(x, 0, z + rz)[1]) / 2;
  g.save(); g.translate(sx, sy); g.scale(1, Math.max(0.05, ay / ax)); const gr = g.createRadialGradient(0, 0, 0, 0, 0, ax);
  gr.addColorStop(0, rgba(color, a)); gr.addColorStop(0.5, rgba(color, a * 0.45)); gr.addColorStop(1, rgba(color, 0)); g.fillStyle = gr; g.fillRect(-ax, -ax, ax * 2, ax * 2); g.restore();
}
// cac duong ke tren san hoi tu ve diem tu (van go / gach): doc theo z, ngang theo z
export function floorLines(g, V, x0, x1, z0, z1, o = {}) {
  g.save(); g.strokeStyle = o.color || 'rgba(0,0,0,0.12)'; g.lineWidth = o.lw ?? 1.2; g.beginPath();
  for (let x = x0; x <= x1 + 1e-6; x += o.dx ?? 0.22) { g.moveTo(...V.p(x, 0, z0)); g.lineTo(...V.p(x, 0, z1)); }
  if (o.dz) for (let z = z0; z <= z1 + 1e-6; z += o.dz) { g.moveTo(...V.p(x0, 0, z)); g.lineTo(...V.p(x1, 0, z)); }
  g.stroke(); g.restore();
}
