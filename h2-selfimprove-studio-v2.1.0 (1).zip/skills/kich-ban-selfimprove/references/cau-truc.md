# Cấu trúc phim ngắn không lời (ngách Self-Improvement)

Học từ các kênh dẫn đầu ngách "An Animated Short Film" (tiếng Anh, 3–5 phút, không lời đọc, hàng triệu view). Chỉ học **khung, nhịp, cách kể**. Không dùng lại câu chữ, câu chuyện hay cảnh đặc trưng của họ.

## Vì sao dạng này ăn khách
- Không lời đọc → người xem mọi nước đều hiểu, xem trọn vì phải đọc chữ.
- Nhân vật đầu tròn không mặt mũi cụ thể → ai cũng thấy mình trong đó.
- **Bộ đếm** (DAY 1, DAY 47, DAY 412 → 0) biến thói quen vô hình thành con số nhìn thấy. Cú sụp về 0 là khoảnh khắc đau nhất.
- **Giọng cám dỗ** là một bóng đen nói rất nhẹ nhàng, rất hợp lý. Người xem nhận ra đó là giọng trong đầu họ.

## Khung truyện
Thư viện 7 khung ở **`references/khung-truyen.md`**: Vực dậy (khung 6 nhịp cũ, đã thêm nhịp Ước mơ), Tiếc nuối / cảnh tỉnh, Hai cuộc đời song song, Vòng lặp, Thư gửi bản thân, và từ 2.1: **Bước nhỏ** (thu nhỏ mục tiêu), **Giải mã** (đặt tên hiện tượng có thật). Mỗi khung có bảng nhịp %, kiểu bộ đếm, kiểu kết, đề tài hợp; kèm bảng chọn khung theo đề tài và các thủ pháp học được. Mỗi phim chọn 1 khung; tự kiểm áp theo khung đã chọn (không bắt mọi phim phải "đếm lại / đứng lên").

## Chiều sâu cảm xúc (bắt buộc mọi khung)
- **Ước mơ / mục tiêu cụ thể** (chơi bóng rổ ở giải trường, vẽ xong bức tranh, viết xong sổ nhạc…), ghi ở dòng đầu file `ƯỚC MƠ:`. Gài **bằng hình** trong **15% đầu** (cảnh nhân vật đang sống với nó, vật của nó trong phòng), **không** giải thích bằng chữ ("He dreamed of…").
- **1 vật biểu tượng** (dòng `VẬT:`) xuất hiện **≥ 3 lần** và **đổi trạng thái** theo truyện: mới → bỏ quên / phủ bụi → dùng lại / cho đi / vỡ. Vật chọn trong danh sách bộ dựng vẽ được (cuối `khung-truyen.md`); vật khác thì chọn vật gần nhất, hoặc ghi `# cần vẽ thêm: <vật>`.
- **≥ 1 cặp gài – trả:** một câu chữ hoặc hình ở đầu phim quay lại ở 40% cuối **với nghĩa mới** (cảnh sân bóng lúc đầu là nơi cậu chơi, lúc cuối là nơi cậu trao bóng cho đứa trẻ; câu mở "He had plenty of time." thành câu "you still have time.").
- Hay nhất khi 3 thứ gắn vào nhau: vật biểu tượng là đồ của ước mơ, và cặp gài – trả đi qua vật đó.

## Câu móc (2 phương án mỗi kịch bản)
7 kiểu. Ghi ở `MÓC:` đúng tên ở cột trái (hoặc mã trong ngoặc).

| Kiểu (`MÓC:`) | Cách làm |
|---|---|
| chữ trên màn đen (`chu-man-den`) | 1 câu trạng thái / con số / nghịch lý về nhân vật trên nền đen (2 dòng: câu + câu chốt). |
| cảnh hình ảnh mạnh ngay giây đầu | Cảnh đầu đã có chuyện (ném điện thoại, gương nứt, bóng đen khổng lồ), chữ đến sau. |
| cảnh từ đoạn cuối đặt lên đầu | Mở bằng 1 cảnh của 30% cuối (cùng bối cảnh), rồi `! 3 years earlier.` / `! How did he get here?`. |
| bộ đếm sụp ngay đầu rồi tua lại | `HUD: DAY 412 -> 0` ngay cảnh 1–2, rồi `! 412 days earlier.` (ghi `# TRUYỆN: tua lại`). |
| câu hỏi thẳng người xem | Câu hỏi trên màn đen ("How many hours did you lose today?"). |
| châm ngôn nghịch lý trên màn đen (`cham-ngon`) | **Mới 2.1.** Một nhận định chung, thì hiện tại, không có "he" — hơi ngược đời, người xem gật đầu ngay: `> Big plans feel like progress.` / `! Small steps feel like nothing.` Cảnh đầu là màn đen. |
| lời thú nhận ngôi thứ nhất (`thu-nhan`) | **Mới 2.1.** Nhân vật tự nói "I" trong 3 giây đầu, trên màn đen hoặc trên cảnh có hình: `> Every night, I promised: one hour of reading.` / `! I read the first page. Again.` Ngôi thứ nhất chỉ ở móc và kết (xem "Giọng người"). |

File 01 dùng phương án A (`MÓC:`). Phương án B (`MÓC B:`, **khác kiểu**) viết sẵn thành khối dòng bắt đầu bằng `#` ngay sau đầu file (bộ dựng bỏ qua), để người dùng chọn thì chỉ cần thay các cảnh đầu:
```
# MÓC B — bộ đếm sụp ngay đầu rồi tua lại (thay [B01]–[B02] bằng):
# [B01] 4s | CẢNH: ... | NỀN: ... | HUD: AGE 31 -> 16
# ! 15 years earlier.
```

## Độ dài và giữ chân
- Mặc định **3,5 phút** (dòng `DÀI: 3.5`), cho phép 3–5 phút. Tổng giây các cảnh lệch ≤ 5% so với `DÀI`. Nhịp trung bình 4–6 giây / cảnh, montage 1–2 giây / cảnh: 3,5 phút ≈ 38–48 cảnh, 5 phút ≈ 55–70 cảnh.
- Dài hơn 3 phút: **ít nhất 1 điểm "móc lại"** ở 35–70% — câu hỏi mở (`! What if he was wrong?`), đổi nhịp (đoạn lặng, đoạn giải thích, montage đổi tốc độ), bất ngờ nhỏ (tin nhắn lạ, người cũ xuất hiện, lật nghĩa một câu trước đó).
- **Lý do xem tiếp ít nhất mỗi 20–25 giây** (từ 2.1): biến cố mới (đổi nhịp, nhảy thời gian, bộ đếm gạch, bóng đen nói câu mới leo thang, người thật xuất hiện, vật đổi trạng thái), điểm xoay, câu hỏi sắc (dòng kết bằng `?`), thẻ khái niệm / trích dẫn, người dẫn đường, bước nhỏ. Đánh dấu bằng `# TRUYỆN: biến cố <gì>` / `xoay <gì>` / … Máy kiểm: khung 6–7 tối đa **25 giây**; khung 1–5 giữ luật cũ **40 giây** (tương thích kịch bản cũ) — muốn kiểm khung cũ theo 25 giây thì chạy `kiem_truyen.py --giu-chan 25`. Viết mới thì nhắm 25 giây cho mọi khung.
- **≥ 2 điểm xoay** (`# TRUYỆN: xoay <gì>`): chỗ câu chuyện đổi hướng (người dẫn đường đưa đề nghị, lý do cũ bị đáp lại, sự thật được nói ra, tái phạm). Khung 6–7 bắt buộc; khung cũ nên có (cú sụp, bước ngoặt).
- **Nhịp có khoảng lặng:** ≥ 2 cảnh không chữ (không tính thẻ kết / kêu gọi).

## Chữ trên hình

### Giọng người (khung 6–7; mới 2.1)
- **Ngôi thứ nhất** được phép ở **móc** và **kết** (1–3 dòng mỗi chỗ, mỗi dòng ≤ 9 từ): `> I bought the planner in January.` / `> I still miss days. Never two.` Giữa phim vẫn kể ngôi thứ ba quá khứ (`>`), ngắn.
- **Thoại là xương sống:** bong bóng `" [ai] …` (1–7 từ, như người nói thật) và tin nhắn `@ <tên>: …` kể phần lớn câu chuyện; chữ kể chuyện `>` chỉ nối. Mỗi cảnh vẫn **tối đa 3 dòng chữ**.
- **≥ 3 người nói khác nhau** cả phim (nhân vật chính + ≥ 2 người phụ, tính cả tin nhắn), mỗi người một chức năng: kéo / hỏi / thương / đo (`viet-hay.md` mục d). Một người là **người dẫn đường** (`# TRUYỆN: người dẫn đường`).
- **Lý do bào chữa** của chính nhân vật (`~` trên cảnh lịch / điện thoại / mặt, hoặc bong bóng của nhân vật) thay hoặc đi cùng bóng đen.
- Không giảng bài học giữa phim; bài học chỉ nằm ở `BÀI HỌC:` và 02-PACKAGE.
- Viết hay hơn (cụ thể, ngầm ý, câu hỏi sắc, nhịp): `viet-hay.md`.

### Chữ kể chuyện (`>`)
- Thì quá khứ, ngôi thứ ba ("he"), câu cực ngắn, tối đa 9 từ. Nhiều câu 2–4 từ.
- Tách thành cặp đối: "He used to be first. / Now he was gone." Dòng sau thường ngắn hơn và đau hơn.
- Không giải thích bài học giữa phim. Chỉ kể việc xảy ra.
- 1–3 câu cuối (nhịp 5–6) chuyển sang nói thẳng với người xem ("you"), giọng thì thầm, không giảng.
- Mỗi cảnh tối đa 2 câu kể chuyện.

### Giọng cám dỗ (`~`)
- Chữ thường, 2–7 từ, kết bằng `.` hoặc `...`.
- Nghe như lời bạn thân: an ủi, khen, xin "chỉ một lần". **Không** bao giờ nói kiểu ác ("give up, loser").
- Leo thang theo nhịp: xin nhỏ ("just this once.") → hợp lý hoá ("you earned it.") → cô lập ("they don't get you.") → buông xuôi ("it's gone anyway.") → yếu dần ở nhịp 5 (cùng câu cũ nhưng nhỏ, nhạt).
- Ví dụ tự nghĩ cho đề "trì hoãn": "start tomorrow.", "you work better under pressure.", "one episode first.", "it's already late.", "why even try now?".

### Bong bóng lời nói (`"`), chữ to giữa màn (`!`), tin nhắn (`@`)
- Bong bóng: 1–3 từ ("hi.", "hey!", "you okay?").
- **Màn đen** là chỗ đặt câu đắt: 1 dòng kể chuyện + 1 dòng chốt. Ghi 2 dòng `>` liền nhau, bộ dựng tự cho dòng sau thành chữ nhấn to giữa màn (hoặc ghi thẳng `!` cho dòng chốt). Ví dụ:
  `> There was a light on in the kitchen.` / `> He knew who was waiting.`
- Chữ to giữa màn (`!`) cũng dùng cho mốc thời gian ("3 hours later...", "Day 1. Again.").
- Tin nhắn: viết thường, như người thật nhắn ("u up?", "we miss you bro", "proud of you."). Dùng ở cảnh điện thoại.

### Thẻ khái niệm và thẻ trích dẫn (mới 2.1; cú pháp có sẵn của file 01)
Cả hai là **màn đen** (tính vào giới hạn 3–4 màn đen mỗi phim), đặt sau ít nhất một cảnh có hình. Chỉ dùng khái niệm / câu nói **có thật, đã kiểm nguồn** (`viet-hay.md` mục h, i).
- **Thẻ khái niệm:** dòng `!` = tên hiện tượng, dòng `>` = định nghĩa 1 câu ≤ 9 từ, lời của mình nhưng đúng nghĩa. Ghi `# TRUYỆN: khái niệm <tên>`.
  ```
  [B06] 5s | CẢNH: màn đen, thẻ khái niệm | NỀN: màn đen | NHẠC: none
  # TRUYỆN: khái niệm planning fallacy
  ! Planning fallacy.
  > We underestimate how long things take.
  ```
- **Thẻ trích dẫn:** 1–2 dòng `>` là câu trích (giữ nguyên văn, có ngoặc kép), dòng cuối `> — Tác giả` (bắt đầu bằng gạch dài `—` và dấu cách; bộ cinematic dựng thành chữ nhỏ in hoa). Ghi `# TRUYỆN: trích dẫn`. Đặt ở 35–70%. Tối đa 3 dòng.
  ```
  [B18] 9s | CẢNH: màn đen, trích dẫn | NỀN: màn đen | NHẠC: none
  # TRUYỆN: trích dẫn
  > "How we spend our days is,
  > of course, how we spend our lives."
  > — Annie Dillard
  ```
  `--dry-run` tính giờ đọc dòng nguồn như câu thường → thẻ 2 dòng + nguồn cần ~8–9 giây và có `CANH BAO màn đen > 5s`: giữ cảnh báo, ghi lý do "thẻ trích dẫn". Bộ legacy (`dem`) chưa có kiểu chữ nguồn (dựng như chữ to): xem "Đề xuất cho bộ dựng" ở CHANGELOG 2.1.0.
- Nguồn đầy đủ (tác giả, tác phẩm, năm / người đặt tên khái niệm, nơi công bố) ghi ở `SỰ THẬT:` đầu file và ở 02-PACKAGE, không ghi thêm lên hình.

### Bộ đếm (HUD)
- `DAY 47` · `DAY 3..30` (đếm dần trong cảnh) · `DAY 412 -> 0` (gạch xoá về 0, đổi màu nhấn) · `SEEN 1,388; KNOWN 0` (2 dòng đối nghịch) · `NIGHT 30` · `HOURS LOST 2,140` · `-` (tắt bộ đếm).
- Không ghi `HUD` thì cảnh giữ bộ đếm của cảnh trước.
- Nhãn có số đi kèm tối đa 9 ký tự (`DAY`, `AGE`, `HOURS`, `DAYS LEFT`): nhãn dài hơn thì số bị dính vào chữ (`--dry-run` cảnh báo). Nhãn không số (`DAY 4 · STRENGTH`) dài được.
- Kiểu bộ đếm và chỗ sụp theo khung truyện (`khung-truyen.md`): Vực dậy gạch về 0 ở Đáy; Tiếc nuối chỉ tăng (AGE / YEARS); Hai cuộc đời 2 dòng; Vòng lặp về DAY 1 mỗi vòng; Thư gửi bản thân đếm năm / tuổi; **Bước nhỏ: lịch**; **Giải mã: giờ**. Bộ đếm có thể kèm tên việc: `DAY 4 · RUN`.
- **Bộ đếm "lịch"** (mới 2.1; dùng mẫu có sẵn trong kho cảnh): cảnh `NỀN: cận lịch, tháng sep, 0 tới 6, tô màu` (hoặc mặc định gạch X; `xoá về 0` khi bỏ cuộc) + HUD `DAY 6 · READ` (nhãn có `·` không bị giới hạn 9 ký tự vì không có số đi kèm). **Ngày thật** (thứ, ngày tháng) đặt ở dòng chữ `!` của cảnh lịch / màn khoá: `! Mon, Sep 22.` — bộ dựng hiện chưa in ngày lên ô lịch hay màn khoá (xem "Đề xuất cho bộ dựng"). Lý do bào chữa của ngày đó đặt ở dòng `~` hoặc `>` cùng cảnh.
- **Bộ đếm "giờ"** (mới 2.1): giờ cụ thể bằng `NỀN: cận đồng hồ, 1:59 -> 2:00` hoặc `cận điện thoại, màn khoá 2:14`, kèm HUD `NIGHT 12`; mỗi lần nhảy giờ là 1 biến cố.

## Thẻ kết
- `THẺ KẾT: WORD. / dòng phụ 1 / dòng phụ 2` — WORD là từ khoá phim (DISCIPLINE., TOMORROW., LUST.). Chuỗi thì thêm `PART 2` vào WORD (`LUST. PART 2`); bộ dựng tự tách `PART 2` thành dòng riêng dưới từ khoá.
- Dòng phụ 1: câu đảo ngữ hoặc câu đối ngắn (3–6 từ). Dòng phụ 2 (màu nhấn): lời thách / lựa chọn (2–5 từ).
- Ví dụ tự nghĩ: `TOMORROW. / Tomorrow is a place. / Nobody lives there.` · `SCROLL. / The feed never ends. / You can.`

## Tiêu đề
- Theo công thức cân bằng trong `kenh-chuoi.md` (đọc hậu tố, tên kênh, chuỗi từ `KENH.md`): 4 tiêu đề từ khoá + hậu tố kênh, 3 câu đâm thẳng có từ khoá ngách ("Tomorrow Is Lying To You.", "You're Not Tired. You're Bored."), 2 dấu ấn chuỗi / kênh, **tối đa 1** theo mẫu đối thủ `WORD | An Animated Short Film`.
- ≤ 60 ký tự. Không emoji, không hashtag trong tiêu đề.

## Kho cảnh vẽ được (chỉ dùng các cảnh này)

**Nguồn duy nhất: `references/kho-canh.md`.** File đó sinh tự động từ mã bộ dựng (`phim.py --kho`), gồm tên ghi được và mã bộ dựng nhận cho: bối cảnh, mẫu cận cảnh, nhân vật, mốc đặt người, **tư thế tĩnh**, biểu cảm, **động tác có chuyển động**, **động tác chưa hỗ trợ + cách thay**, máy quay, nhạc, SFX. Chỉ viết giá trị có trong file đó. Bộ dựng nâng cấp thì sinh lại file, không sửa tay.

Tóm tắt (tên chính xác xem kho-canh.md):
- **Bối cảnh:** phòng ngủ, thành phố, phố mưa, hành lang tủ đồ, lớp học, sân bóng rổ, quán cà phê, phòng tập, cầu thang, đồi hoàng hôn, gương, phòng khách (sofa), bếp đêm, khung cửa mở hắt sáng, khoảng tối có đèn rọi, màn đen.
- **Cận cảnh:** điện thoại (feed ghi rõ ảnh từng bài / video / chat / email / màn khoá có thông báo / **ứng dụng đếm ngày** / màn tắt), đồng hồ báo thức, lịch, cận mặt (khóc, **mắt đỏ gân máu**, nước mắt, mồ hôi, ánh màn hình), sổ tay.
- **Tư thế tĩnh** (đứng yên cả cảnh, chỉ thở và chớp mắt): đứng, cúi gục, cầm điện thoại, ôm đầu, khoanh tay, thủ thế, ngồi, ôm gối, quỳ, leo, cầm ô, nằm sàn…
- **Động tác có chuyển động** (bộ dựng diễn thật): đi / chạy tới vị trí x, chạy tại chỗ (đường cuộn), đứng dậy, ngồi xuống, quỵ xuống, ngã, ném điện thoại, bỏ đi, thở dốc, đấm liên tục (bao cát lõm, số đếm), quay người, đổi tư thế / biểu cảm giữa cảnh, bóng đen hiện / vỡ / tan thành tro, người nằm giường với tay tắt báo thức / ngồi dậy / trở mình.
- **Chưa hỗ trợ** (không viết như hành động): đẩy / mở cửa, nhảy, hít đất, nâng tạ lặp lại, leo cầu thang liên tục, ăn uống, lái xe, lắc đầu… Thay bằng tư thế + cắt cảnh theo bảng ở kho-canh.md mục 7.
- **Ngồi** chỉ đẹp ở chỗ có ghế: mép giường, ghế bàn, sofa, ghế xe buýt, ghế băng sân bóng. Quán cà phê chưa có ghế.

Cần cảnh ngoài kho (xe hơi, bãi biển, bệnh viện...) thì đổi sang cảnh gần nhất trong kho, hoặc thêm dòng `# cần vẽ thêm: ...` dưới cảnh để người dựng biết.

## Định dạng file 01

```
TITLE: TOMORROW
ACCENT: amber
NHÂN VẬT: hoodie
ĐỀ TÀI: trì hoãn
KHUNG: vực dậy
KẾT: hy vọng
ƯỚC MƠ: làm xong đồ án game đầu tay
VẬT: laptop
MÓC: chữ trên màn đen
MÓC B: bộ đếm sụp ngay đầu rồi tua lại
DÀI: 3.5

# MÓC B — bộ đếm sụp ngay đầu rồi tua lại (thay [B01] bằng 2 cảnh):
# [B01] 4s | CẢNH: cận lịch, gạch về 0 | NỀN: cận lịch, tháng nov, 0 tới 30, xoá về 0 | HUD: DAYS LEFT 30 -> 0
# # TRUYỆN: nhịp Móc; tua lại
# ! 30 days earlier.

[B01] 4s | CẢNH: màn đen | NỀN: màn đen | NHẠC: none
# TRUYỆN: nhịp Móc
> He was going to start tomorrow.

[B02] 5s | CẢNH: phòng ngủ đêm trăng, cậu ngồi bàn nhìn laptop trống | NỀN: phòng ngủ, đêm trăng, laptop | AI: cậu@ghế bàn ngồi bàn, mệt | MÁY: đẩy chậm | HUD: DAYS LEFT 30 | NHẠC: sad
# TRUYỆN: nhịp Ước mơ; ước mơ; vật 1 sáng màn hình, đồ án mở dở; gài màn hình laptop
> The project was due in 30 days.

[B03] 6s | CẢNH: bóng đen hiện sau lưng cậu, cúi xuống thì thầm | NỀN: phòng ngủ, đêm trăng, laptop | AI: cậu@ghế bàn ngồi bàn, mệt; bóng đen@0.66 với tay, hiện 0.6s | ĐỘNG TÁC: cậu bị cám dỗ 2.5s | SFX: tempt_swell@0.6
# TRUYỆN: nhịp Sa ngã; biến cố bóng đen xuất hiện
~ start tomorrow.

[B04] 5s | CẢNH: cận điện thoại, feed lướt nhanh | NỀN: cận điện thoại, feed: mì, xe, burger, game, lướt nhanh | HUD: DAYS LEFT 30..12 | SFX: whoosh_mid
> One video became ten.

[B09] 6s | CẢNH: cậu đứng giữa khoảng tối, ôm đầu rồi quỵ xuống | NỀN: khoảng tối | AI: cậu@0.5 đứng, sốc | ĐỘNG TÁC: quỵ xuống 2s; khóc 2.6s | MÁY: đẩy chậm vào mặt | HUD: DAYS LEFT 0 | NHẠC: dark | SFX: sting_low@2
# TRUYỆN: nhịp Đáy; sụp
> It was due today.

[B14] 6s | CẢNH: cận điện thoại, Mia nhắn | NỀN: cận điện thoại, chat
@ mia: did you finish it?
@me: almost.

[B22] 6s | CẢNH: phòng tập, cậu đấm bao cát, bóng đen vỡ tan | NỀN: phòng tập | AI: band@0.4 thủ thế, nghiến răng; bóng đen@0.78 đứng | ĐỘNG TÁC: band đấm liên tục 0.5s; bóng đen vỡ 4s | NHẠC: rise | SFX: vanish_burst@4
~ you'll quit.

[B30] 6s | THẺ KẾT: TOMORROW. / Tomorrow is a place. / Nobody lives there.
[B31] 6s | KÊU GỌI
> If this hit, like and subscribe.
```

(Ví dụ rút gọn: phim thật đủ mọi nhịp của khung, đủ 3 lần vật biểu tượng và cặp gài – trả.)

- **Đầu file:** `TITLE`, `ACCENT`, và `NHÂN VẬT: <preset>` (preset của "cậu" cả phim: `hoodie`, `hero`, `band`, `hooded`; xem kho-canh.md mục 3).
- **Hồ sơ truyện** (đầu file, bộ dựng bỏ qua): `ĐỀ TÀI` (tên / mã trong bảng phân loại của `doi-thu.md`, vd `trì hoãn`, `lust`, `kỷ luật`, `đức tính`), `KHUNG` (`vực dậy`, `tiếc nuối`, `hai cuộc đời song song`, `vòng lặp`, `thư gửi bản thân`, `bước nhỏ`, `giải mã`), `KẾT` (`hy vọng`, `tiếc nuối`, `mở`, `vòng lặp`, `bước nhỏ`), `ƯỚC MƠ` (cụ thể), `VẬT` (vật biểu tượng), `MÓC` + `MÓC B` (2 kiểu câu móc khác nhau, 7 kiểu), `DÀI` (phút, mặc định 3.5). Kiểm trùng đối thủ dùng `ĐỀ TÀI / KHUNG / KẾT / VẬT`; máy kiểm truyện dùng tất cả.
- **Ý nghĩa mang đi** (mới 2.1; đầu file, bộ dựng bỏ qua; **tuỳ chọn** với khung 1–5, **bắt buộc** với khung 6–7):
  - `BÀI HỌC:` 1 câu tiếng Anh hoặc Việt, kiểm chứng được hoặc là nhận định có thể bàn luận, không phải khẩu hiệu. ✗ `Never give up.` ✓ `A habit you can do on your worst day beats a plan for your best day.`
  - `BƯỚC NHỎ:` 1 hành động cụ thể người xem làm được trong **1 phút hoặc 1 giờ**, có thời lượng / thời điểm. ✓ `Tonight, put your phone on charge outside the bedroom at 11.` Xuất hiện **đúng 1 lần ở cuối phim** bằng hình + chữ (`# TRUYỆN: bước nhỏ`).
  - `SỰ THẬT:` khái niệm hoặc trích dẫn thật kèm nguồn (`Planning fallacy — Kahneman & Tversky (1979)` · `Annie Dillard, The Writing Life (1989)`). Không chắc thì ghi `SỰ THẬT: không`. Có trích dẫn / khái niệm mà chưa kiểm được nguồn thì thêm dòng `# CẦN KIỂM NGUỒN` ngay dưới, và **không** đưa thẻ đó vào phim (máy kiểm báo LỖI).
  ```
  BÀI HỌC: A habit you can do on your worst day beats a plan for your best day.
  BƯỚC NHỎ: Read one page tonight before you touch your phone.
  SỰ THẬT: Planning fallacy — Kahneman & Tversky (1979), Intuitive Prediction: Biases and Corrective Procedures
  ```
- **Khối `# MÓC B`** ngay sau đầu file: các cảnh thay thế cho câu móc B, mỗi dòng bắt đầu bằng `#` (bộ dựng bỏ qua).
- **Ghi truyện `# TRUYỆN:`** (dòng ngay dưới dòng đầu cảnh, bộ dựng bỏ qua; cách nhau `;`): `nhịp <tên nhịp của khung>` ở cảnh mở nhịp · `ước mơ` · `vật <lần> <trạng thái>` · `gài <tên>` / `trả <tên>` · `sụp` · `người thật` · `móc lại <câu hỏi mở / đổi nhịp / bất ngờ>` · `biến cố <gì>` · `tua lại` (câu móc tua) · `khác <chi tiết>` (khép vòng lặp) · `nhánh A` / `nhánh B` (hai cuộc đời) · **mới 2.1:** `xoay <gì>` (điểm xoay) · `người dẫn đường` · `khái niệm <tên>` · `trích dẫn` · `bước nhỏ` (cảnh trao bước nhỏ, đúng 1 lần). Máy kiểm truyện đọc các dòng này.
- **Dòng đầu cảnh:** `[B<số>] <giây>s | CẢNH | NỀN | AI | ĐỘNG TÁC | MÁY | HUD | NHẠC | SFX`.
  - `CẢNH` (bắt buộc): mô tả tiếng Việt tự do cho người đọc.
  - `NỀN` (luôn ghi), `AI` (luôn ghi khi cảnh có người hoặc bóng đen), `ĐỘNG TÁC` và `MÁY` (khi cần): bộ dựng dùng **đúng** giá trị ghi ở đây, không đoán từ CẢNH. Giá trị chỉ lấy từ kho-canh.md.
  - `HUD`, `NHẠC`, `SFX` chỉ ghi khi đổi.
  - File 01 cũ chỉ có `CẢNH` vẫn dựng được (bộ dựng đoán như trước), nhưng dễ hiểu sai. Viết mới thì luôn ghi đủ trường.
- **NỀN:** `<bối cảnh>[, chi tiết, chi tiết]`. Chi tiết theo cột cuối bảng NỀN ở kho-canh.md (vd `phòng ngủ, bình minh, đồng hồ 5:00 kêu, đèn bàn` · `phố, cửa neon` · `gương, gương nứt`). Cận cảnh: `cận điện thoại, chat` · `cận điện thoại, feed: mì, xe, burger` · `cận điện thoại, màn khoá 3:17` · `cận điện thoại, đếm ngày` (số lấy từ HUD) · `cận đồng hồ, 11:59 -> 12:00, kêu` · `cận lịch, tháng nov, 0 tới 24, tô màu` · `cận mặt, nền phòng ngủ` · `sổ tay` (dòng `>` của cảnh thành chữ viết tay) · `màn đen`.
- **AI:** mỗi người 1 cụm, cách nhau `;`: `<ai>[@vị trí] <tư thế>, <biểu cảm>, <cầm đồ / chi tiết>, <chuyển động>`.
  - Ai: `cậu` (= preset dòng NHÂN VẬT), `band`, `hoodie`, `bạn bè` (2 người), `bạn`, `cô gái`, `mẹ`, `bố`, `em nhỏ`, `bóng mờ`, `bóng đen`.
  - Vị trí: `@0.35` (0 = mép trái, 1 = mép phải) hoặc mốc `@mép giường`, `@ghế bàn`, `@sofa`, `@ghế xe buýt`, `@ghế băng`, `@bàn trái`, `@đỉnh đồi`, `@bậc 3`, `@trong gương`, `@cửa`.
  - Ví dụ: `cậu@mép giường ngồi, cầm điện thoại, mắt đỏ` · `bạn bè@0.88 đi tới 0.46, cười đùa` · `bóng đen@0.66 với tay, hiện 0.6s` · `cậu@0.5 đứng → ôm đầu 2s` (`→` đổi tư thế / biểu cảm giữa cảnh).
  - Nhiều người: đặt cách nhau ≥ 0,2 để không đè; người đi ngang thì cho đi tới gần rồi dừng, không xuyên qua người đứng.
- **ĐỘNG TÁC:** `[ai] <động tác> <giây>s`, cách nhau `;`, không ghi ai = nhân vật chính. Chỉ dùng mục "Động tác có chuyển động" của kho-canh.md (vd `đứng dậy 1.5s; ném điện thoại 3s; bóng đen vỡ 3.6s; khóc 2.6s`). Động tác "chưa hỗ trợ" thì thay theo bảng mục 7.
- **MÁY:** `đẩy chậm` · `đẩy chậm vào mặt` · `đẩy nhanh vào mặt` · `kéo ra` · `lia trái` / `lia phải` · `bám theo` (người chính đang đi / chạy) · `rung 2s` · `cầm tay` · `đứng yên`.
- **Dòng chữ** (0–2 mỗi cảnh, tối đa 3): `>` kể chuyện, `~` cám dỗ, `" [girl] hi.` bong bóng (trong `[]` là ai nói), `!` chữ to giữa màn, `@ <tên>: ...` / `@me: ...` tin nhắn (chỉ ở cảnh `cận điện thoại, chat` hoặc `màn khoá`). `{2.5}` đầu dòng = hiện ở giây 2,5 của cảnh.
- **NHẠC:** `sad` (piano buồn), `dark` (trầm, nhịp tim — đáy, cám dỗ thắng), `rise` (lên, có trống — đứng lên), `hope` (sáng, nhẹ — bước ngoặt), `resolve` (ấm — kết), `none` (im lặng). `tension` chỉ có khi bộ dựng cài đầy đủ.
- **SFX:** danh sách đầy đủ ở kho-canh.md mục 9. Ghi `tên@giây` để đặt đúng giây, ví dụ `sting_low@2`.
- Thường: 1 SFX mỗi 1–2 cảnh. `tempt_swell` hoặc `tempt_whisper` khi bóng đen nói. `sting_low` hoặc `boom_deep` ở cú sụp. Bóng đen vỡ: `vanish_burst@<giây vỡ>`; tan thành tro: `vanish_ash`.

### Kiểm câu chuyện bằng máy (bắt buộc trước khi giao)

```
python "<thư mục skill này>/tools/kiem_truyen.py" --phim "<file 01>"
```
In nhịp (vị trí %), ước mơ, đường đi của vật biểu tượng, cặp gài – trả, bộ đếm, 2 câu móc, điểm móc lại, quãng dài nhất không có biến cố; rồi `LOI` / `CANH BAO`. Luật lấy từ bảng của khung đã chọn trong `khung-truyen.md`. Sửa đến khi `SACH LOI`.

### Tự kiểm bằng máy (bắt buộc trước khi giao)

```
python "<thư mục plugin>/skills/lam-video-selfimprove/kit/tools/phim.py" --phim "<file 01>" --dry-run [--dai 3.5]
```
Chỉ đọc, không ghi file. In từng cảnh **bộ dựng hiểu thành gì** (bối cảnh, ai, tư thế, biểu cảm, động tác, máy), rồi `LOI` / `CANH BAO` và tổng thời lượng. Sửa file 01 đến khi dòng cuối là `SACH LOI`. Đọc lại cột "hiểu thành" xem có đúng ý cảnh không. `CANH BAO` xem có cố ý không (vd "cảnh cuối nên là KÊU GỌI").
