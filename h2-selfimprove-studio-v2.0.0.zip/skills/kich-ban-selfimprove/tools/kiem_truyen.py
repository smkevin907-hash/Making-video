"""kiem_truyen.py — may kiem cau chuyen cua file 01 theo khung truyen da chon (R9-R12). Chi can Python 3.8+.
  python kiem_truyen.py --phim <01-PHIM.txt> [--dai 3.5]
Bang nhip + luat "Máy kiểm" doc thang tu references/khung-truyen.md (sua bang la sua luat).
Kiem: khung hop le; du nhip, dung thu tu, dung vi tri (+-10%); uoc mo gai trong 15% dau; vat bieu tuong >= 3 lan va doi trang thai; >= 1 cap gai - tra;
bo dem dung kieu cua khung; sup, nguoi that, ket, cau "you" o cuoi; 2 cau moc (MÓC + MÓC B) khac kieu va dung cau truc;
tong thoi luong dung muc (mac dinh 3,5 phut, cho phep 3-5 phut, lech <= 5%); ban > 3 phut co moc lai o 35-70%; khong qua 40 giay lien khong co bien co.
Dau file: KHUNG, ƯỚC MƠ, VẬT, MÓC, MÓC B, DÀI. Trong canh: dong "# TRUYỆN: nhịp <tên>; ước mơ; vật <n> <trạng thái>; gài <tên>; trả <tên>; sụp; người thật;
móc lại <kiểu>; biến cố <mô tả>; khác <chi tiết>; nhánh A|B; tua lại" (bo dung bo qua dong #).
"""
import argparse, os, re, sys, unicodedata
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import doi_thu as DT
try: sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except (AttributeError, ValueError): pass
kd = DT.khong_dau
HEAD = re.compile(r"^\s*\[?\s*(B\d+[A-Za-z]?)\s*\]?\s*(\d+(?:[.,]\d+)?)\s*s?\s*(\|.*)?$", re.I)
TOKS = ["nhip", "uoc mo", "vat", "gai", "tra", "sup", "nguoi that", "moc lai", "bien co", "khac", "nhanh", "tua lai"]

def doc_khung(p):   # cac muc "## N. Ten (`ma`)" -> {ma: {ten, nhip: [(ten, %)], luat: {}}}
    K, cur = {}, None
    for l in open(p, encoding="utf-8"):
        m = re.match(r"^## \d+\. (.+?) \(`([\w-]+)`\)", l)
        if m: cur = K.setdefault(m.group(2), {"ten": m.group(1).strip(), "nhip": [], "luat": {}}); continue
        if l.startswith("## ") or l.startswith("---"): cur = None if l.startswith("## ") else cur; continue
        if not cur: continue
        m = re.match(r"^\|\s*([^|]+?)\s*\|\s*(\d+)\s*\|", l)
        if m: cur["nhip"].append((m.group(1).strip(), int(m.group(2)))); continue
        m = re.match(r"^Máy kiểm:\s*(.+)$", l.strip())
        if m: cur["luat"] = {k.strip(): v.strip() for k, v in (x.split("=", 1) for x in m.group(1).split(";") if "=" in x)}
    return K
def gon_chu(s): return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9 ]", " ", kd(s))).strip()
def doc_vat_ve(p):
    t = open(p, encoding="utf-8").read(); m = re.search(r"## Vật biểu tượng bộ dựng vẽ được\n(.*?)(\n## |\Z)", t, re.S)
    return [gon_chu(x) for x in re.split(r"[,:;.\n]", (m.group(1) if m else "").split("Vật khác")[0]) if 2 < len(gon_chu(x)) < 25]

def doc_phim(p):
    meta, sc, cur, moc_b, ve_them = {}, [], None, [], []
    for raw in open(p, encoding="utf-8-sig"):
        s = unicodedata.normalize("NFC", raw.rstrip()); st = s.strip(); k0 = kd(st)
        if not st: continue
        if k0.startswith("#"):
            if re.match(r"^#\s*truyen\s*:", k0) and cur is not None: cur["tok"] += [t.strip() for t in st.split(":", 1)[1].split(";") if t.strip()]
            elif re.match(r"^#\s*moc b\b", k0): moc_b.append(st)
            elif moc_b and re.match(r"^#\s*\[?b\d", k0): moc_b.append(st)
            elif re.match(r"^#\s*can ve them", k0): ve_them.append(st)
            continue
        m = HEAD.match(s)
        if m:
            tags = {}
            for part in (m.group(3) or "").split("|")[1:]:
                k, _, v = part.partition(":"); tags[kd(k).strip()] = v.strip()
            cur = {"id": m.group(1).upper(), "dur": float(m.group(2).replace(",", ".")), "tags": tags, "tok": [], "chu": []}; sc.append(cur); continue
        mm = re.match(r"^\s*([A-ZÀ-Ỹ][A-ZÀ-Ỹ ]*?)\s*:\s*(.+)$", s)
        if cur is None and mm: meta[kd(mm.group(1))] = mm.group(2).strip(); continue
        if cur is not None: cur["chu"].append(re.sub(r"^\{[\d.,]+\}\s*", "", st))
    t = 0.0
    for c in sc: c["t"] = t; t += c["dur"]
    return meta, sc, t, moc_b, ve_them
def tag(c, *ks): return next((v for k, v in c["tags"].items() for n in ks if k.startswith(n)), None)
def tok(c, name): return [x for x in c["tok"] if kd(x).startswith(name)]
def rest(x, name): return re.sub(r"^\S+(\s+\S+)?\s*", "", x, count=1).strip() if " " in name else x.split(None, 1)[1].strip() if len(x.split(None, 1)) > 1 else ""

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("--phim", required=True); ap.add_argument("--dai", type=float); ap.add_argument("--khung-md")
    a = ap.parse_args(); md = a.khung_md or os.path.join(HERE, "..", "references", "khung-truyen.md")
    K = doc_khung(md); meta, sc, tot, moc_b, ve_them = doc_phim(a.phim); LOI, CB = [], []
    if not sc: sys.exit("Khong doc duoc canh nao.")
    pct = lambda c: round(100 * c["t"] / tot) if tot else 0; loc = lambda c: f"{c['id']} {pct(c)}%"
    card = [c for c in sc if tag(c, "the ket", "card") is not None or any(k.startswith(("keu goi", "cta")) for k in c["tags"])]
    nd = [c for c in sc if c not in card]
    # khung
    kv = meta.get("khung", ""); km = next((m for m, x in K.items() if kd(kv) in (m, kd(x["ten"]), kd(x["ten"].split(" / ")[0]))), None)
    if not km: print(f"LOI: KHUNG '{kv}' khong co trong thu vien ({', '.join(x['ten'] for x in K.values())})"); sys.exit(1)
    KH = K[km]; L = KH["luat"]
    # do dai
    dai = a.dai or float((meta.get("dai") or "3.5").replace(",", ".").split()[0])
    if not 3 <= dai <= 5: CB.append(f"DÀI {dai} phút ngoài khoảng 3–5 phút")
    if abs(tot - dai * 60) > dai * 60 * 0.05: LOI.append(f"tổng {DT.mmss(tot)} ({tot:.0f}s) lệch quá 5% so với mục tiêu {dai:g} phút ({dai * 60:.0f}s)")
    # nhip
    nh = [(c, rest(x, "nhip")) for c in sc for x in tok(c, "nhip")]
    if card and not any(kd(n) == kd("Thẻ kết") for _, n in nh): nh.append((card[0], "Thẻ kết"))
    found, last_t = [], -1
    for ten, p0 in KH["nhip"]:
        hit = next(((c, n) for c, n in nh if kd(n) == kd(ten) or kd(n).startswith(kd(ten))), None)
        if not hit: LOI.append(f"thiếu nhịp '{ten}' (ghi # TRUYỆN: nhịp {ten} ở cảnh mở nhịp, khoảng {p0}%)"); continue
        c = hit[0]; found.append(f"{ten} {pct(c)}%")
        if abs(pct(c) - p0) > 10: LOI.append(f"nhịp '{ten}' bắt đầu ở {loc(c)}, khung {KH['ten']} cần khoảng {p0}% (±10)")
        if c["t"] < last_t: LOI.append(f"nhịp '{ten}' ({loc(c)}) đứng sai thứ tự")
        last_t = max(last_t, c["t"])
    for c, n in nh:
        if not any(kd(n) == kd(t) or kd(n).startswith(kd(t)) for t, _ in KH["nhip"]): CB.append(f"{c['id']}: nhịp '{n}' không có trong khung {KH['ten']}")
    # R10 uoc mo
    if not meta.get("uoc mo"): LOI.append("thiếu dòng đầu file ƯỚC MƠ: <ước mơ / mục tiêu cụ thể>")
    um = [c for c in sc if tok(c, "uoc mo")]
    if not um: LOI.append("chưa gài ước mơ (# TRUYỆN: ước mơ) — phải hiện bằng hình trong 15% đầu")
    elif pct(um[0]) > 15: LOI.append(f"ước mơ gài muộn ở {loc(um[0])} (cần ≤ 15%)")
    for c in um:
        for x in c["chu"]:
            if x[:1] in ">!" and re.search(r"\b(dream|dreamed|wanted to|goal|wish)\b", x, re.I): CB.append(f"{c['id']}: ước mơ đang được giải thích bằng chữ ('{x[1:].strip()}') — nên để hình nói")
    # vat bieu tuong
    vat = meta.get("vat", ""); vv = [(c, re.sub(r"^\d+\s*", "", rest(x, "vat"))) for c in sc for x in tok(c, "vat")]
    if not vat: LOI.append("thiếu dòng đầu file VẬT: <vật biểu tượng>")
    if len(vv) < 3: LOI.append(f"vật biểu tượng xuất hiện {len(vv)} lần (cần ≥ 3, ghi # TRUYỆN: vật <n> <trạng thái>)")
    elif len({kd(s) for _, s in vv}) < 2 or kd(vv[0][1]) == kd(vv[-1][1]): LOI.append("vật biểu tượng không đổi trạng thái theo truyện (lần đầu và lần cuối phải khác)")
    ve = doc_vat_ve(md)
    if vat and not ve_them and not any(w in gon_chu(vat) or gon_chu(vat) in w for w in ve): CB.append(f"VẬT '{vat}' chưa có trong danh sách bộ dựng vẽ được → đổi vật gần nhất hoặc thêm dòng # cần vẽ thêm: {vat}")
    # gai - tra
    gai = {kd(rest(x, "gai")): c for c in sc for x in tok(c, "gai")}; tra = {kd(rest(x, "tra")): c for c in sc for x in tok(c, "tra")}
    cap = [(n, gai[n], tra[n]) for n in gai if n in tra]
    if not cap: LOI.append("chưa có cặp gài – trả (# TRUYỆN: gài <tên> ở đầu, trả <tên> ở cuối)")
    for n, g, t in cap:
        if t["t"] <= g["t"]: LOI.append(f"trả '{n}' ({loc(t)}) đứng trước gài ({loc(g)})")
        elif pct(t) < 60: CB.append(f"trả '{n}' ở {loc(t)}: nên đặt ở 40% cuối để mang nghĩa mới")
    for n in set(gai) - set(tra): CB.append(f"gài '{n}' ({loc(gai[n])}) chưa được trả")
    # bo dem
    hud = [(c, tag(c, "hud")) for c in sc if tag(c, "hud") not in (None, "", "-")]
    if not hud: LOI.append("không có bộ đếm (HUD) — bộ đếm là xương sống phim")
    elif pct(hud[0][0]) > 20: LOI.append(f"bộ đếm xuất hiện muộn ({loc(hud[0][0])}, cần ≤ 20%)")
    reset = [(c, h) for c, h in hud if re.search(r"->|→", h)]
    nums = [int(re.sub(r"\D", "", m)) for _, h in hud for m in re.findall(r"\d[\d,]*", h.split(";")[0])[-1:]]
    d = L.get("dem")
    if d == "reset" and not any(re.search(r"(->|→)\s*0\b", h) for _, h in reset): LOI.append("khung cần bộ đếm gạch về 0 ở Đáy (HUD: DAY 47 -> 0)")
    if d == "tang":
        if len(nums) < 2 or nums[-1] <= nums[0]: LOI.append("khung cần bộ đếm thời gian tăng dần (AGE 17 … 34 / YEARS LOST …)")
        if any(re.search(r"(->|→)\s*0\b", h) for _, h in reset): CB.append("khung này không gạch bộ đếm về 0 (thời gian không quay lại)")
    if d == "2dong" and not any(";" in h for _, h in hud): LOI.append("khung cần bộ đếm 2 dòng (HUD: A 10; B 10)")
    if d == "lap" and sum(1 for _, h in hud if re.search(r"(->|→)\s*[01]\b|\bDAY 1\b", h, re.I)) < 2: LOI.append("khung cần bộ đếm bị đưa về DAY 1 ít nhất 2 lần (mỗi vòng 1 lần)")
    # sup, nguoi that, ket, you
    if L.get("sup") == "1" and not any(tok(c, "sup") for c in sc): LOI.append("thiếu cú sụp (# TRUYỆN: sụp)")
    if L.get("nguoi") == "1" and not any(tok(c, "nguoi that") for c in sc): LOI.append("thiếu khoảnh khắc người thật (# TRUYỆN: người thật)")
    ket = DT.ma("kieu_ket", meta.get("ket")); ok_ket = [x.strip() for x in L.get("ket", "").split(",") if x.strip()]
    if not ket: LOI.append(f"KẾT '{meta.get('ket')}' sai (hy vọng / tiếc nuối / mở / vòng lặp)")
    elif ok_ket and ket not in ok_ket: CB.append(f"KẾT '{DT.KET[ket]}' không phải kiểu kết của khung {KH['ten']} ({', '.join(DT.KET[x] for x in ok_ket)})")
    nar = [(c, x) for c in nd for x in c["chu"] if x[:1] in ">!"]
    if not any(re.search(r"\byou(r|'re|'ll)?\b", x, re.I) for _, x in nar[-3:]): LOI.append("1–3 câu kể chuyện cuối chưa chuyển sang nói với 'you'")
    if L.get("vong") == "1":
        a0, z0 = kd(tag(nd[0], "nen") or tag(nd[0], "canh") or ""), kd(tag(nd[-1], "nen") or tag(nd[-1], "canh") or "")
        if a0.split(",")[0].strip() != z0.split(",")[0].strip(): LOI.append(f"vòng lặp: cảnh cuối ({nd[-1]['id']}) phải cùng bối cảnh cảnh đầu ({nd[0]['id']})")
        if not any(tok(c, "khac") for c in nd if pct(c) >= 80): LOI.append("vòng lặp: ghi # TRUYỆN: khác <chi tiết> ở cảnh khép vòng")
    if L.get("thu") == "1" and sum(1 for c in nd for x in c["chu"] if x.startswith("@")) + sum(1 for c in nd if "so tay" in kd(tag(c, "nen") or "")) < 2:
        LOI.append("thư gửi bản thân: lời thư phải hiện ≥ 2 lần bằng sổ tay (NỀN: sổ tay) hoặc tin nhắn @")
    # R11 cau moc
    ma_ = DT.ma("kieu_cau_moc", meta.get("moc")); mb = DT.ma("kieu_cau_moc", meta.get("moc b"))
    if not ma_: LOI.append(f"MÓC '{meta.get('moc')}' sai — chọn: {', '.join(v for k, v in DT.MOC.items() if k != 'khac')}")
    if not mb: LOI.append("thiếu MÓC B (câu móc thứ 2 để chọn, khác kiểu MÓC)")
    elif mb == ma_: LOI.append("MÓC B phải khác kiểu MÓC")
    if mb and len(moc_b) < 2: CB.append("thiếu khối '# MÓC B' (các dòng cảnh thay thế, viết sẵn để dán) ở đầu file")
    c0 = nd[0]; first_txt = next((x for c in nd for x in c["chu"]), "")
    early = [c for c in nd if pct(c) <= 20]
    if ma_ == "chu-man-den" and not re.search(r"man den|nen den|black", kd((tag(c0, "nen") or "") + " " + (tag(c0, "canh") or ""))): LOI.append("MÓC chữ trên màn đen: cảnh đầu phải là màn đen có chữ")
    if ma_ == "bo-dem-sup":
        if not any(re.search(r"->|→", tag(c, "hud") or "") for c in nd if pct(c) <= 12): LOI.append("MÓC bộ đếm sụp: cần HUD gạch (… -> …) trong 12% đầu")
        if not any(tok(c, "tua lai") or any(x[:1] == "!" and re.search(r"earlier|ago|before|back", x, re.I) for x in c["chu"]) for c in early): CB.append("MÓC bộ đếm sụp: nên có cảnh tua lại (! 412 days earlier / # TRUYỆN: tua lại)")
    if ma_ == "cuoi-len-dau":
        n0 = kd(tag(c0, "nen") or "").split(",")[0].strip()
        if not any(kd(tag(c, "nen") or "").split(",")[0].strip() == n0 for c in nd if pct(c) >= 70): LOI.append("MÓC cảnh cuối lên đầu: bối cảnh cảnh đầu phải xuất hiện lại ở 30% cuối")
    if ma_ == "hinh-manh" and re.search(r"man den|black", kd(tag(c0, "nen") or "")): LOI.append("MÓC hình ảnh mạnh: cảnh đầu không phải màn đen")
    if ma_ == "cau-hoi" and not first_txt.rstrip().endswith("?"): LOI.append("MÓC câu hỏi: dòng chữ đầu tiên phải là câu hỏi")
    # R12 giu chan
    ml = [c for c in sc if tok(c, "moc lai")]
    if tot > 180 and not any(35 <= pct(c) <= 70 for c in ml): LOI.append("bản dài hơn 3 phút cần ít nhất 1 điểm móc lại ở 35–70% (# TRUYỆN: móc lại <câu hỏi mở / đổi nhịp / bất ngờ>)")
    ev = sorted({c["t"] for c in sc if any(kd(x).startswith(tuple(t for t in TOKS if t not in ("vat", "nhanh"))) for x in c["tok"])
                 or re.search(r"->|→", tag(c, "hud") or "") or re.search(r"\bvo\b|tan tro|tan bien", kd(tag(c, "dong tac") or "")) or c in card} | {0.0})
    ev.append(tot); gaps = [(ev[i], ev[i + 1]) for i in range(len(ev) - 1)]; big = max(gaps, key=lambda g: g[1] - g[0])
    for g0, g1 in gaps:
        if g1 - g0 > 40: LOI.append(f"{DT.mmss(g0)}–{DT.mmss(g1)}: {g1 - g0:.0f} giây liền không có biến cố mới (tối đa 40)")
    for c in sc:
        for x in c["tok"]:
            if not kd(x).startswith(tuple(TOKS)): CB.append(f"{c['id']}: không hiểu '# TRUYỆN: {x}'")
    # in
    print(f"KIEM TRUYEN {os.path.basename(a.phim)} — khung {KH['ten']} ({km}), dài {DT.mmss(tot)} ({tot:.0f}s; mục tiêu {dai:g} phút)")
    print("  Nhịp:    " + " · ".join(found))
    print(f"  Ước mơ:  {meta.get('uoc mo', '—')}" + (f" — gài ở {loc(um[0])}" if um else ""))
    print(f"  Vật:     {vat or '—'} — " + " → ".join(f"{s} ({loc(c)})" for c, s in vv))
    print("  Gài–trả: " + ("; ".join(f"{n}: {loc(g)} → {loc(t)}" for n, g, t in cap) or "—"))
    print(f"  Bộ đếm:  {d} — " + " → ".join(h for _, h in hud[:3]) + (" … " + hud[-1][1] if len(hud) > 3 else ""))
    print(f"  Móc:     A {DT.MOC.get(ma_, '?')} · B {DT.MOC.get(mb, '?')}" + (f" (khối thay thế {len(moc_b) - 1} cảnh)" if moc_b else ""))
    print(f"  Giữ chân: móc lại {', '.join(loc(c) for c in ml) or '—'}; quãng dài nhất không biến cố {big[1] - big[0]:.0f}s ({DT.mmss(big[0])}–{DT.mmss(big[1])}); {len(ev) - 1} mốc biến cố")
    if LOI: print(f"\nLOI ({len(LOI)}):"); [print("  " + x) for x in LOI]
    if CB: print(f"\nCANH BAO ({len(CB)}):"); [print("  " + x) for x in CB]
    print("=> SACH LOI." if not LOI else f"=> CON {len(LOI)} LOI: sua file 01 roi chay lai.")
    sys.exit(1 if LOI else 0)

if __name__ == "__main__": main()
