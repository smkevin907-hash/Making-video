# Thư viện khung truyện

Mỗi phim chọn **1 khung**. Bảng nhịp dưới đây vừa là hướng dẫn viết vừa là luật máy kiểm (`tools/kiem_truyen.py` đọc thẳng các bảng này, nên sửa bảng là sửa luật). Cột `%` = vị trí **bắt đầu** của nhịp tính theo tổng thời lượng; máy cho lệch ±10%.

Chung cho mọi khung:
- **Bộ đếm luôn có** (xương sống), nhưng mỗi khung một kiểu.
- Luật chữ trên hình giữ nguyên: kể chuyện thì quá khứ ngôi thứ ba, tối đa 9 từ, cặp câu đối, 1–3 câu cuối chuyển sang "you". Giọng cám dỗ dịu dàng, hợp lý, leo thang, yếu dần.
- Chiều sâu cảm xúc (ước mơ gài đầu, vật biểu tượng 3 lần, gài – trả), câu móc, độ dài và giữ chân: xem `cau-truc.md`.
- Ghi tên nhịp vào dòng `# TRUYỆN: nhịp <tên>` ở cảnh mở nhịp (tên đúng như cột Nhịp).

**Chọn khung theo đề tài** (skill đề xuất 1 khung + lý do, người dùng đổi được):

| Đề tài | Hợp nhất | Cũng hợp |
|---|---|---|
| điện thoại / dopamine, lust, game | Vực dậy | Vòng lặp (tái nghiện), Hai cuộc đời |
| trì hoãn, sợ thất bại, vùng an toàn | Tiếc nuối | Thư gửi bản thân, Hai cuộc đời |
| lười / dậy sớm, kỷ luật | Hai cuộc đời | Vực dậy |
| cô đơn, người cũ | Thư gửi bản thân | Vực dậy |
| rượu / vape, ăn uống | Vòng lặp | Tiếc nuối |
| thời gian / tiếc nuối | Tiếc nuối | Thư gửi bản thân |

Lý do ghi 1 câu (vd: "trì hoãn không có cú sụp rõ ràng mà là mất dần → Tiếc nuối hợp hơn Vực dậy"). Tránh trùng khung + kết mà đối thủ đã dùng cho đề tài đó (xem `phan-tich/`).

---

## 1. Vực dậy (`vuc-day`)
Nhân vật sa vào thói xấu, chạm đáy, một khoảnh khắc người thật kéo dậy, làm lại. Kết hy vọng.
- **Bộ đếm:** DAY N tăng → gạch về 0 ở Đáy → đếm lại (DAY 1) ở Đứng lên. Biến thể: đếm ngày lãng phí rồi quay về DAY 1; DAY N kèm tên thói quen mới ("DAY 4 · RUN").
- **Kết:** hy vọng, câu cuối nói với "you".
- **Vật biểu tượng gợi ý:** mới / đang dùng → bỏ quên → dùng lại.

| Nhịp | % | Làm gì |
|---|---|---|
| Móc | 0 | Câu móc (xem kiểu câu móc). Chưa có bóng đen. |
| Ước mơ | 5 | 1–3 cảnh đời thường có ước mơ hiện bằng hình; vật biểu tượng lần 1; gài. |
| Sa ngã | 15 | Bóng đen thì thầm, nhượng bộ từng chút, bộ đếm chạy; 1 montage "ngày qua ngày"; vật lần 2 (bị bỏ quên). |
| Đáy | 40 | Cái giá hiện hình, bộ đếm gạch về 0 (sụp), 1 câu đau nhất rồi im lặng. |
| Bước ngoặt | 58 | Khoảnh khắc người thật; một việc nhỏ khác đi. |
| Đứng lên | 70 | Montage làm lại, bộ đếm đếm lại; bóng đen yếu dần rồi vỡ; vật lần 3 (dùng lại); trả. |
| Thẻ kết | 92 | THẺ KẾT + KÊU GỌI. |

Máy kiểm: dem=reset; ket=hy-vong,mo; sup=1; nguoi=1

## 2. Tiếc nuối / cảnh tỉnh (`tiec-nuoi`)
Nhân vật mãi "để mai", thời gian trôi tới khi nhận ra đã quá muộn cho chính giấc mơ đó. **Không** cho nhân vật vực dậy; cái giá được giữ nguyên. Hy vọng được **trao cho người xem** ở câu cuối ("you still have time.").
- **Bộ đếm:** thời gian sống tăng, không về 0: `AGE 17 → 34`, `YEARS LOST 0 → 12`, hoặc 2 dòng `AGE 17; YEARS LEFT 13`. Mỗi lần nhảy tuổi là 1 biến cố.
- **Kết:** tiếc nuối (cho nhân vật) + 1–2 câu "you" trao hy vọng cho người xem. Đề tài nặng: thêm dòng hỗ trợ ở mô tả.
- **Vật biểu tượng gợi ý:** mới tinh → phủ bụi → cho đi / thấy người khác dùng.
- **Không dùng:** cảnh tự hại, tuyệt vọng không lối ra.

| Nhịp | % | Làm gì |
|---|---|---|
| Móc | 0 | Câu móc. Thường là câu hứa hẹn ("He had plenty of time.") hoặc cảnh cuối đặt lên đầu. |
| Ước mơ | 5 | Tuổi trẻ, ước mơ hiện bằng hình, vật lần 1 (mới); gài. |
| Để mai | 15 | Vòng lặp "để mai": cám dỗ dịu ("next year."), tuổi nhảy, mỗi vòng ngắn hơn; vật lần 2 (bụi). |
| Nhận ra | 45 | Nhân vật thấy người khác sống giấc mơ đó / thấy mình trong gương; tuổi lớn; sụp (cái giá). |
| Cái giá | 65 | Thử lại nhưng quá muộn cho giấc mơ này; lặng; khoảnh khắc người thật (gia đình, bạn cũ) cho thấy điều đã mất; vật lần 3. |
| Trao lại | 85 | Quay sang người xem: 1–2 câu "you" trao hy vọng; trả (hình mở đầu lặp lại với nghĩa mới). |
| Thẻ kết | 94 | THẺ KẾT + KÊU GỌI. |

Máy kiểm: dem=tang; ket=tiec-nuoi; sup=1; nguoi=1

## 3. Hai cuộc đời song song (`song-song`)
Cùng một người, một ngã rẽ, hai lựa chọn chạy song song (X VS Y). Bộ dựng chưa chia đôi khung → **xen kẽ** cảnh nhánh A / nhánh B, cùng mốc thời gian, bộ đếm 2 dòng.
- **Bộ đếm:** 2 dòng đối nghịch, cùng hiện: `SCROLLED 2,140 HOURS; TRAINED 2,140 HOURS`, `A: DAY 300; B: DAY 300`, hoặc `SEEN 1,388; KNOWN 0`.
- **Kết:** mở (người xem chọn) hoặc hy vọng (hai nhánh hội tụ ở hiện tại). Tiêu đề hợp công thức X VS Y.
- **Vật biểu tượng gợi ý:** cùng 1 vật ở 2 nhánh, 2 số phận (bóng rổ bám bụi / bóng rổ mòn vì dùng).
- Ghi nhánh vào `# TRUYỆN: nhánh A` / `nhánh B`; màu nhấn có thể khác nhau nhờ đồ vật (đèn bàn ấm vs ánh điện thoại xanh).

| Nhịp | % | Làm gì |
|---|---|---|
| Móc | 0 | Một khoảnh khắc, hai lựa chọn ("One night. Two choices."). |
| Ngã rẽ | 6 | Cảnh rẽ nhánh; ước mơ chung hiện bằng hình; vật lần 1; gài. |
| Song song | 15 | Xen kẽ A / B cùng mốc giờ, bộ đếm 2 dòng tách dần; cám dỗ nói với nhánh A. |
| Phân kỳ | 55 | Khoảng cách lớn rõ; cả hai nhánh đều có cái giá (A mất bạn, B đau vì tập); sụp ở nhánh A; vật lần 2 hai số phận. |
| Hội tụ | 78 | Hai nhánh gặp nhau ở cùng 1 nơi (gương, cùng con phố); khoảnh khắc người thật; vật lần 3; trả. |
| Thẻ kết | 93 | THẺ KẾT dạng "X VS Y." + KÊU GỌI. |

Máy kiểm: dem=2dong; ket=mo,hy-vong; sup=1; nguoi=1

## 4. Vòng lặp (`vong-lap`)
Phim kết **đúng ở cảnh mở đầu**, chỉ khác **một chi tiết** (điện thoại đã cất vào ngăn kéo, báo thức tắt trước khi reo…). Hợp đề tài tái nghiện.
- **Bộ đếm:** bị gạch về DAY 1 nhiều lần (mỗi vòng 1 lần), mỗi vòng ngắn hơn; hoặc `LOOP 1 / 2 / 3`.
- **Kết:** vòng lặp — cảnh cuối = cảnh đầu (cùng bối cảnh, cùng góc) + 1 chi tiết khác, ghi `# TRUYỆN: khác <chi tiết>`. Chi tiết đó là câu trả lời; có thể kèm 1 câu "you".
- **Vật biểu tượng gợi ý:** cùng 1 vật ở cùng 1 chỗ mỗi vòng, vòng cuối khác vị trí / trạng thái.

| Nhịp | % | Làm gì |
|---|---|---|
| Mở vòng | 0 | Cảnh mở đầu cụ thể (bối cảnh, giờ, vật); câu móc; ước mơ hiện bằng hình; gài. |
| Vòng 1 | 12 | Cố gắng, cám dỗ, gục, quay về cảnh mở đầu; bộ đếm về DAY 1 (sụp). |
| Vòng 2 | 38 | Lặp nhanh hơn, cắt ngắn hơn; nhân vật bắt đầu nhận ra vòng lặp (móc lại); vật lần 2. |
| Lệch vòng | 62 | Khoảnh khắc người thật; một lựa chọn nhỏ khác đi. |
| Khép vòng | 85 | Cảnh mở đầu lặp lại y hệt, trừ 1 chi tiết (khác); vật lần 3; trả. |
| Thẻ kết | 93 | THẺ KẾT + KÊU GỌI. |

Máy kiểm: dem=lap; ket=vong-lap,hy-vong; sup=1; nguoi=1; vong=1

## 5. Thư gửi bản thân / nhìn lại (`thu-gui`)
Bản thân già hơn (hoặc tương lai) viết cho bản thân trẻ. Lời thư hiện như **chữ trong thế giới phim** (sổ tay viết tay, tin nhắn `@` từ "me, 2046") nên chữ kể chuyện `>` vẫn giữ thì quá khứ ngôi thứ ba.
- **Bộ đếm:** năm / tuổi: `2026 → 2046`, `AGE 20 → 40`, hoặc `YEARS SINCE 0 → 20`.
- **Kết:** hy vọng (bản thân trẻ nhận thư, làm 1 việc nhỏ) hoặc mở (người xem là người nhận).
- **Vật biểu tượng gợi ý:** vật người viết vẫn giữ (sổ tay, quả bóng cũ) → trong hồi tưởng còn mới → được trao lại.

| Nhịp | % | Làm gì |
|---|---|---|
| Móc | 0 | Lá thư / tin nhắn xuất hiện (sổ tay, chat). |
| Người viết | 8 | Lộ người viết (già hơn / tương lai); hồi tưởng ước mơ bằng hình; vật lần 1; gài. |
| Hồi tưởng | 20 | Lời thư (sổ tay / chat) xen cảnh tuổi trẻ phí thời gian; cám dỗ trong hồi tưởng; vật lần 2. |
| Điều ước | 55 | Người viết nói điều ước giá đã làm; cái giá lộ ra (sụp); khoảnh khắc người thật. |
| Trả lời | 78 | Bản thân trẻ đọc thư / người xem được hỏi; 1 việc nhỏ khác đi; vật lần 3; trả. |
| Thẻ kết | 93 | THẺ KẾT + KÊU GỌI. |

Máy kiểm: dem=tang; ket=hy-vong,mo; sup=1; nguoi=1; thu=1

---

## Thủ pháp học được (dùng được trong mọi khung)
Rút từ thư viện phân tích (`DOI-THU-SELFIMPROVE/phan-tich/`), chỉ học cách làm, không chép.
- **Ẩn dụ nhìn thấy được làm thước đo phụ:** một thứ trong cảnh đổi dần theo thói xấu (căn phòng tối dần, kệ đồ vơi dần, cửa sổ từ nắng sang mưa) song song với bộ đếm. Bộ dựng làm được: đổi `sky` cửa sổ, đèn bàn tắt / bật, `dim`, lịch tô dần. (Đổi cả cảnh sang màu xám: chưa hỗ trợ.)
- **Bộ đếm kèm tên việc:** `DAY 4 · RUN`, `DAY 10 · READ` biến phần làm lại thành danh sách người xem làm theo được.
- **Đếm ngược theo giờ trong 1 ngày** cho montage nghiện: 2:14 PM → 3:47 AM (cận đồng hồ / thanh trạng thái điện thoại).
- **Màn hình tắt phản chiếu mặt** ở bước ngoặt (`cận điện thoại, màn tắt`).
- **Đoạn giải thích giữa phim** làm móc lại (đổi nhịp, cho người xem 1 ý để chia sẻ): bộ dựng chưa có mẫu đồ thị → dùng `cận lịch` / bộ đếm / sổ tay vẽ chữ.
- **Gài – trả bằng người + vật:** người bạn + món đồ ở cảnh 2 quay lại ở cảnh cuối.

## Vật biểu tượng bộ dựng vẽ được
Cầm theo người: điện thoại, ô, sách, quả bóng (rổ), cặp, cốc. Trong bối cảnh: đồng hồ báo thức, lịch, đèn bàn, laptop, sổ tay (cận), gương (nứt được), bao cát, tạ, cửa phòng, cửa neon, ghế băng sân bóng, rổ bóng, cầu thang, đỉnh đồi, trạm xe buýt, cửa sổ (trăng / mưa / bình minh). Ảnh trong feed điện thoại: xem `kho-canh.md`.
Vật khác (đàn guitar, giá vẽ, diều, máy chơi game…): chọn vật gần nhất ở trên, hoặc ghi dòng `# cần vẽ thêm: <vật>` trong file 01 để người dựng biết.
