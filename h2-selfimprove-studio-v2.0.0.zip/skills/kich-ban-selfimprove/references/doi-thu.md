# Theo dõi kênh lớn (đối thủ)

Hai công cụ trong `tools/` của skill này (Python 3.8+, không cài thêm gói): `doi_thu.py` (quét, nhập, báo cáo, kiểm trùng) và `phan_tich.py` (phân tích 1 video; cần `ffmpeg`, `ffprobe` — studio đã có, hoặc đặt biến `H2_FFMPEG`, `H2_FFPROBE`). Dùng `python3` nếu `python` không phải Python 3. `<D>` = thư mục người dùng đã kết nối.

## Thư mục `<D>/DOI-THU-SELFIMPROVE/`
| File | Nội dung |
|---|---|
| `kenh.txt` | Kênh theo dõi, mỗi dòng 1 link. Tạo tự động lần đầu với Day One Films + Monk Mode Films. Người dùng thêm / xoá dòng tuỳ ý. |
| `video.csv` | Mỗi video 1 dòng, **cộng dồn** (không xoá video cũ): kênh, tiêu đề, ngày đăng (`ngay_uoc` = 1 nếu là ngày ước tính), lượt xem, lượt thích, độ dài, loại (dài / short / sắp chiếu), link, thumbnail, tag, lượt xem / ngày, **điểm vượt trội** (lượt xem ÷ trung vị của chính kênh, cùng loại), đánh dấu (`VUOT TROI` ≥ 2, `HUT` ≤ 0,5; video < 7 ngày ghi "HUT (moi < 7 ngay)"), đề tài + công thức tiêu đề (tự xếp), nguồn, ngày thấy đầu, ngày cập nhật. Mở được bằng Excel. |
| `lich-su.csv` | Mỗi lần quét thêm 1 dòng / video (ngày, lượt xem, nguồn) → theo dõi tăng trưởng. |
| `lan-quet.csv` | Mỗi lần quét: thời gian, kênh, nguồn, số video, số mới, kết quả / lỗi. |
| `phan-tich/*.md` | Mỗi video đối thủ đã phân tích: bảng phân loại + tóm tắt bằng lời của mình + ≤ 3 câu trích ngắn. |
| `bao-cao/bao-cao-<ngày>.md` | Báo cáo xu hướng. |
| `.tam/`, `.cache/` | Tạm (khung hình, bản chép chữ — tự xoá sau khi ghi phân tích) và mã kênh đã tra. |

File cũ `DOI-THU-SELFIMPROVE.txt` (trước 1.7.0) không dùng nữa; để nguyên, không xoá.

## Tầng 1 — dữ liệu video (tự động, không hỏi người dùng)
Chạy khi người dùng nói "quét đối thủ", và trước khi gợi ý đề tài nếu lần quét cuối (`lan-quet.csv`) đã quá 3 ngày.

1. **Nguồn 1 — RSS:** `python tools/doi_thu.py quet --thu-muc <D>`. Mã thoát 0 = xong. Mã 2 = có kênh RSS hỏng (YouTube từng trả 404 cho RSS hàng loạt): làm ngay nguồn 2 cho từng kênh được liệt kê, không hỏi.
2. **Nguồn 2 — trình duyệt** (built-in browser, hoặc Claude in Chrome):
   - Mở `<link kênh>/videos` bằng `preview_start` (tab mới). Trang trống (khung trình duyệt đang ẩn) thì mở tab mới khác và đợi tới khi có link video (≤ 15 giây).
   - **Link video** (mã + tiêu đề + thời lượng): chạy JavaScript chỉ đọc thẻ `<a>` chuẩn của trang:
     ```js
     [...new Map([...document.querySelectorAll('a[href*="/watch?v="]')].map(a => [a.getAttribute('href').match(/v=([\w-]{11})/)[1], (a.getAttribute('aria-label') || a.textContent).trim().replace(/\s+/g, ' ')]).filter(x => x[1])).entries()].map(x => x.join('\t')).join('\n')
     ```
     Không chạy được JavaScript thì dùng `find "watch?v="` / `read_page` (dòng `link "Tiêu đề 3 minutes, 21 seconds" href="/watch?v=…"`). **Không đọc dữ liệu nội bộ của trang** (ytInitialData…).
   - **Chữ hiển thị** (lượt xem rút gọn, "7d ago", video sắp chiếu): `get_page_text`.
   - Ghi 2 file vào `DOI-THU-SELFIMPROVE/.tam/` rồi: `python tools/doi_thu.py nhap --thu-muc <D> --kenh <link kênh> --nguon trinh-duyet --link <link.txt> --trang <trang.txt>`.
   - Kênh > 30 video: cuộn xuống rồi lấy lại; muốn video nổi nhất mọi thời thì bấm tab "Popular".
3. **Nguồn 3 — tìm kiếm web** (trình duyệt không dùng được): `WebSearch` với `allowed_domains: ["youtube.com"]`, vài truy vấn (`"<tên kênh>" "An Animated Short Film"`, tên kênh + đề tài). Chép mọi link `watch?v=` vào 1 file rồi `nhap --nguon tim-kiem --link <file>`. Video của kênh khác tự bị loại (đối chiếu thẻ tác giả trên trang video).
4. **Làm giàu (tự động, mọi nguồn có mã video):** `doi_thu.py` mở từng trang xem video và đọc thẻ chuẩn schema.org (lượt xem, lượt thích, ngày đăng, thời lượng, tag, ảnh). Trang video không đọc được → giữ số ước tính từ trang kênh (`ngay_uoc = 1`).
5. Báo người dùng mỗi kênh 1 dòng: **nguồn đã dùng, số video, số video mới**, bao nhiêu video giữ số ước tính. Xoá file trong `.tam/`.

Thử nhánh dự phòng: `quet --gia-lap-loi rss`, `nhap --gia-lap-loi trang-video`.

## Tầng 2 — phân tích kịch bản 1 video (khi người dùng đưa file .mp4 hoặc ảnh chụp màn hình)
1. `python tools/phan_tich.py cat --video <file> --thu-muc <D> --ten <kenh-tu-khoa>` (ảnh chụp: `--anh <ảnh hoặc thư mục>`). Máy cắt cảnh tự động (so khung cách 0,25 giây, ngưỡng theo chính video), lấy khung (cảnh dài thêm 1 khung / 2,5 giây), làm ảnh tổng hợp 4×3 có nhãn khung (`c07`, `c07b`…) + giây, đo âm lượng, khoảng im lặng, nhịp nhạc ước.
2. Mở **từng** `sheet_XX.jpg` (Read), đọc chữ trên hình. Chép `doc-mau.json` thành `doc.json` và điền:
   - `tieu_de`, `kenh`, `video_id` (lấy trong `video.csv` nếu có).
   - Mỗi khung có thông tin: `loai` (`narr` kể chuyện, `tempt` giọng cám dỗ, `chat` tin nhắn, `big` chữ to, `hud` bộ đếm, `say` bong bóng, `card` thẻ kết, `cta`), `chu` (chữ đúng như trên hình — bản chép **tạm**, bị xoá sau bước 3), `dem` (vd `DAY 47`), `boi_canh`, `nhip` (tên nhịp ở khung mở nhịp: Móc / Sa ngã / Đáy / Bước ngoặt / Đứng lên / Kết / Thẻ kết, hoặc nhịp của khung truyện khác). Khung trống thì bỏ qua.
   - Ranh giới cảnh: khung mở cảnh mới mà máy chưa cắt (đổi bối cảnh, đổi mốc thời gian) → `"moi_canh": true`; máy cắt thừa → `false`.
   - `phan_loai` theo bảng dưới; `cu_sup_khung` = nhãn khung lúc cú sụp; `chu_thumbnail`: mở ảnh `https://i.ytimg.com/vi/<mã>/hqdefault.jpg` bằng trình duyệt nếu có mã.
   - `tom_tat` 3–5 câu **lời của mình** (tiếng Việt); `vi_sao` 1–3 câu giả thuyết (dùng số liệu ×TV); `trich` tối đa 3 câu ngắn (≤ 12 từ) làm ví dụ phong cách.
3. `python tools/phan_tich.py ghi --tam <thư mục .tam> --doc <doc.json> --thu-muc <D>`. Máy dựng lại cảnh, kiểm bảng phân loại, nối với `video.csv`, ghi `phan-tich/<kênh>-<từ khoá>.md`, **kiểm không lọt nguyên văn** (dòng ≥ 4 từ hoặc cụm 6 từ của video xuất hiện ngoài 3 câu trích → từ chối ghi), in **dàn cảnh dựng lại** (có chữ) để đưa người dùng xem trong cuộc trò chuyện — **không lưu**, rồi xoá `.tam`.
4. Trả lời người dùng: dàn cảnh dựng lại (rút gọn nếu dài), bảng phân loại, 2–3 ý "học được gì" (cấu trúc, không phải câu chữ).

### Bảng phân loại cố định
| Trường | Giá trị (ghi mã hoặc tên tiếng Việt) |
|---|---|
| Đề tài | `lust` lust / porn · `game` · `dien-thoai` điện thoại / dopamine · `mang-xa-hoi` so sánh mạng xã hội · `tinh-yeu` người yêu / người cũ · `co-don` cô đơn · `chat` rượu / vape / chất · `an-uong` ăn uống · `tri-hoan` trì hoãn · `luoi` lười / thoải mái / dậy sớm · `suy-nghi` nghĩ quá nhiều · `so-that-bai` sợ thất bại · `tiec-nuoi` thời gian / tiếc nuối · `ky-luat` kỷ luật / động lực chung · `khac` |
| Khung truyện | `vuc-day` vực dậy · `tiec-nuoi` tiếc nuối / cảnh tỉnh · `song-song` hai cuộc đời song song · `vong-lap` vòng lặp · `thu-gui` thư gửi bản thân / nhìn lại · `khac` |
| Kiểu câu móc | `chu-man-den` chữ trên màn đen · `hinh-manh` cảnh hình ảnh mạnh ngay giây đầu · `cuoi-len-dau` cảnh cuối đặt lên đầu · `bo-dem-sup` bộ đếm sụp ngay đầu rồi tua lại · `cau-hoi` câu hỏi thẳng người xem · `khac` |
| Kiểu bộ đếm | `day-n` DAY N tăng · `dem-nguoc` DAYS LEFT · `thoi-gian-mat` HOURS / YEARS LOST · `tuoi` AGE · `hai-dong` 2 dòng đối nghịch · `dong-ho` giờ đồng hồ · `khong-co` · `khac` |
| Cú sụp | nhãn khung → máy tính % thời lượng |
| Khoảnh khắc người thật | `tin-nhan-ban` · `nguoi-la` · `gia-dinh` · `nguoi-yeu` · `ban-than` (quá khứ / tương lai) · `khong-co` · `khac` |
| Kiểu kết | `hy-vong` · `tiec-nuoi` · `mo` · `vong-lap` |
| Vật biểu tượng | tự ghi (vật lặp ≥ 2 lần và đổi theo truyện) hoặc "không có" |
| Tự tính | số cảnh, nhịp TB (giây / cảnh), % cảnh có chữ theo loại, mốc bộ đếm, dàn nhịp %, nhạc (im lặng, to lên / nhỏ xuống, BPM ước), công thức tiêu đề, lượt xem + ×TV |

## Báo cáo xu hướng
`python tools/doi_thu.py bao-cao --thu-muc <D> [--ngay 90]` → in và lưu `bao-cao/bao-cao-<ngày>.md`: (1) lần quét + nguồn, video mới từ lần quét trước; (2) top vượt trội 90 ngày; (3) đề tài / công thức tiêu đề đang ăn (số video, số kênh, ×TV trung vị, video tốt nhất) + khung / kết / câu móc / bộ đếm từ thư viện phân tích (cần ≥ 3 video); (4) khoảng trống: ít người làm mà nổ, kênh này làm dở trong khi kênh kia nổ, đề tài đang dày, đề tài đối thủ chưa làm; (5) đề tài kênh mình đã làm (`projects/`); (6) gợi ý lịch quét.

Trả lời người dùng **ngắn**: 4–6 gạch đầu dòng có số (top vượt trội, đề tài ăn, khoảng trống, chỗ trùng với kênh mình) + đường dẫn file báo cáo.

**Lịch quét tuần:** sau báo cáo, nếu chưa có việc định kỳ, hỏi 1 lần "Tạo lịch quét đối thủ mỗi tuần?". Chỉ khi người dùng đồng ý mới tạo (công cụ việc định kỳ / scheduled task): mỗi thứ Hai 8:00, nội dung "quét đối thủ trong <D>: chạy doi_thu.py quet (RSS hỏng thì trình duyệt), rồi bao-cao, tóm tắt 5 dòng". Không tự tạo.

## Dùng dữ liệu khi viết
- **Gợi ý đề tài** (SKILL mục 6): mỗi đề tài ghi **bằng chứng** (kênh, tiêu đề, lượt xem, ×TV của video đối thủ cùng loại) và **góc khác biệt** (khung / kết / vật / góc nhìn mà đối thủ chưa dùng cho đề tài đó). Đề tài "đối thủ chưa làm" ghi rõ là chưa có bằng chứng view.
- **Trước khi giao kịch bản:** đầu file 01 có `ĐỀ TÀI`, `KHUNG`, `KẾT`, `VẬT`; chạy `python tools/doi_thu.py trung-lap --thu-muc <D> --phim <file 01>`:
  - `TRUNG 4/4` (cùng đề tài + khung + kết + vật với 1 video đã phân tích) → đổi **ít nhất 2 trong 4** theo gợi ý máy in ra, chạy lại.
  - `LOI chép câu` (dùng lại câu trích của đối thủ, kể cả ở thẻ kết) → viết lại câu.
  - `CANH BAO tiêu đề` (trùng tiêu đề đối thủ) → đổi tiêu đề hoặc thêm dấu ấn kênh.
  - Ghi 1 dòng kết quả vào 02-PACKAGE.

## Chống chép
- Không lưu nguyên văn chữ của đối thủ: file phân tích chỉ có bảng phân loại, tóm tắt bằng lời của mình và ≤ 3 câu trích ≤ 12 từ. Bản chép chữ tạm bị xoá sau khi ghi.
- Không dùng lại câu, cảnh đặc trưng, câu chuyện hay tên kênh đối thủ trong kịch bản, tiêu đề, mô tả. Chỉ học **loại** đề tài và **cấu trúc**.
