"""mix.py — tron voice + nhac nen + hieu ung am thanh theo story/shots.json, chuan -14 LUFS, ghep vao video.
  python tools/mix.py --project projects/<ten>            -> build/mix.wav (+ out/<tieu de>.mp4 neu da co build/video_silent.mp4)
shots.json:
  "music": [{"start":0,"end":42,"bed":"curious","gainDb":0}, {"start":42,"end":50,"bed":"none"}]   bed: wonder|curious|tension|emotional|triumph|mystery|none
  config.json "music": { "flow": true (mac dinh: nhac lap noi lien, doi nhac hoa dan, quay lai nhac cu thi phat tiep), "xfade": 2.5 (giay hoa am),
                         "resume": true, "unique": true (nhac rieng tung du an neu bo phong cach co), "seed": <so doi ban nhac> }
  shot "sfx": [{"at":0.3,"name":"whoosh_fast","gain":-6}]  (at = giay tinh tu dau shot; name = ten file trong audio/sfx, khong can duoi)
  Khong co timeline/voice.wav (phim khong loi doc) thi chi tron nhac + SFX.
  shot "notes" co chu DROP -> tat nhac trong shot do.
"""
import argparse, glob, os, re, subprocess, sys
import numpy as np
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import SR, load_audio, save_wav, read_json, run

KIT = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
ap = argparse.ArgumentParser(); ap.add_argument("--project", required=True); ap.add_argument("--no-video", action="store_true")
a = ap.parse_args(); P = a.project
cfg = read_json(os.path.join(P, "config.json"), {}); story = read_json(os.path.join(P, "story", "shots.json"), {})
shots = story.get("shots", []); dur = story.get("duration") or (shots[-1]["end"] if shots else 0)
N = int(dur * SR) + SR
# phim khong loi doc (vd pack dem): khong co timeline/voice.wav -> chi tron nhac + SFX
vpath = os.path.join(P, "timeline", "voice.wav")
voice = load_audio(vpath) if os.path.exists(vpath) else np.zeros(N); voice = np.pad(voice, (0, max(0, N - len(voice))))[:N]
db = lambda x: 10 ** (x / 20)
def loud(y):
    try:
        import pyloudnorm as pyln
        return pyln.Meter(SR).integrated_loudness(y.astype(np.float64))
    except Exception:
        e = y[np.abs(y) > 1e-4]; return 20 * np.log10(np.sqrt(np.mean(e ** 2)) + 1e-9) - 0.7 if len(e) else -70
if np.any(voice): voice *= db(-16 - loud(voice))
log = []
def smooth(x, k):  # trung binh truot (nhanh, thay np.convolve rat cham voi phim dai)
    k = max(1, int(k)); c = np.cumsum(np.concatenate([np.full(k // 2, x[0]), x, np.full(k - k // 2, x[-1])])); c = np.insert(c, 0, 0)
    return (c[k:k + len(x)] - c[:len(x)]) / k
def bed_info(path):  # nhac lap: bpm (tu ten file) + doan mo / nho dan co san o dau, cuoi file can bo khi lap
    side = os.path.splitext(path)[0] + ".json"; meta = read_json(side, {}) if os.path.exists(side) else {}
    m = re.search(r"(\d+)bpm", os.path.basename(path)); drone = "drone" in os.path.basename(path)
    return meta.get("bpm", float(m.group(1)) if m else None), meta.get("trim", [2.0, 2.0] if drone else [1.0, 3.0]), bool(meta.get("loop"))
def loop_unit(y, trim, X, seamless=False):  # noi duoi vao dau bang hoa am -> lap bao nhieu vong cung khong co cho hut
    if seamless: return y                                               # nhac tao san de lap lien (nhac rieng du an)
    h, tl = int(trim[0] * SR), int(trim[1] * SR); body = y[h:len(y) - tl] if len(y) > h + tl + 4 * X else y
    M = len(body) - X; u = body[:M].copy(); k = np.arange(X) / X
    u[:X] = body[:X] * np.sin(k * np.pi / 2) + body[M:M + X] * np.cos(k * np.pi / 2)
    return u

# ---------- nhac nen
music = np.zeros(N)
mcfg = cfg.get("music", {"enabled": True})
if mcfg.get("enabled", True):
    beds = {os.path.basename(f).split("_")[1]: f for f in glob.glob(os.path.join(KIT, "audio", "music", "bed_*.wav"))}
    # khong ghi nhac: "curious" (nhac chung); cai gon khong co nhac chung -> "sad" (nhac rieng du an, tu sinh)
    secs = story.get("music") or [{"start": 0, "end": dur, "bed": "curious" if "curious" in beds or not cfg.get("pack") else "sad"}]
    if mcfg.get("file"): beds["user"] = os.path.join(P, mcfg["file"])
    # nhac rieng tung du an: bo phong cach co packs/<pack>/audio.py --project thi tao (1 lan, theo ten phim + music.seed) vao build/music
    pk = os.path.join(KIT, "packs", str(cfg.get("pack", "")), "audio.py")
    if mcfg.get("unique", True) and not mcfg.get("file") and cfg.get("pack") and os.path.exists(pk) and "--project" in open(pk, encoding="utf-8").read():
        want = sorted({str(s.get("bed")) for s in secs} - {"none", "drop", "None"})
        r = subprocess.run([sys.executable, pk, "--project", os.path.abspath(P), "--beds", ",".join(want), "--seed", str(int(mcfg.get("seed", 0)))], capture_output=True, text=True)
        if r.returncode: log.append("khong tao duoc nhac rieng (dung nhac chung): " + r.stderr.strip()[-200:])
        for f in glob.glob(os.path.join(P, "build", "music", "bed_*.wav")): beds[os.path.basename(f).split("_")[1]] = f
    gate = np.ones(N)
    for s in shots:
        if "DROP" in str(s.get("notes", "")).upper(): gate[int(s["start"] * SR):int(s["end"] * SR)] = 0
    cache = {}
    def bed_audio(name):
        if name not in cache:
            y = load_audio(beds[name]); y *= db(-16 + float(mcfg.get("gainDb", -13)) - loud(y)); cache[name] = y
        return cache[name]
    if not mcfg.get("flow", True):  # cach cu: moi doan phat tu dau bai, vao / ra 1,2 giay, lap thang file
        for sec in secs:
            name = sec.get("bed", "curious")
            if name in ("none", "drop"): continue
            if mcfg.get("file"): name = "user"
            if name not in beds: log.append(f"khong co nhac '{name}'"); continue
            y = bed_audio(name); a0, a1 = int(sec["start"] * SR), min(N, int(sec["end"] * SR)); L = a1 - a0
            if L <= 0: continue
            seg = np.tile(y, L // len(y) + 1)[:L] * db(float(sec.get("gainDb", 0)))
            f = min(int(1.2 * SR), L // 3); seg[:f] *= np.linspace(0, 1, f); seg[-f:] *= np.linspace(1, 0, f)
            music[a0:a1] += seg
    else:
        # nhac lien mach: gop doan lien nhau cung loai nhac; doi nhac -> hoa am dang cong suat xfade giay quanh moc, vao nhac moi dung dau o nhip;
        # quay lai loai nhac da nghe -> phat tiep cho dang do; canh "none" -> nho dan / lon dan 1,5 giay (im lang co chu y)
        X0 = int(float(mcfg.get("xfade", 2.5)) * SR); Q = int(1.5 * SR); units, pos, segs = {}, {}, []
        for sec in secs:
            name = "user" if mcfg.get("file") and sec.get("bed") not in ("none", "drop") else sec.get("bed", "curious")
            a0, a1 = int(sec["start"] * SR), min(N, int(sec["end"] * SR))
            if a1 <= a0: continue
            if name not in ("none", "drop") and name not in beds: log.append(f"khong co nhac '{name}'"); name = "none"
            if segs and segs[-1]["name"] == name and abs(segs[-1]["a1"] - a0) < SR // 10: segs[-1]["a1"] = a1; segs[-1]["g"].append((a0, a1, float(sec.get("gainDb", 0)))); continue
            segs.append({"name": name, "a0": a0, "a1": a1, "g": [(a0, a1, float(sec.get("gainDb", 0)))]})
        for i, s in enumerate(segs):
            if s["name"] in ("none", "drop"): continue
            pm = i > 0 and segs[i - 1]["name"] not in ("none", "drop") and abs(segs[i - 1]["a1"] - s["a0"]) < SR // 10
            nm = i + 1 < len(segs) and segs[i + 1]["name"] not in ("none", "drop") and abs(segs[i + 1]["a0"] - s["a1"]) < SR // 10
            L = s["a1"] - s["a0"]; X = min(X0, L // 2)
            s0 = max(0, s["a0"] - (X // 2 if pm else 0)); e1 = min(N, s["a1"] + (X // 2 if nm else 0))
            fi = (X if pm else (int(1.2 * SR) if s["a0"] < SR else Q)); fo = (X if nm else (int(1.2 * SR) if s["a1"] >= N - SR - 1 else Q))
            fi, fo = min(fi, (e1 - s0) // 2), min(fo, (e1 - s0) // 2)
            bpm, trim, seamless = bed_info(beds[s["name"]])
            if s["name"] == "user": trim = [0, 0]                                             # nhac rieng cua nguoi dung: khong cat dau / cuoi
            if s["name"] not in units: units[s["name"]] = loop_unit(bed_audio(s["name"]), trim, int(2.0 * SR), seamless)
            u = units[s["name"]]; p = pos.get(s["name"], 0) if mcfg.get("resume", True) else 0
            if bpm: bar = int(4 * 60 / bpm * SR); p = int(round(p / bar)) * bar   # vao dung dau o nhip
            seg = u[(p + np.arange(e1 - s0)) % len(u)].copy()
            env = np.zeros(e1 - s0)
            for g0, g1, gd in s["g"]: env[max(0, g0 - s0):max(0, g1 - s0)] = db(gd)
            env[:max(0, s["g"][0][0] - s0)] = db(s["g"][0][2]); env[max(0, s["g"][-1][1] - s0):] = db(s["g"][-1][2])
            if len(s["g"]) > 1: env = smooth(env, SR)                                         # doi gainDb giua chung -> doi dan 1 giay
            k = np.arange(fi) / max(1, fi); env[:fi] *= np.sin(k * np.pi / 2) if pm else 0.5 - 0.5 * np.cos(k * np.pi)
            k = np.arange(fo) / max(1, fo); env[len(env) - fo:] *= np.cos(k * np.pi / 2) if nm else 0.5 + 0.5 * np.cos(k * np.pi)
            music[s0:e1] += seg * env; pos[s["name"]] = (p + (s["a1"] - s0)) % len(u)
    # tat / mo nhac em (0.25 s)
    music *= smooth(gate, int(0.25 * SR))

# ---------- hieu ung am thanh
sfx = np.zeros(N); scfg = cfg.get("sfx", {"enabled": True})
lib = {os.path.splitext(os.path.basename(f))[0]: f for f in glob.glob(os.path.join(KIT, "audio", "sfx", "*.wav"))}
def find(name):
    if os.path.exists(os.path.join(P, name)): return os.path.join(P, name), 0.0
    for k, f in lib.items():
        if k == name or k.startswith(name + "_") or k.startswith(name):
            m = re.search(r"hitAt(\d+)ms", k); return f, (int(m.group(1)) / 1000 if m else 0.0)
    return None, 0
cues = [(s["start"] + c.get("at", 0), c) for s in shots for c in s.get("sfx", [])] + [(c["t"], c) for c in story.get("sfx", [])]
if scfg.get("enabled", True):
    cache = {}
    for t, c in cues:
        f, off = find(c["name"])
        if not f: log.append(f"khong co sfx '{c['name']}'"); continue
        if f not in cache: cache[f] = load_audio(f)
        y = cache[f]; t0 = t - off - (0.12 if c["name"].startswith("whoosh") else 0)
        i0 = int(t0 * SR); y = y[max(0, -i0):]; i0 = max(0, i0); L = min(len(y), N - i0)
        if L > 0: sfx[i0:i0 + L] += y[:L] * db(float(c.get("gain", -8)) + float(scfg.get("gainDb", -4)))

mix = voice + music + sfx
pk = np.max(np.abs(mix)) + 1e-9
if pk > 0.95: mix = np.tanh(mix / pk * 1.5) / np.tanh(1.5) * 0.95
raw = os.path.join(P, "build", "mix_raw.wav"); save_wav(raw, mix)
out = os.path.join(P, "build", "mix.wav"); lufs = cfg.get("loudness", -14)
tmp = os.path.join(P, "build", "mix_ln.wav")
run(["ffmpeg", "-y", "-v", "error", "-i", raw, "-af", f"loudnorm=I={lufs}:TP=-1.5:LRA=11", "-ar", str(SR), "-ac", "2", tmp]); os.remove(raw)
# loudnorm 1 luot hay thieu ~1 dB: do lai va bu
r = subprocess.run(["ffmpeg", "-v", "info", "-i", tmp, "-af", "ebur128", "-f", "null", "-"], capture_output=True, text=True).stderr
m = re.findall(r"I:\s+(-?[\d.]+) LUFS", r); gain = (lufs - float(m[-1])) if m else 0.0
run(["ffmpeg", "-y", "-v", "error", "-i", tmp, "-af", f"volume={gain:.2f}dB,alimiter=limit=0.89:level=false", "-ar", str(SR), out]); os.remove(tmp)
print("Am thanh:", out, "|", "; ".join(sorted(set(log))) if log else "ok")
video = os.path.join(P, "build", "video_silent.mp4")
if os.path.exists(video) and not a.no_video:
    title = re.sub(r'[\\/:*?"<>|]', "", cfg.get("title", "video")).strip() or "video"
    os.makedirs(os.path.join(P, "out"), exist_ok=True); final = os.path.join(P, "out", title + ".mp4")
    run(["ffmpeg", "-y", "-v", "error", "-i", video, "-i", out, "-map", "0:v:0", "-map", "1:a:0", "-c:v", "copy", "-c:a", "aac", "-b:a", "192k", "-shortest", "-movflags", "+faststart", final])
    print("Video hoan chinh:", final)
