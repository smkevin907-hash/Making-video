// templates.js — mau canh cho phim khong loi doc. shots.json: { "tpl": "<ten>", "args": {...} }. Thoi gian "at" = giay tinh tu dau canh.
// Mau: scene (boi canh + nhan vat + giong noi) | phone | clock | calendar | face | note | card | black | cta
// Lop phu chung cho moi mau: texts, hud, fx, lights, cam (xem README trong references/mau-canh.md)
import { E, clamp, lerp, ease, kf, rng, noise, alpha, shade, mix, registerTemplate, text, measure, radGrad } from '/engine/core.js';
import { PAL, accent, fx, fy, fs, at, window01, safe, narr, tempt, say, big, stroke, light, beam, vignette, ln, box, oval, FONT_NARR, FONT_HAND, FONT_UI, fillAll, wrap, CAM, depth, obj, temptFont, classic, wave, worldGrade, asLayer, fitX } from './ink.js';
import { bean, lyingHead, head, bigHand, CAST, poseOf, poseDur, easePose, headK } from './bean.js';
import { set, rain, dust, calendar, digitClock } from './sets.js';
import { phone, bigClock, notebook, phoneHand } from './phone.js';
import { vanishSpec, vanishSnap, vanishDraw, vanishScreen, vanishLetters, BURST_PRE } from './vanish.js';

// ---------- may quay: cam = { from: [x, y, zoom], to: [x, y, zoom], at, dur, ease, hand, follow, lead } (x, y = diem nhin 0..1). shake = { at, amt, dur }
// hand: rung tay (troi cham + run rat nho, khong giat). 0 = may dung yen nhu ban cu, 1 = mac dinh (config "camHand"), 2 = cam tay ro.
// follow: ten nhan vat (who) -> may bam theo nguoi do theo chieu ngang, tre nhip nhe; lead: dat nguoi lech khoi giua (0..1 khung, + = phia truoc)
// Boi canh ve theo lop (ink.js depth): lop xa troi cham hon lop gan khi may di chuyen / rung.
// vi tri may (khong rung) o giay lt: dung cho may quay va de chu chon cho dung yen ca canh
export function camAt(lt, info) {
  const c = info.args.cam || {}, d = info.dur;
  const a0 = c.at ?? 0, dd = c.dur ?? (d - a0), k = (c.ease === 'linear' ? (x) => x : ease.sine)(clamp((lt - a0) / Math.max(0.1, dd)));
  const A = c.from || [0.5, 0.5, 1], B = c.to || (c.from ? c.from : [0.5, 0.5, info.args.push === false ? 1 : classic() ? 1.05 : 1.08]);   // 1.10: 1.05 qua cham tren khung toi (khoang toi, dem) -> ffmpeg do la dung hinh
  let z = lerp(A[2] ?? 1, B[2] ?? 1, k), cx = lerp(fx(A[0]), fx(B[0]), k), cy = lerp(fy(A[1]), fy(B[1]), k);
  if (info.followX) { let s = 0; for (let i = 0; i < 6; i++) s += info.followX(lt - i * 0.07); cx = s / 6 + (c.lead ?? 0) * E.W * (info.followDir || 1); }
  const hw = E.W / (2 * z), hh = E.H / (2 * z); return { z, cx: clamp(cx, hw, E.W - hw), cy: clamp(cy, hh, E.H - hh) };
}
export function camera(g, lt, info, fn) {
  const c = info.args.cam || {};
  const { z, cx, cy } = camAt(lt, info);
  let dx = 0, dy = 0; for (const s of [].concat(info.args.shake || [])) { const p = (lt - (s.at ?? 0)) / (s.dur ?? 0.45); if (p >= 0 && p < 1) { const amp = (s.amt ?? 1) * 18 * (1 - p); dx += noise(lt * 40, 1) * amp; dy += noise(lt * 40, 5) * amp; } }
  const hand = c.hand ?? E.cfg.camHand ?? 1, gt = info.globalT ?? lt;
  dx += (noise(gt * 0.23, 11) * 7 + noise(gt * 0.9, 12) * 1.4) * hand / z; dy += (noise(gt * 0.19, 21) * 5 + noise(gt * 0.8, 22) * 1.1) * hand / z;
  const rot = noise(gt * 0.17, 31) * 0.0022 * hand;
  Object.assign(CAM, { g, z, cx, cy, dx, dy, rot });
  g.save(); g.translate(E.W / 2, E.H / 2); if (rot) g.rotate(rot); g.scale(z, z); g.translate(-cx + dx, -cy + dy); fn(); g.restore();
  CAM.g = null;
}
// tien canh mo (fg): [{ kind: figure | post | plant | frame, x, y, s, color, blur }] — vat sat may, mo, troi nhanh hon (do sau 1,35)
const _fgc = new Map();
function drawFg(g, list) {
  for (const f of list || []) {
    const s = fs(f.s, 0.9), key = JSON.stringify([f.kind, s, f.color, f.blur]) + E.W;
    let c = _fgc.get(key);
    if (!c) {
      const w = Math.ceil(s * 0.9), h = Math.ceil(s * 1.1), q = 0.25, raw = document.createElement('canvas'); raw.width = Math.ceil(w * q) + 40; raw.height = Math.ceil(h * q) + 40;
      const r = raw.getContext('2d'); r.filter = `blur(${f.blur ?? 10}px)`; r.translate(20, 20); r.scale(q, q); r.fillStyle = f.color || '#07070a';
      if (f.kind === 'post') r.fillRect(w * 0.4, 0, w * 0.2, h);
      else if (f.kind === 'plant') for (let i = 0; i < 9; i++) { r.beginPath(); r.ellipse(w * (0.2 + 0.6 * ((i * 37) % 9) / 9), h * (0.3 + 0.5 * ((i * 53) % 7) / 7), w * 0.09, h * 0.25, (i - 4) * 0.25, 0, 7); r.fill(); }
      else if (f.kind === 'frame') { r.fillRect(0, 0, w * 0.12, h); r.fillRect(0, 0, w, h * 0.08); }
      else { r.beginPath(); r.arc(w * 0.5, h * 0.3, w * 0.22, 0, 7); r.fill(); r.beginPath(); r.ellipse(w * 0.5, h * 0.95, w * 0.48, h * 0.42, 0, Math.PI, 0); r.fill(); }   // figure: dau + vai
      c = raw; _fgc.set(key, c); if (_fgc.size > 20) _fgc.delete(_fgc.keys().next().value);
    }
    depth(g, f.depth ?? 1.35, () => { g.save(); g.imageSmoothingEnabled = true; g.drawImage(c, fx(f.x, 0.08) - s * 0.45 - 80, fy(f.y, 1.0) - s * 1.1 - 80 + s * 0.1, c.width * 4, c.height * 4); g.restore(); });
  }
}

// ---------- vi tri: so 0..1 | px | "moc" cua boi canh: bed.sit, bed.head, desk.seat, bus.seat, bench, table.left, table.right, top, door, neon, step:3, mirror
function anchor(M, v, axis, def) {
  if (typeof v === 'string') {
    let p = null; const [k, sub] = v.split('.');
    if (k.startsWith('step') && M.step) p = M.step(+(v.split(':')[1] || 0));
    else if (M[k]) p = sub ? M[k][sub] : (Array.isArray(M[k]) ? M[k] : M[k].seat || M[k].sit || [M[k].x, M.gy]);
    if (p) return axis === 'x' ? p[0] : p[1];
  }
  return axis === 'x' ? fx(v, def) : fy(v, def);
}
// ---------- chuyen dong muot: tu the, bieu cam, huong nhin doi dan theo moc [[giay, gia tri, giay chuyen?], ...]
// tu the luc lt: lay da -> vuot -> doi ve (easePose); doi moc khi dang chuyen thi noi tiep tu tu the dang co. dur 0 = doi ngay (nhu ban cu)
export function poseNow(lt, list, def, durDef, lag = 0) {
  let to = def, from = null, t0 = 0, d = 0;
  const now = (tt) => (from && d > 0 ? poseOf(to, from, easePose(clamp((tt - t0 - lag) / d))) : poseOf(to));
  for (const e of (list || []).slice().sort((p, q) => p[0] - q[0])) { if (lt < e[0]) break; const cur = now(e[0]); from = cur; to = e[1]; t0 = e[0]; d = e[2] ?? durDef ?? poseDur(cur, e[1]); }
  const p = now(lt);
  return p.drop < 0 ? { ...p, drop: 0 } : p;
}
// bieu cam luc lt: { face, fromFace, faceK (0..1), faceSince (giay tu luc doi) }
export function faceNow(lt, list, def, durDef) {
  let v = def, from = null, t0 = 0, d;
  for (const e of list || []) if (lt >= e[0]) { from = v; v = e[1]; t0 = e[0]; d = e[2]; }
  const D = d ?? durDef ?? 0.32;
  if (from === null || from === v || !(D > 0) || lt - t0 >= D) return { face: v, faceSince: from !== null ? lt - t0 : undefined };
  return { face: v, fromFace: from, faceK: ease.inOut((lt - t0) / D), faceSince: lt - t0 };
}
// huong nhin luc lt: quay dan trong dur giay (mat truot qua chinh dien, tay chan thu vao roi sang ben kia). turning 0..1 = dang giua vong quay
export function facingNow(lt, ev, f0, dur = 0.3) {
  let f = f0, from = f0, t0 = -1e9;
  const val = (tt) => (dur > 0 ? lerp(from, f, ease.inOut(clamp((tt - t0) / dur))) : f);
  for (const [t, v] of (ev || []).slice().sort((p, q) => p[0] - q[0])) { if (lt < t) break; if (v !== f) { from = val(t); f = v; t0 = t; } }
  const k = dur > 0 ? clamp((lt - t0) / dur) : 1;
  return { f: val(lt), turning: k < 1 ? Math.sin(Math.PI * k) * Math.abs(f - from) / 2 : 0, from: Math.sign(from) || 1 };
}
// quang di: tang toc -> deu -> giam toc (r = phan thoi gian tang / giam toc; 0 = deu tu dau den cuoi)
function travel(k, r) {
  if (!(r > 0)) return k; const vm = 1 / (1 - r), I = (u) => u * u * u - u * u * u * u / 2;
  return k < r ? vm * r * I(k / r) : k > 1 - r ? 1 - vm * r * I((1 - k) / r) : vm * (r / 2 + k - r);
}

// ---------- dong tac ke chuyen (act): xem R8 ben duoi
const _acts = new WeakMap();
function expandActs(ac) { let r = _acts.get(ac); if (!r) { r = buildActs(ac); _acts.set(ac, r); } return r; }
// act: [{ do, at, dur, ... }] -> them moc tu the / huong nhin / quang di / xoay than / do vat bay. Moi dong tac la 1 dong trong shots.json.
//   standUp | sitDown | collapse (guc dau -> quy goi) | fall (do sap xuong san) | throwPhone { to: [x, y] } | walkAway { dir, dur, run } | pant { dur }
function buildActs(ac) {
  const r = { poseAt: [], faceAt: [], facingAt: [], walks: [], rot: [], heavy: [], props: [], hideHold: Infinity, fast: [] };
  for (const e of ac.act || []) {
    const t = e.at ?? 0;
    if (e.do === 'standUp') { r.poseAt.push([t, 'sitfwd', 0.32], [t + 0.34, e.pose || 'stand', e.dur ?? 0.55]); }
    else if (e.do === 'sitDown') { r.poseAt.push([t, e.pose || 'sit', e.dur ?? 0.6]); }
    else if (e.do === 'collapse') { r.poseAt.push([t, 'slump', 0.35], [t + 0.45, 'headhold', 0.4], [t + 1.0, 'knees', e.dur ?? 0.55]); }
    else if (e.do === 'fall') { r.poseAt.push([t, 'slump', 0.25], [t + 0.3, 'lie', 0.35]); r.rot.push([t + 0.25, e.dur ?? 0.45]); r.fast.push([t + 0.35, 0.4]); }
    else if (e.do === 'throwPhone') {
      const rel = t + 0.36; r.poseAt.push([t - 0.15, 'stand', 0.2], [t, 'throw', 0.32], [rel - 0.02, 'release', 0.1], [rel + 0.45, 'stand', 0.5]); r.hideHold = Math.min(r.hideHold, rel);   // ha dien thoai khoi mat truoc khi vung tay
      r.props.push({ kind: 'phone', t0: rel, fly: e.fly ?? 0.6, to: e.to }); r.fast.push([rel - 0.08, 0.22]);
    }
    else if (e.do === 'walkAway') { const dir = e.dir ?? -(ac.facing ?? 1); r.facingAt.push([t, dir]); r.walks.push({ to: e.to ?? (dir > 0 ? 1.15 : -0.15), at: t + 0.35, dur: e.dur ?? 2.6, run: !!e.run, speed: e.speed }); }
    else if (e.do === 'pant') { const d = e.dur ?? 2; r.poseAt.push([t, 'pant', 0.5], [t + d, e.pose || 'stand', 0.6]); r.heavy.push([t, t + d + 0.3]); }
  }
  return r;
}
// cac quang di: walk / run (1 cum hoac danh sach cum) + walkAway; moi quang bat dau tu cho quang truoc dung lai
function walkList(a) {
  const L = [];
  for (const [mv, run] of [[a.walk, false], [a.run, true]]) for (const s of [].concat(mv && typeof mv === 'object' ? mv : [])) if (s && s.to !== undefined) L.push({ ...s, run: s.run ?? run });
  for (const s of expandActs(a).walks) L.push(s);
  return L.sort((p, q) => (p.at ?? 0) - (q.at ?? 0));
}
// chan om theo than nguoi nam: occ 1 = co nguoi (0 = giuong trong), roll 0 = nam ngua -> 1 = nam nghieng co goi, breath = nhip tho,
// cover 1 = dap kin -> 0 = da tuot ve phia chan (luc ngoi day). Mac dinh (occ 1, roll 0, cover 1) giong het chan cu.
function blanketBody(g, M, occ, roll, breath, cover) {
  const bx = M.bed.x0, bw = M.bed.x1 - M.bed.x0, top = M.bed.top, bh = M.gy - top, s = lerp(0.72, 0.17, cover), bunch = (1 - cover) * 10;
  const X = (f) => bx + bw * (s + (f - 0.17) / 0.81 * (0.98 - s)), mixh = (back, side, empty) => lerp(empty, lerp(back, side, roll), occ) - bunch;
  const c1 = mixh(-34 - breath * 2, -42 - breath * 2, -4), p1 = mixh(-28 - breath * 1.5, -26 - breath, -8), c2 = mixh(-36, -48, -12), p2 = mixh(-18, -14, -8);
  obj(g, (c) => { c.moveTo(X(0.17), top + 4); c.quadraticCurveTo(X(0.19), top + c1, X(0.35), top + p1); c.quadraticCurveTo(X(0.6), top + c2, X(0.8), top + p2); c.lineTo(X(0.98), top + bh * 0.5); c.lineTo(X(0.16), top + bh * 0.5); c.closePath(); }, { fill: PAL.blanket, line: '#8c95b5', la: 0.5 });
}
// dien thoai bay (act throwPhone): vong cung, xoay, nay nhe roi nam yen; man hinh tat dan
function drawProps(g, a, lt, st, U, f) {
  for (const p of expandActs(a).props) {
    if (lt < p.t0) continue;
    const x0 = st.x0 + f * 22 * U, y0 = st.y0 - 72 * U, x1 = p.to ? fx(p.to[0]) : x0 + f * E.W * 0.26, y1 = p.to ? fy(p.to[1]) : st.y0 - 1.5 * U;
    const k = clamp((lt - p.t0) / p.fly), land = lt - p.t0 - p.fly, bounce = land > 0 && land < 0.25 ? Math.sin(Math.PI * land / 0.25) * 14 * U * 0.3 : 0;
    const x = lerp(x0, x1, k) + (land > 0 ? f * Math.min(land, 0.25) * 30 * U : 0), y = lerp(y0, y1, k) - 4 * 40 * U * k * (1 - k) - bounce;
    const rot = land > 0 ? Math.PI / 2 : k * Math.PI * 3.2 * f, glowA = clamp(1 - Math.max(0, land) / 1.6);
    g.save(); g.translate(x, y); g.rotate(rot);
    g.beginPath(); g.roundRect(-3.2 * U, -6.5 * U, 6.4 * U, 12 * U, 1.2 * U); g.fillStyle = '#1b1c20'; g.fill(); g.lineWidth = 0.8 * U; g.strokeStyle = '#8b8e96'; g.stroke();
    g.globalAlpha *= glowA; g.fillStyle = PAL.screen; g.fillRect(-2.5 * U, -5.6 * U, 5 * U, 10.2 * U); g.restore();
    if (glowA > 0) light(g, x, y, 22 * U, PAL.screen, 0.3 * glowA);
  }
}

// ---------- nhoe chuyen dong (engine/player.js goi): so khung phu can ve o giay lt cua canh; chi bat o pha nhanh de khong cham ca phim.
// Tat: shot args "blur": false hoac config "motionBlur": false. Ep: args "blur": 3..8
export function blurFrames(shot, lt) {
  const a = shot.args || {}; let n = 0; const on = (t0, d) => lt >= t0 && lt < t0 + d;
  for (const s of [].concat(a.shake || [])) if (on(s.at ?? 0, s.dur ?? 0.45)) n = Math.max(n, 3);
  for (const f of a.fx || []) if (f.kind === 'speed' && on(f.at ?? 0, f.dur ?? 1e9)) n = Math.max(n, 3);
  for (const ac of a.actors || []) {
    const mv = ac.run;
    if (typeof mv === 'number') n = Math.max(n, 3);
    else if (mv && mv.to !== undefined) { const s0 = mv.at ?? ac.at ?? 0; if (on(s0, mv.dur ?? Math.max(0.5, shot.end - shot.start - s0))) n = Math.max(n, 3); }
    for (const e of ac.poseAt || []) { const d = e[2] ?? ac.poseDur; if (d > 0 && d <= 0.25 && on(e[0], d + 0.06)) n = Math.max(n, 5); }   // dam, nem, giat minh
    for (const e of expandActs(ac).fast) if (on(e[0], e[1])) n = Math.max(n, 5);
    const vs = vspec(ac, a); if (vs && vs.style === 'burst' && on(vs.t0 - 0.02, 0.5)) n = Math.max(n, 4);   // bong den vo
  }
  return n;
}

// ---------- nhan vat: actors = [{ who, x, y, h, pose, face, facing, look, at, out, walk: { to, at, dur, speed, ramp, ease, back } | run, poseAt, faceAt, facingAt, lookAt, hold, glowFace, scale, rot, z }]
function actorState(a, lt, M, info) {
  const a0 = a.at ?? 0; let x = anchor(M, a.x, 'x', 0.5), y = a.y !== undefined ? anchor(M, a.y, 'y', 0.8) : (typeof a.x === 'string' ? anchor(M, a.x, 'y', 0.8) : M.gy);
  const bx = x, by = y; let moving = false, facing = a.facing ?? 1, walk = null, segs = [];
  for (const mv of walkList(a)) {   // noi tiep cac quang: quang sau bat dau tu cho quang truoc dung
    const s0 = mv.at ?? a0, s1 = s0 + (mv.dur ?? Math.max(0.5, info.dur - s0)), x0 = segs.length ? segs[segs.length - 1].tx : bx, y0 = segs.length ? segs[segs.length - 1].ty : by;
    const tx = anchor(M, mv.to, 'x', 0.5), ty = mv.toY !== undefined ? anchor(M, mv.toY, 'y', 0.8) : (typeof mv.to === 'string' ? anchor(M, mv.to, 'y', y0) : y0);
    segs.push({ mv, s0, s1, x0, y0, tx, ty, dir: tx >= x0 ? 1 : -1, r: mv.ease === false || mv.ease === 'linear' ? 0 : clamp((mv.ramp ?? (mv.run ? 0.45 : 0.35)) / (s1 - s0), 0, 0.35) });
  }
  if (segs.length && a.facing === undefined) facing = segs[0].mv.back ? -segs[0].dir : segs[0].dir;
  for (const s of segs) {
    if (s !== segs[0] && lt < s.s0 - 0.3) break;
    const k = clamp((lt - s.s0) / (s.s1 - s.s0)), pos = (tt) => travel(clamp((tt - s.s0) / (s.s1 - s.s0)), s.r), e = pos(lt), D = Math.hypot(s.tx - s.x0, s.ty - s.y0);
    x = lerp(s.x0, s.tx, e); y = lerp(s.y0, s.ty, e); moving = k > 0 && k < 1;
    walk = { s0: s.s0, s1: s.s1, D, d: e * D, dir: s.dir, mv: s.mv, acc: (pos(lt + 0.03) - 2 * e + pos(lt - 0.03)) / 0.0009 * D };   // gia toc px/s^2
  }
  return { x, y, moving, facing, walk, segs, x0: x, y0: y };
}
// bong den dung chan truoc nguoi (che > 30% than nguoi luc bong den hien): tu dung sang canh nguoi, quay mat ve phia nguoi.
// Giu nguyen: actor "keepX": true, "behind": true, hoac x la moc. Ban sao actor duoc nho lai (cac bang nho theo actor van dung).
const _vp = new WeakMap();
function placeVoices(list, M, info, bed) {
  const people = list.filter((p) => p.who !== 'voice');
  return list.map((v) => {
    if (v.who !== 'voice' || v.keepX || v.behind || typeof v.x !== 'number' || v.walk || v.run) return v;
    if (_vp.has(v)) return _vp.get(v);
    const t = v.at ?? 0, hv = fs(v.h, 0.48), sv = actorState(v, t, M, info), boxes = [];
    for (const p of people) { const hp = fs(p.h, 0.42), s = actorState(p, t, M, info); if (Number.isFinite(s.x)) boxes.push([s.x - 0.3 * hp, s.y - 1.05 * hp, s.x + 0.3 * hp, s.y]); }
    if (bed && M.bed) { const R = fs(bed.r, bedR()); boxes.push([M.bed.head[0] - R * 1.5, M.bed.head[1] - R * 1.5, M.bed.head[0] + R * 1.5, M.bed.head[1] + R * 1.5]); }
    const vb = (x) => [x - 0.3 * hv, sv.y - 1.05 * hv, x + 0.3 * hv, sv.y], hit = (x) => boxes.find((b) => ovl(b, [vb(x)]) > 0.3 * (b[2] - b[0]) * (b[3] - b[1]));
    let out = v; const b = hit(sv.x);
    if (b) {
      const cx = (b[0] + b[2]) / 2, half = (b[2] - b[0]) / 2 + 0.3 * hv + E.W * 0.02, side = sv.x >= cx ? 1 : -1;
      const ok = (x) => x > E.W * 0.06 && x < E.W * 0.94 && !hit(x), x = ok(cx + side * half) ? cx + side * half : ok(cx - side * half) ? cx - side * half : null;
      if (x !== null) out = { ...v, x, facing: x > cx ? -1 : 1, _moved: true };
    }
    _vp.set(v, out); return out;
  });
}
// bong den tan bien (vanish.js): truoc luc vo ve than + vet nut; tu luc vo thay than bang manh vo / tro cat tu chinh hinh luc do
const _vs = new WeakMap();
// dau nguoi nam tren goi cung co dau nhan vat dung (0.42 * 18.5 / 100) -> ngoi day khong lon dan
const bedR = () => 0.42 * headK() / 100;   // dang moi dau nho hon (15.5) -> dau tren goi cung nho theo
export function vspec(a, args) { if (!_vs.has(a)) _vs.set(a, a.who === 'voice' || a.vanish !== undefined ? vanishSpec(a, args || {}) : null); return _vs.get(a); }
function drawActor(g, a, lt, M, info, heroX, ctx) {
  const V = vspec(a, info.args);
  if (!V || lt < V.t0 - (V.style === 'burst' ? BURST_PRE : 0)) return drawActorBody(g, a, lt, M, info);
  if (lt > V.end) return null;
  const st = actorState(a, V.t0, M, info), h = fs(a.h, a.who === 'voice' ? 0.48 : 0.42);
  const S = vanishSnap(V, st.x, st.y, h, (c) => drawActorBody(c, a, V.t0 - 1e-3, M, info, 1, V.style === 'burst'), heroX);   // burst: chup voi quang sang mo (bi chop trang che); ash: giu nguyen de khong giat
  if (ctx) (ctx.vanish = ctx.vanish || []).push({ spec: V, hit: [E.W / 2 + CAM.z * (S.hit[0] - CAM.cx + CAM.dx), E.H / 2 + CAM.z * (S.hit[1] - CAM.cy + CAM.dy)] });
  let r = S.r;
  if (lt < V.t0) r = drawActorBody(g, a, lt, M, info, V.style === 'burst' ? 1 + 0.04 * clamp((lt - V.t0 + BURST_PRE) / BURST_PRE) : 1);
  vanishDraw(g, lt, V, S);
  return r;
}
// ---------- R24 chi tiet nho tu bat (dang moi). Tat: config / shot args / actor "details": false. Dang classic: chi bat khi "details": true
export const detOn = (info, a) => (classic() ? E.cfg.details === true || info?.args?.details === true : E.cfg.details !== false && info?.args?.details !== false && a?.details !== false);
const COUNT_POSES = ['punch', 'lift'];
function actorDetails(g, a, o, r, st, h, lt, fz, W, X, info) {
  if (!r || !r.head) return; const U = h / 100, dir = Math.sign(fz.f || 1), [hx, hy] = r.head, R = r.R, t = lt + (a.seed || 0);
  const running = !!(o.run || (o.stride && o.stride.run && W && lt > W.s0 && lt < W.s1));
  const puff = (x, y, s, k, col = '200,195,185') => { if (k <= 0 || k >= 1) return; g.save(); g.fillStyle = `rgba(${col},${0.32 * (1 - k)})`; g.beginPath(); g.ellipse(x, y, s * (0.4 + k), s * (0.25 + 0.5 * k), 0, 0, Math.PI * 2); g.fill(); g.restore(); };
  if (a.who === 'voice') {   // khoi mong do bay len tu vien bong den. 1.10: mac dinh TAT (trong nhu bong bong; doi thu khong co khoi). Bat: actor "smoke": true / config "voiceSmoke": true
    if (a.smoke !== true && E.cfg.voiceSmoke !== true) return;
    g.save(); g.globalCompositeOperation = 'lighter'; const c = a.glow || accent();
    for (let i = 0; i < 6; i++) { const u = (t * 0.35 + i / 6) % 1, sx = hx + Math.sin(i * 2.3) * R * 1.1 + Math.sin(t * 1.5 + i) * R * 0.2, sy = hy + R * (0.6 + (i % 3) * 0.9) - u * R * 2.4; g.fillStyle = alpha(c, 0.1 * Math.sin(Math.PI * u)); g.beginPath(); g.ellipse(sx, sy, R * (0.18 + 0.25 * u), R * (0.3 + 0.35 * u), 0.3 * Math.sin(i), 0, Math.PI * 2); g.fill(); }
    g.restore(); return;
  }
  // mo hoi vang ra (chay, tho doc, gang suc)
  if (running || (o.heavy || 0) > 0.2 || ['effort', 'exhausted', 'grit', 'panic'].includes(o.face)) for (let i = 0; i < 3; i++) {
    const u = (t * 1.25 + i / 3) % 1, x = hx - dir * R * (0.6 + 1.6 * u) + i * R * 0.15, y = hy - R * 0.7 - R * 1.1 * u + R * 2.4 * u * u;
    g.save(); g.globalAlpha *= Math.sin(Math.PI * u) * 0.9; g.fillStyle = 'rgba(165,212,255,0.95)'; g.beginPath(); g.ellipse(x, y, R * 0.06, R * 0.09, -dir * 0.5, 0, Math.PI * 2); g.fill(); g.restore();
  }
  // bui duoi chan khi chay; bui khi nga cham dat
  const gy = st.y;
  if (running) for (let i = 0; i < 3; i++) { const u = (t * 2.6 + i / 3) % 1; puff(st.x - dir * (h * 0.06 + u * h * 0.18), gy - U * 2 - u * U * 4, U * 4, u); }
  for (const [r0, rd] of X.rot) { const k = (lt - r0 - rd) / 0.7; if (k > 0 && k < 1) for (const s of [-1, 1]) puff(st.x + s * dir * h * (0.15 + 0.25 * k), gy - U * 2 - k * U * 5, U * 6, k); }
  // hoi tho trang khi troi lanh / mua
  const sa = info.args.setArgs || {};
  if (sa.cold || (info.args.set === 'street' && sa.rain !== false)) { const u = (t / 1.7) % 1; if (u < 0.55) { const k = u / 0.55; puff(hx + dir * R * (1.0 + 0.9 * k), hy + R * 0.35 - k * R * 0.3, R * 0.35, k, '225,230,240'); } }
  // so dem khi tap (>= 3 lan dam / nang ta, hoac count: true): so bat len tren dau roi mo
  if (a.count !== false) { const ev = (a.poseAt || []).filter((e) => COUNT_POSES.includes(e[1])); if (ev.length >= 3 || a.count === true) ev.forEach((e, i) => { const k = (lt - e[0]) / 0.75; if (k > 0 && k < 1) text(g, String(i + 1), hx + dir * R * 0.2, hy - R * 1.9 - ease.out(k) * R * 0.4, { size: R * (0.9 + 0.3 * ease.outBack(clamp(k * 4))), font: FONT_NARR, weight: 700, color: '#f2efe8', a: Math.min(1, (1 - k) * 2.5) }); }); }
}
// vet toc do: cac vach ngang mo troi ve phia sau nguoi dang chay (nhu phim mau)
function speedLines(g, x, y, h, dir, t) {
  const r = rng(77); g.save(); g.lineCap = 'round';
  for (let i = 0; i < 8; i++) { const yy = y - h * (0.2 + 0.7 * r()), len = h * (0.22 + 0.4 * r()), sp = h * (2.4 + 1.6 * r()), off = (t * sp + r() * h * 1.4) % (h * 1.4), x0 = x - dir * (h * 0.22 + off), a = 0.3 * Math.sin(Math.PI * off / (h * 1.4));
    g.strokeStyle = `rgba(225,220,208,${a})`; g.lineWidth = Math.max(1.5, h * 0.005); g.beginPath(); g.moveTo(x0, yy); g.lineTo(x0 - dir * len, yy); g.stroke(); }
  g.restore();
}
function drawActorBody(g, a, lt, M, info, swell = 1, snap = false, solid = false) {
  const a0 = a.at ?? 0; if (lt < a0 - 0.001) return null; if (a.out !== undefined && lt > a.out + (a.fade ?? 0.6)) return null;
  const st = actorState(a, lt, M, info), h = fs(a.h, a.who === 'voice' ? 0.48 : 0.42), U = h / 100;
  if (a.who === 'voice' && a.facing === undefined && info.aim && !classic() && !st.segs.length) st.facing = Math.sign(info.aim[0] - st.x) || 1;   // 1.10 bong den luon quay ve phia nguoi hung (truoc day mac dinh nhin phai -> quay lung voi nguoi nam ben trai)
  let alphaK = 1; if (a.fadeIn !== false && a.at) alphaK = clamp((lt - a0) / (a.fadeIn ?? (a.who === 'voice' ? 0.8 : 0.001))); if (a.out !== undefined) alphaK *= clamp(1 - (lt - a.out) / (a.fade ?? 0.6));
  if (solid) alphaK = 1;   // dang ve trong lop rieng (asLayer da lo do mo)
  const mv0 = a.walk || a.run, W = st.walk, mv = W ? W.mv : mv0, X = expandActs(a);
  // tu the + bieu cam doi dan (poseDur / faceDur = giay chuyen, 0 = doi ngay); dau theo tre nhip 0,07 giay. act them moc vao day
  const pAt = X.poseAt.length ? [...(a.poseAt || []), ...X.poseAt] : a.poseAt;
  const p = { ...poseNow(lt, pAt, a.pose || 'stand', a.poseDur) }; p.head = poseNow(lt, pAt, a.pose || 'stand', a.poseDur, 0.07).head;
  const fc = faceNow(lt, a.faceAt, a.face || (a.who === 'voice' ? 'grin' : 'neutral'), a.faceDur);
  // huong nhin: facingAt [[giay, 1 | -1]] + tu quay ve huong di truoc moi quang (walk.back: di lui, khong quay)
  const ev = [...(a.facingAt || []), ...X.facingAt].sort((p1, q1) => p1[0] - q1[0]);
  const fAt = (tt) => { let v = st.facing; for (const e of ev) if (e[0] <= tt) v = e[1]; return v; };
  st.segs.forEach((s, i) => { if (s.mv.back || (i === 0 && a.facing === undefined)) return; const tt = Math.max(0, s.s0 - 0.12); if (fAt(tt) !== s.dir) { ev.push([tt, s.dir]); ev.sort((p1, q1) => p1[0] - q1[0]); } });
  const fz = facingNow(lt, ev, st.facing, a.turnDur ?? 0.3);
  if (fz.turning) p.squat = (p.squat || 0) + 1.2 * fz.turning;   // nhun nhe giua vong quay (gap goi, chan giu tai cho)
  const o = { ...a, t: lt + (a.seed || 0), facing: fz.f, ffrom: fz.from, pose: p, face: fc.face, fromFace: fc.fromFace, faceK: fc.faceK, faceSince: fc.faceSince, look: at(lt, a.lookAt, a.look ?? 0.25),
    blinkSeed: a.seed ?? (typeof a.x === 'number' ? a.x * 7.3 : 2.1) + (a.who || '').length * 1.7 + (typeof a.y === 'number' ? a.y * 3.7 : 0) };
  // walk/run trong shots.json la cum lenh { to, at, dur, speed }, khong phai toc do: khong dua nguyen vao nhan vat (truoc / sau quang di bi mat tay chan)
  delete o.walk; delete o.run; delete o.act;
  if (lt >= X.hideHold) delete o.hold;
  for (const [h0, h1] of X.heavy) o.heavy = Math.max(o.heavy || 0, clamp((lt - h0) / 0.4) * clamp((h1 - lt) / 0.6));
  for (const [r0, rd] of X.rot) { const k = clamp((lt - r0) / rd); if (k > 0) { const e = k < 1 ? k * k * (1 + 0.6 * (1 - k)) : 1; o.rot = (a.rot || 0) + Math.sign(fz.f || 1) * Math.PI / 2 * Math.min(1, e) + (k >= 1 ? 0 : 0); o.lift = 16 * U * Math.sin(Math.PI / 2 * Math.min(1, e)); const b = lt - r0 - rd; if (b > 0 && b < 0.3) o.lift += Math.sin(Math.PI * b / 0.3) * 4 * U * (1 - b / 0.3); } }   // do sap: roi nhanh dan, nay nhe khi cham dat
  if (W) {
    // nhip buoc theo quang duong: do dai buoc tu chinh de dung lai dung luc 2 chan khep; speed = so nhip / giay mong muon
    const run = !!mv.run, cad = mv.speed || (run ? 1.6 : 0.9), dur = Math.max(0.1, W.s1 - W.s0);
    let S = clamp(W.D / U / dur / (2 * cad), run ? 24 : 16, run ? 52 : 29); S = W.D / U / Math.max(1, Math.round(W.D / U / S));
    const w = lt <= W.s1 ? clamp((lt - W.s0 + 0.25) / 0.25) : 1 - clamp((lt - W.s1) / 0.35);   // vao dang di trong 0,25 giay TRUOC khi buoc (chan chua roi dat)
    if (w > 0 && W.D > 1) o.stride = { d: (mv.back ? -1 : 1) * W.d / U, S, run, w: ease.inOut(w) };
    // quan tinh: nghieng theo gia toc; lay da (hoi lui, khuyu goi) truoc khi di; toi noi chui nhe roi lay lai thang bang
    let lean = clamp(W.acc / U / 2500, -0.09, 0.09) * (mv.back ? -1 : 1);
    const pre = W.s0 - lt; if (pre > 0 && pre < 0.25 && W.s0 > 0.2) { const q = Math.sin(Math.PI * (1 - pre / 0.25)); lean -= 0.05 * q; p.squat = (p.squat || 0) + 1.2 * q; }
    const post = lt - W.s1; if (post > 0 && post < 1) lean += 0.08 * Math.exp(-7 * post) * Math.sin(16 * post);
    p.lean = (p.lean || 0) + lean;
  }
  else if (mv0 && !Array.isArray(mv0) && (typeof mv0 === 'number' || mv0.to === undefined)) { const sp = typeof mv0 === 'number' ? mv0 : mv0.speed || (a.run ? 1.6 : 0.9); if (a.run) o.run = sp; else o.walk = sp; }   // di / chay tai cho
  const k = alphaK; if (k <= 0) return null;
  // 1.10 tay vuon (reach / point) cua bong den tu nham vao vai nguoi hung (khong choc vao mat, khong chi vao khoang khong). Tat: "aim": false
  if (a.who === 'voice' && info.aim && a.aim !== false && !classic()) o.aim = [info.aim[0] - Math.sign(info.aim[0] - st.x) * info.aim[2] * 0.08, info.aim[1]];
  if (a.who === 'voice' && !snap && !solid && !classic() && k < 0.999 && E.cfg.voiceLayer !== false) return asLayer(g, k * g.globalAlpha, (q) => drawActorBody(q, a, lt, M, info, swell, snap, true));   // mo dan: ve lop rieng -> khong lo khop
  g.save(); g.globalAlpha *= k;
  if (a.who === 'ghost') g.globalAlpha *= 0.4;
  if (a.who === 'voice') { const pulse = 0.85 + 0.15 * Math.sin(lt * 3.2); o.glow = a.glow || accent(); if (classic()) g.globalAlpha *= pulse * 0.25 + 0.75; else o.glowK = 0.7 + 0.6 * (pulse - 0.7); }   // 1.10: nhip sang o quang sang, than luon dac
  if (swell !== 1) o.scale = (a.scale || 1) * swell;   // phong nhe truoc khi vo
  if (snap && a.who === 'voice') { o.glow = mix(o.glow, '#000000', 0.72); g.globalAlpha = 1; }   // anh chup de vo: quang sang mo -> manh la chat bong toi, mep chay do
  if (!classic() && !snap && a.speedLines !== false && (o.run || (o.stride && o.stride.run && W && lt > W.s0 && lt < W.s1))) speedLines(g, st.x, st.y, h, Math.sign(fz.f || 1), lt + (a.seed || 0));   // chay (dang moi): vet toc do sau lung
  // net rung ve tay: moi 0,1 giay nhan vat lech rat nhe (duoi 1 px) + do day vien doi chut it
  const hand = handOn(info) && !snap, step = Math.floor((info.globalT ?? lt) * 10) + (a.seed || 0) * 13 + (a.who || '').length * 7;
  if (hand) { const q = rng(step * 31 + 5); g.translate(st.x, st.y); g.rotate((q() - 0.5) * 0.007); g.translate(-st.x, -st.y); o.boil = q() - 0.5; o.anim = 'hand'; }   // xoay quanh ban chan: dau lech ~1 px, chan dung yen
  const r = bean(g, st.x, st.y, h, { ...o, details: detOn(info, a) });
  if (!snap && detOn(info, a)) actorDetails(g, a, o, r, st, h, lt, fz, W, X, info);
  if (!snap) { const ok = Number.isFinite(st.x) && Number.isFinite(st.y), b0 = ok ? scr(st.x - 0.3 * h, st.y - 1.05 * h) : null, b1 = ok ? scr(st.x + 0.3 * h, st.y) : null;
    LAY.actors.push({ who: a.who, anchor: typeof a.x === 'string' ? a.x : null, ok, moving: !!(W || a.out !== undefined || (a.act || []).some((e) => e.do === 'walkAway')), voice: a.who === 'voice',
      box: ok ? [b0[0], b0[1], b1[0], b1[1]] : null, head: r && ok ? [...scr(r.head[0], r.head[1]), r.R * (CAM.z || 1)] : null, feet: r && r.feet ? r.feet : null, still: !(o.rot || o.lift || o.stride || o.walk || o.run), inPlace: !!(o.walk || o.run) && !o.stride, behind: !!a.behind }); }
  if (X.props.length) drawProps(g, a, lt, st, U, Math.sign(fz.f || 1));
  g.restore();
  return r;
}

// ---------- chu tu tranh do vat / nguoi: chon cho trong gan cho dinh dat nhat. Tinh theo may luc chu bat dau hien -> dung yen ca canh.
// Tat: shot args "textAvoid": false hoac config "textAvoid": false. Chu da ghi x / y thi giu nguyen.
function avoidScr(ctx, t) {
  const c = camAt(t, ctx.info), S = (x, y) => [E.W / 2 + c.z * (x - c.cx), E.H / 2 + c.z * (y - c.cy)];
  return { R: ctx.avoid.map((r) => { const a = S(r[1], r[2]), b = S(r[3], r[4]); return [a[0], a[1], b[0], b[1]]; }), S };
}
const ovl = (b, R) => R.reduce((s, r) => s + Math.max(0, Math.min(b[2], r[2]) - Math.max(b[0], r[0])) * Math.max(0, Math.min(b[3], r[3]) - Math.max(b[1], r[1])), 0);
function pickSpot(cands, box, R) {   // cands: [x, y, phat]; box(x, y) -> [x0, y0, x1, y1]
  const S = safe(); let best = null;
  for (const [x, y, pen] of cands) { const b = box(x, y); if (b[0] < 16 || b[2] > E.W - 16 || b[1] < S.top + 6 || b[3] > S.bottom - 6) continue; const s = ovl(b, R) * 40 + pen; if (!best || s < best.s) best = { x, y, s }; }
  return best;
}

// ---------- chu: texts = [{ kind: narr | tempt | say | big | sign, t, at, dur, x, y, pos: top|bottom|center, size, color, type: true, emph: {"word": "#hex"} }]
// Chu da dat cung tranh nhau: dat chu ke chuyen truoc, chu cam do sau; chu sau tranh moi chu truoc co hien cung luc (tinh ca khi chu truoc chua / da tat -> khong nhay cho)
const TXT_RANK = { narr: 0, big: 0, tempt: 1 };
export function drawTexts(g, lt, info, list, ctx = {}) {
  const S = safe(), placed = [];
  const order = (list || []).map((tx, i) => [tx, i]).sort((p, q) => (TXT_RANK[p[0].kind || 'narr'] ?? 2) - (TXT_RANK[q[0].kind || 'narr'] ?? 2) || p[1] - q[1]).map((p) => p[0]);
  for (const tx of order) {
    const a0 = tx.at ?? 0.3, dur = tx.dur ?? (info.dur - a0 - 0.1), win = (tt) => window01(tt, a0, dur, tx.fi ?? (tx.kind === 'tempt' ? 0.2 : 0.45), tx.fo ?? 0.45);
    const kind = tx.kind || 'narr', vz = kind === 'tempt' && ctx.vanish ? ctx.vanish.find((v) => v.spec.words && win(v.spec.t0) > 0.25) : null;
    const a = vz && lt >= vz.spec.t0 ? win(vz.spec.t0) : win(lt); if (a <= 0 && kind !== 'narr' && kind !== 'tempt') continue;
    const avoidOn = ctx.avoid && ctx.info && info.args.textAvoid !== false && E.cfg.textAvoid !== false;
    const near = placed.filter((p) => p.s0 < a0 + dur && a0 < p.s1).map((p) => p.box), keep = (b) => placed.push({ s0: a0, s1: a0 + dur, box: b });
    if (kind === 'narr') { const pos = tx.pos || 'top'; let y = tx.y !== undefined ? fy(tx.y) : pos === 'bottom' ? S.bottom - (E.vertical ? 260 : 70) : pos === 'center' ? E.H / 2 : S.top + (E.vertical ? 260 : 64), x = fx(tx.x, 0.5);
      const size = tx.size || (E.vertical ? 64 : 58), maxW = tx.maxW ? fx(tx.maxW) : E.W * (E.vertical ? 0.84 : 0.7), lines = wrap(g, tx.t, maxW, size, FONT_NARR, 700), w = Math.max(...lines.map((l) => measure(g, l, size, FONT_NARR, 700))), hh = lines.length * size * 1.25;
      const box = (cx, cy) => [cx - w / 2, cy - hh / 2, cx + w / 2, cy + hh / 2];
      if (avoidOn && tx.x === undefined && tx.y === undefined) {   // tim cho trong: doc theo huong ra giua khung truoc, roi lech ngang
        const { R } = avoidScr(ctx, a0 + 0.2), dir = pos === 'bottom' ? -1 : 1, C = [];
        // 1.10: lech ngang bi phat nang (doi thu: chu ke chuyen luon CAN GIUA) -> het cho o tren thi xuong giua duoi truoc khi day sang ben
        for (let k = 0; k <= 16; k++) for (const s of pos === 'center' ? [1, -1] : [dir, -dir]) for (const dx of [0, -0.24, 0.24]) if (w < E.W * 0.5 || dx === 0) C.push([x + dx * E.W, y + s * k * 18, k * 18 * (s === dir ? 1 : 1.6) + Math.abs(dx) * (classic() ? 600 : 2200)]);
        for (const [yy, p] of [[S.top + (E.vertical ? 260 : 64), 320], [S.bottom - (E.vertical ? 260 : 70), 320], [E.H * 0.5, 420]]) for (let k = 0; k <= 3; k++) C.push([x, yy + (yy > E.H / 2 ? -1 : 1) * k * 36, p + k * 36]);   // het cho thi chuyen han len tren / xuong duoi
        const b = pickSpot(C, box, [...R, ...near]); if (b) { x = b.x; y = b.y; }
      }
      if (tx.x === undefined) x += fitX(box(x, y));   // 1.10 khong bao gio cat mep
      keep(box(x, y)); if (a <= 0) continue;
      LAY.texts.push({ kind, t: tx.t, box: box(x, y) });
      narr(g, tx.t, x, y, { a, size: tx.size, color: tx.color, emph: tx.emph, maxW: tx.maxW ? fx(tx.maxW) : undefined, type: tx.type ? clamp((lt - a0) / Math.max(0.4, String(tx.t).length / 28)) : undefined }); }
    else if (kind === 'big') big(g, tx.t, fx(tx.x, 0.5), fy(tx.y, 0.5), { maxW: tx.maxW ? fx(tx.maxW) : undefined, a, size: tx.size, color: tx.color, type: tx.type ? clamp((lt - a0) / Math.max(0.4, String(tx.t).length / 18)) : undefined });
    else if (kind === 'tempt') { const v = ctx.voice || (avoidOn ? ctx.heads?.hero || ctx.heads?.first : null) /* khong co bong den: canh dau nguoi hung */; const S2 = safe(); let x = tx.x !== undefined ? fx(tx.x) : v ? v.head[0] : E.W * 0.7, y = tx.y !== undefined ? fy(tx.y) : v ? v.head[1] - v.R * 2.3 : E.H * 0.3; if (tx.y === undefined && v && y < S2.top + 150) { y = v.head[1] - v.R * 0.2; x = v.head[0] + (v.head[0] > E.W * 0.55 ? -1 : 1) * v.R * 4.2; } if (tx.x === undefined) x = Math.min(E.W * 0.86, Math.max(E.W * 0.14, x));
      let size = tx.size || (E.vertical ? 76 : 62); const pre = vz && vz.spec.style === 'burst' ? clamp((lt - vz.spec.t0 + BURST_PRE) / BURST_PRE) : 0;
      let ttxt = String(tx.t), tl = ttxt.split('\n'), tw = Math.max(...tl.map((l) => measure(g, l, size, temptFont(), 700)));
      if (!classic() && !vz && tl.length === 1 && tw > E.W * 0.5) {   // 1.10 cau dai: tu xuong 2 dong can doi (chu cam do o doi thu luon gon canh bong den)
        const w = ttxt.split(' '), M2 = (s) => measure(g, s, size, temptFont(), 700); let bi = 0, bd = 1e9;
        for (let i = 1; i < w.length; i++) { const dd = Math.abs(M2(w.slice(0, i).join(' ')) - M2(w.slice(i).join(' '))); if (dd < bd) { bd = dd; bi = i; } }
        if (bi && w.length >= 4) { ttxt = w.slice(0, bi).join(' ') + '\n' + w.slice(bi).join(' '); tl = ttxt.split('\n'); tw = Math.max(...tl.map(M2)); }
      }
      if (!classic() && tw > E.W * 0.8) { size *= E.W * 0.8 / tw; tw = E.W * 0.8; }   // 1.10 van qua dai: thu nho cho vua khung
      const box = (cx, cy) => [cx - tw / 2, cy - size * 0.55, cx + tw / 2, cy + (tl.length - 1) * size * 1.05 + size * 0.55];
      if (avoidOn && tx.x === undefined && tx.y === undefined) {   // canh bong den nhung khong de len do vat / mat nguoi
        const { R, S } = avoidScr(ctx, a0 + 0.2), c = camAt(a0 + 0.2, ctx.info), hp = v ? S(v.head[0], v.head[1]) : [x, y], r = v ? v.R * c.z : 60, C = [[x, y, 0]];
        for (const [dx, dy, p] of [[0, -2.3, 5], [4.2, -0.2, 25], [-4.2, -0.2, 25], [3.4, -1.9, 15], [-3.4, -1.9, 15], [0, -3.4, 40], [5.6, 1.2, 60], [-5.6, 1.2, 60], [4.6, -3.2, 50], [-4.6, -3.2, 50]]) C.push([hp[0] + dx * r, hp[1] + dy * r, p]);
        if (!classic()) for (const s of [-1, 1]) for (const dy of [-0.4, -1.6, 0.8]) C.push([hp[0] + s * (tw / 2 + r * 1.8), hp[1] + dy * r, 22 + Math.abs(dy) * 8]);   // 1.10 sat canh dau theo be rong cau
        const b = pickSpot(C, box, [...R, ...near]); if (b) { x = b.x; y = b.y; }
      }
      if (tx.x === undefined && !classic()) x += fitX(box(x, y));   // 1.10 khong cat mep ("you work better under pressu|")
      keep(box(x, y)); if (a <= 0) continue;
      LAY.texts.push({ kind, t: tx.t, box: box(x, y) });
      if (!(vz && vanishLetters(g, lt, vz.spec, tx.t, x, y, size, tx.color || accent(), a, vz.hit))) tempt(g, ttxt, x, y, { a, size, color: tx.color, t: lt, shake: pre * 4, type: tx.type === false ? undefined : clamp((lt - a0) / Math.max(0.35, String(tx.t).length / 16)) }); }   // bong den vo -> chu vo tung chu cai
    else if (kind === 'say') { const who = ctx.heads?.[tx.who || 'hero'] || ctx.heads?.first; const x = tx.x !== undefined ? fx(tx.x) : who ? who.head[0] + who.R * 1.6 : E.W * 0.55, y = tx.y !== undefined ? fy(tx.y) : who ? who.head[1] - who.R * 1.9 : E.H * 0.35; say(g, tx.t, x, y, { a: clamp((lt - a0) / 0.4) * clamp((a0 + dur - lt) / 0.3), size: tx.size, tail: tx.tail }); }
    else if (kind === 'sign') text(g, tx.t, fx(tx.x, 0.5), fy(tx.y, 0.5), { size: tx.size || 40, font: FONT_HAND, weight: 700, color: tx.color || PAL.white, a });
  }
}

// ---------- bo dem goc trai: hud = { label: "DAY", n | from+to (dem dan), at, dur, reset: { at, to }, rows: [{ label, n, from, to, color }], color, x, y }
export function drawHud(g, lt, info, h) {
  if (!h) return; const S = safe(), size = E.vertical ? 40 : 30;
  const rows = h.rows ? h.rows : [{ label: h.label ?? 'DAY', n: h.n, from: h.from, to: h.to, at: h.at, dur: h.dur, reset: h.reset, color: h.color }];
  // 1.10 so cua canh truoc cung nhan (bo qua canh khong co bo dem) -> so doi thi nay + loe mau nhan 0,8 giay
  const si = E.shots.indexOf(info.shot), prevOf = (label) => { for (let j = si - 1; j >= 0; j--) { const hh = (E.shots[j].args || {}).hud; if (!hh) continue; const rr = (hh.rows || [{ label: hh.label ?? 'DAY', n: hh.n, to: hh.to, reset: hh.reset }]).find((q) => (q.label ?? 'DAY') === label); return rr ? (rr.reset ? rr.reset.to ?? 0 : rr.n ?? rr.to) : undefined; } return undefined; };
  g.save(); if (!classic()) { g.shadowColor = 'rgba(0,0,0,0.8)'; g.shadowBlur = 8; g.shadowOffsetY = 1; }
  rows.forEach((r, i) => {
    const x = fx(h.x, E.vertical ? 0.08 : 0.032), y = (h.y !== undefined ? fy(h.y) : S.top + (E.vertical ? 220 : 42)) + i * size * 1.25;
    let n = r.n ?? r.to ?? 0; if (r.from !== undefined && r.to !== undefined) n = Math.round(lerp(r.from, r.to, ease.inOut(clamp((lt - (r.at ?? 0)) / (r.dur ?? Math.max(0.5, info.dur * 0.8))))));
    const fmt = (v) => (typeof v === 'number' && r.comma !== false ? v.toLocaleString('en-US') : String(v));
    text(g, r.label, x, y, { size, font: FONT_UI, weight: 700, color: '#e9e9ec', align: 'left', spacing: 1 });
    const nx = x + measure(g, r.label, size, FONT_UI, 700) + size * 0.45;
    const pv = r.from === undefined && !r.reset && !classic() && h.bump !== false && r.bump !== false ? prevOf(r.label ?? 'DAY') : undefined, bk = pv !== undefined && String(pv) !== String(n) ? clamp(lt / 0.8) : 1;
    if (bk < 1) {   // nay: phong 1,45 -> 1 (outBack), mau nhan -> trang
      const sc = 1 + 0.45 * (1 - ease.outBack(clamp(bk * 1.6))), w = measure(g, fmt(n), size, FONT_UI, 700);
      g.save(); g.translate(nx, y); g.scale(sc, sc); text(g, fmt(n), 0, 0, { size, font: FONT_UI, weight: 700, color: mix(accent(), r.color || (r.accent ? accent() : '#e9e9ec'), ease.inOut(clamp((bk - 0.35) / 0.65))), align: 'left', glowColor: alpha(accent(), 0.6 * (1 - bk)) }); g.restore();
      if (bk < 0.5) stroke(g, nx - 2, y + size * 0.62, nx + w + 2, y + size * 0.6, { p: ease.out(clamp(bk * 4)), lw: 3, glow: true, color: alpha(accent(), 1 - bk * 2) });
      return;
    }
    const rs = r.reset;
    if (rs && lt >= rs.at) {
      const p = clamp((lt - rs.at) / 0.35), w = measure(g, fmt(n), size, FONT_UI, 700), q = clamp((lt - rs.at - 0.45) / 0.3);
      text(g, fmt(n), nx, y, { size, font: FONT_UI, weight: 700, color: '#e9e9ec', align: 'left', a: 1 - q * 0.9 });
      stroke(g, nx - 4, y + 2, nx + w + 4, y - 2, { p, lw: 5, glow: true });
      if (q > 0) text(g, fmt(rs.to ?? 0), nx + w + 14, y, { size, font: FONT_UI, weight: 700, color: accent(), align: 'left', a: q, glowColor: alpha(accent(), 0.6) });
    } else text(g, fmt(n), nx, y, { size, font: FONT_UI, weight: 700, color: r.color || (r.accent ? accent() : '#e9e9ec'), align: 'left' });
  });
  g.restore();
}

// ---------- hieu ung: fx = [{ kind: flash | shards | speed | zzz | embers | pulse | rain | dust | spot | glitch | dark, at, dur, x, y, color }]
export function drawFx(g, lt, info, list, ctx = {}) {
  for (const f of list || []) {
    const a0 = f.at ?? 0, d = f.dur ?? 0.8, p = (lt - a0) / d; if (lt < a0) continue;
    const x = f.x !== undefined ? fx(f.x) : ctx.voice ? ctx.voice.head[0] : E.W / 2, y = f.y !== undefined ? fy(f.y) : ctx.voice ? ctx.voice.head[1] + ctx.voice.R * 2 : E.H / 2;
    if (f.kind === 'shards' && f.style !== 'classic' && ctx.vanish && ctx.vanish.length) continue;   // da thay bang vanish.js (bong den vo that)
    if (f.kind === 'shards' && p < 1.6) { const r = rng(f.seed || 3); g.save(); g.globalCompositeOperation = 'lighter'; for (let i = 0; i < 26; i++) { const ang = r() * Math.PI * 2, sp = 200 + r() * 520, px = x + Math.cos(ang) * sp * ease.out(clamp(p)), py = y + Math.sin(ang) * sp * ease.out(clamp(p)) + 200 * p * p, s = 10 + r() * 22; g.save(); g.translate(px, py); g.rotate(r() * 6 + p * 4); g.globalAlpha = clamp(1.4 - p); g.strokeStyle = f.color || accent(); g.lineWidth = 2.5; g.shadowColor = f.color || accent(); g.shadowBlur = 10; g.beginPath(); g.moveTo(-s, 0); g.lineTo(0, -s * 0.6); g.lineTo(s * 0.7, s * 0.4); g.closePath(); g.stroke(); g.restore(); } g.restore(); }
    else if (f.kind === 'flash' && p < 1) { g.save(); g.setTransform(E.PX, 0, 0, E.PX, 0, 0); g.fillStyle = `rgba(255,250,240,${(1 - ease.out(clamp(p))) * (f.a ?? 0.85)})`; g.fillRect(0, 0, E.W, E.H); g.restore(); }
    else if (f.kind === 'speed' && (f.dur === undefined || p < 1)) { const r = rng(9); g.save(); g.strokeStyle = alpha(f.color || '#e8d9a0', 0.55); g.lineWidth = 3; for (let i = 0; i < 14; i++) { const yy = y + (r() - 0.5) * 220, len = 120 + r() * 200, xx = x - 100 - ((lt * 900 + r() * 400) % 500) * (f.dir ?? 1); g.beginPath(); g.moveTo(xx, yy); g.lineTo(xx - len * (f.dir ?? 1), yy + len * 0.18); g.stroke(); } g.restore(); }
    else if (f.kind === 'zzz') {   // 1.10: khong ghi x / y -> bay tu dau NGUOI DANG NGU (truoc day lay dau bong den -> zzz moc tu bong den)
      const zx = f.x !== undefined ? x : ctx.sleeper ? ctx.sleeper[0] : ctx.heads?.hero ? ctx.heads.hero.head[0] + ctx.heads.hero.R : x, zy = f.y !== undefined ? y : ctx.sleeper ? ctx.sleeper[1] : ctx.heads?.hero ? ctx.heads.hero.head[1] - ctx.heads.hero.R * 1.2 : y;
      for (let i = 0; i < 3; i++) { const q = ((lt * 0.5 + i / 3) % 1); text(g, 'z', zx + q * 60 + i * 6, zy - q * 90, { size: 22 + q * 26, font: FONT_NARR, weight: 700, color: '#d8d8de', a: Math.sin(q * Math.PI) }); } }
    else if (f.kind === 'embers') { const r = rng(5); g.save(); g.globalCompositeOperation = 'lighter'; for (let i = 0; i < 40; i++) { const q = (lt * (0.15 + r() * 0.2) + r()) % 1, px = x + (r() - 0.5) * E.W * 0.6 + Math.sin(lt + i) * 20, py = y + E.H * 0.25 - q * E.H * 0.7; g.fillStyle = alpha(f.color || '#ffb03b', Math.sin(q * Math.PI) * 0.8); g.beginPath(); g.arc(px, py, 2 + r() * 3, 0, 7); g.fill(); } g.restore(); }
    else if (f.kind === 'pulse') { const k = Math.max(0, Math.sin(lt * (f.speed ?? 6))) ** 3 * (f.a ?? 0.35); g.save(); g.setTransform(E.PX, 0, 0, E.PX, 0, 0); const R = Math.hypot(E.W, E.H) / 2; g.fillStyle = radGrad(g, E.W / 2, E.H / 2, R * 0.4, R, [[0, 'rgba(0,0,0,0)'], [1, alpha(f.color || accent(), k)]]); g.fillRect(0, 0, E.W, E.H); g.restore(); }
    else if (f.kind === 'rain') rain(g, lt, { n: f.n || 160, a: f.a });
    else if (f.kind === 'dust') dust(g, lt, { n: f.n || 40 });
    else if (f.kind === 'spot') light(g, x, y, fs(f.r, 0.4), f.color || '#ffe9c0', f.a ?? 0.3);
    else if (f.kind === 'dark' ) { g.save(); g.setTransform(E.PX, 0, 0, E.PX, 0, 0); g.fillStyle = `rgba(0,0,0,${clamp(p) * (f.a ?? 0.7)})`; g.fillRect(0, 0, E.W, E.H); g.restore(); }
    else if (f.kind === 'glitch' && p < 1) { const r = rng(Math.floor(lt * 30)); g.save(); g.setTransform(E.PX, 0, 0, E.PX, 0, 0); for (let i = 0; i < 6; i++) { g.fillStyle = alpha(i % 2 ? accent() : '#5ad1ff', 0.18); g.fillRect(0, r() * E.H, E.W, 6 + r() * 30); } g.restore(); }
  }
}
function drawLights(g, list) { for (const l of list || []) light(g, fx(l.x), fy(l.y), fs(l.r, 0.3), l.color || PAL.lamp, l.a ?? 0.35); }

// lop phu chung (ngoai may quay): chu, bo dem, hieu ung man hinh
function overlays(g, lt, info, ctx) {
  const a = info.args;
  drawFx(g, lt, info, (a.fx || []).filter((f) => ['flash', 'pulse', 'dark', 'glitch'].includes(f.kind)), ctx);
  for (const v of ctx.vanish || []) vanishScreen(g, lt, v.spec);   // chop trang loa khi bong den vo
  if (a.vignette !== false) vignette(g, a.vignette ?? (handOn(info) ? 0.62 : 0.5));
  drawHud(g, lt, info, a.hud);
  drawTexts(g, lt, info, a.texts, ctx);
}
// nen mo (canh phone / face): ve boi canh 1 lan vao canvas nho, lam mo 1 lan, phong to -> nhanh
const _bgc = new Map();
function blurBg(g, kind, setArgs = {}, dim = 0.4) {
  const key = kind + JSON.stringify(setArgs) + E.W;
  let c = _bgc.get(key);
  if (!c) {
    const w = Math.round(E.W / 4), h = Math.round(E.H / 4), raw = document.createElement('canvas'); raw.width = w; raw.height = h;
    const q = raw.getContext('2d'); q.scale(0.25, 0.25); const M = set(q, kind, { ...setArgs, t: 0 }); if (M.mirrorFrame) M.mirrorFrame();
    c = document.createElement('canvas'); c.width = w; c.height = h; const z = c.getContext('2d'); z.filter = 'blur(3px)'; z.drawImage(raw, 0, 0); z.filter = 'none'; z.fillStyle = `rgba(0,0,0,${dim})`; z.fillRect(0, 0, w, h);
    _bgc.set(key, c); if (_bgc.size > 30) _bgc.delete(_bgc.keys().next().value);
  }
  g.save(); g.imageSmoothingEnabled = true; g.drawImage(c, -20, -12, E.W + 40, E.H + 24); g.restore();
}
// bo cuc moi khung (render.mjs --check doc window.__lay): nguoi (dau, than, chan), chu, do vat — toa do man hinh logic
export const LAY = { actors: [], texts: [], objs: [] };
const scr = (x, y) => (CAM.g ? [E.W / 2 + CAM.z * (x - CAM.cx + CAM.dx), E.H / 2 + CAM.z * (y - CAM.cy + CAM.dy)] : [x, y]);
// ---------- R21 nhip ve tay: hat nhieu phim doi 10 lan / giay tren toan khung (nhu phim mau). Tat: config / shot args "anim": "smooth" (classic: tat)
export const handOn = (info) => !classic() && E.cfg.anim !== 'smooth' && info?.args?.anim !== 'smooth';
// 5 tam nhieu ve san o nua do phan giai, moi khung chi 1 lan dan anh (khong tinh lai); khung phu cua nhoe chuyen dong (canvas an) bo qua
let _grain = null;
function grain(g, lt, info) {
  if (!handOn(info) || info.args.grain === false || (g.canvas && !g.canvas.isConnected)) return;
  const amt = info.args.grainAmt ?? E.cfg.grain ?? 0; if (!(amt > 0)) return;   // mac dinh tat: hat nhieu lam khau nen video cham ~40%. Bat: config "grain": 7
  const w = Math.ceil(g.canvas.width / 2), h = Math.ceil(g.canvas.height / 2), key = w + 'x' + h + ':' + amt;
  if (!_grain || _grain.key !== key) { _grain = { key, c: [] }; for (let k = 0; k < 5; k++) { const c = document.createElement('canvas'); c.width = w; c.height = h; const x = c.getContext('2d'), d = x.createImageData(w, h), r = rng(900 + k); for (let i = 0; i < d.data.length; i += 4) { const v = r(); if (v > 0.12) continue; const q = r() > 0.45 ? 255 : 0; d.data[i] = d.data[i + 1] = d.data[i + 2] = q; d.data[i + 3] = (0.5 + r()) * amt * 2.2; } /* hat thua ~12% diem anh: giong hat phim, nen JPEG nhe hon */ x.putImageData(d, 0, 0); _grain.c.push(c); } }
  const step = Math.floor((info.globalT ?? lt) * 10);
  g.save(); g.setTransform(1, 0, 0, 1, 0, 0); g.globalAlpha = 1; g.globalCompositeOperation = 'source-over'; g.imageSmoothingEnabled = false; g.drawImage(_grain.c[step % 5], 0, 0, g.canvas.width, g.canvas.height); g.restore();
}
const tpl = (name, draw) => registerTemplate(name, { draw: (g, lt, info) => { LAY.actors = []; LAY.texts = []; LAY.objs = []; window.__lay = LAY; const r = draw(g, lt, info, info.args || {}); grain(g, lt, info); return r; } });

// ---------- scene: boi canh + nguoi + giong noi.  args: set, setArgs {...}, bed {who, face, faceAt, arm, at}, actors [...], lights, fx, cam, texts, hud
tpl('scene', (g, lt, info, a) => {
  const ctx = { heads: {} };
  // may bam nguoi (cam.follow = who): chi voi x la so
  const fa = a.cam && a.cam.follow ? (a.actors || []).find((x) => x.who === a.cam.follow && typeof x.x === 'number') : null, gm = { gy: fy((a.setArgs || {}).gy ?? (E.vertical ? 0.7 : 0.8)) };
  if (fa) { const mv = fa.walk || fa.run, tx = mv && mv.to !== undefined ? fx(mv.to) : fx(fa.x); info = { ...info, followX: (tt) => actorState(fa, tt, gm, info).x, followDir: mv && mv.back ? -Math.sign(tx - fx(fa.x)) : Math.sign(tx - fx(fa.x)) || 1 }; }
  // setArgs.scroll: "sync" -> duong / nha troi khop buoc chan nguoi di / chay tai cho
  const sync = (a.setArgs || {}).scroll === 'sync' ? (a.actors || []).find((x) => typeof x.run === 'number' || typeof x.walk === 'number') : null;
  // bong den tan bien kieu burst: may rung nhe dung luc vo
  const vb = (a.actors || []).map((x) => vspec(x, a)).filter((v) => v && v.style === 'burst');
  if (vb.length) info = { ...info, args: { ...info.args, shake: [...[].concat(a.shake || []), ...vb.map((v) => ({ at: v.t0, amt: 0.55, dur: 0.5 }))] } };
  camera(g, lt, info, () => {
    const so = { ...(a.setArgs || {}), t: lt, occupied: !!a.bed, details: detOn(info), hand: handOn(info) };
    if (so.hits === undefined) { const h = []; for (const ac of a.actors || []) for (const e of ac.poseAt || []) if (e[1] === 'punch') { h.push(e[0] + (e[2] ?? 0.12)); if (typeof ac.x === 'number' && so.hitFrom === undefined) { so.hitFrom = Math.sign(fx(ac.x) - fx(so.bagX ?? 0.62)) || -1; so.hitY = (ac.y !== undefined ? fy(ac.y) : fy(so.gy ?? (E.vertical ? 0.7 : 0.8))) - fs(ac.h, 0.42) * 0.6; } } if (h.length) so.hits = h; }   // bao cat vang khi trung don (+ phia nguoi dam: chop sang dung cho)
    if ((a.setArgs || {}).scroll === 'sync') so.scroll = sync ? (2 * (sync.run ? 34 : 24) * (sync.run || sync.walk) * fs(sync.h, 0.42) / 100) / 60 : 0;
    const M = set(g, a.set || 'bedroom', so), AC = placeVoices(a.actors || [], M, info, a.bed);
    worldGrade(g, a.grade, lt);   // 1.10 boi canh mat mau / toi theo nhip (nguoi + bong den + chu giu mau)
    const hero = AC.find((x) => x.who !== 'voice'), heroX = hero ? actorState(hero, lt, M, info).x : a.bed && M.bed ? M.bed.head[0] : undefined;   // diem bi danh cua bong den: phia nguoi hung
    // 1.10 diem tay bong den nham toi: vai nguoi hung (theo do ha hong khi ngoi), hoac vai nguoi nam trong chan
    if (hero && Number.isFinite(heroX)) { const hs = actorState(hero, lt, M, info), hh = fs(hero.h, 0.42), pz = poseNow(lt, hero.poseAt, hero.pose || 'stand', hero.poseDur); info = { ...info, aim: [hs.x, hs.y - hh * (0.6 - (pz.drop || 0) / 100), hh] }; }
    else if (a.bed && M.bed) { const R = fs(a.bed.r, bedR()); info = { ...info, aim: [M.bed.head[0] + R * 1.5, M.bed.head[1] + R * 1.1, R * 6] }; }
    // vung chu khong duoc de: do vat cua boi canh + duong di cua moi nhan vat suot canh + nguoi nam giuong
    ctx.info = info; ctx.avoid = (M.avoid || []).slice(); LAY.objs = ctx.avoid.map((r) => [r[0], ...scr(r[1], r[2]), ...scr(r[3], r[4])]);
    for (const ac of AC) { const hh = fs(ac.h, ac.who === 'voice' ? 0.48 : 0.42), t0 = ac.at ?? 0; for (let k = 0; k <= 5; k++) { const s = actorState(ac, t0 + (info.dur - t0) * k / 5, M, info); if (Number.isFinite(s.x) && Number.isFinite(s.y)) ctx.avoid.push([ac.who, s.x - 0.3 * hh, s.y - 1.05 * hh, s.x + 0.3 * hh, s.y + 6]); } }
    if (a.bed && M.bed) { const R = fs(a.bed.r, bedR()); ctx.avoid.push(['nguoi nam', M.bed.head[0] - R * 1.5, M.bed.head[1] - R * 1.5, M.bed.head[0] + R * 1.5, M.bed.head[1] + R * 1.5]); }
    drawLights(g, a.lights);
    const actors = AC.slice().sort((p, q) => (p.z || 0) - (q.z || 0));
    const behind = actors.filter((x) => x.behind), front = actors.filter((x) => !x.behind);
    for (const ac of behind) { const inM = ac.inMirror && M.mirrorClip; if (inM) { g.save(); M.mirrorClip(g); } const r = drawActor(g, ac, lt, M, info, heroX, ctx); if (inM) g.restore(); if (r) { if (ac.who === 'voice') ctx.voice = r; else { ctx.heads[ac.who] = r; ctx.heads.first = ctx.heads.first || r; } } }
    if (M.mirrorFrame) M.mirrorFrame();   // khung guong (va vet nut) ve de len bong trong guong
    if (a.bed && M.bed) {
      M.pillow(); const b = a.bed, R = fs(b.r, bedR());
      const breath = Math.sin(lt * 1.6), hx = M.bed.head[0] + (b.dx || 0), hy = M.bed.head[1] + (b.dy || 0) + breath * 1.5;
      const fc = faceNow(lt, b.faceAt, b.face || 'sleep', b.faceDur);
      // co nguoi trong chan (at / out), tro minh (rollAt [[giay, "side" | "back"]]), ngoi day (up: { at, dur, h, face })
      const occ = clamp((lt - (b.at ?? -1)) / 0.5) * (b.out !== undefined ? clamp(1 - (lt - b.out) / 0.5) : 1);
      const roll = (b.rollAt || []).reduce((v, [t0, s]) => (lt >= t0 ? lerp(v, s === 'side' ? 1 : 0, ease.inOut(clamp((lt - t0) / 0.8))) : v), b.side ? 1 : 0);
      const up = b.up === undefined ? null : typeof b.up === 'object' ? b.up : { at: b.up }, ku = up ? clamp((lt - up.at) / (up.dur ?? 1.6)) : 0;
      const headA = occ * (1 - clamp(ku / 0.15)), cl = classic();
      // tay vuon tat bao thuc (dang moi): chui ra tu mep chan, luon DUOI cam (ve truoc dau, chan de len goc tay)
      const armK = b.arm && ku <= 0 && occ > 0 ? (typeof b.arm === 'object' ? ease.inOut(clamp((lt - (b.arm.at ?? 0)) / (b.arm.dur ?? 0.8))) : 1) : -1;
      if (!cl && armK > 0.02) { /* truoc luc vuon: tay nam trong chan */ const ex = lerp(hx + R * 1.3, M.clock[0] + 30, armK), ey = lerp(hy + R * 1.5, M.clock[1] + 30, armK), sx = hx + R * 1.6, sy = hy + R * 1.45; g.save(); g.lineCap = 'round'; g.beginPath(); g.moveTo(sx, sy); g.quadraticCurveTo(hx + R * 0.2, hy + R * 1.35, ex, ey); g.strokeStyle = '#4f4a43'; g.lineWidth = R * 0.4; g.stroke(); g.strokeStyle = PAL.hero; g.lineWidth = R * 0.32; g.stroke(); g.beginPath(); g.arc(ex, ey, R * 0.2, 0, 7); g.fillStyle = PAL.hero; g.fill(); g.restore(); }
      if (headA > 0) { g.save(); g.globalAlpha *= headA; lyingHead(g, hx, hy, R, { who: b.who || 'hero', ...fc, look: at(lt, b.lookAt, b.look ?? -0.4), t: lt, rot: (b.rot ?? -0.25) + roll * 0.18, facing: b.facing ?? -1, blink: b.blink, age: b.age }); g.restore(); }
      if (ku > 0) {   // ngoi day: than tu nam -> ngoi mep giuong, chan tuot xuong; chan tuot ve phia chan giuong
        // xoay quanh HONG: than nhom day tren nem (0 -> 55%), hong truot ra mep giuong, chan buong xuong (30% -> 100%)
        const hL = R / headK() * 100, hS = fs(up.h, 0.42), hh = lerp(hL, hS, ease.inOut(clamp(ku / 0.6))), Uu = hh / 100, ex = ease.inOut(clamp((ku - 0.3) / 0.7));
        const pz = poseOf(up.pose || 'sit', 'lie', ease.inOut(clamp((ku - 0.3) / 0.7))), rot = lerp(-Math.PI / 2, 0, ease.inOut(clamp(ku / 0.55)) * 0.88 + ease.inOut(clamp((ku - 0.55) / 0.45)) * 0.12);
        const Hx = lerp(hx + 47 * Uu, M.bed.sit[0], ex), Hy = lerp(hy + 2 * Uu, M.bed.sit[1] - 15 * Uu, ex), aa = (-30 + (pz.drop || 0)) * Uu;
        const ox = Hx + aa * Math.sin(rot), oy = Hy - aa * Math.cos(rot);
        g.save(); g.globalAlpha *= clamp(ku / 0.15);
        const fu = up.face ? faceNow(lt, [[up.at + 0.3, up.face]], fc.face) : fc;
        const rr = bean(g, ox, oy, hh, { who: b.who || 'hero', ...fu, pose: pz, rot, facing: 1, t: lt, look: 0.2, idle: false });
        g.restore(); ctx.heads.hero = rr; ctx.heads.first = ctx.heads.first || rr;
      }
      blanketBody(g, M, occ, roll, breath, 1 - ease.inOut(clamp(ku / 0.7)));
      if (cl && b.arm && ku <= 0 && occ > 0) { const k = typeof b.arm === 'object' ? ease.inOut(clamp((lt - (b.arm.at ?? 0)) / (b.arm.dur ?? 0.8))) : 1, ex = lerp(hx + R * 1.2, M.clock[0] + 30, k), ey = lerp(hy + R * 1.6, M.clock[1] + 30, k); g.save(); g.lineCap = 'round'; g.strokeStyle = PAL.heroLine; g.lineWidth = R * 0.42; g.beginPath(); g.moveTo(hx + R * 1.4, hy + R * 1.3); g.quadraticCurveTo((hx + ex) / 2, ey - R * 0.5, ex, ey); g.stroke(); g.strokeStyle = PAL.hero; g.lineWidth = R * 0.32; g.stroke(); g.fillStyle = PAL.hero; g.beginPath(); g.arc(ex, ey, R * 0.26, 0, 7); g.fill(); g.restore(); }
      ctx.heads.hero = ctx.heads.hero || { head: [hx, hy], R }; ctx.heads.first = ctx.heads.first || ctx.heads.hero;
      if (ku <= 0 && occ > 0) ctx.sleeper = [hx + R, hy - R * 1.2];
      if (b.zzz && ku <= 0 && occ > 0 && !(a.fx || []).some((f) => f.kind === 'zzz')) drawFx(g, lt, info, [{ kind: 'zzz', x: hx + R, y: hy - R * 1.2 }]);   // 1.10: da co fx zzz thi khong ve them (het zzz doi)
    }
    for (const ac of front) { const r = drawActor(g, ac, lt, M, info, heroX, ctx); if (r) { if (ac.who === 'voice') ctx.voice = r; else { ctx.heads[ac.who] = r; ctx.heads.first = ctx.heads.first || r; } } }
    drawFx(g, lt, info, (a.fx || []).filter((f) => !['flash', 'pulse', 'dark', 'glitch'].includes(f.kind)), ctx);
    drawFg(g, a.fg);
  });
  overlays(g, lt, info, ctx);
});

// ---------- phone: dien thoai can canh, hai tay cam. args: screen + du lieu man hinh (xem phone.js), bg (boi canh mo phia sau), hands (true), tilt
tpl('phone', (g, lt, info, a) => {
  camera(g, lt, info, () => {
    if (a.bg) blurBg(g, a.bg, a.setArgs, 0.45); else { fillAll(g, '#0d0e12'); light(g, E.W / 2, E.H / 2, E.H, '#3a4a8a', 0.18); }
    worldGrade(g, a.grade, lt);   // 1.10 nen mat mau theo nhip (man hinh van sang mau)
    // 1.10: mac dinh = tay tu nhien (ban 1.4.0: ngon thon co bong, ngon cai luot). Tay 1.3.0 (ngon xam vien den day, trong nhu cong tac gat): "hands": "classic" hoac look classic
    const hc = a.hands === 'classic' || (classic() && a.hands !== 'new'), h = fs(a.h, E.vertical ? 0.62 : hc ? 0.95 : 0.88), cx = fx(a.x, 0.5), cy = fy(a.y, E.vertical ? 0.5 : hc ? 0.6 : 0.575) + Math.sin(lt * 1.3) * 3 + (hc ? 0 : noise(lt * 0.6, 21) * 4);
    const hold = a.hold ?? 1.1, pw = h * 0.49, rot = (a.tilt ?? -0.03) + (hc ? 0 : noise(lt * 0.5, 23) * 0.008), ho = { t: lt, sleeve: a.sleeve ?? PAL.hood, tap: a.thumb ?? (hc ? undefined : a.screen === 'feed' || a.screen === 'reel'), hands: hc ? 'classic' : 'new', period: a.screen === 'feed' ? hold + Math.min(0.3, hold * 0.4) : 1.6 };
    g.save(); g.translate(cx, cy); g.rotate(rot);
    if (a.hands !== false) { phoneHand(g, -pw / 2, -h / 2, pw, h, -1, 'back', ho); if (a.hands !== 'left') phoneHand(g, -pw / 2, -h / 2, pw, h, 1, 'back', ho); }
    phone(g, 0, 0, h, { ...a, t: lt - (a.screenAt ?? 0) });
    if (a.hands !== false) { phoneHand(g, -pw / 2, -h / 2, pw, h, -1, 'front', ho); if (a.hands !== 'left') phoneHand(g, -pw / 2, -h / 2, pw, h, 1, 'front', ho); }
    g.restore();
    drawFx(g, lt, info, (a.fx || []).filter((f) => !['flash', 'pulse', 'dark', 'glitch'].includes(f.kind)));
  });
  // chu ke chuyen dat canh dien thoai (khong de len man hinh)
  const side = (a.texts || []).map((t) => (t.kind === 'narr' && t.x === undefined && t.y === undefined && !t.pos && !E.vertical ? { ...t, x: fx(a.x, 0.5) < E.W / 2 ? 0.76 : 0.78, y: 0.5, maxW: 0.32 } : t));
  overlays(g, lt, { ...info, args: { ...a, texts: side } }, {});
});
// ---------- clock: dong ho bao thuc to. args: time, timeAt [[giay, "5:01"]], ring, blink
tpl('clock', (g, lt, info, a) => { camera(g, lt, info, () => { fillAll(g, '#0d0d10'); bigClock(g, fx(a.x, 0.5), fy(a.y, 0.52), fs(a.s, 0.55), { time: at(lt, a.timeAt, a.time ?? '5:00'), ring: a.ring, blink: a.blink, t: lt, color: a.color }); drawFx(g, lt, info, (a.fx || []).filter((f) => !['flash', 'pulse', 'dark', 'glitch'].includes(f.kind))); }); overlays(g, lt, info, {}); });
// ---------- calendar: lich to. args: month, from, to (so o danh dau, dem dan), mode x|fill, reset {at}
tpl('calendar', (g, lt, info, a) => { camera(g, lt, info, () => { fillAll(g, '#121216'); const w = fs(a.s, 0.4) * (E.vertical ? 1.6 : 1); let n = Math.round(lerp(a.from ?? 0, a.to ?? a.from ?? 0, ease.inOut(clamp((lt - (a.at ?? 0.3)) / (a.dur ?? Math.max(0.5, info.dur * 0.7)))))); if (a.reset && lt >= a.reset.at) n = Math.round(lerp(n, 0, clamp((lt - a.reset.at) / 0.5))); calendar(g, E.W / 2 - w / 2, E.H * 0.56 - w * 0.55, w, { month: a.month, fill: n, mode: a.mode, color: a.color }); }); overlays(g, lt, info, {}); });
// ---------- face: can mat (tu nguc len). args: who, face, faceAt, look, lookAt, tears, sweat, bg (boi canh mo), glowFace, x
tpl('face', (g, lt, info, a) => {
  const ctx = { heads: {} };
  camera(g, lt, info, () => {
    if (a.bg) blurBg(g, a.bg, a.setArgs, 0.35); else fillAll(g, '#121216');
    worldGrade(g, a.grade, lt);
    drawLights(g, a.lights);
    const hgt = fs(a.h, E.vertical ? 0.95 : 1.2), x = fx(a.x, 0.5), y = fy(a.y, 0.52);
    const pp = { ...poseNow(lt, a.poseAt, a.pose || 'stand', a.poseDur) }; pp.head = poseNow(lt, a.poseAt, a.pose || 'stand', a.poseDur, 0.07).head;
    const fz = facingNow(lt, a.facingAt, a.facing ?? 1, a.turnDur ?? 0.3);
    const r = bean(g, x, y + hgt * 0.77, hgt, { who: a.who || 'hero', pose: pp, ...faceNow(lt, a.faceAt, a.face || 'neutral', a.faceDur), look: at(lt, a.lookAt, a.look ?? 0), facing: fz.f, t: lt, tears: a.tears, sweat: a.sweat, bloodshot: a.bloodshot, glowFace: a.glowFace, hold: a.hold, blink: a.blink, idle: a.idle, seed: a.seed, age: a.age });
    ctx.heads.hero = r; ctx.heads.first = r;
    for (const ac of a.actors || []) { const rr = drawActor(g, ac, lt, { gy: E.H * 0.8 }, info, x, ctx); if (rr && ac.who === 'voice') ctx.voice = rr; }
    drawFx(g, lt, info, (a.fx || []).filter((f) => !['flash', 'pulse', 'dark', 'glitch'].includes(f.kind)), ctx);
  });
  overlays(g, lt, info, ctx);
});
// ---------- note: so tay, tay viet chu (Caveat). args: text ("\n" xuong dong), at, cps
tpl('note', (g, lt, info, a) => { camera(g, lt, info, () => { fillAll(g, '#16130f'); notebook(g, fx(a.x, 0.5), fy(a.y, 0.52), fs(a.s, 0.8) * (E.vertical ? 0.9 : 1), { text: a.text, at: a.at, cps: a.cps, t: lt, sleeve: a.sleeve }); }); overlays(g, lt, info, {}); });
// ---------- black: nen den + chu (dung kem texts)
// black: nen den, chu to giua man. Dong ke chuyen (narr) co 72px; dong nhan (big) 112px vien xam. Tu xep doc giua man neu khong ghi y.
// 1.10 (do tu 3 video doi thu): khong vach mau nhan duoi chu (line: true de bat lai), bui troi mac dinh, chu day vao cham 1 -> 1,04 suot the
// (truoc day: 10 the den dung im = 34 giay dung hinh), dong nhan 92px (= 1,2 lan dong dau, nhu doi thu) thay vi 112px
tpl('black', (g, lt, info, a) => {
  const cl = classic(), bigS = a.bigSize || (cl ? (E.vertical ? 92 : 112) : (E.vertical ? 84 : 92)), narS = E.vertical ? 72 : 78;
  fillAll(g, '#0b0b0d'); if (a.dust ?? !cl) dust(g, lt, { n: cl ? 25 : 34, hand: handOn(info) });
  const list = (a.texts || []).map((t) => ({ ...t, ...(t.kind === 'big' && !t.size ? { size: bigS } : {}), ...(cl || t.at !== undefined ? {} : { at: 0.15 }), ...(cl || t.fi !== undefined ? {} : { fi: 0.8 }) })); /* 1.10 chu hien dan 0,8s (doi thu): khong co quang dung giua 2 dong */ const free = list.filter((t) => t.y === undefined && !t.pos && (t.kind === 'narr' || t.kind === 'big' || !t.kind));
  if (free.length) {
    const hs = free.map((t) => (t.kind === 'big' ? bigS * 1.25 : narS * 1.5)); const tot = hs.reduce((p, q) => p + q, 0); let y = E.H * (a.cy ?? (cl ? 0.43 : 0.47)) - tot / 2;
    free.forEach((t, i) => { t.y = y + hs[i] / 2; y += hs[i]; if (t.kind !== 'big' && !t.size) t.size = narS; t.maxW = t.maxW ?? 0.9; });
  }
  const push = cl || a.push === false ? 1 : 1 + (a.push ?? 0.08) * clamp(lt / Math.max(1, info.dur));   // deu (tuyen tinh): khong co doan gan nhu dung yen o dau / cuoi
  g.save(); g.translate(E.W / 2, E.H / 2); g.scale(push, push); g.translate(-E.W / 2, -E.H / 2);
  overlays(g, lt, { ...info, args: { ...a, texts: list, vignette: cl ? false : a.vignette ?? 0.35 } }, {});
  g.restore();
  if (cl ? a.line !== false : a.line === true) { const S = safe(), w = E.W * 0.115, yy = S.bottom - (E.vertical ? 200 : 26); g.save(); g.strokeStyle = accent(); g.globalAlpha = 0.85; g.lineWidth = 6; g.lineCap = 'round'; g.shadowColor = accent(); g.shadowBlur = 12; g.beginPath(); g.moveTo(E.W / 2 - w / 2, yy); g.lineTo(E.W / 2 + w / 2, yy); g.stroke(); g.restore(); }
});
// ---------- card: the ket. args: word ("DISCIPLINE."), sub, sub2 (mau nhan), part ("PART 2"), type (go tung chu), at
tpl('card', (g, lt, info, a) => {
  fillAll(g, '#0f0f12'); dust(g, lt, { n: 22, hand: handOn(info) }); light(g, E.W / 2, E.H * 0.45, E.H * 0.7, '#ffffff', 0.05);
  if (!classic() && a.push !== false) { const z = 1 + (a.push ?? 0.06) * clamp(lt / Math.max(1, info.dur)); g.translate(E.W / 2, E.H * 0.45); g.scale(z, z); g.translate(-E.W / 2, -E.H * 0.45); }   // 1.10 day vao cham: the ket khong dung im
  const word = a.word || 'DISCIPLINE.', a0 = a.at ?? 0.4, size = fs(a.size, E.vertical ? 0.075 : 0.15), cy = E.H * (E.vertical ? 0.45 : 0.42);
  const nType = a.type === false ? word.length : Math.floor(clamp((lt - a0) / (a.typeDur ?? 1.2)) * word.length);
  const vis = word.slice(0, nType), fullW = measure(g, word, size, FONT_NARR, 700);
  const cl = classic(), u0 = a0 + (a.typeDur ?? 1.2) + 0.1;
  if (cl) text(g, vis, E.W / 2 - fullW / 2, cy, { size, font: FONT_NARR, weight: 700, color: PAL.white, align: 'left', glowColor: 'rgba(255,255,255,0.25)' });
  else { g.save(); g.shadowColor = 'rgba(255,255,255,0.35)'; g.shadowBlur = size * 0.22; text(g, vis, E.W / 2 - fullW / 2, cy, { size, font: FONT_NARR, weight: 700, color: '#f3f0e8', align: 'left', stroke: size * 0.045, strokeColor: '#f3f0e8' }); g.restore(); }   // chu day, vien sang mem
  if (cl) stroke(g, E.W / 2 - fullW * 0.52, cy + size * 0.62, E.W / 2 + fullW * 0.52, cy + size * 0.6, { p: clamp((lt - u0) / 0.45), lw: size * 0.06, wob: 2 });
  else wave(g, E.W / 2 - fullW * 0.53, E.W / 2 + fullW * 0.53, cy + size * 0.68, { p: ease.out(clamp((lt - u0) / 0.55)), lw: size * 0.05, amp: size * 0.045, waves: 2.6 });   // gach chan luon song ve tay
  let y = cy + size * 1.1;
  if (a.part) { const q = clamp((lt - u0 - 0.2) / 0.4); text(g, a.part, E.W / 2, y, { size: size * 0.38, font: FONT_NARR, weight: 700, color: PAL.white, a: q }); y += size * 0.55; }
  if (a.sub) { const q = clamp((lt - u0 - 0.5) / 0.5); text(g, a.sub, E.W / 2, y, { size: size * 0.3, font: FONT_NARR, weight: 700, color: '#e6e6ea', a: q }); y += size * 0.42; }
  if (a.sub2) { const q = clamp((lt - (a.sub2At ?? u0 + 1.5)) / 0.5); text(g, a.sub2, E.W / 2, y, { size: size * 0.3, font: FONT_NARR, weight: 700, color: accent(), a: q, glowColor: alpha(accent(), 0.5) }); }
  drawTexts(g, lt, info, a.texts);
});
// ---------- cta: man xin dang ky cuoi phim. args: line ("If this hit, like and subscribe."), line2, who (nhan vat vay tay)
tpl('cta', (g, lt, info, a) => {
  fillAll(g, '#0f0f12'); light(g, E.W / 2, E.H * 0.6, E.H * 0.6, '#ffffff', 0.05);
  const cl = classic(); if (!cl) { dust(g, lt, { n: 22, hand: handOn(info) }); const z = 1 + 0.06 * clamp(lt / Math.max(1, info.dur)); g.translate(E.W / 2, E.H / 2); g.scale(z, z); g.translate(-E.W / 2, -E.H / 2); }   // 1.10 khong dung im
  const S = safe(), y0 = E.vertical ? E.H * 0.32 : S.top + (S.h * 0.18);
  narr(g, a.line || 'If this hit, like and subscribe.', E.W / 2, y0, { size: E.vertical ? 60 : 54, a: clamp((lt - 0.2) / 0.5) });
  const by = y0 + (E.vertical ? 150 : 120), k1 = lt > 1.6, k2 = lt > 2.6;
  const btn = (x, label, on, col) => { const w = measure(g, label, 38, FONT_UI, 700) + 90; g.save(); g.fillStyle = on ? col : '#2a2c33'; g.beginPath(); g.roundRect(x - w / 2, by - 36, w, 72, 36); g.fill(); g.restore(); text(g, (on && label === 'SUBSCRIBE' ? '✓ SUBSCRIBED' : label), x, by, { size: 34, font: FONT_UI, weight: 700, color: '#fff' }); };
  btn(E.W / 2 - 190, 'LIKE', k1, '#3d6ff2'); btn(E.W / 2 + 170, 'SUBSCRIBE', k2, '#4a4c55');
  const cxk = lt < 1.6 ? kf(lt, [[0.6, [E.W * 0.7, E.H * 0.7]], [1.5, [E.W / 2 - 180, by + 14]]]) : kf(lt, [[1.7, [E.W / 2 - 180, by + 14]], [2.5, [E.W / 2 + 200, by + 14]]]);
  g.save(); g.translate(cxk[0], cxk[1]); g.fillStyle = '#fff'; g.strokeStyle = '#000'; g.lineWidth = 2; g.beginPath(); g.moveTo(0, 0); g.lineTo(0, 30); g.lineTo(8, 23); g.lineTo(14, 36); g.lineTo(19, 33); g.lineTo(13, 21); g.lineTo(23, 21); g.closePath(); g.fill(); g.stroke(); g.restore();
  if (a.line2) narr(g, a.line2, E.W / 2, by + 80, { size: 34, color: accent(), a: clamp((lt - 3) / 0.5) });
  bean(g, E.W / 2, (E.vertical ? E.H * 0.72 : S.bottom - 40), E.H * (E.vertical ? 0.16 : cl ? 0.2 : 0.3), { who: a.who || 'hero', pose: poseNow(lt, [[2.8, 'wave']], 'stand'), ...faceNow(lt, [[2.8, 'smile']], 'neutral'), t: lt, look: 0 });
});

// ---------- graph (1.10, kieu DOPAMINE "Every cheap high comes with a crash."): do thi cam xuc ve dan tren nen den.
// args: kind crash | climb | spikes | flat | pts [[x 0..1, y 0..1], ...]; color; ylabel ("how good you feel"); xlabel ("time"); baseline (true | 0..1 | false);
//       markers ("phone" o cac dinh | false); label { t, at: 0..1 vi tri tren duong }; at (giay bat dau ve), dur (giay ve xong); texts (chu ke chuyen o tren)
const GRAPHS = {
  crash: [[0, 0.5], [0.1, 0.5], [0.16, 0.92], [0.23, 0.32], [0.32, 0.4], [0.39, 0.8], [0.46, 0.22], [0.58, 0.28], [0.72, 0.17], [0.86, 0.2], [1, 0.14]],
  spikes: [[0, 0.5], [0.08, 0.5], [0.13, 0.9], [0.19, 0.38], [0.28, 0.86], [0.34, 0.3], [0.44, 0.82], [0.5, 0.24], [0.6, 0.78], [0.66, 0.18], [0.8, 0.2], [1, 0.12]],
  climb: [[0, 0.2], [0.12, 0.14], [0.26, 0.18], [0.42, 0.28], [0.58, 0.42], [0.74, 0.56], [0.88, 0.66], [1, 0.76]],
  flat: [[0, 0.45], [0.25, 0.47], [0.5, 0.44], [0.75, 0.46], [1, 0.45]],
};
const crPt = (P, u) => {   // Catmull-Rom tren danh sach diem (u 0..1 theo doan)
  const n = P.length - 1, s = clamp(u) * n, i = Math.min(n - 1, Math.floor(s)), k = s - i, p0 = P[Math.max(0, i - 1)], p1 = P[i], p2 = P[i + 1], p3 = P[Math.min(n, i + 2)];
  const c = (a, b, c2, d) => 0.5 * (2 * b + (-a + c2) * k + (2 * a - 5 * b + 4 * c2 - d) * k * k + (-a + 3 * b - 3 * c2 + d) * k * k * k);
  return [c(p0[0], p1[0], p2[0], p3[0]), c(p0[1], p1[1], p2[1], p3[1])];
};
tpl('graph', (g, lt, info, a) => {
  fillAll(g, '#0b0b0d'); dust(g, lt, { n: 26, hand: handOn(info) });
  const kind = a.kind || 'crash', P = a.pts || GRAPHS[kind] || GRAPHS.crash, col = a.color || (kind === 'climb' ? '#ffc04d' : accent());
  const x0 = E.W * (E.vertical ? 0.12 : 0.16), x1 = E.W * (E.vertical ? 0.9 : 0.8), y0 = E.H * (E.vertical ? 0.38 : 0.3), y1 = E.H * (E.vertical ? 0.7 : 0.8);
  const X = (u) => lerp(x0, x1, u), Y = (v) => lerp(y1, y0, v), a0 = a.at ?? 0.5, d = a.dur ?? Math.max(1.2, info.dur - a0 - 1.2), pr = ease.inOut(clamp((lt - a0) / d));
  const z = 1 + 0.05 * clamp(lt / Math.max(1, info.dur)); g.save(); g.translate(E.W / 2, E.H / 2); g.scale(z, z); g.translate(-E.W / 2, -E.H / 2);
  const ax = clamp(lt / 0.5); g.save(); g.globalAlpha *= ax; g.strokeStyle = '#d9d9de'; g.lineWidth = 3; g.lineCap = 'round'; g.beginPath(); g.moveTo(x0, y0 - 20); g.lineTo(x0, y1); g.lineTo(x1 + 20, y1); g.stroke();
  text(g, a.ylabel ?? 'how good you feel', x0 + 14, y0 - 12, { size: E.vertical ? 30 : 24, font: FONT_NARR, weight: 700, color: '#b9b9c0', align: 'left' });
  text(g, a.xlabel ?? 'time', x1 + 14, y1 + 30, { size: E.vertical ? 30 : 24, font: FONT_NARR, weight: 700, color: '#b9b9c0', align: 'right' });
  if (a.baseline !== false) { const bv = typeof a.baseline === 'number' ? a.baseline : P[0][1]; g.setLineDash([12, 12]); g.strokeStyle = 'rgba(200,200,210,0.45)'; g.lineWidth = 2; g.beginPath(); g.moveTo(x0, Y(bv)); g.lineTo(x1, Y(bv)); g.stroke(); g.setLineDash([]); text(g, a.baseLabel ?? 'baseline', x1 + 10, Y(bv) - 18, { size: E.vertical ? 26 : 20, font: FONT_NARR, weight: 700, color: '#8d8d96', align: 'right' }); }
  g.restore();
  if (pr > 0) {   // duong ve dan + dau phat sang
    const N = 160, m = Math.max(2, Math.round(N * pr)); g.save(); g.strokeStyle = col; g.lineWidth = E.vertical ? 8 : 7; g.lineCap = 'round'; g.lineJoin = 'round'; g.shadowColor = col; g.shadowBlur = 16;
    g.beginPath(); for (let i = 0; i <= m; i++) { const q = crPt(P, (i / N)), px = X(q[0]), py = Y(q[1]); i ? g.lineTo(px, py) : g.moveTo(px, py); } g.stroke(); g.restore();
    const hd = crPt(P, m / N); light(g, X(hd[0]), Y(hd[1]), 46, col, 0.55); g.save(); g.fillStyle = '#fff'; g.beginPath(); g.arc(X(hd[0]), Y(hd[1]), 8, 0, 7); g.fill(); g.restore();
    if (a.markers !== false && (kind === 'crash' || kind === 'spikes' || a.markers === 'phone')) {   // dien thoai nho o moi dinh vuot duong nen (cu "high" re tien)
      const base = P[0][1]; P.forEach((p, i) => { if (i === 0 || i === P.length - 1 || p[1] < base + 0.2 || p[1] < P[i - 1][1] || p[1] < P[i + 1][1]) return; const u = i / (P.length - 1); if (m / N < u) return; const k2 = ease.outBack(clamp((m / N - u) * 8)), px = X(p[0]), py = Y(p[1]) - 46;
        g.save(); g.translate(px, py); g.scale(k2, k2); g.fillStyle = '#1b1c22'; g.strokeStyle = col; g.lineWidth = 2.5; g.shadowColor = col; g.shadowBlur = 12; g.beginPath(); g.roundRect(-12, -20, 24, 40, 5); g.fill(); g.stroke(); g.fillStyle = alpha(col, 0.8); g.fillRect(-8, -15, 16, 28); g.restore(); });
    }
    if (a.label) { const lu = a.label.at ?? 0.15, q = crPt(P, lu); if (pr > lu) text(g, a.label.t, X(q[0]) + 10, Y(q[1]) + 34, { size: E.vertical ? 32 : 26, font: FONT_NARR, weight: 700, color: col, align: 'left', a: clamp((pr - lu) * 6) }); }
  }
  g.restore();
  overlays(g, lt, { ...info, args: { ...a, vignette: 0.3 } }, {});
});

export const TEMPLATE_LIST = ['scene', 'phone', 'clock', 'calendar', 'face', 'note', 'black', 'card', 'cta', 'graph'];
