// stage.js — che do cinematic 2D (kieu phim hoat hinh vector dien anh, do tu "1-MINUTE"): canh = cac lop phang tu xa toi gan,
// may 2D (dich / phong / xoay) thuong dung yen, thinh thoang day cham deu / lia nhe; parallax theo lop; nhoe theo lop (lop tinh luu san ban nhoe);
// vang sang gradient, vignette, hat nhieu co seed. Ve bang Canvas 2D (CPU, khong can GPU), tat dinh: cung t -> cung khung.
import { E, clamp, lerp } from '../core.js';
import { easeOf, fbm1, rng } from '../cine/timeline.js';

// ---------- may 2D: { x, y (diem nhin, px logic), z (phong), r (xoay) }
// spec: { from, to, at, len, ease: 'steady' (day deu, vao / ra rat mem — kieu phim tham khao) | 'cubic' | ..., hand (rung % khung, mac dinh 0) }
const steady = (k) => lerp(k, k * k * (3 - 2 * k), 0.3);
export function camAt(lt, dur, spec = {}) {
  const A = { x: E.W / 2, y: E.H / 2, z: 1, r: 0, ...(spec.from || {}) }, B = { ...A, ...(spec.to || {}) };
  const a0 = spec.at ?? 0, len = spec.len ?? Math.max(0.1, dur - a0);
  const k = (spec.ease === 'steady' || !spec.ease ? steady : easeOf(spec.ease))(clamp((lt - a0) / len));
  const c = { x: lerp(A.x, B.x, k), y: lerp(A.y, B.y, k), z: lerp(A.z, B.z, k), r: lerp(A.r, B.r, k) };
  const h = spec.hand || 0, gt = spec.gt ?? lt;
  if (h) { c.x += fbm1(gt * 0.4, 3) * h / 100 * E.W; c.y += fbm1(gt * 0.33, 7) * h / 100 * E.H; c.r += fbm1(gt * 0.25, 11) * h / 100 * 0.3; }
  // giu khung trong anh (khong lo mep lop)
  const hw = E.W / (2 * c.z), hh = E.H / (2 * c.z); c.x = clamp(c.x, hw, E.W - hw); c.y = clamp(c.y, hh, E.H - hh);
  return c;
}
// bien doi cua 1 lop co do sau p (0 = xa vo cuc, 1 = mat phang chu the, > 1 = tien canh): phong 1 + (z - 1) * p, dich theo p
export function applyLayer(g, cam, p = 1) {
  const z = 1 + (cam.z - 1) * p, cx = E.W / 2, cy = E.H / 2;
  g.translate(cx, cy); if (cam.r) g.rotate(cam.r * p); g.scale(z, z); g.translate(-cx - (cam.x - cx) * p, -cy - (cam.y - cy) * p);
}

// diem trong lop do sau p -> diem tren man hinh (px logic), bo qua xoay (de dat chu / do de chu)
export function toScreen(pt, cam, p = 1) {
  const z = 1 + (cam.z - 1) * p, cx = E.W / 2, cy = E.H / 2;
  return [cx + (pt[0] - cx - (cam.x - cx) * p) * z, cy + (pt[1] - cy - (cam.y - cy) * p) * z];
}

// ---------- lop: { key, p, draw(g, lt), dyn: true (ve lai moi khung) | false (ve 1 lan, luu canvas), add: 'lighter' | 'screen' (lop anh sang) }
// lop tinh: ve vao canvas rong hon khung (le M) va do phan giai cao hon (OS) de day may / lia khong lo mep, khong mo
const M = 0.12, CACHE = new Map();
function osOf() { return Math.min(1.5, 3000 / ((E.W * (1 + 2 * M)) * E.PX)); }
function baked(L, blur) {
  const os = osOf(), key = `${L.key}|${E.PX}|${Math.round(blur * 2) / 2}`;
  if (CACHE.has(key)) return CACHE.get(key);
  let c;
  const base = `${L.key}|${E.PX}|0`;
  if (!CACHE.has(base)) {
    c = document.createElement('canvas'); c.width = Math.ceil(E.W * (1 + 2 * M) * E.PX * os); c.height = Math.ceil(E.H * (1 + 2 * M) * E.PX * os);
    const x = c.getContext('2d'); x.setTransform(E.PX * os, 0, 0, E.PX * os, E.W * M * E.PX * os, E.H * M * E.PX * os); L.draw(x, 0); CACHE.set(base, c);
  }
  if (blur < 0.5) return CACHE.get(base);
  const s = CACHE.get(base); c = document.createElement('canvas'); c.width = s.width; c.height = s.height;
  const x = c.getContext('2d'); x.filter = `blur(${blur * E.PX * os}px)`; x.drawImage(s, 0, 0); CACHE.set(key, c);
  if (CACHE.size > 14) for (const k of [...CACHE.keys()].slice(0, CACHE.size - 14)) CACHE.delete(k);   // moi canvas ~20 MB: giu toi da 14
  return c;
}
// canvas tam theo "ngan" (moi ngan 1 kich thuoc co dinh -> khong tao lai canvas moi khung)
const SLOTS = {};
function slot(name, w, h) { let c = SLOTS[name]; if (!c || c.width !== w || c.height !== h) { c = SLOTS[name] = document.createElement('canvas'); c.width = w; c.height = h; } const x = c.getContext('2d'); x.setTransform(1, 0, 0, 1, 0, 0); x.clearRect(0, 0, w, h); return x; }
let _tmp = null, _blr = null;
function blurCanvas(w, h) { const x = slot('blur', w, h); _blr = x.canvas; return x; }
function tmpCanvas(w, h) { const x = slot(w > E.W * E.PX * 0.75 ? 'full' : 'half', w, h); _tmp = x.canvas; return x; }
// do nhoe cua lop (px logic o 1080p): aperture * |p - focus| * 12, toi da 16. focus = do sau cua chu the (thuong 1)
export const blurOf = (p, o) => Math.min(16, (o.aperture ?? 0) * Math.abs(p - (o.focus ?? 1)) * 12) * (E.H / 1080);
export function renderLayers(g, layers, cam0, o = {}, lt = 0) {
  for (const L0 of [...layers].sort((a, b) => (a.order ?? a.p) - (b.order ?? b.p))) {
    const L = L0, cam = L0.cam || cam0;   // lop co may rieng (vd can mat: nen phong to + nhoe, nguoi ve thang)
    const b = L.blur ?? blurOf(L.p, o);
    g.save(); g.setTransform(E.PX, 0, 0, E.PX, 0, 0);
    if (L.add) g.globalCompositeOperation = L.add;
    if (L.a !== undefined) g.globalAlpha = L.a;
    if (!L.dyn) { const c = baked(L, b); applyLayer(g, cam, L.p); g.drawImage(c, -E.W * M, -E.H * M, E.W * (1 + 2 * M), E.H * (1 + 2 * M)); }
    else if (b >= 0.5) {   // lop dong bi nhoe: ve o NUA do phan giai roi lam mo + phong len (nhanh ~4 lan, nhoe thi khong thay khac)
      const W = Math.ceil(g.canvas.width / 2), H = Math.ceil(g.canvas.height / 2), x = tmpCanvas(W, H); x.setTransform(E.PX / 2, 0, 0, E.PX / 2, 0, 0); applyLayer(x, cam, L.p); L.draw(x, lt);
      const y = blurCanvas(W, H); y.filter = `blur(${b * E.PX / 2}px)`; y.drawImage(_tmp, 0, 0); y.filter = 'none';
      g.setTransform(1, 0, 0, 1, 0, 0); g.drawImage(_blr, 0, 0, g.canvas.width, g.canvas.height);
    } else { applyLayer(g, cam, L.p); L.draw(g, lt); }
    g.restore();
  }
}

// ---------- anh sang + hau ky (ve trong toa do logic, khong theo may tru khi goi trong applyLayer)
export function glow(g, x, y, r, color, a = 0.5) {
  if (!(r > 1) || !(a > 0)) return;
  const gr = g.createRadialGradient(x, y, 0, x, y, r); gr.addColorStop(0, rgba(color, a)); gr.addColorStop(0.35, rgba(color, a * 0.45)); gr.addColorStop(1, rgba(color, 0));
  g.fillStyle = gr; g.fillRect(x - r, y - r, r * 2, r * 2);
}
export function rgba(c, a) { const h = c.replace('#', ''), n = parseInt(h.length === 3 ? h.split('').map((x) => x + x).join('') : h, 16); return `rgba(${(n >> 16) & 255},${(n >> 8) & 255},${n & 255},${a})`; }
export function vgrad(g, x0, y0, x1, y1, stops) { const gr = g.createLinearGradient(x0, y0, x1, y1); stops.forEach(([o, c]) => gr.addColorStop(o, c)); return gr; }

let grains = null;
// hau ky toan khung: vignette manh (nhu phim tham khao), mau ke chuyen (sat, dim), hat nhieu rat nhe doi moi 2 khung
export function post(g, o = {}) {
  const w = g.canvas.width, h = g.canvas.height;
  g.save(); g.setTransform(1, 0, 0, 1, 0, 0);
  if ((o.sat ?? 1) < 0.995 || (o.dim ?? 0) > 0.005) { const x = tmpCanvas(w, h); x.drawImage(g.canvas, 0, 0); g.filter = `saturate(${o.sat ?? 1}) brightness(${1 - (o.dim ?? 0)})`; g.drawImage(_tmp, 0, 0); g.filter = 'none'; }
  const vg = o.vignette ?? 0.55;
  if (vg > 0) { const r = Math.hypot(w, h) / 2, gr = g.createRadialGradient(w / 2, h / 2, r * 0.35, w / 2, h / 2, r * 1.02); gr.addColorStop(0, 'rgba(0,0,0,0)'); gr.addColorStop(0.6, `rgba(0,0,0,${vg * 0.35})`); gr.addColorStop(1, `rgba(0,0,0,${vg})`); g.fillStyle = gr; g.fillRect(0, 0, w, h); }
  const gn = o.grain ?? 0.05;
  if (gn > 0) {
    if (!grains) { grains = []; for (let k = 0; k < 4; k++) { const c = document.createElement('canvas'); c.width = c.height = 256; const x = c.getContext('2d'), id = x.createImageData(256, 256), r = rng(k + 31); for (let i = 0; i < id.data.length; i += 4) { const v = 128 + (r() - 0.5) * 255; id.data[i] = id.data[i + 1] = id.data[i + 2] = v; id.data[i + 3] = 255; } x.putImageData(id, 0, 0); grains.push(c); } }
    g.globalCompositeOperation = 'overlay'; g.globalAlpha = gn; g.fillStyle = g.createPattern(grains[Math.floor(E.frame / 2) % 4], 'repeat'); g.fillRect(0, 0, w, h);
  }
  g.restore();
}
export function clearCache() { CACHE.clear(); }
