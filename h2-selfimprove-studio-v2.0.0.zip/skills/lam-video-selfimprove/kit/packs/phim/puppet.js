// puppet.js — nhan vat roi 2D kieu phim hoat hinh vector dien anh (do tu "1-MINUTE"):
// khoi DEN dac (dau tron to ~29% chieu cao, than bo goc, tay chan hinh con nhong, ban tay tron), VIEN XAM MANH lech ve phia nguon sang
// (tung bo phan co vien rieng -> thay ca duong tach tay / than), mat bau duc mau KEM co cham sang, long may XAM cung manh, khong mieng.
// Chuyen dong muot 30 fps (tween), cu dong roi giu yen; cam xuc o long may doi goc dan, chop mat, nghieng dau, dang nguoi.
// Tu the dung lai ngu phap 2D cua bo legacy (poseNow: goc canh tay / cang tay / dui / cang chan trong mat phang nghieng) -> chieu sang goc nhin bat ky.
import { E, clamp, lerp, ease } from '/engine/core.js';
import { blink as blinkAt, fbm1 } from '/engine/cine/timeline.js';
import { poseNow, faceNow, facingNow } from '/packs/dem/templates.js';
import { rgba } from '/engine/flat/stage.js';

const ACC = { red: '#ff3b3b', pink: '#ff4fa3', amber: '#ffb03b', teal: '#38d1c4' };
export const accent = () => ACC[E.cfg.accent] || E.cfg.accent || ACC.red;
// bieu cam khong mieng: [mo mat, nghieng mat (+ duoi ngoai cup), nang may (x ban kinh dau), goc may (+ dau trong nhuong len = buon / lo), cui dau (rad)]
export const F2 = {
  neutral: [1, 0, 0, 0, 0], tired: [0.5, 0.05, -0.02, 0.05, 0.08], sleepy: [0.3, 0, -0.03, 0, 0.1], sleep: [0.06, 0, -0.04, 0, 0.08],
  sad: [0.85, 0.12, 0.01, 0.3, 0.12], cry: [0.7, 0.15, 0.02, 0.4, 0.15], worried: [1, 0.08, 0.03, 0.34, 0.03], scared: [1.25, 0, 0.06, 0.25, 0],
  shock: [1.35, 0, 0.08, 0.05, -0.04], angry: [0.85, -0.15, -0.04, -0.38, 0.02], determined: [0.9, -0.08, -0.02, -0.22, -0.02], effort: [0.6, -0.08, -0.03, -0.3, 0.04],
  smile: [0.45, -0.04, 0.02, 0.08, -0.02], happy: [0.4, 0, 0.03, 0.12, -0.04], smirk: [0.7, 0, 0.01, -0.12, 0], empty: [0.75, 0, -0.01, 0, 0.06],
  guilty: [0.75, 0.1, 0.01, 0.26, 0.16], bloodshot: [0.55, 0.04, -0.01, 0.08, 0.06], haunted: [1.05, 0.04, 0.02, 0.22, 0.04], grin: [0.6, -0.3, -0.03, -0.42, 0.03],
  hopeful: [1.08, 0, 0.04, 0.16, -0.1], relieved: [0.4, 0.04, 0.02, 0.12, -0.04], proud: [0.75, -0.04, 0.02, 0, -0.1], embarrassed: [0.75, 0.08, 0.02, 0.26, 0.15],
  disgusted: [0.6, -0.08, -0.03, -0.26, 0.02], annoyed: [0.6, -0.12, -0.03, -0.3, 0], skeptical: [0.85, 0, 0.02, -0.08, 0], exhausted: [0.38, 0.12, -0.02, 0.18, 0.12],
  yawn: [0.2, 0, 0.03, 0.18, -0.06], dazed: [0.6, 0, 0, 0, 0.05], panic: [1.3, 0, 0.07, 0.4, 0], sob: [0.35, 0.16, 0.03, 0.44, 0.17],
  shout: [0.95, -0.12, -0.03, -0.35, -0.04], thinking: [0.9, 0, 0.04, 0.08, -0.08], tempted: [0.65, 0, 0, 0.04, 0.05], grit: [0.6, -0.12, -0.04, -0.35, 0.03], lonely: [0.85, 0.1, 0.01, 0.22, 0.14],
};
const ANX = ['scared', 'worried', 'panic', 'cry', 'sob', 'shock', 'embarrassed'];
// phu kien theo nhan vat (khoa suot phim). Than luon den; chi phu kien co mau
export const CAST2 = {
  hero: {}, hoodie: { hood: true }, hooded: { hood: 'up' }, band: { band: '#ece6d6' },
  friend: { cap: '#e8b33c' }, friend2: { cap: '#4d8cff' }, friend3: { cap: '#d64545' },
  girl: { tail: true, scarf: '#e8b33c' }, mom: { bun: true }, dad: { glasses: true }, kid: { kid: true }, voice: { voice: true },
};
const INK = '#09090a', EYE = '#efe6d2', BROW = '#8f9498';

// ---------- hinh hoc (don vi = chieu cao h; goc toa do o giua hai ban chan, y len tren la am)
const G = { headR: 0.145, headY: -0.855, torsoTop: -0.735, torsoBot: -0.33, torsoW: 0.3, shY: -0.69, shX: 0.135, up: 0.2, fo: 0.18, armW: 0.052, handR: 0.036, hipY: -0.34, hipX: 0.066, th: 0.17, sh: 0.15, legW: 0.052 };
// huong chi trong khong gian than (x ngang, y len, z ve phia truoc) tu goc nghieng a (0 = thang xuong, + = ve truoc) + goc dang ab
// (toa do man hinh: y DUONG la xuong duoi -> chi buong thang = +y)
const dir = (a, ab, side) => [side * Math.sin(ab), Math.cos(a) * Math.cos(ab), Math.sin(a) * Math.cos(ab)];

// ve nhan vat. st: { pose (doi tuong tu the 2D), yaw (0 truoc, +-pi/2 nghieng, pi sau), face [5 so], look [x, y], blink 0..1, breath -1..1,
//   rim: -1 trai | 1 phai (phia nguon sang), rimC, who, outfit, alpha, tilt (nghieng dau), lag (tu the dau tre nhip) }
export function puppet(g, x, y, h, st) {
  const C = { ...(CAST2[st.who] || {}), ...(st.outfit || {}) }, V = !!C.voice, p = st.pose || {}, yaw = st.yaw || 0, cy = Math.cos(yaw), sy = Math.sin(yaw);
  const s = h * (C.kid ? 0.72 : 1), lean = (p.lean || 0) * 0.85, drop = st.anchor === 'hip' ? 0 : (p.drop || 0) / 100 * 0.55;
  // vien: phia sang day 2,5–3 px (60–85%), phia toi 1 px mo -> tach khoi nen toi ma van manh
  const ink = V ? '#040405' : INK, rimC = st.rimC || (V ? accent() : '#c9cdd0'), rw = Math.max(2.6, (V ? 0.012 : 0.0075) * s);
  const rdx = (st.rim ?? -1) * rw, rdy = -rw * 0.55, rimLit = rgba(rimC.length === 7 ? rimC : '#c9cdd0', V ? 0.95 : 0.85), rimDark = rgba(rimC.length === 7 ? rimC : '#c9cdd0', 0.35);
  // diem than (x, y, z) -> man hinh, co cui than (lean quanh hong) va quay (yaw)
  const hipY = G.hipY + drop;
  const P = (q, upper) => {
    let [qx, qy, qz] = q;
    if (upper && lean) { const dy = qy - hipY; qy = hipY + dy * Math.cos(lean); qz -= dy * Math.sin(lean); }   // cui than quanh hong: phan tren ra truoc + thap xuong
    const X = qx * cy + qz * sy, Z = -qx * sy + qz * cy;
    return [x + X * s, y + (st.anchor === 'hip' ? (qy - hipY) : qy) * s, Z];
  };
  const parts = [];   // { z, draw(fill, dx, dy) }
  const capsule = (a, b, w) => (c, dx, dy) => { g.strokeStyle = c; g.lineWidth = w * s; g.lineCap = 'round'; g.beginPath(); g.moveTo(a[0] + dx, a[1] + dy); g.lineTo(b[0] + dx, b[1] + dy); g.stroke(); };
  const disc = (q, r) => (c, dx, dy) => { g.fillStyle = c; g.beginPath(); g.arc(q[0] + dx, q[1] + dy, r * s, 0, Math.PI * 2); g.fill(); };
  // tay
  const ab = (u) => 0.1 + clamp((Math.abs(u) - 1.5) / 1.2) * 0.5;
  for (const [side, key] of [[1, 'aF'], [-1, 'aB']]) {
    const [u, f] = p[key] || [0, 0], sh = [side * G.shX, G.shY + drop, 0], d1 = dir(u, ab(u), side), el = sh.map((v, i) => v + d1[i] * G.up), d2 = dir(f, ab(u) * 0.6, side), hd = el.map((v, i) => v + d2[i] * G.fo);
    const S = P(sh, true), Ee = P(el, true), Hh = P(hd, true), z = (Ee[2] + Hh[2]) / 2 + (side * sy > 0 ? 0.001 : 0);
    parts.push({ z: Math.min(S[2], z) - 0.02 + Math.max(0, z) * 2, draw: (c, dx, dy) => { capsule(S, Ee, G.armW)(c, dx, dy); capsule(Ee, Hh, G.armW * 0.93)(c, dx, dy); disc(Hh, G.handR)(c, dx, dy); }, hand: Hh });
  }
  // chan
  for (const [side, key] of [[1, 'lF'], [-1, 'lB']]) {
    const [t, k] = p[key] || [0, 0], hp = [side * G.hipX, hipY, 0], d1 = dir(t, 0.03, side), kn = hp.map((v, i) => v + d1[i] * G.th), d2 = dir(k, 0.02, side), ft = kn.map((v, i) => v + d2[i] * G.sh);
    const A = P(hp), K = P(kn), F = P(ft);
    parts.push({ z: -0.05 + K[2] * 0.5, draw: (c, dx, dy) => { capsule(A, K, G.legW)(c, dx, dy); capsule(K, F, G.legW * 0.95)(c, dx, dy); g.fillStyle = c; g.beginPath(); g.ellipse(F[0] + dx + (Math.abs(sy) > 0.5 ? Math.sign(sy) * 0.02 * s : 0), F[1] + dy + 0.006 * s, (Math.abs(sy) > 0.5 ? 0.055 : 0.04) * s, 0.024 * s, 0, 0, Math.PI * 2); g.fill(); }, foot: F });
  }
  // than: hinh bo goc (vai tron), rong theo goc nhin (chinh dien rong, nghieng hep)
  const tw = G.torsoW * (Math.abs(cy) * 0.82 + 0.18 + Math.abs(sy) * 0.42), T0 = P([0, G.torsoTop + drop, 0], true), T1 = P([0, G.torsoBot + drop, 0]);
  const br = 1 + (st.breath || 0) * 0.008;
  parts.push({ z: 0, draw: (c, dx, dy) => { const w = tw * s * br, top = T0[1] + dy - (br - 1) * 0.3 * s, x0 = (T0[0] + T1[0]) / 2 - w / 2 + dx; g.fillStyle = c; g.beginPath(); g.roundRect(x0, top, w, T1[1] + dy - top, [0.1 * s, 0.1 * s, 0.045 * s, 0.045 * s]); g.fill(); } });
  if (C.hood === true) parts.push({ z: -0.02 + (Math.abs(yaw) > 2 ? 0.2 : 0), draw: (c, dx, dy) => { g.fillStyle = c; g.beginPath(); g.ellipse(T0[0] + dx, T0[1] + dy + 0.01 * s, 0.11 * s, 0.045 * s, 0, 0, Math.PI * 2); g.fill(); } });
  // dau: lech theo tu the (tre nhip) + cui theo bieu cam + nghieng
  const fv = st.face || F2.neutral, hl = st.lag || p, hd = hl.head || [0, 0];
  const hc = P([hd[0] * 0.004, G.headY + drop + hd[1] * 0.004 + fv[4] * 0.04, fv[4] * 0.05], true), R = G.headR * s;
  parts.push({ z: 0.05, head: true, draw: (c, dx, dy) => { g.fillStyle = c; g.beginPath(); g.arc(hc[0] + dx, hc[1] + dy, R, 0, Math.PI * 2); g.fill(); if (C.tail) { g.beginPath(); g.ellipse(hc[0] + dx - Math.sign(sy || 1) * R * 0.85, hc[1] + dy - R * 0.2, R * 0.38, R * 0.62, 0.5 * Math.sign(sy || 1), 0, Math.PI * 2); g.fill(); } if (C.bun) { g.beginPath(); g.arc(hc[0] + dx, hc[1] + dy - R * 1.02, R * 0.32, 0, Math.PI * 2); g.fill(); } if (C.hood === 'up') { g.beginPath(); g.arc(hc[0] + dx, hc[1] + dy - R * 0.06, R * 1.12, Math.PI * 1.05, Math.PI * 1.95); g.lineTo(hc[0] + dx + R * 1.1, hc[1] + dy + R * 0.7); g.lineTo(hc[0] + dx - R * 1.1, hc[1] + dy + R * 0.7); g.fill(); } } });
  // ve: theo do sau; moi bo phan: ban vien (lech ve phia sang) roi khoi den
  parts.sort((a, b) => a.z - b.z);
  g.save(); if (st.alpha !== undefined) g.globalAlpha *= st.alpha;
  for (const q of parts) { q.draw(rimDark, -Math.sign(rdx) * 1, 0.6); q.draw(rimLit, rdx, rdy); q.draw(ink, 0, 0); }
  if (V) { g.save(); g.globalCompositeOperation = 'lighter'; g.shadowColor = rimC; g.shadowBlur = 0.03 * s; for (const q of parts) q.draw(rgba(rimC.length === 7 ? rimC : '#ff3b3b', 0.12), rdx * 0.6, rdy * 0.6); g.restore(); for (const q of parts) q.draw(ink, 0, 0); }
  // mat + long may (an khi quay lung)
  const tilt = (st.tilt || 0) + fbm1((st.t || 0) * 0.3, 7) * 0.015;
  g.save(); g.translate(hc[0], hc[1]); g.rotate(tilt);
  if (C.band) { g.save(); g.beginPath(); g.arc(0, 0, R, 0, Math.PI * 2); g.clip(); g.fillStyle = C.band; g.fillRect(-R * 1.1, -R * 0.62, R * 2.2, R * 0.26); g.restore(); if (Math.abs(yaw) > 0.4) { g.fillStyle = C.band; const sx = -Math.sign(sy) * R * 0.95; g.beginPath(); g.moveTo(sx, -R * 0.5); g.lineTo(sx - Math.sign(sy) * R * 0.45, -R * 0.2); g.lineTo(sx - Math.sign(sy) * R * 0.3, -R * 0.12); g.closePath(); g.fill(); } }
  if (C.cap) { g.save(); g.beginPath(); g.arc(0, 0, R * 1.01, 0, Math.PI * 2); g.clip(); g.fillStyle = C.cap; g.fillRect(-R * 1.1, -R * 1.1, R * 2.2, R * 0.62); g.restore(); g.fillStyle = C.cap; g.beginPath(); g.ellipse(sy * R * 0.5, -R * 0.5, R * 0.8, R * 0.12, 0, 0, Math.PI * 2); g.fill(); }
  if (C.scarf) { g.fillStyle = C.scarf; g.beginPath(); g.roundRect(-R * 0.75, R * 0.88, R * 1.5, R * 0.3, R * 0.14); g.fill(); }
  const open = Math.max(0.06, fv[0] * (1 - 0.94 * (st.blink || 0))), lk = st.look || [0, 0];
  for (const side of [-1, 1]) {
    const ang = side * 0.42 + yaw, vis = Math.cos(ang); if (vis < 0.12) continue;
    const ex = R * Math.sin(ang) * 0.95 + lk[0] * R * 0.08, ey = R * 0.1 + lk[1] * R * 0.06, ew = R * 0.105 * (0.45 + 0.55 * vis), eh = R * 0.15 * open;
    g.save(); g.translate(ex, ey); g.rotate(-side * fv[1]);
    g.fillStyle = V ? accent() : EYE; if (V) { g.shadowColor = accent(); g.shadowBlur = R * 0.25; }
    g.beginPath(); g.ellipse(0, 0, ew, Math.max(R * 0.012, eh), 0, 0, Math.PI * 2); g.fill(); g.shadowBlur = 0;
    if (!V && open > 0.3) { g.fillStyle = 'rgba(255,255,255,0.9)'; g.beginPath(); g.arc(-ew * 0.3, -eh * 0.35, ew * 0.28, 0, Math.PI * 2); g.fill(); }
    g.restore();
    {   // long may: cung manh xam (bong den: mau nhan toi), goc theo cam xuc
      const bx = ex, by = -R * 0.22 - fv[2] * R - (1 - Math.min(1, open)) * R * 0.02, bl = R * 0.3 * (0.5 + 0.5 * vis), ba = side * fv[3];
      g.save(); g.translate(bx, by); g.rotate(ba); g.strokeStyle = V ? rgba(accent(), 0.7) : BROW; g.lineWidth = R * 0.05; g.lineCap = 'round';
      g.beginPath(); g.moveTo(-bl / 2, R * 0.015); g.quadraticCurveTo(0, -R * 0.035, bl / 2, R * 0.015); g.stroke(); g.restore();
    }
  }
  if (C.glasses && Math.abs(yaw) < 1.2) { g.strokeStyle = '#6c7076'; g.lineWidth = R * 0.03; for (const side of [-1, 1]) { g.beginPath(); g.arc(side * R * 0.38 + yaw * R * 0.3, R * 0.1, R * 0.17, 0, Math.PI * 2); g.stroke(); } }
  g.restore(); g.restore();
  const hands = parts.filter((q) => q.hand).map((q) => q.hand), feet = parts.filter((q) => q.foot).map((q) => q.foot);
  // do cam tay: dien thoai (man hinh sang + quang nho), ve sau tay truoc
  if (st.hold === 'phone' && hands[0]) {
    const [hx, hy] = hands[0], w = 0.05 * s, hh = 0.09 * s;
    const sg = g.createRadialGradient(hx, hy - hh * 0.3, 0, hx, hy - hh * 0.3, hh * 2.2); sg.addColorStop(0, 'rgba(170,200,255,0.28)'); sg.addColorStop(1, 'rgba(170,200,255,0)');
    g.save(); g.globalCompositeOperation = 'screen'; g.fillStyle = sg; g.fillRect(hx - hh * 2.2, hy - hh * 2.5, hh * 4.4, hh * 4.4); g.restore();
    g.save(); g.translate(hx, hy - hh * 0.35); g.rotate(-0.15 * (st.rim ?? -1)); g.fillStyle = '#16171b'; g.beginPath(); g.roundRect(-w / 2, -hh / 2, w, hh, w * 0.18); g.fill();
    g.fillStyle = '#b9cdf2'; g.beginPath(); g.roundRect(-w * 0.4, -hh * 0.42, w * 0.8, hh * 0.84, w * 0.12); g.fill(); g.restore();
    // ngon cai den om mep (tay van la khoi den)
    g.fillStyle = ink; g.beginPath(); g.arc(hx + 0.02 * s * -(st.rim ?? -1), hy - hh * 0.05, G.handR * 0.8 * s, 0, Math.PI * 2); g.fill();
  }
  return { head: [hc[0], hc[1], R], box: [x - 0.28 * s, hc[1] - R, x + 0.28 * s, Math.max(...feet.map((f) => f[1])) + 0.03 * s], hands, feet };
}

// ---------- 1 dien vien theo thoi gian (shots.json actor). place(a) -> { x, y, h, anchor } (px). Tra { update(lt, gt), draw(g), boxes }
export function actor2d(a, place) {
  const seed = (a.seed ?? 3) + 1, f0 = a.facing ?? 1;
  const walks = [].concat(a.walk && a.walk.to !== undefined ? a.walk : a.walk || []).filter((w) => w && w.to !== undefined);
  const S = { a, who: a.who || 'hero', voice: a.who === 'voice', vis: true, last: null };
  S.update = (lt, gt) => {
    S.vis = (a.at === undefined || lt >= a.at) && (a.out === undefined || lt < a.out); S.lt = lt; S.gt = gt;
    const p = poseNow(lt, a.poseAt, a.pose || 'stand', a.poseDur), ph = poseNow(lt, a.poseAt, a.pose || 'stand', a.poseDur, 0.09);
    const F = faceNow(lt, a.faceAt, a.face || (S.voice ? 'grin' : 'neutral'), a.faceDur), A0 = F2[F.fromFace || F.face] || F2.neutral, B0 = F2[F.face] || F2.neutral, k = F.faceK ?? 1;
    const fc = facingNow(lt, a.facingAt, f0, a.turnDur ?? 0.3);
    let pl = place(a, lt);
    // di bo: noi suy vi tri (quang duong), chan dua luan phien theo quang duong (khong truot), than nhun
    let moving = false, ph2 = 0;
    for (const w of walks) {
      const t0 = w.at ?? 0, d = w.dur ?? 3, kk = clamp((lt - t0) / d), e = kk < 0.5 ? 2 * kk * kk : 1 - Math.pow(-2 * kk + 2, 2) / 2;
      if (lt >= t0) { const to = place({ ...a, x: w.to }, lt); pl = { ...pl, x: lerp(pl.x, to.x, e), y: lerp(pl.y, to.y, e), h: lerp(pl.h, to.h, e) }; if (kk < 1) { moving = true; ph2 = e * d * (w.run ? 3.2 : 1.9) * Math.PI; } }
    }
    // dien xuat than (khong chi o mat): cui / nguoc theo cam xuc, khuyu tay chung tu nhien, don trong tam, cu chi khi noi (a.talk: [[giay, dur]])
    const fv0 = A0.map((v, i) => lerp(v, B0[i], k));
    let pose = { ...p, lean: (p.lean || 0) + fv0[4] * 0.55 };
    for (const key of ['aF', 'aB']) { const [u, f] = pose[key] || [0, 0]; if (Math.abs(u) < 0.35 && Math.abs(f - u) < 0.25) pose[key] = [u + 0.04, u + 0.3]; }
    // cu dong theo viec dang lam: cam dien thoai -> tay nhun nhe nhip vuot; ngoi ban -> 2 cang tay go phim; bong den -> tay vuon ra / thu ve cham
    const pn = typeof a.pose === 'string' ? a.pose : '';
    if (a.hold === 'phone' || /phone/.test(pn)) { const [u, f] = pose.aF || [0, 0], k2 = Math.max(0, Math.sin(lt * 2 * Math.PI * 0.8)) ** 2; pose.aF = [u + k2 * 0.12, f + k2 * 0.22]; pose.head = [(pose.head || [0, 0])[0], (pose.head || [0, 0])[1] + k2 * 0.8]; }
    if (pn === 'sitdesk') { const tp = Math.sin(lt * 2 * Math.PI * 3.2); pose.aF = [(pose.aF || [0, 0])[0], (pose.aF || [0, 0])[1] + tp * 0.07]; pose.aB = [(pose.aB || [0, 0])[0], (pose.aB || [0, 0])[1] - tp * 0.07]; }
    if (S.voice) { const k3 = 0.5 + 0.5 * Math.sin(lt * 2 * Math.PI * 0.22 + seed); pose.aF = [(pose.aF || [0, 0])[0] + k3 * 0.25, (pose.aF || [0, 0])[1] + k3 * 0.3]; pose.lean = (pose.lean || 0) + k3 * 0.06; }
    let talkK = 0; for (const [t0, d] of a.talk || []) { const q = clamp((lt - t0) / 0.35) * (1 - clamp((lt - t0 - d + 0.3) / 0.35)); talkK = Math.max(talkK, q); }
    if (talkK > 0) { const [u, f] = pose.aF || [0, 0], e = ease.outBack(talkK); pose.aF = [lerp(u, 0.75, e), lerp(f, 1.9, e)]; pose.head = [(pose.head || [0, 0])[0], (pose.head || [0, 0])[1] + Math.sin(lt * 7) * 1.2 * talkK]; }
    if (moving) { const sw = Math.sin(ph2) * 0.42; pose = { ...p, lF: [sw, Math.max(sw, 0) * 0.3 + sw * 0.6], lB: [-sw, Math.max(-sw, 0) * 0.3 - sw * 0.6], aF: [-sw * 0.6, -sw * 0.5], aB: [sw * 0.6, sw * 0.5] }; }
    S.st = {
      who: S.who, outfit: a.outfit, pose, lag: ph, yaw: a.yaw ?? (fc.f > 0 ? 0.35 : -0.35) * (a.front ? 0 : 1) + (a.back ? Math.PI : 0),
      face: A0.map((v, i) => lerp(v, B0[i], k)), look: a.look !== undefined ? [a.look, 0] : [0, 0], blink: a.blink === false ? 0 : blinkAt(lt, seed),
      breath: Math.sin(lt * 2 * Math.PI / (ANX.includes(F.face) ? 1.6 : 3.8)), rim: a.rim ?? place.rim ?? -1, rimC: place.rimC, alpha: a.alpha, anchor: pl.anchor, t: gt,
      tilt: a.tilt ?? 0, hold: a.hold,
    };
    // don trong tam rat cham (khong bao gio dung yen hoan toan) + nhun khi di
    const sway = moving || a.idle === false ? 0 : Math.sin(gt * 2 * Math.PI * (S.voice ? 0.25 : 0.17) + seed) * pl.h * (S.voice ? 0.014 : 0.006);
    S.pl = { ...pl, x: pl.x + sway, y: pl.y - (moving ? Math.abs(Math.sin(ph2)) * pl.h * 0.012 : 0) };
    S.st.tilt = (S.st.tilt || 0) + fbm1(gt * 0.4, seed + 3) * 0.035;
  };
  S.draw = (g) => { if (!S.vis) return null; const r = puppet(g, S.pl.x, S.pl.y, S.pl.h, S.st); S.last = r; return r; };
  return S;
}
