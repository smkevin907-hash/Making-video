// director2d.js — tinh chinh ke hoach goc may (sau planFilm) cho ban 2D, theo phan hoi giam khao (I1 I2 I3 I12):
// - goc dai > 3,0 s tach (moi goc ~2,6 s, nhip cat gan phim tham khao: trung vi 3,0 s), goc moi khac co / khac goc;
// - MOI goc co chuyen dong may co chu dich (dolly / truck / pan / tilt / nang may) + cam tay nhe 0,3% co seed;
// - toan canh luan phien goc cao / ngang mat / thap; ca phim co it nhat 1 goc thap + 1 goc qua vai;
// - khong 2 goc lien tiep cung co + cung goc (tru matchCut). Tat dinh: chi doc shots.json.
const NEXT = { wide: 'push', push: 'closeMain', ots: 'push', face: 'faceSide', closeMain: 'push', pov: 'closeMain', povClose: 'pov', insertClock: 'clockWide', otsPoster: 'insertPoster', insertPoster: 'insertPoster', top: 'wide', manual: 'push' };
const SIZE = { wide: 'ws', push: 'mcu', closeMain: 'cu', ots: 'mcu', face: 'cu', faceSide: 'cu', top: 'cu', pov: 'ecu', povClose: 'ecu', insertClock: 'ecu', clockWide: 'ms', otsPoster: 'mcu', insertPoster: 'ecu', void: 'void', manual: 'ms' };
const WIDE_ANG = ['high', 'eye', 'low'], WIDE_MOVE = ['dollyIn', 'truck', 'lowAngleRise', 'pullBack'];

export function refine(shots) {
  let lastSize = null, lastAng = null, nWide = 0, hasLow = false, hasOts = false, k = 0;
  for (const s of shots) {
    if (!s.__plan) { lastSize = lastAng = null; continue; }
    const d = s.end - s.start, P = [];
    for (let i = 0; i < s.__plan.length; i++) {
      const p = s.__plan[i], end = i + 1 < s.__plan.length ? s.__plan[i + 1].at : d, len = end - p.at;
      if (p.role === 'void' || len <= 2.8 || p.manual) { P.push({ ...p }); continue; }
      const n = Math.min(3, Math.ceil(len / 2.3)), step = len / n; let role = p.role;
      for (let j = 0; j < n; j++) { P.push({ ...p, role, at: Math.round((p.at + j * step) * 100) / 100, split: j > 0 }); role = NEXT[role] || 'push'; }
    }
    for (const p of P) {
      if (p.role === 'void') { p.move = 'dollyIn'; continue; }
      p.size = SIZE[p.role] || p.size;
      if (p.role === 'wide') { p.angle = p.manual && p.angle ? p.angle : WIDE_ANG[nWide % 3]; if (!p.manual) p.move = WIDE_MOVE[nWide % 4]; nWide++; }
      else if (!p.angle || p.angle === 'ots' || p.angle === 'pov') p.angle = p.role === 'ots' || p.role === 'otsPoster' ? 'ots' : p.role === 'pov' || p.role === 'povClose' ? 'pov' : 'eye';
      if (!p.move || p.move === 'hold') p.move = p.role === 'ots' ? 'truck' : p.role === 'pov' ? 'pushToCloseUp' : 'dollyIn';
      p.hand = p.hand ?? (p.role === 'insertClock' || p.role === 'clockWide' ? 0.25 : 0.4);
      // khong 2 goc lien tiep cung co + cung goc
      if (p.size === lastSize && p.angle === lastAng && !p.match) { if (p.role === 'wide') p.angle = p.angle === 'low' ? 'high' : 'low'; else p.angle = p.angle === 'low' ? 'eye' : 'low'; p.fixed = 'trung co + goc canh truoc'; }
      if (p.angle === 'low') hasLow = true; if (p.angle === 'ots') hasOts = true;
      lastSize = p.size; lastAng = p.angle; k++;
    }
    s.__plan = P;
  }
  // ca phim chua co goc thap: doi toan canh thu 2 sang goc thap
  if (!hasLow) { let c = 0; for (const s of shots) for (const p of s.__plan || []) if (p.role === 'wide' && ++c === 2) { p.angle = 'low'; p.move = 'lowAngleRise'; } }
  return { hasLow, hasOts };
}
