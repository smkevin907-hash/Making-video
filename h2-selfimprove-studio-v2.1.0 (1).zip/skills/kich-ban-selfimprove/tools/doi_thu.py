"""doi_thu.py — theo doi kenh lon: du lieu video (tang 1), bao cao xu huong, kiem tra trung lap. Chi can Python 3.8+ (khong cai them goi).
  python doi_thu.py quet      --thu-muc <thu muc nguoi dung> [--gia-lap-loi rss,trang-video] [--hom-nay YYYY-MM-DD]
  python doi_thu.py nhap      --thu-muc <..> --kenh <url> --nguon trinh-duyet|tim-kiem --link <file> [--trang <file>] [--gia-lap-loi trang-video]
  python doi_thu.py bao-cao   --thu-muc <..> [--ngay 90]
  python doi_thu.py trung-lap --thu-muc <..> --phim <01-PHIM.txt>     (hoac --de-tai .. --khung .. --ket .. --vat ..)
Du lieu: <thu muc>/DOI-THU-SELFIMPROVE/  kenh.txt  video.csv  lich-su.csv  lan-quet.csv  phan-tich/*.md  bao-cao/*.md  .cache/kenh.json
Nguon lan luot: 1 RSS cua kenh -> 2 trinh duyet doc trang /videos (Claude doc chu hien thi + duong link, nap bang `nhap`) -> 3 tim kiem web (nap bang `nhap`).
Nguon nao co ma video thi lam giau tu trang xem video: the schema.org chuan (luot xem, ngay dang, thoi luong, tag, anh). Khong doc du lieu noi bo cua trang YouTube.
video.csv cong don: khong xoa video cu, cap nhat so moi + ngay cap nhat; moi lan quet ghi them 1 dong / video vao lich-su.csv.
"""
import argparse, csv, datetime as dt, json, os, re, statistics, sys, time, unicodedata, urllib.error, urllib.request, xml.etree.ElementTree as ET
try: sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except (AttributeError, ValueError): pass

UA = {"User-Agent": "h2-selfimprove-studio/1.7 (competitor tracker)", "Accept-Language": "en-US,en;q=0.9"}
KENH_MAC_DINH = ["https://www.youtube.com/@dayonefilmsofficial", "https://www.youtube.com/@MonkModeFilms", "https://www.youtube.com/@lastsoulorigin"]
COT = ["kenh", "ten_kenh", "video_id", "tieu_de", "ngay_dang", "ngay_uoc", "tuoi_ngay", "luot_xem", "luot_thich", "do_dai", "do_dai_giay", "loai", "luot_xem_ngay",
       "diem_vuot_troi", "danh_dau", "de_tai", "cong_thuc_tieu_de", "tag", "link", "thumbnail", "nguon", "ngay_thay_dau", "ngay_cap_nhat"]
GIA_LAP = set()

# ---------- bang phan loai co dinh (dung chung voi phan_tich.py)
DE_TAI = [  # (ma, nhan, tu khoa trong tieu de / tag). Cu the truoc, chung sau.
    ("lust", "lust / porn", r"lust|porn|nofap|no ?nut|\bfap"),
    ("game", "game", r"gaming|gamer|\bgames?\b"),
    ("dien-thoai", "điện thoại / dopamine", r"phone|scroll|dopamine|screen ?time|tiktok|\breels\b"),
    ("mang-xa-hoi", "so sánh mạng xã hội", r"social media|instagram|comparison|compar|followers"),
    ("tinh-yeu", "người yêu / người cũ", r"\blove\b|\bex\b|break ?up|heartbreak|girlfriend|text her|relationship"),
    ("co-don", "cô đơn", r"lonel|\balone\b"),
    ("chat", "rượu / vape / chất", r"alcohol|\bvap|smok|\bdrink|weed|\bdrugs?\b"),
    ("an-uong", "ăn uống", r"\bfood\b|sugar|junk food|\beating\b|binge"),
    ("tri-hoan", "trì hoãn", r"procrastinat|tomorrow|someday"),
    ("luoi", "lười / thoải mái / dậy sớm", r"lazy|comfort|wake up|\b5 ?am\b|morning|alarm|sleep"),
    ("suy-nghi", "nghĩ quá nhiều / lo âu", r"overthink|anxiety|\bworr"),
    ("so-that-bai", "sợ thất bại", r"failure|\bfear\b|afraid|scared to"),
    ("tiec-nuoi", "thời gian / tiếc nuối", r"regret|too late|wasted|\byears\b|never forgot|last time"),
    ("duc-tinh", "đức tính", r"patien|gratitud|grateful|thankful|kindness|\bkind\b|honest|courage|\bbrave|humil|humble|integrity|forgiv|virtue|loyal"),
    ("ky-luat", "kỷ luật / động lực chung", r"disciplin|consisten|motivat|monk mode|winter arc|\bready\b|grind|habit|\broots\b|focus|self.?control|\bbook\b"),
    ("khac", "khác", r"$^"),
]
KHUNG = {"vuc-day": "vực dậy", "tiec-nuoi": "tiếc nuối / cảnh tỉnh", "song-song": "hai cuộc đời song song", "vong-lap": "vòng lặp", "thu-gui": "thư gửi bản thân / nhìn lại", "buoc-nho": "bước nhỏ",
         "giai-ma": "giải mã", "khac": "khác"}
MOC = {"chu-man-den": "chữ trên màn đen", "hinh-manh": "cảnh hình ảnh mạnh ngay giây đầu", "cuoi-len-dau": "cảnh từ đoạn cuối đặt lên đầu", "bo-dem-sup": "bộ đếm sụp ngay đầu rồi tua lại",
       "cau-hoi": "câu hỏi thẳng người xem", "cham-ngon": "châm ngôn nghịch lý trên màn đen", "thu-nhan": "lời thú nhận ngôi thứ nhất", "khac": "khác"}
DEM = {"day-n": "DAY N tăng dần", "dem-nguoc": "đếm ngược (DAYS LEFT)", "thoi-gian-mat": "thời gian mất (HOURS / YEARS LOST)", "tuoi": "tuổi (AGE)", "hai-dong": "2 dòng đối nghịch",
       "dong-ho": "giờ đồng hồ", "lich": "lịch có ngày tháng", "khong-co": "không có", "khac": "khác"}
KET = {"hy-vong": "hy vọng", "tiec-nuoi": "tiếc nuối", "mo": "mở", "vong-lap": "vòng lặp", "buoc-nho": "bước nhỏ"}
NGUOI = {"tin-nhan-ban": "tin nhắn bạn bè", "nguoi-la": "người lạ", "gia-dinh": "gia đình", "nguoi-yeu": "người yêu / người cũ", "ban-than": "bản thân (quá khứ / tương lai)",
         "khong-co": "không có", "khac": "khác"}
CONG_THUC = {"word-film": "WORD | An Animated Short Film", "part": "WORD PART N | …", "vs": "X VS Y | …", "cum-film": "Cụm từ | An Animated Short Film",
             "khang-dinh": "câu khẳng định (vd: X Is Killing You.)", "cau-hoi": "câu hỏi", "khac": "khác"}
NHOM = {"de_tai": {m: n for m, n, _ in DE_TAI}, "khung_truyen": KHUNG, "kieu_cau_moc": MOC, "kieu_bo_dem": DEM, "kieu_ket": KET, "khoanh_khac_nguoi_that": NGUOI}
# vat bieu tuong bo dung ve duoc (de goi y doi vat khi trung)
VAT = ["điện thoại", "đồng hồ báo thức", "lịch", "sổ tay", "laptop", "gương", "bao cát", "cây ô", "quả bóng rổ", "cặp sách", "cốc cà phê", "cuốn sách", "cửa phòng", "đèn bàn", "giường", "cầu thang", "đỉnh đồi"]
VAT_GOP = {"phone": "điện thoại", "dien thoai": "điện thoại", "đồng hồ": "đồng hồ báo thức", "clock": "đồng hồ báo thức", "calendar": "lịch", "notebook": "sổ tay", "book": "cuốn sách",
           "sách": "cuốn sách", "mirror": "gương", "umbrella": "cây ô", "ô": "cây ô", "ball": "quả bóng rổ", "bóng": "quả bóng rổ", "cup": "cốc cà phê", "cốc": "cốc cà phê"}

def khong_dau(s): return "".join(c for c in unicodedata.normalize("NFD", str(s).lower().replace("đ", "d")) if not unicodedata.combining(c)).strip()
def ma(nhom, v):   # ten tieng Viet / ma -> ma trong bang; khong co -> None
    if v is None or str(v).strip() == "": return None
    k = khong_dau(v); B = NHOM[nhom]
    for m, n in B.items():
        if k in (m, khong_dau(n)) or k == khong_dau(n.split(" / ")[0]) or k == khong_dau(n.split(" (")[0]): return m
    return None
def vat_chuan(v):
    k = (v or "").strip().lower(); return VAT_GOP.get(k, VAT_GOP.get(khong_dau(k), k))
def de_tai_of(title, tags=""):
    for src in (title, tags):
        t = (src or "").lower()
        for m, _, rx in DE_TAI:
            if t and re.search(rx, t): return m
    return "khac"
def cong_thuc_of(t):
    t0 = (t or "").strip(); base = t0.split("|")[0].strip()
    if re.search(r"\bvs\.?\b", base, re.I): return "vs"
    if re.search(r"\bpart\s*\d+", base, re.I): return "part"
    if "|" in t0: return "word-film" if base == base.upper() else "cum-film"
    if t0.endswith("?"): return "cau-hoi"
    if t0.endswith("."): return "khang-dinh"
    return "khac"

# ---------- tien ich
def get(url, timeout=20):
    with urllib.request.urlopen(urllib.request.Request(url, headers=UA), timeout=timeout) as r: return r.read().decode("utf-8", "replace")
def so(v):   # "976K" "5M" "1.2M views" "12,345" "1,2 Tr" -> int
    t = str(v or "").strip().lower().replace("views", "").replace("view", "").replace("lượt xem", "").strip()
    if not t or t.startswith("no"): return 0 if t.startswith("no") else None
    m = re.match(r"^([\d.,]+)\s*([kmb]|n|tr|t)?\b", t)
    if not m: return None
    n, u = m.group(1), m.group(2)
    if u: n = n.replace(",", ".")
    else: n = n.replace(",", "").replace(".", "")
    try: x = float(n)
    except ValueError: return None
    return int(round(x * {"k": 1e3, "n": 1e3, "m": 1e6, "tr": 1e6, "b": 1e9, "t": 1e9}.get(u, 1)))
def ngay_rel(t):   # "7d ago", "2w ago", "3 weeks ago", "1 năm trước" -> so ngay
    t = (t or "").lower(); m = re.search(r"(\d+)\s*(second|giây|minute|phút|min|hour|giờ|h\b|day|ngày|d\b|week|tuần|w\b|month|tháng|mo\b|year|năm|y\b)", t)
    if not m: return None
    n, u = int(m.group(1)), m.group(2)
    return n * (365 if u in ("year", "năm", "y") else 30 if u in ("month", "tháng", "mo") else 7 if u in ("week", "tuần", "w") else 1 if u in ("day", "ngày", "d") else 0)
def iso_s(d):   # PT3M21S -> 201
    m = re.match(r"P(?:(\d+)D)?T?(?:(\d+)H)?(?:(\d+)M)?(?:(\d+)S)?", d or "")
    return (int(m.group(1) or 0) * 86400 + int(m.group(2) or 0) * 3600 + int(m.group(3) or 0) * 60 + int(m.group(4) or 0)) if m and any(m.groups()) else None
def mmss(s): return f"{int(s) // 60}:{int(s) % 60:02d}" if s not in (None, "") else ""
def gon(n):
    n = int(n or 0); return f"{n / 1e6:.1f}M".replace(".0M", "M") if n >= 1e6 else f"{n / 1e3:.0f}K" if n >= 1e3 else str(n)
def thu_muc(D): p = os.path.join(D, "DOI-THU-SELFIMPROVE"); os.makedirs(os.path.join(p, ".cache"), exist_ok=True); return p
def chuan_url(u):
    u = u.strip().split("#")[0].strip().split()[0] if u.strip() else ""
    if u.startswith("@"): u = "https://www.youtube.com/" + u
    if u and not u.startswith("http"): u = "https://" + u
    return re.sub(r"/(videos|shorts|featured|streams|playlists|about)/?$", "", u.rstrip("/"))
def doc_kenh(D):
    p = os.path.join(thu_muc(D), "kenh.txt")
    if not os.path.exists(p):
        with open(p, "w", encoding="utf-8") as f: f.write("# Kenh theo doi: moi dong 1 link kenh YouTube (them / xoa dong tuy y). Dong bat dau bang # bi bo qua.\n" + "\n".join(KENH_MAC_DINH) + "\n")
    return [chuan_url(l) for l in open(p, encoding="utf-8-sig") if l.strip() and not l.strip().startswith("#")]
def cache(D, val=None):
    p = os.path.join(thu_muc(D), ".cache", "kenh.json")
    if val is None: return json.load(open(p, encoding="utf-8")) if os.path.exists(p) else {}
    json.dump(val, open(p, "w", encoding="utf-8"), ensure_ascii=False, indent=1)
def kenh_info(D, url):   # -> (channel_id, ten). Doc the <link rel=canonical> / <meta> chuan cua trang kenh, nho vao .cache
    C = cache(D); m = re.search(r"/channel/(UC[\w-]{22})", url)
    if url in C: return C[url]["id"], C[url]["ten"]
    h = get(url); cid = (m and m.group(1)) or next(iter(re.findall(r'<link rel="canonical" href="https://www\.youtube\.com/channel/(UC[\w-]{22})"', h) + re.findall(r'<meta itemprop="identifier" content="(UC[\w-]{22})"', h)), None)
    ten = (re.findall(r'<meta property="og:title" content="([^"]+)"', h) or re.findall(r'<meta itemprop="name" content="([^"]+)"', h) or [url.rsplit("/", 1)[-1]])[0]
    if not cid: raise RuntimeError("khong tim thay ma kenh tren trang kenh")
    C[url] = {"id": cid, "ten": unescape(ten)}; cache(D, C); return cid, C[url]["ten"]
def unescape(s): return s.replace("&amp;", "&").replace("&#39;", "'").replace("&quot;", '"').replace("&lt;", "<").replace("&gt;", ">")

# ---------- nguon 1: RSS
NS = {"a": "http://www.w3.org/2005/Atom", "yt": "http://www.youtube.com/xml/schemas/2015", "media": "http://search.yahoo.com/mrss/"}
def rss(cid):
    if "rss" in GIA_LAP: raise RuntimeError("gia lap loi RSS")
    x = ET.fromstring(get("https://www.youtube.com/feeds/videos.xml?channel_id=" + cid)); out = []
    for e in x.findall("a:entry", NS):
        st = e.find("media:group/media:community/media:statistics", NS); th = e.find("media:group/media:thumbnail", NS); ln = e.find("a:link", NS).get("href")
        out.append({"video_id": e.find("yt:videoId", NS).text, "tieu_de": e.find("a:title", NS).text, "ngay_dang": e.find("a:published", NS).text[:10], "ngay_uoc": "0",
                    "luot_xem": st.get("views") if st is not None else "", "link": ln, "thumbnail": th.get("url") if th is not None else "", "loai": "short" if "/shorts/" in ln else ""})
    return out
# ---------- lam giau: trang xem video, the schema.org (itemprop) chuan
def lam_giau(v):
    if "trang-video" in GIA_LAP: return False
    try: h = get("https://www.youtube.com/watch?v=" + v["video_id"])
    except (urllib.error.URLError, OSError, ValueError): return False
    meta = lambda p: (re.findall(r'<meta itemprop="' + p + r'" content="([^"]*)"', h) or [""])[0]
    cnt = lambda a: (re.findall(r'schema\.org/' + a + r'"><meta itemprop="userInteractionCount" content="(\d+)"', h) or [""])[0]
    dur, pub, views = iso_s(meta("duration")), (meta("datePublished") or meta("uploadDate"))[:10], cnt("WatchAction")
    if not (dur or views or pub): return False
    if views: v["luot_xem"] = views
    if cnt("LikeAction"): v["luot_thich"] = cnt("LikeAction")
    if pub: v["ngay_dang"] = pub; v["ngay_uoc"] = "0"
    if dur is not None: v["do_dai_giay"] = str(dur); v["do_dai"] = mmss(dur)
    if meta("name"): v["tieu_de"] = unescape(meta("name"))
    kw = meta("keywords")
    if kw: v["tag"] = unescape(kw)[:300]
    img = re.findall(r'<meta property="og:image" content="([^"]+)"', h)
    if img: v["thumbnail"] = img[0]
    au = re.findall(r'itemprop="author"[^>]*>\s*<link itemprop="url" href="([^"]+)"', h)
    if au: v["_tac_gia"] = au[0].rstrip("/").rsplit("/", 1)[-1].lower()   # @handle hoac ma kenh cua nguoi dang
    v["link"] = v.get("link") or "https://www.youtube.com/watch?v=" + v["video_id"]
    return True
# ---------- nguon 2 / 3: chu hien thi + duong link do Claude lay bang trinh duyet / tim kiem
DUR_TXT = r"(?:(\d+) hours?,? )?(?:(\d+) minutes?,? )?(?:(\d+) seconds?)?$"
def doc_link(txt):   # dong "ID<tab>nhan" | read_page: link "nhan" href="/watch?v=ID" | link YouTube tran -> [(id, tieu_de, giay)]
    out, seen = [], set()
    for ln in txt.splitlines():
        m = re.search(r'(?:v=|youtu\.be/|/shorts/)([\w-]{11})', ln) or re.match(r"^([\w-]{11})\t", ln)
        if not m or m.group(1) in seen: continue
        vid = m.group(1); seen.add(vid)
        lab = (re.findall(r'link "([^"]*)"', ln) or [ln.split("\t", 1)[1] if "\t" in ln else ""])[0].strip()
        d = re.search(r"\s" + DUR_TXT, lab); sec = None
        if d and any(d.groups()): sec = int(d.group(1) or 0) * 3600 + int(d.group(2) or 0) * 60 + int(d.group(3) or 0); lab = lab[:d.start()].strip()
        out.append((vid, lab, sec, "/shorts/" in ln))
    return out
def doc_trang(txt):   # chu hien thi trang /videos: [thoi luong] tieu de / luot xem / "7d ago" ; video sap chieu: tieu de / "N waiting" / "Premieres ..."
    L = [l.strip() for l in txt.splitlines() if l.strip()]; out = {}
    for i, l in enumerate(L):
        if re.search(r"\bago\b|trước$|^streamed|^premieres|^công chiếu", l, re.I) and i >= 2:
            if re.match(r"^(premieres|công chiếu)", l, re.I): out[L[i - 2]] = {"sap": True}
            elif so(L[i - 1]) is not None: out[L[i - 2]] = {"luot_xem": so(L[i - 1]), "ngay": ngay_rel(l)}
    return out

# ---------- video.csv
def doc_csv(p):
    return list(csv.DictReader(open(p, encoding="utf-8-sig", newline=""))) if os.path.exists(p) else []
def ghi_csv(p, rows, cot):
    with open(p, "w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cot, extrasaction="ignore"); w.writeheader(); [w.writerow({k: r.get(k, "") for k in cot}) for r in rows]
def them_csv(p, rows, cot):
    moi = not os.path.exists(p)
    with open(p, "a", encoding="utf-8-sig" if moi else "utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=cot, extrasaction="ignore")
        if moi: w.writeheader()
        for r in rows: w.writerow({k: r.get(k, "") for k in cot})
def tinh(rows, today):   # luot xem / ngay, diem vuot troi = luot xem / trung vi cua chinh kenh (cung loai dai / short)
    for r in rows:
        if r.get("loai") not in ("sap-chieu", "short"): r["loai"] = "short" if r.get("do_dai_giay") and int(r["do_dai_giay"]) <= 60 else "dai"
        try: r["tuoi_ngay"] = str(max(0, (today - dt.date.fromisoformat(r["ngay_dang"])).days))
        except (ValueError, KeyError): r["tuoi_ngay"] = ""
        r["luot_xem_ngay"] = f"{int(r['luot_xem']) / max(1, int(r['tuoi_ngay'] or 1)):.0f}" if r.get("luot_xem") and r["tuoi_ngay"] != "" else ""
        r["de_tai"] = r.get("de_tai_tay") or de_tai_of(r.get("tieu_de"), r.get("tag")); r["cong_thuc_tieu_de"] = cong_thuc_of(r.get("tieu_de"))
    for k in {(r["kenh"], r["loai"]) for r in rows}:
        g = [r for r in rows if (r["kenh"], r["loai"]) == k and r.get("luot_xem") and r["loai"] != "sap-chieu"]
        med = statistics.median(int(r["luot_xem"]) for r in g) if len(g) >= 3 else None
        for r in g:
            r["diem_vuot_troi"] = f"{int(r['luot_xem']) / med:.2f}" if med else ""
            x = float(r["diem_vuot_troi"]) if med else None; moi = r["tuoi_ngay"] != "" and int(r["tuoi_ngay"]) < 7
            r["danh_dau"] = "VUOT TROI" if x and x >= 2 else ("HUT (moi < 7 ngay)" if moi else "HUT") if x is not None and x <= 0.5 else ""
    return rows
def gop(D, kenh, ten, items, nguon, today):   # cong don vao video.csv; tra so video moi
    p = os.path.join(thu_muc(D), "video.csv"); rows = doc_csv(p); by = {r["video_id"]: r for r in rows}; moi = 0; hom = today.isoformat()
    for v in items:
        r = by.get(v["video_id"])
        if r is None: r = {"kenh": kenh, "ten_kenh": ten, "video_id": v["video_id"], "ngay_thay_dau": hom}; rows.append(r); by[v["video_id"]] = r; moi += 1
        for k, x in v.items():
            if x not in (None, "") and k in COT: r[k] = str(x)
        if r.get("loai") == "sap-chieu" and v.get("loai") != "sap-chieu": r["loai"] = ""   # da cong chieu
        r["kenh"], r["ten_kenh"], r["ngay_cap_nhat"] = kenh, ten, hom
        r["nguon"] = "+".join(dict.fromkeys([x for x in (r.get("nguon", "") + "+" + nguon).split("+") if x]))
        r["link"] = r.get("link") or "https://www.youtube.com/watch?v=" + v["video_id"]
        r["thumbnail"] = r.get("thumbnail") or f"https://i.ytimg.com/vi/{v['video_id']}/hqdefault.jpg"
    rows = tinh(rows, today); rows.sort(key=lambda r: (r["kenh"], r.get("ngay_dang", "")), reverse=False)
    ghi_csv(p, rows, COT)
    them_csv(os.path.join(thu_muc(D), "lich-su.csv"), [{"ngay": hom, "kenh": kenh, "video_id": v["video_id"], "luot_xem": by[v["video_id"]].get("luot_xem", ""), "nguon": nguon} for v in items], ["ngay", "kenh", "video_id", "luot_xem", "nguon"])
    return moi
def ghi_lan(D, kenh, nguon, n, moi, kq, today=None):
    them_csv(os.path.join(thu_muc(D), "lan-quet.csv"), [{"thoi_gian": (today or dt.date.today()).isoformat() + dt.datetime.now().strftime("T%H:%M:%S"), "kenh": kenh, "nguon": nguon, "so_video": n, "so_moi": moi, "ket_qua": kq}],
             ["thoi_gian", "kenh", "nguon", "so_video", "so_moi", "ket_qua"])
def giau_het(items):
    ok = 0
    for i, v in enumerate(items):
        if i: time.sleep(0.6)
        ok += lam_giau(v)
    return ok

# ---------- lenh
def cmd_quet(a, today):
    D = a.thu_muc; can = []
    print(f"QUET DOI THU {today} — kenh.txt: {len(doc_kenh(D))} kenh")
    for url in doc_kenh(D):
        try: cid, ten = kenh_info(D, url)
        except Exception as e: print(f"  {url}: KHONG mo duoc trang kenh ({e}) -> can nguon du phong"); can.append((url, f"trang kenh loi: {e}")); ghi_lan(D, url, "rss", 0, 0, f"loi trang kenh: {e}", today); continue
        try: items = rss(cid)
        except Exception as e:
            print(f"  {ten}: RSS LOI ({e}) -> chuyen nguon du phong: trinh duyet"); can.append((url, f"RSS loi: {e}")); ghi_lan(D, url, "rss", 0, 0, f"loi: {e}", today); continue
        ok = giau_het(items); moi = gop(D, url, ten, items, "rss" + ("+trang-video" if ok else ""), today)
        print(f"  {ten}: nguon RSS, {len(items)} video ({ok} lay so chinh xac tu trang video), {moi} video moi"); ghi_lan(D, url, "rss", len(items), moi, "ok", today)
    if can:
        print("\nCAN NGUON DU PHONG (Claude lam tiep ngay, khong can hoi nguoi dung):")
        for url, why in can:
            print(f"  {url}  [{why}]\n    1) trinh duyet: mo {url}/videos, doc chu hien thi (get_page_text) + danh sach link video, luu 2 file, roi:\n"
                  f"       python doi_thu.py nhap --thu-muc \"{D}\" --kenh {url} --nguon trinh-duyet --link <file link> --trang <file chu>\n"
                  f"    2) trinh duyet hong: tim kiem web ten kenh + 'youtube', lay link video, roi: ... nhap --nguon tim-kiem --link <file>")
        sys.exit(2)
    print("Xong. Xem video.csv hoac chay: python doi_thu.py bao-cao --thu-muc ...")
def cmd_nhap(a, today):
    D = a.thu_muc; url = chuan_url(a.kenh)
    try: cid, ten = kenh_info(D, url)
    except Exception: ten = a.ten or url.rsplit("/", 1)[-1]
    lk = doc_link(open(a.link, encoding="utf-8-sig").read()); tr = doc_trang(open(a.trang, encoding="utf-8-sig").read()) if a.trang else {}
    if not lk: sys.exit("Khong doc duoc link video nao trong file --link (can dong co watch?v=<ma> hoac 'ma<TAB>tieu de').")
    items = []
    for vid, title, sec, is_short in lk:
        v = {"video_id": vid, "tieu_de": title}
        if sec is not None: v["do_dai_giay"] = str(sec); v["do_dai"] = mmss(sec)
        if is_short: v["loai"] = "short"
        t = tr.get(title) or next((x for k, x in tr.items() if k.lower() == title.lower()), None)
        if t and t.get("sap"): v["loai"] = "sap-chieu"
        elif t:
            v["luot_xem"] = t["luot_xem"]
            if t.get("ngay") is not None: v["ngay_dang"] = (today - dt.timedelta(days=t["ngay"])).isoformat(); v["ngay_uoc"] = "1"
        items.append(v)
    ok = giau_het([v for v in items if v.get("loai") != "sap-chieu"]) if not a.khong_lam_giau else 0
    me = {url.rstrip("/").rsplit("/", 1)[-1].lower(), (cache(D).get(url) or {}).get("id", "").lower()} - {""}
    la = [v for v in items if v.get("_tac_gia") and v["_tac_gia"] not in me]   # tim kiem web lan video kenh khac: bo theo the tac gia
    if la: items = [v for v in items if v not in la]; ok -= len(la); print(f"  bo {len(la)} video khong thuoc kenh (the tac gia tren trang video: {', '.join(sorted({v['_tac_gia'] for v in la}))})")
    if not items: sys.exit("Khong con video nao thuoc kenh nay.")
    nguon = a.nguon + ("+trang-video" if ok else ""); moi = gop(D, url, ten, items, nguon, today)
    thieu = sum(1 for v in items if not v.get("luot_xem") and v.get("loai") != "sap-chieu")
    print(f"{ten}: nguon {a.nguon}, {len(items)} video ({ok} lay so chinh xac tu trang video" + (f", {len(items) - ok} giu so uoc tinh tu {a.nguon}" if ok < len(items) else "") + f"), {moi} video moi"
          + (f", {thieu} video chua co luot xem" if thieu else "") + (f", {sum(1 for v in items if v.get('loai') == 'sap-chieu')} sap chieu" if any(v.get("loai") == "sap-chieu" for v in items) else ""))
    ghi_lan(D, url, nguon, len(items), moi, "ok", today)
    if not ok and not a.khong_lam_giau: print("  (trang video khong doc duoc: luot xem / ngay dang la so uoc tinh tu trang kenh, cot ngay_uoc = 1)")

def doc_phan_tich(D):
    out = []
    for f in sorted(glob_md(os.path.join(thu_muc(D), "phan-tich"))):
        t = open(f, encoding="utf-8").read(); m = re.search(r"<!-- phan-loai (\{.*?\}) -->", t, re.S)
        if m:
            try: x = json.loads(m.group(1)); x["_file"] = os.path.basename(f); out.append(x)
            except ValueError: pass
    return out
def ngan(t): return re.sub(r"\s*\|\s*An Animated Short Film\.?$", "", t or "", flags=re.I).replace("|", "¦").strip()   # tieu de gon cho bang
def glob_md(p): return [os.path.join(p, f) for f in os.listdir(p) if f.endswith(".md")] if os.path.isdir(p) else []
def du_an_cua_toi(D):   # projects/<NN>-<slug>/01-PHIM-*.txt -> [(ten, de_tai)]
    out, P = [], os.path.join(D, "projects")
    for d in sorted(os.listdir(P)) if os.path.isdir(P) else []:
        fs = [f for f in os.listdir(os.path.join(P, d)) if f.startswith("01-PHIM")] if os.path.isdir(os.path.join(P, d)) else []
        if not fs: continue
        meta = doc_meta(os.path.join(P, d, fs[0])); tit = meta.get("title", d)
        out.append((d, tit, ma("de_tai", meta.get("đề tài")) or de_tai_of(tit + " " + d.replace("-", " ")), meta))
    return out
def doc_meta(p):
    meta = {}
    for l in open(p, encoding="utf-8-sig"):
        if re.match(r"^\s*\[?\s*B\d+", l, re.I): break
        m = re.match(r"^\s*([A-ZÀ-Ỹ][A-ZÀ-Ỹ ]*?)\s*:\s*(.+)$", unicodedata.normalize("NFC", l.strip()))
        if m: meta[m.group(1).lower()] = m.group(2).strip()
    return meta

def cmd_bao_cao(a, today):
    D = a.thu_muc; T = thu_muc(D); rows = tinh(doc_csv(os.path.join(T, "video.csv")), today); lq = doc_csv(os.path.join(T, "lan-quet.csv"))
    if not rows: sys.exit("Chua co video.csv: chay quet truoc.")
    ngay_q = sorted({r["thoi_gian"][:10] for r in lq}); cuoi = ngay_q[-1] if ngay_q else today.isoformat(); truoc = ngay_q[-2] if len(ngay_q) > 1 else None
    dl = [r for r in rows if r["loai"] == "dai" and r.get("luot_xem")]; ten = {r["kenh"]: r["ten_kenh"] for r in rows}
    L = [f"# Báo cáo đối thủ — {today}", ""]
    src = {}
    for r in lq:
        if r["thoi_gian"][:10] == cuoi: src.setdefault(r["kenh"], []).append(f"{r['nguon']} ({r['so_video']} video{', ' + r['ket_qua'] if r['ket_qua'] != 'ok' else ''})")
    L.append(f"**Lần quét {cuoi}**" + (f" (trước đó {truoc})" if truoc else " (lần đầu)") + ": " + "; ".join(f"{ten.get(k, k)} — {', '.join(v)}" for k, v in src.items()) + ".")
    L.append(f"Kho: {len(rows)} video, {len(ten)} kênh. `×TV` = lượt xem ÷ trung vị của chính kênh (video dài). Video < 7 ngày chưa kết luận hụt.")
    # 1 video moi
    L += ["", "## 1. Video mới từ lần quét trước"]
    nv = [r for r in rows if truoc and r.get("ngay_thay_dau", "") > truoc]
    if not truoc: L.append("Lần quét đầu: chưa có mốc so sánh.")
    elif not nv: L.append("Không có video mới.")
    else: L += ["| Kênh | Video | Đăng | View | ×TV |", "|---|---|---|---|---|"] + [f"| {r['ten_kenh']} | {ngan(r['tieu_de'])} | {r.get('ngay_dang', '')} | {gon(r.get('luot_xem'))} | {r.get('diem_vuot_troi') or '—'} |" for r in sorted(nv, key=lambda r: r.get("ngay_dang", ""), reverse=True)]
    # 2 top vuot troi 90 ngay
    gan = [r for r in dl if r.get("tuoi_ngay") != "" and int(r["tuoi_ngay"]) <= a.ngay and r.get("diem_vuot_troi")]
    top = sorted(gan, key=lambda r: float(r["diem_vuot_troi"]), reverse=True)[:10]
    L += ["", f"## 2. Vượt trội {a.ngay} ngày gần nhất", "| # | Kênh | Video | Đăng | View | View/ngày | ×TV | Đề tài |", "|---|---|---|---|---|---|---|---|"]
    L += [f"| {i} | {r['ten_kenh']} | {ngan(r['tieu_de'])} | {r.get('ngay_dang', '')} | {gon(r['luot_xem'])} | {gon(r.get('luot_xem_ngay'))} | **{r['diem_vuot_troi']}** | {NHOM['de_tai'].get(r['de_tai'], r['de_tai'])} |" for i, r in enumerate(top, 1)]
    # 3 cai dang an
    def bang(key, lab, names, src_rows):
        g = {}
        for r in src_rows: g.setdefault(r[key], []).append(r)
        out = [f"| {lab} | Số video | Kênh làm | ×TV trung vị | Tốt nhất |", "|---|---|---|---|---|"]
        for k, v in sorted(g.items(), key=lambda kv: -statistics.median(float(x["diem_vuot_troi"] or 0) for x in kv[1])):
            best = max(v, key=lambda x: int(x["luot_xem"]))
            out.append(f"| {names.get(k, k).replace('|', '¦')} | {len(v)} | {len({x['kenh'] for x in v})} | {statistics.median(float(x['diem_vuot_troi'] or 0) for x in v):.2f} | {ngan(best['tieu_de'])[:42]} ({gon(best['luot_xem'])}) |")
        return out, g
    L += ["", "## 3. Cái gì đang ăn", "**Đề tài** (tự xếp theo tiêu đề + tag; video đã phân tích tay thì theo bảng phân tích):"]
    pt = doc_phan_tich(D); ptv = {x.get("video_id"): x for x in pt if x.get("video_id")}
    for r in dl:
        if r["video_id"] in ptv and ptv[r["video_id"]].get("de_tai"): r["de_tai"] = ptv[r["video_id"]]["de_tai"]
    b, gdt = bang("de_tai", "Đề tài", NHOM["de_tai"], dl); L += b
    b, _ = bang("cong_thuc_tieu_de", "Công thức tiêu đề", CONG_THUC, dl); L += ["", "**Công thức tiêu đề:**"] + b
    L += ["", f"**Khung truyện / kiểu kết / câu móc** (từ {len(pt)} video đã phân tích ở `phan-tich/`):"]
    if len(pt) < 3: L.append(f"Chưa đủ dữ liệu (cần ≥ 3 video phân tích; đang có {len(pt)}). Đưa thêm video đối thủ (.mp4 hoặc ảnh chụp) để phân tích tầng 2.")
    for key, nm, lab_pt in (("khung_truyen", KHUNG, "khung truyện"), ("kieu_ket", KET, "kiểu kết"), ("kieu_cau_moc", MOC, "câu móc"), ("kieu_bo_dem", DEM, "bộ đếm")):
        if pt:
            c = {}
            for x in pt: c.setdefault(x.get(key) or "?", []).append(float(x.get("diem_vuot_troi") or 0))
            L.append(f"- {lab_pt}: " + "; ".join(f"{nm.get(k, k)} {len(v)} video" + (f" (×TV TB {statistics.mean(v):.1f})" if any(v) else "") for k, v in sorted(c.items(), key=lambda kv: -len(kv[1]))))
    # 4 khoang trong
    L += ["", "## 4. Khoảng trống"]
    kt = []
    for k, v in gdt.items():
        best = max(float(x["diem_vuot_troi"] or 0) for x in v); nm = NHOM["de_tai"].get(k, k)
        if len(v) <= 2 and best >= 2: kt.append(f"- **{nm}**: ít người làm ({len(v)} video) nhưng làm là nổ (×{best:.1f}: {ngan(max(v, key=lambda x: float(x['diem_vuot_troi'] or 0))['tieu_de'])}).")
        hi = sorted([x for x in v if float(x["diem_vuot_troi"] or 0) >= 2], key=lambda x: -float(x["diem_vuot_troi"]))
        lo = [x for x in v if x["diem_vuot_troi"] and float(x["diem_vuot_troi"]) <= 0.7 and int(x.get("tuoi_ngay") or 0) >= 7]
        for kn in dict.fromkeys(l["kenh"] for l in lo):   # moi kenh lam do 1 dong: kenh nay hut, kenh khac no cung de tai
            h = [x for x in hi if x["kenh"] != kn]
            if h: kt.append(f"- **{nm}** — {ten[kn]} làm dở (" + ", ".join(f"{ngan(l['tieu_de'])} ×{float(l['diem_vuot_troi']):.2f}" for l in lo if l["kenh"] == kn) + f") trong khi {h[0]['ten_kenh']} nổ ({ngan(h[0]['tieu_de'])} ×{float(h[0]['diem_vuot_troi']):.1f}): khán giả muốn, làm tốt hơn thì có chỗ.")
        rec = [x for x in v if x.get("tuoi_ngay") != "" and int(x["tuoi_ngay"]) <= 30]
        if len(rec) >= 4: kt.append(f"- **{nm}** đang dày ({len(rec)} video / 30 ngày): làm thì phải khác hẳn góc kể (khung, kết, vật biểu tượng).")
    chua = [n for m, n, _ in DE_TAI if m not in gdt and m != "khac"]
    if chua: kt.append("- Đối thủ chưa làm (chưa có bằng chứng view, ít cạnh tranh): " + ", ".join(chua) + ".")
    L += list(dict.fromkeys(kt)) or ["- Chưa thấy khoảng trống rõ."]
    # 5 kenh minh
    L += ["", "## 5. Kênh mình đã làm (projects/)"]
    mine = du_an_cua_toi(D)
    if not mine: L.append("Chưa có dự án nào trong `projects/`.")
    for d, tit, dtai, _ in mine:
        same = gdt.get(dtai, []); L.append(f"- {d} — {tit} ({NHOM['de_tai'].get(dtai, dtai)})" + (f": đối thủ có {len(same)} video cùng đề tài, tốt nhất ×{max(float(x['diem_vuot_troi'] or 0) for x in same):.1f}" if same else ": đối thủ chưa làm"))
    L += ["", "## 6. Gợi ý", "- Muốn quét tự động mỗi tuần: trả lời \"tạo lịch quét tuần\" (tạo việc định kỳ, ví dụ thứ Hai 8:00, chạy \"quét đối thủ\" và lưu báo cáo vào `bao-cao/`)."]
    md = "\n".join(L) + "\n"; os.makedirs(os.path.join(T, "bao-cao"), exist_ok=True); p = os.path.join(T, "bao-cao", f"bao-cao-{today}.md")
    open(p, "w", encoding="utf-8").write(md); print(md); print(f"(da luu {p})")

def cmd_trung_lap(a, today):
    D = a.thu_muc; me = {"de_tai": a.de_tai, "khung_truyen": a.khung, "kieu_ket": a.ket, "vat": a.vat}; lines = []
    if a.phim:
        meta = doc_meta(a.phim); me = {"de_tai": meta.get("đề tài"), "khung_truyen": meta.get("khung"), "kieu_ket": meta.get("kết"), "vat": meta.get("vật")}
        for l in open(a.phim, encoding="utf-8-sig"):   # dong chu (> ~ ! ") va cac dong cua THẺ KẾT
            l = unicodedata.normalize("NFC", l.strip()); m = re.search(r"THẺ KẾT\s*:\s*([^|]+)", l, re.I)
            if m: lines += [x.strip() for x in m.group(1).split("/") if x.strip()]
            elif re.match(r"^(\{[\d.,]+\}\s*)?[>~!\"“]", l): lines.append(re.sub(r"^\{[\d.,]+\}\s*", "", l)[1:].strip())
        tit = meta.get("title", "")
    else: tit = a.tieu_de or ""
    code = {"de_tai": ma("de_tai", me["de_tai"]), "khung_truyen": ma("khung_truyen", me["khung_truyen"]), "kieu_ket": ma("kieu_ket", me["kieu_ket"]), "vat": vat_chuan(me["vat"])}
    thieu = [k for k in ("de_tai", "khung_truyen", "kieu_ket") if not code[k]] + ([] if me["vat"] else ["vat"])
    print(f"KIEM TRA TRUNG LAP — {os.path.basename(a.phim) if a.phim else 'kich ban'}: đề tài {NHOM['de_tai'].get(code['de_tai'], me['de_tai'])}, khung {KHUNG.get(code['khung_truyen'], me['khung_truyen'])}, "
          f"kết {KET.get(code['kieu_ket'], me['kieu_ket'])}, vật {code['vat'] or '—'}")
    loi = 0
    if thieu: print(f"LOI: thiếu / sai {', '.join(thieu)} (đầu file 01: ĐỀ TÀI / KHUNG / KẾT / VẬT; giá trị theo bảng ở references/doi-thu.md)"); loi += 1
    pt = doc_phan_tich(D); hit = []
    for x in pt:
        same = [k for k in ("de_tai", "khung_truyen", "kieu_ket") if x.get(k) and x.get(k) == code[k]] + (["vat"] if code["vat"] and vat_chuan(x.get("vat_bieu_tuong")) == code["vat"] else [])
        if len(same) >= 3: hit.append((len(same), same, x))
    print(f"So với {len(pt)} video đã phân tích ở phan-tich/:")
    if not pt: print("  (thư viện phân tích trống: chưa so được khung / kết / vật; chỉ so được tiêu đề và câu chữ)")
    for n, same, x in sorted(hit, key=lambda h: -h[0]):
        tag = "TRUNG" if n == 4 else "GAN TRUNG"
        print(f"  {tag} {n}/4 với {x.get('kenh', '?')} '{x.get('tieu_de', '?')}' ({x['_file']}): trùng {', '.join({'de_tai': 'đề tài', 'khung_truyen': 'khung', 'kieu_ket': 'kết', 'vat': 'vật'}[k] for k in same)}")
        if n == 4:
            loi += 1; used = [y for y in pt if y.get("de_tai") == code["de_tai"]]
            alt_k = [KHUNG[k] for k in KHUNG if k not in {y.get("khung_truyen") for y in used} and k != "khac"]
            alt_e = [KET[k] for k in KET if k not in {y.get("kieu_ket") for y in used}]
            alt_v = [v for v in VAT if v not in {vat_chuan(y.get("vat_bieu_tuong")) for y in used}]
            print("    -> ĐỔI ÍT NHẤT 2 TRONG 4. Gợi ý (đối thủ chưa dùng cho đề tài này):")
            print(f"       khung: {', '.join(alt_k[:3]) or '—'} | kết: {', '.join(alt_e[:3]) or '—'} | vật: {', '.join(alt_v[:4]) or '—'} | đề tài gần: {', '.join(gan_de_tai(code['de_tai']))}")
    if not hit and pt: print("  Không trùng ≥ 3/4 với video nào.")
    # cau chu: khong dung lai cau trich / tieu de cua doi thu
    rows = doc_csv(os.path.join(thu_muc(D), "video.csv"))
    norm = lambda s: re.sub(r"[^a-z0-9 ]", "", s.lower()).strip()
    for x in pt:
        for q in x.get("trich", []):
            for l in lines:
                if norm(l) and norm(q) and (norm(l) == norm(q) or (len(norm(q)) > 12 and norm(q) in norm(l))): print(f"  LOI chép câu: '{l}' trùng câu của {x.get('kenh')} '{x.get('tieu_de')}'"); loi += 1
    if a.phim:   # 2.1: khong dung lai dung khai niem / cau trich ma doi thu da dung lam diem nhan (phan-tich: the_khai_niem, the_trich_dan)
        ckn = lambda s: re.sub(r"\s+", " ", re.sub(r"[^a-z0-9 ]", " ", khong_dau(s))).strip(); su_that = ckn(meta.get("sự thật", ""))
        tk = [ckn(y) for x in open(a.phim, encoding="utf-8-sig") if re.match(r"^#\s*truyen\s*:", khong_dau(x.strip())) for y in x.split(":", 1)[1].split(";")]
        kn = [y[len("khai niem"):].strip() for y in tk if y.startswith("khai niem")]
        for x in pt:
            for k, nhan in (("the_khai_niem", "khái niệm"), ("the_trich_dan", "trích dẫn")):
                v = ckn(x.get(k) or "")
                if len(v) > 3 and (v in su_that or any(v in y or y in v for y in kn if y)): print(f"  LOI dùng lại {nhan} '{x.get(k)}' của {x.get('kenh')} '{x.get('tieu_de')}' → chọn {nhan} khác"); loi += 1
    if tit:
        same_t = [r for r in rows if norm(r.get("tieu_de", "").split("|")[0]) == norm(tit.split("|")[0])]
        for r in same_t: print(f"  CANH BAO tiêu đề: '{tit}' trùng {r['ten_kenh']} '{r['tieu_de']}' ({gon(r.get('luot_xem'))}) → đổi tiêu đề / thêm dấu ấn kênh")
    print("=> CAN SUA TRUOC KHI GIAO." if loi else "=> KHONG TRUNG.")
    sys.exit(1 if loi else 0)
GAN = {"lust": ["tinh-yeu", "co-don", "dien-thoai"], "dien-thoai": ["mang-xa-hoi", "game", "tri-hoan"], "game": ["dien-thoai", "luoi", "tri-hoan"], "co-don": ["tinh-yeu", "mang-xa-hoi"],
       "tri-hoan": ["luoi", "tiec-nuoi", "so-that-bai"], "luoi": ["tri-hoan", "ky-luat"], "ky-luat": ["luoi", "tiec-nuoi", "tri-hoan"], "tiec-nuoi": ["tri-hoan", "dien-thoai"]}
def gan_de_tai(m): return [NHOM["de_tai"][x] for x in GAN.get(m, ["tiec-nuoi", "co-don", "luoi"])]

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("lenh", choices=["quet", "nhap", "bao-cao", "trung-lap"]); ap.add_argument("--thu-muc", default=".")
    ap.add_argument("--gia-lap-loi", default=""); ap.add_argument("--hom-nay"); ap.add_argument("--kenh"); ap.add_argument("--ten"); ap.add_argument("--nguon", default="trinh-duyet", choices=["trinh-duyet", "tim-kiem"])
    ap.add_argument("--link"); ap.add_argument("--trang"); ap.add_argument("--khong-lam-giau", action="store_true"); ap.add_argument("--ngay", type=int, default=90)
    ap.add_argument("--phim"); ap.add_argument("--de-tai"); ap.add_argument("--khung"); ap.add_argument("--ket"); ap.add_argument("--vat"); ap.add_argument("--tieu-de")
    a = ap.parse_args(); GIA_LAP.update(x.strip() for x in a.gia_lap_loi.split(",") if x.strip())
    today = dt.date.fromisoformat(a.hom_nay) if a.hom_nay else dt.date.today()
    if a.lenh == "nhap" and not (a.kenh and a.link): sys.exit("nhap can --kenh <url> va --link <file>")
    {"quet": cmd_quet, "nhap": cmd_nhap, "bao-cao": cmd_bao_cao, "trung-lap": cmd_trung_lap}[a.lenh](a, today)

if __name__ == "__main__": main()
