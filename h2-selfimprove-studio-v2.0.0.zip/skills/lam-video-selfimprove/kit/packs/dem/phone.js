// phone.js — can canh: dien thoai (feed, reel, chat, email, man khoa, tat, bo dem), dong ho bao thuc to, so tay viet chu.
import { E, clamp, lerp, ease, rng, noise, alpha, shade, text, measure, radGrad } from '/engine/core.js';
import { PAL, accent, box, oval, ln, light, FONT_UI, FONT_HAND, FONT_NARR, wrap, seg7, classic } from './ink.js';
import { bigHand } from './bean.js';
import { postArt, ARTS } from './art.js';

const UIF = '"Be Vietnam Pro"';
function rr(g, x, y, w, h, r, fill) { g.beginPath(); g.roundRect(x, y, w, h, r); g.fillStyle = fill; g.fill(); }
const fmt = (s) => { s = Math.max(0, Math.floor(s)); const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60), x = s % 60; return (h ? h + ':' + String(m).padStart(2, '0') : m) + ':' + String(x).padStart(2, '0'); };

// phone(g, cx, cy, h, o): o.screen = feed | reel | chat | email | lock | off | counter ; o.t = giay trong canh
export function phone(g, cx, cy, h, o = {}) {
  const w = h * 0.49, x = cx - w / 2, y = cy - h / 2, t = o.t || 0, s = h / 1000;
  light(g, cx, cy, h * 0.9, o.glowColor || (o.screen === 'reel' ? accent() : PAL.screen), o.screen === 'off' ? 0 : 0.18);
  rr(g, x - 14 * s, y - 14 * s, w + 28 * s, h + 28 * s, 70 * s, '#0e0f12'); g.lineWidth = 3 * s; g.strokeStyle = '#5b5e66'; g.stroke();
  g.save(); g.beginPath(); g.roundRect(x, y, w, h, 56 * s); g.clip();
  const sc = o.screen || 'feed', U = s;
  g.fillStyle = sc === 'chat' || sc === 'email' ? '#121317' : '#0b0b0e'; g.fillRect(x, y, w, h);
  const status = (col = '#e8e8ea') => { text(g, o.clock || '23:41', x + 70 * U, y + 52 * U, { size: 30 * U, font: UIF, weight: 700, color: col }); rr(g, x + w - 110 * U, y + 40 * U, 60 * U, 24 * U, 6 * U, alpha(col, 0.8)); };
  if (sc === 'feed' && o.style === 'blocks') {
    status(); const off = (t * (o.scroll ?? 220)) % (h * 0.62);
    const cols = o.colors || ['#ff4f8a', '#7a4dff', '#ff8a3d', '#3dc6ff', '#ff3d6b', '#c94dff'];
    for (let i = -1; i < 4; i++) {
      const cy0 = y + 110 * U + i * h * 0.62 - off; rr(g, x + 24 * U, cy0, w - 48 * U, h * 0.5, 22 * U, '#1d1e24');
      const c = cols[(i + 10 + Math.floor((t * (o.scroll ?? 220)) / (h * 0.62))) % cols.length];
      g.fillStyle = c; g.fillRect(x + 24 * U, cy0 + 60 * U, w - 48 * U, h * 0.36);
    }
  } else if (sc === 'feed') {
    // moi lan 1 bai dang (minh hoa phang), giu "hold" giay roi vuot len; posts = ['ramen', 'car', ...]
    const posts = o.posts && o.posts.length ? o.posts : ['ramen', 'car', 'burger', 'beach', 'watch', 'game'];
    const hold = o.hold ?? 1.1, sw = Math.min(0.3, hold * 0.4), per = hold + sw, k = Math.max(0, t) / per, n = Math.floor(k), f = k - n, slide = f < hold / per ? 0 : (f - hold / per) / (sw / per);
    const off = -(n + (slide < 1 ? slide * slide * (3 - 2 * slide) : 1)) * h;
    const avc = ['#e0875a', '#5a7fe0', '#5ac08a', '#c05ab0', '#e0c05a', '#5ab8e0'];
    for (let i = Math.max(0, n - 1); i <= n + 1; i++) {
      const yy = y + i * h + off, kind = posts[i % posts.length];
      if (yy > y + h || yy + h < y) continue;
      oval(g, x + 62 * U, yy + 220 * U, 32 * U, 32 * U, { fill: avc[i % avc.length], line: null }); rr(g, x + 110 * U, yy + 208 * U, 230 * U, 24 * U, 12 * U, '#4a4d57'); text(g, '•••', x + w - 70 * U, yy + 220 * U, { size: 36 * U, font: UIF, weight: 700, color: '#ddd' });
      postArt(g, kind, x, yy + 275 * U, w, w * 1.05, t, o);
      const iy = yy + 275 * U + w * 1.05 + 60 * U; g.lineWidth = 4 * U; g.strokeStyle = '#eee';
      g.beginPath(); const hx = x + 60 * U; g.moveTo(hx, iy + 14 * U); g.bezierCurveTo(hx - 30 * U, iy - 10 * U, hx - 16 * U, iy - 34 * U, hx, iy - 16 * U); g.bezierCurveTo(hx + 16 * U, iy - 34 * U, hx + 30 * U, iy - 10 * U, hx, iy + 14 * U); g.stroke();
      g.beginPath(); g.arc(x + 140 * U, iy - 6 * U, 22 * U, 0.6, Math.PI * 2.35); g.lineTo(x + 118 * U, iy + 20 * U); g.closePath(); g.stroke();
    }
    g.fillStyle = '#0b0b0e'; g.fillRect(x, y, w, 150 * U); status(); rr(g, x + w / 2 - 110 * U, y + 110 * U, 220 * U, 28 * U, 14 * U, '#555864'); text(g, '•••', x + w - 70 * U, y + 120 * U, { size: 36 * U, font: UIF, weight: 700, color: '#eee' });
  } else if (sc === 'reel') {
    const c = o.color || accent();
    if (o.art) { g.fillStyle = '#000'; g.fillRect(x, y, w, h); postArt(g, o.art, x, y + h * 0.25, w, w * 1.0, t, o); }
    else { const gr = g.createRadialGradient(x + w / 2, y + h * 0.45, 0, x + w / 2, y + h * 0.45, h * 0.6); gr.addColorStop(0, alpha(c, 0.85)); gr.addColorStop(1, '#100810'); g.fillStyle = gr; g.fillRect(x, y, w, h);
    g.save(); g.globalAlpha = 0.35 + 0.1 * Math.sin(t * 3); oval(g, x + w / 2, y + h * 0.42 + Math.sin(t * 2) * 10, w * 0.22, h * 0.2, { fill: shade(c, 0.4), line: null }); g.restore(); }
    status(); const a = (o.from ?? 47) + t * (o.speed ?? 1) , tot = o.total ?? 9720;
    rr(g, x + 30 * U, y + h - 120 * U, w - 60 * U, 8 * U, 4 * U, 'rgba(255,255,255,0.3)'); rr(g, x + 30 * U, y + h - 120 * U, (w - 60 * U) * clamp(a / tot), 8 * U, 4 * U, c);
    text(g, fmt(a) + ' / ' + fmt(tot), x + 30 * U, y + h - 80 * U, { size: 28 * U, font: UIF, weight: 700, color: '#fff', align: 'left' });
  } else if (sc === 'chat') {
    status(); rr(g, x, y + 80 * U, w, 110 * U, 0, '#18191e');
    text(g, '‹', x + 40 * U, y + 135 * U, { size: 60 * U, font: UIF, weight: 700, color: '#ddd' }); oval(g, x + 105 * U, y + 135 * U, 32 * U, 32 * U, { fill: o.avatar || PAL.capB, line: null });
    text(g, o.name || 'jay', x + 155 * U, y + 135 * U, { size: 38 * U, font: UIF, weight: 700, color: '#f2f2f4', align: 'left' });
    let yy = y + 240 * U; const bw = w * 0.72;
    for (const m of o.messages || []) {
      const at = m.at ?? 0; if (t < at - (m.me ? 0 : 0.9)) break;
      const size = 32 * U, lines = wrap(g, m.text, bw - 50 * U, size, UIF, 700), bh = lines.length * size * 1.3 + 30 * U;
      if (t < at) { rr(g, x + 30 * U, yy, 110 * U, 60 * U, 30 * U, '#2a2c33'); for (let k = 0; k < 3; k++) oval(g, x + 62 * U + k * 24 * U, yy + 30 * U - Math.max(0, Math.sin(t * 9 - k)) * 6 * U, 7 * U, 7 * U, { fill: '#bbb', line: null }); break; }
      const bwr = Math.min(bw, Math.max(...lines.map((l) => measure(g, l, size, UIF, 700))) + 50 * U), bx = m.me ? x + w - 30 * U - bwr : x + 30 * U;
      const k = ease.outBack(clamp((t - at) / 0.3)); g.save(); g.translate(bx + bwr / 2, yy + bh / 2); g.scale(k, k); g.translate(-(bx + bwr / 2), -(yy + bh / 2));
      rr(g, bx, yy, bwr, bh, 26 * U, m.me ? PAL.blueMsg : '#2a2c33'); lines.forEach((l, i) => text(g, l, bx + 25 * U, yy + 15 * U + size * 0.65 + i * size * 1.3, { size, font: UIF, weight: 600, color: '#fff', align: 'left' })); g.restore();
      yy += bh + 18 * U; if (m.day) { text(g, m.day, x + w / 2, yy - bh - 40 * U, { size: 22 * U, font: UIF, weight: 600, color: '#888' }); }
    }
    if (o.seen !== undefined && t >= o.seen) text(g, 'Seen', x + w - 40 * U, yy, { size: 24 * U, font: UIF, weight: 600, color: '#9a9aa0', align: 'right' });
    // o nhap + ban phim
    const ky = o.keyboard ? y + h * 0.62 : y + h - 110 * U; rr(g, x + 24 * U, ky, w - 48 * U, 70 * U, 35 * U, '#24262c');
    const draft = o.draft || ''; const shown = draft.slice(0, Math.floor(clamp((t - (o.draftAt ?? 0)) * 12) / 1) || 0); if (draft) text(g, draft.slice(0, Math.max(0, Math.floor((t - (o.draftAt ?? 0)) * 12))), x + 50 * U, ky + 36 * U, { size: 30 * U, font: UIF, weight: 600, color: '#eee', align: 'left' });
    if (Math.floor(t * 2) % 2 === 0) rr(g, x + 50 * U + (draft ? measure(g, draft.slice(0, Math.max(0, Math.floor((t - (o.draftAt ?? 0)) * 12))), 30 * U, UIF, 600) : 0), ky + 18 * U, 3 * U, 36 * U, 1, '#4d8cff');
    oval(g, x + w - 62 * U, ky + 35 * U, 26 * U, 26 * U, { fill: PAL.blueMsg, line: null }); text(g, '↑', x + w - 62 * U, ky + 36 * U, { size: 32 * U, font: UIF, weight: 700, color: '#fff' });
    if (o.keyboard) { rr(g, x, ky + 90 * U, w, h, 0, '#1a1b20'); ['qwertyuiop', 'asdfghjkl', 'zxcvbnm'].forEach((row, ri) => [...row].forEach((ch, ci) => { const kw = (w - 40 * U) / 10, kx = x + 20 * U + ci * kw + ri * kw * 0.5; rr(g, kx + 3 * U, ky + 110 * U + ri * 80 * U, kw - 6 * U, 66 * U, 10 * U, '#3a3c44'); text(g, ch, kx + kw / 2, ky + 143 * U + ri * 80 * U, { size: 28 * U, font: UIF, weight: 600, color: '#ddd' }); })); }
  } else if (sc === 'email') {
    status(); text(g, 'Inbox', x + 40 * U, y + 140 * U, { size: 50 * U, font: UIF, weight: 700, color: '#fff', align: 'left' });
    const rows = o.rows || [{ from: o.from || 'Recruiting', subject: o.subject || 'Re: your application', preview: o.preview || 'Thank you for your time. We have decided to move forward with other candidates.', hl: true }, { from: 'Promo', subject: '50% off', preview: '...' }, { from: 'Bank', subject: 'Statement', preview: '...' }];
    rows.forEach((r, i) => { const yy = y + 200 * U + i * 210 * U; if (r.hl) rr(g, x + 14 * U, yy - 10 * U, w - 28 * U, 200 * U, 20 * U, '#1f2230'); oval(g, x + 52 * U, yy + 40 * U, 10 * U, 10 * U, { fill: r.hl ? '#4d8cff' : '#333', line: null }); text(g, r.from, x + 80 * U, yy + 30 * U, { size: 30 * U, font: UIF, weight: 700, color: '#fff', align: 'left' }); text(g, r.subject, x + 80 * U, yy + 72 * U, { size: 27 * U, font: UIF, weight: 600, color: '#ddd', align: 'left' }); wrap(g, r.preview, w - 120 * U, 24 * U, UIF, 600).slice(0, 2).forEach((l, k) => text(g, l, x + 80 * U, yy + 112 * U + k * 32 * U, { size: 24 * U, font: UIF, weight: 600, color: '#8c8f99', align: 'left' })); });
  } else if (sc === 'lock') {
    const gr = g.createLinearGradient(x, y, x, y + h); gr.addColorStop(0, '#1d2340'); gr.addColorStop(1, '#3a2240'); g.fillStyle = gr; g.fillRect(x, y, w, h);
    text(g, o.time || '3:17', x + w / 2, y + h * 0.22, { size: 150 * U, font: UIF, weight: 700, color: '#f4f4f6' }); text(g, o.date || 'Tuesday, March 4', x + w / 2, y + h * 0.12, { size: 30 * U, font: UIF, weight: 600, color: '#ddd' });
    (o.notes || []).forEach((n, i) => { if (t < (n.at ?? 0)) return; const k = ease.outBack(clamp((t - (n.at ?? 0)) / 0.35)), yy = y + h * 0.38 + i * 150 * U; g.save(); g.globalAlpha = k; rr(g, x + 24 * U, yy, w - 48 * U, 130 * U, 26 * U, 'rgba(60,62,74,0.85)'); text(g, n.app || 'Messages', x + 60 * U, yy + 38 * U, { size: 24 * U, font: UIF, weight: 700, color: '#bbb', align: 'left' }); text(g, n.text, x + 60 * U, yy + 86 * U, { size: 30 * U, font: UIF, weight: 600, color: '#fff', align: 'left' }); g.restore(); });
  } else if (sc === 'counter') {
    status(); const n = o.n ?? 0; text(g, o.label || 'CLEAN STREAK', x + w / 2, y + h * 0.3, { size: 34 * U, font: UIF, weight: 700, color: '#aaa', spacing: 4 });
    text(g, String(n), x + w / 2, y + h * 0.45, { size: 200 * U, font: UIF, weight: 700, color: o.color || '#fff' }); text(g, 'days', x + w / 2, y + h * 0.56, { size: 40 * U, font: UIF, weight: 600, color: '#aaa' });
  } else if (sc === 'off') {
    const gr = g.createLinearGradient(x, y, x + w, y + h); gr.addColorStop(0, '#16171b'); gr.addColorStop(0.5, '#0b0b0d'); gr.addColorStop(1, '#141418'); g.fillStyle = gr; g.fillRect(x, y, w, h);
    g.save(); g.globalAlpha = 0.08; g.fillStyle = '#fff'; g.beginPath(); g.moveTo(x, y + h * 0.3); g.lineTo(x + w, y); g.lineTo(x + w, y + h * 0.1); g.lineTo(x, y + h * 0.45); g.fill(); g.restore();
    if (o.reflect) { g.save(); g.globalAlpha = 0.18; oval(g, x + w / 2, y + h * 0.45, w * 0.26, w * 0.26, { fill: PAL.hero, line: null }); g.restore(); }
  }
  g.restore();
  return { x, y, w, h };
}

// dong ho bao thuc can canh
export function bigClock(g, cx, cy, s, o = {}) {
  const w = s * 1.5, h = s * 0.75, col = o.color || PAL.clock, t = o.t || 0;
  light(g, cx, cy, s * 1.6, col, 0.15);
  box(g, cx - w / 2, cy - h / 2, w, h, { fill: '#1c1d22', line: PAL.line, r: s * 0.1, lw: 4 });
  box(g, cx - s * 0.18, cy - h / 2 - s * 0.07, s * 0.36, s * 0.08, { fill: '#2a2c33', r: s * 0.03 }); text(g, 'SNOOZE', cx, cy - h / 2 - s * 0.03, { size: s * 0.035, font: UIF, weight: 700, color: '#888' });
  const show = o.blink ? Math.floor(t * 2) % 2 === 0 : true;
  if (!classic()) seg7(g, String(o.time ?? '5:00'), cx, cy + s * 0.01, s * 0.36, col, { colon: show });   // so LED 7 doan nhu dong ho that
  else { g.save(); g.shadowColor = col; g.shadowBlur = s * 0.12; text(g, show ? String(o.time ?? '5:00') : String(o.time ?? '5:00').replace(':', ' '), cx, cy + s * 0.02, { size: s * 0.42, font: UIF, weight: 700, color: col, spacing: s * 0.02 }); g.restore(); }
  if (o.ring && Math.sin(t * 24) > -0.2) for (const d of [-1, 1]) for (let i = 0; i < 3; i++) ln(g, [[cx + d * (w / 2 + s * 0.06 + i * s * 0.05), cy - h * 0.6 + i * s * 0.05], [cx + d * (w / 2 + s * 0.11 + i * s * 0.05), cy - h * 0.75 + i * s * 0.05]], { color: col, lw: s * 0.015, la: 1 });
}

// so tay mo, chu viet tay hien dan, tay cam but
export function notebook(g, cx, cy, s, o = {}) {
  const w = s * 1.25, h = s * 0.85, t = o.t || 0;
  light(g, cx, cy, s * 1.2, PAL.lamp, 0.25);
  box(g, cx - w / 2, cy - h / 2, w, h, { fill: '#efe8d6', line: '#7a705e', r: 8 }); ln(g, [[cx, cy - h / 2], [cx, cy + h / 2]], { color: '#7a705e', lw: 2 });
  for (let i = 1; i < 9; i++) ln(g, [[cx + 20, cy - h / 2 + i * h / 9], [cx + w / 2 - 20, cy - h / 2 + i * h / 9]], { color: '#9fb4cf', lw: 1.2, la: 0.6 });
  const str = o.text || 'day 1.', lines = String(str).split('\n'), cps = o.cps || 9, at = o.at ?? 0.3; let n = Math.max(0, Math.floor((t - at) * cps)), lastX = cx - w * 0.38, lastY = cy - h * 0.2;
  lines.forEach((l, i) => { const vis = l.slice(0, n); n -= l.length; if (!vis) return; const x0 = (o.page === 'right' ? cx + 40 : cx - w / 2 + 40), y0 = cy - h * 0.3 + i * s * 0.14; text(g, vis, x0, y0, { size: s * 0.1, font: FONT_HAND, weight: 700, color: '#2b2a33', align: 'left' }); lastX = x0 + measure(g, vis, s * 0.1, FONT_HAND, 700); lastY = y0; });
  if (o.hand !== false) { bigHand(g, lastX + s * 0.08, lastY + s * 0.16 + Math.sin(t * 14) * 3, s * 0.13, { rot: -0.5, sleeve: o.sleeve || PAL.hood }); ln(g, [[lastX + s * 0.02, lastY + s * 0.04], [lastX + s * 0.1, lastY + s * 0.14]], { color: '#222', lw: s * 0.012, la: 1 }); }
}

// tay cam dien thoai (ban moi): back = long ban tay + co tay ao (sau may), front = 4 ngon om mep trai / ngon cai phai (truoc may).
// Mau da kem nhu nhan vat, ngon co dot va mong, ngon cai cong thon; luot theo nhip (cham -> keo len -> nhac). Chi dung khi o.hands = "new"; mac dinh = tay 1.3.0.
const sk = () => ({ skin: PAL.hero, shade: PAL.heroShade, line: PAL.heroLine, nail: '#f7f0e3' });
function capsule(g, x0, y0, x1, y1, w0, w1, C, lw) {   // ngon tay thon dan: than + dau tron
  const a = Math.atan2(y1 - y0, x1 - x0), nx = -Math.sin(a), ny = Math.cos(a);
  const P = new Path2D(); P.moveTo(x0 + nx * w0 / 2, y0 + ny * w0 / 2); P.lineTo(x1 + nx * w1 / 2, y1 + ny * w1 / 2); P.arc(x1, y1, w1 / 2, a + Math.PI / 2, a - Math.PI / 2, true); P.lineTo(x0 - nx * w0 / 2, y0 - ny * w0 / 2); P.closePath();
  g.fillStyle = C.skin; g.fill(P); g.save(); g.clip(P); g.fillStyle = alpha(C.shade, 0.8); g.beginPath(); g.moveTo(x0 + nx * w0 * 0.05, y0 + ny * w0 * 0.05); g.lineTo(x1 + nx * w1 * 0.05, y1 + ny * w1 * 0.05); g.lineTo(x1 + nx * w1, y1 + ny * w1); g.lineTo(x0 + nx * w0, y0 + ny * w0); g.closePath(); g.fill(); g.restore();
  g.lineWidth = lw; g.strokeStyle = C.line; g.stroke(P); return { a, nx, ny };   // 1.10: vien dung hinh ngon tay (truoc: vien nham hinh binh hanh do bong -> "khung chu nhat" tren ngon)
}
function nailAt(g, x, y, a, w, l, C, lw) { g.save(); g.translate(x, y); g.rotate(a); g.beginPath(); g.ellipse(0, 0, l / 2, w / 2, 0, 0, Math.PI * 2); g.fillStyle = C.nail; g.fill(); g.lineWidth = lw * 0.6; g.strokeStyle = alpha(C.line, 0.7); g.stroke(); g.beginPath(); g.ellipse(l * 0.12, 0, l * 0.22, w * 0.3, 0, 0, Math.PI * 2); g.fillStyle = 'rgba(255,255,255,0.55)'; g.fill(); g.restore(); }
function crease(g, x, y, a, w, C, lw) { g.save(); g.translate(x, y); g.rotate(a); g.beginPath(); g.arc(0, 0, w * 0.35, -0.9, 0.9); g.lineWidth = lw * 0.55; g.strokeStyle = alpha(C.line, 0.75); g.stroke(); g.restore(); }
function sleeveAt(g, x, y, w, h, rot, col, lw) { g.save(); g.translate(x, y); g.rotate(rot); g.beginPath(); g.roundRect(-w / 2, 0, w, h, w * 0.25); g.fillStyle = col; g.fill(); g.lineWidth = lw; g.strokeStyle = shade(col, -0.35); g.stroke(); for (let k = 0; k < 3; k++) { g.beginPath(); g.moveTo(-w * 0.32 + k * w * 0.32, w * 0.08); g.lineTo(-w * 0.28 + k * w * 0.32, w * 0.4); g.lineWidth = lw * 0.5; g.stroke(); } g.restore(); }
export function phoneHand(g, px, py, pw, ph, side, part, o = {}) {
  if (o.hands !== 'new') return phoneHandClassic(g, px, py, pw, ph, side, part, o);   // mac dinh: tay 1.3.0
  const C = sk(), s = pw * 0.3, lw = Math.max(2, s * 0.035), t = o.t || 0;
  g.save(); g.lineJoin = 'round'; g.lineCap = 'round';
  if (side < 0 && part === 'back') {   // long ban tay trai sau may + co tay
    if (o.sleeve) sleeveAt(g, px - s * 0.55, py + ph * 0.86, s * 1.25, ph * 0.5, 0.35, o.sleeve, lw);
    g.beginPath(); g.ellipse(px - s * 0.18, py + ph * 0.74, s * 0.62, s * 1.05, 0.15, 0, Math.PI * 2); g.fillStyle = C.shade; g.fill(); g.lineWidth = lw; g.strokeStyle = C.line; g.stroke();
  }
  if (side < 0 && part === 'front' && o.fingers !== 'long') {   // 1.10: 4 ngon NGAN tron om mep trai, xoe nhe, khong mong / vach khop (ban 1.4 trong nhu xap giay)
    const y0 = py + ph * (o.handY ?? 0.5), fw = s * 0.36, Cs = { ...C, line: alpha(C.line, 0.75) };
    for (let i = 3; i >= 0; i--) {
      const w = fw * [0.92, 1, 0.97, 0.84][i], yy = y0 + i * fw * 0.9 + noise(t * 0.7 + i, 4) * s * 0.012, ang = (i - 1.5) * 0.08, L = s * (i === 1 || i === 2 ? 0.66 : 0.58);
      capsule(g, px - s * 0.32, yy, px - s * 0.32 + Math.cos(ang) * L, yy + Math.sin(ang) * L, w * 1.05, w * 0.92, Cs, lw * 0.8);
    }
  }
  if (side < 0 && part === 'front' && o.fingers === 'long') {   // 4 ngon om mep trai, dau ngon ngoi len mat may (ban 1.4)
    const y0 = py + ph * (o.handY ?? 0.48), fw = s * 0.38;
    for (let i = 0; i < 4; i++) {
      const sc = [0.95, 1, 0.97, 0.82][i], yy = y0 + i * fw * 0.98 + [0, 0.04, 0.02, 0.1][i] * fw + noise(t * 0.7 + i, 4) * s * 0.012, w = fw * sc, L = s * 1.2 * sc;
      const g0 = [px - s * 0.5, yy + w * 0.25], g1 = [px + L * 0.5 - s * 0.08, yy - w * 0.1 + i * w * 0.06];
      const { a } = capsule(g, g0[0], g0[1], g1[0], g1[1], w, w * 0.86, C, lw);
      crease(g, px - s * 0.06, yy + w * 0.02, a, w, C, lw); nailAt(g, g1[0] - w * 0.12, g1[1] - w * 0.06, a, w * 0.52, w * 0.62, C, lw);
    }
  }
  if (side > 0 && part === 'back') {   // long ban tay phai + co tay ao
    if (o.sleeve) sleeveAt(g, px + pw + s * 0.75, py + ph * 0.9, s * 1.3, ph * 0.5, -0.45, o.sleeve, lw);
    g.beginPath(); g.ellipse(px + pw + s * 0.3, py + ph * 0.8, s * 0.7, s * 1.0, -0.3, 0, Math.PI * 2); g.fillStyle = C.shade; g.fill(); g.lineWidth = lw; g.strokeStyle = C.line; g.stroke();
  }
  if (side > 0 && part === 'front') {   // ngon cai cong thon de len man hinh; luot: cham (an xuong) -> keo len -> nhac
    const per = o.period || 1.6, ph0 = (((t % per) + per) % per) / per, by = py + ph * (o.thumbY ?? 0.66);
    let lift = 0, drag = 0; if (o.tap) { if (ph0 > 0.62 && ph0 < 0.72) lift = -(ph0 - 0.62) / 0.1; else if (ph0 >= 0.72 && ph0 < 0.92) { lift = -1; drag = (ph0 - 0.72) / 0.2; } else if (ph0 >= 0.92) { lift = -1 + (ph0 - 0.92) / 0.08; drag = 1 - (ph0 - 0.92) / 0.08; } }
    const sm = (x) => x * x * (3 - 2 * x), B = [px + pw + s * 0.42, by + s * 0.42], T = [px + pw - s * 0.72, by - s * 0.1 - sm(clamp(drag)) * ph * 0.12 + noise(t * 0.9, 9) * s * 0.03], K = [px + pw - s * 0.02, by + s * 0.02 - sm(clamp(drag)) * ph * 0.05];
    const N = 12, P = []; for (let i = 0; i <= N; i++) { const u = i / N; P.push([(1 - u) * (1 - u) * B[0] + 2 * (1 - u) * u * K[0] + u * u * T[0], (1 - u) * (1 - u) * B[1] + 2 * (1 - u) * u * K[1] + u * u * T[1]]); }
    const wd = (u) => s * (0.5 - 0.13 * u) * (1 + 0.06 * lift), sideP = (sgn) => P.map((p, i) => { const q = P[Math.min(N, i + 1)], r = P[Math.max(0, i - 1)], a = Math.atan2(q[1] - r[1], q[0] - r[0]); return [p[0] - Math.sin(a) * sgn * wd(i / N) / 2, p[1] + Math.cos(a) * sgn * wd(i / N) / 2]; });
    const L1 = sideP(1), L2 = sideP(-1), aT = Math.atan2(T[1] - P[N - 1][1], T[0] - P[N - 1][0]);
    if (lift < 0) { g.save(); g.globalAlpha *= 0.25 * -lift; g.beginPath(); g.ellipse(T[0] + s * 0.05, T[1] + s * 0.06, wd(1) * 0.55, wd(1) * 0.4, aT, 0, Math.PI * 2); g.fillStyle = '#000'; g.fill(); g.restore(); }   // bong ngon cai khi an xuong man hinh
    const TP = new Path2D(); TP.moveTo(L1[0][0], L1[0][1]); L1.forEach((p) => TP.lineTo(p[0], p[1])); TP.arc(T[0], T[1], wd(1) / 2, aT + Math.PI / 2, aT - Math.PI / 2, true); for (let i = N; i >= 0; i--) TP.lineTo(L2[i][0], L2[i][1]); TP.closePath();
    g.fillStyle = C.skin; g.fill(TP); g.save(); g.clip(TP); g.beginPath(); g.moveTo(L2[0][0], L2[0][1]); L2.forEach((p) => g.lineTo(p[0], p[1])); for (let i = N; i >= 0; i--) g.lineTo(P[i][0] * 0.55 + L2[i][0] * 0.45, P[i][1] * 0.55 + L2[i][1] * 0.45); g.closePath(); g.fillStyle = alpha(C.shade, 0.85); g.fill(); g.restore();
    const TS = new Path2D(); TS.moveTo(L1[0][0], L1[0][1]); L1.forEach((p) => TS.lineTo(p[0], p[1])); TS.arc(T[0], T[1], wd(1) / 2, aT + Math.PI / 2, aT - Math.PI / 2, true); for (let i = N; i >= 0; i--) TS.lineTo(L2[i][0], L2[i][1]);
    g.lineWidth = lw; g.strokeStyle = C.line; g.stroke(TS);   // 1.10: vien dung hinh ngon cai, bo mep goc (lien vao long ban tay, khong thanh "mieng dan")
    crease(g, P[6][0], P[6][1], aT, wd(0.5), C, lw); nailAt(g, T[0] - Math.cos(aT) * wd(1) * 0.28, T[1] - Math.sin(aT) * wd(1) * 0.28 - wd(1) * 0.08, aT, wd(1) * 0.58, wd(1) * 0.72, C, lw);
  }
  g.restore();
}
// tay cu (ban 1.3.0)
export function phoneHandClassic(g, px, py, pw, ph, side, part, o = {}) {
  // trai: 4 ngon tay om mep trai (co mong). phai: ngon cai cheo len man hinh + tay ao.
  const skin = o.skin || '#d9d6cf', ed = '#1b1c22', s = pw * 0.3, t = o.t || 0, lw = Math.max(2.5, s * 0.06);
  g.save(); g.lineWidth = lw; g.strokeStyle = ed; g.lineJoin = 'round';
  const nail = (x, y, w, h) => { g.beginPath(); g.roundRect(x, y, w, h, w * 0.3); g.fillStyle = '#ecebe6'; g.fill(); g.lineWidth = lw * 0.6; g.stroke(); g.lineWidth = lw; };
  if (side < 0 && part === 'front') {
    const fx0 = px - s * 0.45, fy0 = py + ph * (o.handY ?? 0.55);
    for (let i = 0; i < 4; i++) { const yy = fy0 + i * s * 0.5, ww = s * (0.95 - Math.abs(i - 1.2) * 0.08); g.beginPath(); g.roundRect(fx0, yy, ww, s * 0.48, s * 0.22); g.fillStyle = skin; g.fill(); g.stroke(); nail(fx0 + ww - s * 0.34, yy + s * 0.1, s * 0.24, s * 0.28); g.beginPath(); g.arc(fx0 + ww - s * 0.5, yy + s * 0.24, s * 0.08, -1, 1); g.lineWidth = lw * 0.5; g.stroke(); g.lineWidth = lw; }
  }
  if (side > 0 && part === 'front') {
    const tap = o.tap ? Math.max(0, Math.sin(t * 6)) * s * 0.15 : 0;
    const bx = px + pw + s * 0.55, by = py + ph * (o.thumbY ?? 0.8);
    if (o.sleeve) { g.save(); g.translate(bx + s * 0.3, by + s * 0.4); g.rotate(-0.55); g.beginPath(); g.roundRect(-s * 0.9, -s * 0.5, s * 3, s * 1.6, s * 0.3); g.fillStyle = o.sleeve; g.fill(); g.stroke(); g.lineWidth = lw * 0.5; for (let k = 0; k < 4; k++) { g.beginPath(); g.moveTo(-s * 0.7 + k * s * 0.18, -s * 0.45); g.lineTo(-s * 0.7 + k * s * 0.18, s * 0.2); g.stroke(); } g.restore(); g.lineWidth = lw; }
    g.save(); g.translate(bx - s * 0.2, by - s * 0.2 - tap); g.rotate(-0.42); g.scale(0.82, 0.82);
    g.beginPath(); g.moveTo(s * 0.5, s * 0.9); g.lineTo(-s * 1.9, s * 0.35); g.quadraticCurveTo(-s * 2.45, s * 0.3, -s * 2.45, -s * 0.15); g.quadraticCurveTo(-s * 2.45, -s * 0.55, -s * 1.9, -s * 0.5); g.lineTo(s * 0.5, -s * 0.35); g.closePath();
    const gr = g.createLinearGradient(0, -s * 0.5, 0, s * 0.6); gr.addColorStop(0, '#e4e8f2'); gr.addColorStop(1, skin); g.fillStyle = gr; g.fill(); g.stroke();
    nail(-s * 2.3, -s * 0.35, s * 0.42, s * 0.52); g.lineWidth = lw * 0.5; g.beginPath(); g.moveTo(-s * 1.2, -s * 0.3); g.lineTo(-s * 1.2, -s * 0.05); g.moveTo(-s * 1.1, -s * 0.28); g.lineTo(-s * 1.1, -s * 0.1); g.stroke();
    g.restore();
  }
  g.restore();
}
