"""do_nhip.py — do nhip / chuyen dong cua video theo cach giam khao cham (2.0), de tu kiem truoc khi giao.
  python tools/do_nhip.py <video.mp4> [--project projects/<ten>] [--json out.json]
Chi so (anh xam 320x180, 30 fps):
  mean_motion        do khac trung binh giua 2 khung lien tiep (0..255)          nghiem thu >= 1.2   (phim tham khao 1.7–2.0)
  big_changes_per_s  so cum khung co do khac >= 1.5 / giay                        nghiem thu >= 0.6   (phim tham khao 0.7–1.0)
  dup_frame_ratio    ti le khung gan trung (do khac < 0.03)
  longest_frozen_s   doan gan trung dai nhat, KHONG tinh man chu den / the ket (--project)   nghiem thu <= 1.0
  near_black_ratio   ti le khung toi gan den (do sang TB < 12)                    nghiem thu <= 0.10
  static_ge2s_at_s   cac doan dung yen >= 2 giay ngoai man chu den / the ket      nghiem thu: khong co
Tra ma 1 neu chua dat nghiem thu.
"""
import argparse, json, os, subprocess, sys
import numpy as np

ap = argparse.ArgumentParser(); ap.add_argument("video"); ap.add_argument("--project"); ap.add_argument("--json")
a = ap.parse_args()
W, H, FPS = 320, 180, 30
raw = subprocess.run(["ffmpeg", "-v", "error", "-i", a.video, "-an", "-vf", f"fps={FPS},scale={W}:{H},format=gray", "-f", "rawvideo", "-"], capture_output=True).stdout
F = np.frombuffer(raw, np.uint8).reshape(-1, H, W).astype(np.float32)
n = len(F); d = np.abs(np.diff(F, axis=0)).mean((1, 2)); lum = F.mean((1, 2))
# man chu den / the ket (duoc giu yen) tu shots.json
cards = []
if a.project:
    try:
        S = json.load(open(os.path.join(a.project, "story", "shots.json"), encoding="utf-8"))
        cards = [(s["start"], s["end"]) for s in S.get("shots", []) if s.get("tpl") in ("black", "card")]
    except Exception: pass
in_card = lambda t: any(s - 0.05 <= t < e + 0.05 for s, e in cards)
big = d >= 1.5; ev = int((big[1:] & ~big[:-1]).sum() + (big[0] if len(big) else 0))
runs, run, run0 = [], 0, 0
for i, v in enumerate(d):
    if v < 0.03 and not in_card(i / FPS):
        if run == 0: run0 = i
        run += 1
    else:
        if run: runs.append((run0 / FPS, run / FPS))
        run = 0
if run: runs.append((run0 / FPS, run / FPS))
dur = n / FPS
res = {
    "duration_s": round(dur, 2), "mean_motion": round(float(d.mean()), 3), "big_changes_per_s": round(ev / dur, 2),
    "dup_frame_ratio": round(float((d < 0.03).mean()), 3), "longest_frozen_s": round(max([r[1] for r in runs] or [0]), 2),
    "near_black_ratio": round(float((lum < 12).mean()), 3), "static_ge2s_at_s": [round(s, 1) for s, l in runs if l >= 2],
}
acc = {"mean_motion": res["mean_motion"] >= 1.2, "big_changes_per_s": res["big_changes_per_s"] >= 0.6, "longest_frozen_s": res["longest_frozen_s"] <= 1.0,
       "near_black_ratio": res["near_black_ratio"] <= 0.10, "static_ge2s_scenes": not res["static_ge2s_at_s"]}
res["acceptance"] = {k: ("DAT" if v else "CHUA DAT") for k, v in acc.items()}
print(json.dumps(res, ensure_ascii=False, indent=1))
if a.json: open(a.json, "w", encoding="utf-8").write(json.dumps(res, ensure_ascii=False, indent=1))
sys.exit(0 if all(acc.values()) else 1)
