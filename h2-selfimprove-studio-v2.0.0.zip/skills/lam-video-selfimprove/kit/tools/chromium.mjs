// chromium.mjs — tim va mo Chromium chay ngam (render.mjs dung chung). Kiem tra: node tools/chromium.mjs --check
// Thu tu: bien H2_CHROMIUM (duong dan file chrome) -> Chromium Playwright tu tim -> quet thu muc da tai
// (PLAYWRIGHT_BROWSERS_PATH, thu muc mac dinh cua Playwright): chromium-*/chrome-linux64 | chrome-linux | chrome-win64 | chrome-win | chrome-mac*,
// cuoi cung ban headless shell (chromium_headless_shell-*). Ban moi hon thu truoc.
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { pathToFileURL } from 'node:url';
import { chromium } from 'playwright';

const FULL = ['chrome-linux64/chrome', 'chrome-linux/chrome', 'chrome-win64/chrome.exe', 'chrome-win/chrome.exe',
  'chrome-mac-arm64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing', 'chrome-mac-x64/Google Chrome for Testing.app/Contents/MacOS/Google Chrome for Testing',
  'chrome-mac/Chromium.app/Contents/MacOS/Chromium'];
const SHELL = ['chrome-headless-shell-linux64/chrome-headless-shell', 'chrome-linux/headless_shell', 'chrome-headless-shell-win64/chrome-headless-shell.exe', 'chrome-win/headless_shell.exe',
  'chrome-headless-shell-mac-arm64/chrome-headless-shell', 'chrome-headless-shell-mac-x64/chrome-headless-shell', 'chrome-mac/headless_shell'];

export function browserDirs() {
  const home = os.homedir(), env = process.env.PLAYWRIGHT_BROWSERS_PATH, out = [];
  if (env && env !== '0') out.push(env);
  out.push(process.platform === 'win32' ? path.join(process.env.LOCALAPPDATA || path.join(home, 'AppData', 'Local'), 'ms-playwright')
    : process.platform === 'darwin' ? path.join(home, 'Library', 'Caches', 'ms-playwright') : path.join(process.env.XDG_CACHE_HOME || path.join(home, '.cache'), 'ms-playwright'));
  return [...new Set(out)].filter((d) => fs.existsSync(d));
}
// moi file chrome tim thay: ban day du truoc ban headless shell, so hieu ban lon truoc
export function findChromium() {
  const full = [], shell = [], rev = (d) => +d.split('-').pop() || 0;
  for (const base of browserDirs()) {
    const dirs = fs.readdirSync(base).filter((d) => /^chromium(_headless_shell)?-\d+$/.test(d)).sort((a, b) => rev(b) - rev(a));
    for (const d of dirs) {
      const hs = d.startsWith('chromium_headless_shell');
      for (const rel of hs ? SHELL : FULL) { const p = path.join(base, d, ...rel.split('/')); if (fs.existsSync(p)) (hs ? shell : full).push(p); }
    }
  }
  return [...full, ...shell];
}
export let usedExe = null;
export async function launchChromium(opts = {}) {
  const own = process.env.H2_CHROMIUM;
  if (own) {
    if (!fs.existsSync(own)) throw new Error('H2_CHROMIUM tro toi file khong ton tai: ' + own);
    usedExe = own; return chromium.launch({ ...opts, executablePath: own });
  }
  try { const b = await chromium.launch(opts); usedExe = 'Playwright mac dinh'; return b; }
  catch (e) {
    for (const exe of findChromium()) { try { const b = await chromium.launch({ ...opts, executablePath: exe }); usedExe = exe; return b; } catch {} }
    throw new Error('Chua co Chromium. Chay: npx playwright install chromium\n' + e.message);
  }
}

// node tools/chromium.mjs --check : mo thu Chromium roi dong. In "OK <file>" (ma thoat 0) hoac "THIEU <ly do>" (ma thoat 1)
if (process.argv[1] && import.meta.url === pathToFileURL(path.resolve(process.argv[1])).href) {
  try {
    const b = await launchChromium({ args: ['--disable-dev-shm-usage'] });
    const v = b.version(); await b.close();
    const def = chromium.executablePath(), shown = usedExe !== 'Playwright mac dinh' ? usedExe : fs.existsSync(def) ? def : (findChromium().find((p) => /headless/i.test(p)) || def);   // cai gon: chi co ban rut gon
    console.log(`OK ${shown} (Chromium ${v})`);
  } catch (e) { console.log('THIEU ' + String(e.message).split('\n')[0]); process.exitCode = 1; }
}
