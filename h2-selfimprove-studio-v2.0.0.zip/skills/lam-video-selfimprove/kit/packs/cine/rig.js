// rig.js — nhan vat 3D kieu 2.5D minh hoa: dau tron toi, vien sang manh, mat sang nho + long may sang, khong mieng.
// Co khop (hong, than, co, dau, vai, khuyu, co tay, dui, goi), tho, chop mat co seed, follow-through (dau, mu hoodie, duoi bang do tre nhip than).
// Dung lai ngu phap shots.json cua bo 2D: who, pose / poseAt / poseDur, face / faceAt / faceDur, facing / facingAt, hold, at / out, walk, act...
// -> tu the 2D (poseNow cua packs/dem) duoc doi sang goc khop 3D, nen kich ban cu khong phai viet lai.
import { THREE, mat, rimMat, col, blink, fbm1, quant } from '/engine/cine/index.js';
import { poseNow, faceNow, facingNow } from '/packs/dem/templates.js';
import { E, clamp, lerp } from '/engine/core.js';

const ACC = { red: '#ff3b3b', pink: '#ff4fa3', amber: '#ffb03b', teal: '#38d1c4' };
export const accent = () => ACC[E.cfg.accent] || E.cfg.accent || ACC.red;
const SKIN = '#15161c';
// trang phuc KHOA theo nhan vat suot phim (ti le giong nhau moi canh). top: mau ao; hood: mu hoodie ha sau co; band: bang do mau nhan
export const CAST3 = {
  hero:    { top: '#2c3240', pants: '#262a33', shoes: '#cfd4de', rim: '#a9c2ff', ink: '#f4f6fb' },
  // mau ao dam, phang (nhu phim tham khao): duoi anh den xanh van giu sac do, khong bac thanh tim nhat
  hoodie:  { top: '#2e5b52', hood: true, pants: '#23262e', shoes: '#cfd4de', rim: '#a9c2ff', ink: '#f4f6fb' },
  hooded:  { top: '#2e5b52', hood: 'up', pants: '#23262e', shoes: '#cfd4de', rim: '#a9c2ff', ink: '#f4f6fb' },
  band:    { top: '#d9dde6', band: true, pants: '#262a33', shoes: '#cfd4de', rim: '#ffe2c0', ink: '#f4f6fb' },
  friend:  { top: '#c98a3a', cap: '#e8b33c', pants: '#2f3340', shoes: '#e6e6e6', rim: '#ffe2b0', ink: '#ffc96b' },
  friend2: { top: '#3e6ea8', cap: '#4d8cff', pants: '#2f3340', shoes: '#e6e6e6', rim: '#cfe0ff', ink: '#9fd0ff' },
  friend3: { top: '#8a3a3a', cap: '#d64545', pants: '#2f3340', shoes: '#e6e6e6', rim: '#ffd0c0', ink: '#ff9f8a' },
  girl:    { top: '#6c7fa8', hair: 'bob', scarf: '#e8b33c', pants: '#2b2f3c', shoes: '#e9e2d6', rim: '#ffe2c0', ink: '#ffd9a0' },
  mom:     { top: '#7b6a8a', hair: 'bun', pants: '#3a3340', shoes: '#ddd', rim: '#ffe2c0', ink: '#d9c2ff' },
  dad:     { top: '#4d5a6e', pants: '#2a2e36', shoes: '#ddd', rim: '#dfe8ff', ink: '#9fd0ff' },
  kid:     { top: '#5f8f5a', pants: '#2f3340', shoes: '#eee', rim: '#e8ffe0', ink: '#c8f0b0', kid: true },
  voice:   { voice: true },
};
// bieu cam khong mieng: mo mat, nghieng mat (+ = duoi mat cup xuong), nang may (m), goc may (+ = dau trong nhuong len: buon / lo), cui dau (rad), liec [x, y]
const F3 = {
  neutral: [1, 0, 0, 0, 0], tired: [0.45, 0.05, -0.005, 0.05, 0.1], sleepy: [0.3, 0, -0.008, 0, 0.12], sleep: [0.04, 0, -0.01, 0, 0.1],
  sad: [0.75, 0.15, 0.004, 0.35, 0.18], cry: [0.6, 0.2, 0.008, 0.45, 0.2], worried: [0.95, 0.1, 0.01, 0.4, 0.05], scared: [1.25, 0, 0.02, 0.3, 0],
  shock: [1.35, 0, 0.028, 0.1, -0.05], angry: [0.8, -0.2, -0.012, -0.45, 0.02], determined: [0.85, -0.1, -0.006, -0.25, -0.02], effort: [0.55, -0.1, -0.01, -0.35, 0.05],
  smile: [0.55, -0.05, 0.008, 0.1, -0.02], happy: [0.5, 0, 0.012, 0.15, -0.05], smirk: [0.7, 0, 0.004, -0.15, 0], empty: [0.7, 0, -0.004, 0, 0.08],
  guilty: [0.7, 0.12, 0.004, 0.3, 0.22], bloodshot: [0.55, 0.05, -0.004, 0.1, 0.08], haunted: [1.0, 0.05, 0.006, 0.25, 0.05], grin: [0.6, -0.35, -0.01, -0.5, 0.05],
  hopeful: [1.05, 0, 0.014, 0.2, -0.12], relieved: [0.45, 0.05, 0.008, 0.15, -0.05], proud: [0.75, -0.05, 0.006, 0, -0.12], embarrassed: [0.7, 0.1, 0.006, 0.3, 0.2],
  disgusted: [0.6, -0.1, -0.008, -0.3, 0.02], annoyed: [0.6, -0.15, -0.008, -0.35, 0], skeptical: [0.8, 0, 0.006, -0.1, 0], exhausted: [0.35, 0.15, -0.006, 0.2, 0.15],
  yawn: [0.2, 0, 0.01, 0.2, -0.08], dazed: [0.6, 0, 0, 0, 0.06], panic: [1.3, 0, 0.026, 0.45, 0], sob: [0.35, 0.2, 0.01, 0.5, 0.22],
  shout: [0.9, -0.15, -0.01, -0.4, -0.05], thinking: [0.85, 0, 0.012, 0.1, -0.1], tempted: [0.6, 0, 0, 0.05, 0.06], grit: [0.6, -0.15, -0.012, -0.4, 0.04], lonely: [0.8, 0.12, 0.004, 0.25, 0.18],
};
export const FACES3 = Object.keys(F3);
const faceVec = (f) => F3[f] || F3.neutral;
const ANX = ['scared', 'worried', 'panic', 'cry', 'sob', 'shock', 'embarrassed'];

// ---------- dung khung nguoi (don vi m, cao chuan 1.6; scale theo h)
function limb(len, r, m, rim) {
  const g = new THREE.Group(), mesh = new THREE.Mesh(new THREE.CapsuleGeometry(r, Math.max(0.01, len - 2 * r), 4, 12), m);
  mesh.position.y = -len / 2; mesh.castShadow = true; mesh.receiveShadow = true; if (rim) mesh.add(new THREE.Mesh(mesh.geometry, rim)); g.add(mesh); return g;
}
export function buildRig(who = 'hero', o = {}) {
  const C = { ...(CAST3[who] || CAST3.hero), ...(o.outfit || {}) }, V = !!C.voice, acc = accent();
  const skin = mat(V ? '#050507' : SKIN, { bands: 3, shadow: 0.55 }), top = mat(V ? '#050507' : C.top), pants = mat(V ? '#050507' : C.pants), shoes = mat(V ? '#050507' : C.shoes);
  // vien sang: quan ao chi vien rat manh (giu mau ao), dau + tay vien ro hon; bong den: vien mau nhan, than van den dac
  const rim = rimMat(V ? acc : (o.rim || C.rim), { strength: V ? 0.55 : 0.28, power: V ? 3.8 : 5.5 });
  const root = new THREE.Group(); root.name = 'actor:' + who;
  const body = new THREE.Group(); root.add(body);                          // body: nhun / tho / ha hong
  const hips = new THREE.Group(); hips.position.y = 0.77; body.add(hips);
  const spine = new THREE.Group(); hips.add(spine);
  const torso = new THREE.Mesh(new THREE.CapsuleGeometry(0.165, 0.27, 6, 18), top); torso.position.y = 0.28; torso.scale.set(1, 1, 0.82); torso.castShadow = true; torso.add(new THREE.Mesh(torso.geometry, rim)); spine.add(torso);
  const neck = new THREE.Group(); neck.position.y = 0.53; spine.add(neck);
  const head = new THREE.Group(); head.position.y = 0.2; neck.add(head);
  const skull = new THREE.Mesh(new THREE.SphereGeometry(0.2, 40, 28), skin); skull.castShadow = true; skull.add(new THREE.Mesh(skull.geometry, rimMat(V ? acc : (o.rim || C.rim), { strength: V ? 0.65 : 0.6, power: 4 }))); head.add(skull);
  // mat: hinh bau duc sang (khong nhan anh sang), dat tren mat cau; long may: thanh manh sang
  const eyeM = new THREE.MeshBasicMaterial({ color: col(V ? acc : '#f1f3f8') }), browM = new THREE.MeshBasicMaterial({ color: col(V ? acc : '#c9cfdf') });
  const eyes = [], brows = [];
  for (const s of [-1, 1]) {
    const piv = new THREE.Group(); piv.rotation.y = s * 0.36; head.add(piv);
    const e = new THREE.Mesh(new THREE.SphereGeometry(0.034, 16, 12), eyeM); e.position.set(0, 0.0, 0.192); e.scale.set(1, 1.3, 0.3); piv.add(e); eyes.push({ piv, e, s });
    const bp = new THREE.Group(); bp.rotation.y = s * 0.34; head.add(bp);
    const b = new THREE.Mesh(new THREE.CapsuleGeometry(0.009, 0.05, 2, 6), browM); b.rotation.z = Math.PI / 2; b.position.set(0, 0.085, 0.178); bp.add(b); brows.push({ bp, b, s });
  }
  // phu kien theo nhan vat
  let tails = null;
  if (C.hood) {
    const hm = mat(C.top);
    if (C.hood === 'up') { const h = new THREE.Mesh(new THREE.SphereGeometry(0.225, 28, 20, 0, Math.PI * 2, 0, Math.PI * 0.62), hm); h.rotation.x = -0.35; h.position.set(0, 0.01, -0.02); head.add(h); }
    else { const h = new THREE.Mesh(new THREE.TorusGeometry(0.11, 0.055, 16, 36), hm); h.rotation.x = 1.25; h.position.set(0, 0.5, -0.1); h.castShadow = true; spine.add(h); }
  }
  if (C.band) {
    const bm = mat(acc), band = new THREE.Mesh(new THREE.TorusGeometry(0.2, 0.022, 8, 40), bm); band.rotation.x = Math.PI / 2 - 0.1; band.position.y = 0.07; head.add(band);
    tails = new THREE.Group(); tails.position.set(0, 0.06, -0.2); head.add(tails);
    for (const s of [-1, 1]) { const t = new THREE.Mesh(new THREE.BoxGeometry(0.035, 0.14, 0.01), bm); t.position.set(s * 0.03, -0.07, 0); t.rotation.z = s * 0.15; tails.add(t); }
  }
  if (C.cap) { const cm = mat(C.cap); const cap = new THREE.Mesh(new THREE.SphereGeometry(0.206, 28, 14, 0, Math.PI * 2, 0, Math.PI * 0.45), cm); cap.position.y = 0.02; head.add(cap); const brim = new THREE.Mesh(new THREE.CylinderGeometry(0.15, 0.15, 0.015, 24, 1, false, -Math.PI / 2, Math.PI), cm); brim.position.set(0, 0.07, 0.14); brim.rotation.x = 0.1; head.add(brim); }
  if (C.hair === 'bob') { const hm2 = mat('#3a2a22'); const hr = new THREE.Mesh(new THREE.SphereGeometry(0.215, 28, 20, 0, Math.PI * 2, 0, Math.PI * 0.62), hm2); hr.rotation.x = -0.25; head.add(hr); }
  if (C.hair === 'bun') { const hm2 = mat('#2a2220'); const bun = new THREE.Mesh(new THREE.SphereGeometry(0.08, 16, 12), hm2); bun.position.set(0, 0.17, -0.12); head.add(bun); }
  if (C.scarf) { const sc = new THREE.Mesh(new THREE.TorusGeometry(0.12, 0.045, 10, 24), mat(C.scarf)); sc.rotation.x = Math.PI / 2; sc.position.y = 0.52; spine.add(sc); }
  // tay: vai -> khuyu -> ban tay (cau)
  const arm = (s) => {
    const sh = new THREE.Group(); sh.position.set(s * 0.19, 0.46, 0); spine.add(sh);
    const up = limb(0.27, 0.048, top, rim); sh.add(up);
    const el = new THREE.Group(); el.position.y = -0.27; up.add(el);
    const lo = limb(0.25, 0.042, top, rim); el.add(lo);
    const hand = new THREE.Mesh(new THREE.SphereGeometry(0.048, 14, 10), skin); hand.position.y = -0.27; hand.castShadow = true; hand.add(new THREE.Mesh(hand.geometry, rim)); lo.add(hand);
    return { sh, el, hand };
  };
  const leg = (s) => {
    const hp = new THREE.Group(); hp.position.set(s * 0.085, 0, 0); hips.add(hp);
    const th = limb(0.36, 0.06, pants, rim); hp.add(th);
    const kn = new THREE.Group(); kn.position.y = -0.36; th.add(kn);
    const sh = limb(0.36, 0.052, pants, rim); kn.add(sh);
    const ft = new THREE.Mesh(new THREE.CapsuleGeometry(0.045, 0.09, 4, 10), shoes); ft.rotation.x = Math.PI / 2; ft.position.set(0, -0.37, 0.04); ft.castShadow = true; sh.add(ft);
    return { hp, kn };
  };
  const R = { r: arm(1), l: arm(-1) }, L = { r: leg(1), l: leg(-1) };
  // do cam tay: dien thoai (man hinh phat sang)
  let phone = null;
  if (o.hold === 'phone') {
    phone = new THREE.Group(); phone.position.set(-0.04, -0.03, 0.05); R.r.hand.add(phone);
    const pb = new THREE.Mesh(new THREE.BoxGeometry(0.075, 0.15, 0.01), mat('#16171c')); phone.add(pb);
    const sc = new THREE.Mesh(new THREE.PlaneGeometry(0.066, 0.138), new THREE.MeshBasicMaterial({ color: col(o.screen || '#bcd4ff'), fog: false })); sc.position.z = 0.0055; phone.add(sc);
  }
  const s = (o.h ?? (C.kid ? 1.1 : V ? 1.85 : 1.6)) / 1.6; root.scale.setScalar(s);
  return { who, C, root, body, hips, spine, neck, head, eyes, brows, R, L, tails, phone, scale: s, voice: V };
}

// ---------- doi tu the 2D (goc tuyet doi trong mat phang nghieng) sang goc khop 3D
// p.aF / p.aB: [canh tay, cang tay] (0 = thang xuong, + = ve phia truoc); lF / lB: [dui, cang chan]; lean: cui than; drop: ha hong (% chieu cao); head: [dx, dy]
const SIT = (p) => (p.lF?.[0] ?? 0) > 1.15 && (p.drop ?? 0) >= 10 && (p.drop ?? 0) < 20;
export function applyPose(rg, p, o = {}) {
  const ab = (u) => 0.1 + clamp((Math.abs(u) - 1.6) / 1.2) * 0.45;   // tay gio cao -> dang ra (khong xuyen qua dau)
  for (const [side, key, sg] of [['r', 'aF', 1], ['l', 'aB', -1]]) {
    const [u, f] = p[key] || [0, 0], A = rg.R[side];
    A.sh.rotation.set(-u, 0, sg * ab(u)); A.el.rotation.set(-(f - u), 0, 0);
  }
  for (const [side, key] of [['r', 'lF'], ['l', 'lB']]) { const [t, sh] = p[key] || [0, 0], G = rg.L[side]; G.hp.rotation.set(-t, 0, 0); G.kn.rotation.set(-(sh - t), 0, 0); }
  rg.spine.rotation.x = (p.lean || 0) * 0.9;
  const sit = SIT(p);
  rg.hips.position.y = sit ? 0.77 : 0.77 - (p.drop || 0) / 100 * 1.6 * 0.55;
  return sit;
}

// ---------- vi tri: so 0..1 (ngang phong) | moc boi canh ('bed.sit', 'desk.seat', 'bed.head', 'chair', ...) | [x, y, z]
const ANCH = { 'bed.sit': 'bedSit', 'bed.head': 'bedHead', 'desk.seat': 'deskSeat', 'desk': 'deskSeat', 'chair': 'deskSeat', 'clock': 'clock', 'window': 'window', 'poster': 'poster' };
export function place(A, x, o = {}) {
  if (Array.isArray(x)) return x.slice();
  if (typeof x === 'string' && A[ANCH[x] || x]) { const p = A[ANCH[x] || x]; return Array.isArray(p) ? p.slice() : [0, 0, 0]; }
  const R = A.room || { x0: -2, x1: 2 }, k = typeof x === 'number' ? (x > 1.5 ? x / 1920 : x) : 0.5;
  return [lerp(R.x0 + 0.6, R.x1 - 0.6, k), 0, o.z ?? A.stageZ ?? 0.3];
}

// ---------- 1 dien vien trong canh: a = actor trong shots.json; A = anchors cua boi canh
export function actor(a, A, o = {}) {
  const rg = buildRig(a.who || 'hero', { hold: a.hold, screen: a.screen, h: a.h > 0.2 && a.h < 1 ? undefined : a.h, rim: o.rim });
  const base = place(A, a.x, { z: a.z }); rg.base = base;
  const seed = (a.seed ?? Math.round((base[0] + 3) * 17 + (base[2] + 3) * 7)) + 1;
  const f0 = a.facing ?? 1;
  // huong mat: facing 1 = nhin sang phai man hinh (+x), hoi xoay ve phia may (3/4)
  const yawOf = (f) => (typeof a.face3 === 'number' ? a.face3 : f * (Math.PI / 2 - 0.55));
  const walks = [].concat(a.walk && a.walk.to !== undefined ? a.walk : a.walk || [], a.run && a.run.to !== undefined ? { ...a.run, run: true } : []).filter((w) => w && w.to !== undefined);
  let lastSit = false;
  const st = {
    rg, who: rg.who, a, seed, voice: rg.voice,
    update(lt, gt) {
      const tq = a.onTwos ? quant(lt, 12) : lt;   // nhan vat phu: 12 fps co chu dich
      const vis = (a.at === undefined || lt >= a.at) && (a.out === undefined || lt < a.out);
      rg.root.visible = vis; if (!vis) return;
      const p = poseNow(tq, a.poseAt, a.pose || 'stand', a.poseDur), ph = poseNow(tq, a.poseAt, a.pose || 'stand', a.poseDur, 0.09);   // ph: dau tre nhip (follow-through)
      const sit = applyPose(rg, p); lastSit = sit;
      // vi tri + di bo (quang duong -> nhip buoc, chan khong truot)
      let pos = base.slice(), moving = 0, dir = 0, dist = 0;
      for (const w of walks) {
        const to = place(A, w.to, { z: base[2] }), t0 = w.at ?? 0, d = w.dur ?? 3, k = clamp((tq - t0) / d), e = k < 0.5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2;
        if (tq >= t0) { const from = pos.slice(); pos = from.map((v, i) => lerp(v, to[i], e)); dist += Math.hypot(to[0] - from[0], to[2] - from[2]) * e; if (k < 1) { moving = w.run ? 2 : 1; dir = Math.atan2(to[0] - from[0], to[2] - from[2]); } }
      }
      rg.root.position.set(pos[0], sit ? pos[1] - 0.77 * rg.scale : pos[1], pos[2]);
      const fc = facingNow(tq, a.facingAt, f0, a.turnDur ?? 0.3);
      rg.root.rotation.y = moving ? dir : yawOf(fc.f) + (a.yaw || 0);
      if (moving) {
        const ph2 = dist / (moving === 2 ? 0.55 : 0.32) * Math.PI, sw = Math.sin(ph2) * (moving === 2 ? 0.7 : 0.42);
        rg.L.r.hp.rotation.x = -sw; rg.L.l.hp.rotation.x = sw; rg.L.r.kn.rotation.x = Math.max(0, Math.sin(ph2 + 1.2)) * 0.8; rg.L.l.kn.rotation.x = Math.max(0, Math.sin(ph2 + 1.2 + Math.PI)) * 0.8;
        rg.R.r.sh.rotation.x = sw * 0.7; rg.R.l.sh.rotation.x = -sw * 0.7; rg.R.r.el.rotation.x = -0.35; rg.R.l.el.rotation.x = -0.35;
        rg.body.position.y = Math.abs(Math.cos(ph2)) * (moving === 2 ? 0.05 : 0.02); rg.spine.rotation.x += moving === 2 ? 0.25 : 0.05;
      } else rg.body.position.y = 0;
      // tho (nguc phong / vai nang), lo lang thi tho nhanh; dung yen thi don trong tam rat nhe (khong dung hinh)
      const F = faceNow(tq, a.faceAt, a.face || (rg.voice ? 'grin' : 'neutral'), a.faceDur);
      const anx = ANX.includes(F.face) || a.pant, br = Math.sin(lt * 2 * Math.PI / (anx ? 1.6 : 3.8));
      rg.spine.scale.set(1 + br * 0.006, 1 + br * 0.012, 1 + br * 0.01); rg.R.r.sh.position.y = rg.R.l.sh.position.y = 0.46 + br * 0.006;
      if (a.idle !== false && !moving) { rg.hips.rotation.z = fbm1(gt * 0.23, seed) * 0.02; rg.spine.rotation.z = -fbm1(gt * 0.23, seed) * 0.015; }
      // mat: tron 2 bieu cam khi dang chuyen, chop mat (seed), liec
      const A0 = faceVec(F.fromFace || F.face), B0 = faceVec(F.face), fk = F.faceK ?? 1, fv = A0.map((v, i) => lerp(v, B0[i], fk));
      const bl = a.blink === false ? 0 : blink(lt, seed), open = Math.max(0.04, fv[0] * (1 - 0.95 * bl));
      for (const { e, s } of rg.eyes) { e.scale.y = 1.3 * open; e.position.y = (1 - Math.min(1, open)) * -0.012; e.rotation.z = -s * fv[1]; }   // fv[1] > 0: duoi mat (phia ngoai) cup xuong
      for (const { b, s } of rg.brows) { b.position.y = 0.085 + fv[2] + (1 - Math.min(1, open)) * -0.004; b.rotation.z = Math.PI / 2 - s * fv[3]; }
      // dau: cui theo bieu cam + tu the (tre nhip), lac rat nhe; nhan vat voice: nghieng ve phia nguoi hung
      const hd = ph.head || [0, 0];
      rg.neck.rotation.x = fv[4] + hd[1] * 0.035 + (sit ? 0.06 : 0) + (a.look3?.[1] ?? 0);
      rg.neck.rotation.y = (a.look ?? 0) * 0.4 + fbm1(gt * 0.31, seed + 4) * 0.03;
      rg.neck.rotation.z = fbm1(gt * 0.27, seed + 9) * 0.025 + (anx ? Math.sin(lt * 23) * 0.004 : 0);
      if (rg.tails) { const v = (p.lean || 0) - (ph.lean || 0); rg.tails.rotation.x = 0.25 + clamp(v * 6, -0.4, 0.6) + fbm1(gt * 0.9, seed) * 0.08; }
    },
    // diem tren the gioi: dau (tam), dinh dau, man hinh dien thoai
    headPos() { const v = new THREE.Vector3(); rg.head.getWorldPosition(v); return [v.x, v.y, v.z]; },
    headTop() { const v = new THREE.Vector3(0, 0.24, 0); rg.head.localToWorld(v); return [v.x, v.y, v.z]; },
    phonePos() { if (!rg.phone) return null; const v = new THREE.Vector3(); rg.phone.getWorldPosition(v); return [v.x, v.y, v.z]; },
    subject() { const hp = this.headPos(); return { at: [rg.root.position.x, lastSit ? rg.root.position.y + 0.77 * rg.scale - 0.5 : rg.root.position.y, rg.root.position.z], h: 1.6 * rg.scale, face: rg.root.rotation.y, head: hp }; },
  };
  return st;
}
