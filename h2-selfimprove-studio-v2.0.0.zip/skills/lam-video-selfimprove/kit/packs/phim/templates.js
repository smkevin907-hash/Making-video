// templates.js — mau canh cua bo "phim" (2D vector kieu dien anh), CUNG TEN + CUNG args voi legacy de shots.json tu phim.py dung ngay.
// Goc may: director (plan / planFilm dung chung ban 3D) + director2d.refine (tach goc ngan, moi goc co chuyen dong, luan phien goc).
// MOI CO KHUNG LA 1 BO CUC VE RIENG:
//   wide (toan: goc cao / ngang / thap, dolly / truck / nang may, tien canh toi nhoe) | push (trung -> can) | closeMain / face / faceSide (can mat, nen nhoe)
//   ots (qua vai bong den) | top (tu tren xuong nguoi nam) | pov / povClose (dien thoai + tay den) | otsPoster / insertPoster | insertClock / clockWide
//   void (man den: hien dan canh mo phia sau + chu troi) | cta (the keu goi)
// Boi canh: bedroom + noi that chung + ngoai troi (places.js) -> ca phim cung 1 kieu ve. Chi graph / note con ve kieu legacy.
import '/packs/dem/templates.js';
import { E, getTemplate, registerTemplate, clamp, lerp, ease } from '/engine/core.js';
import { renderLayers, camAt, post, glow, toScreen, rgba } from '/engine/flat/stage.js';
import { fbm1, rng } from '/engine/cine/timeline.js';
import { plan } from '/packs/cine/director.js';
import { bedroom, seg7 } from './sets.js';
import { interior, outdoor, stage, INTERIORS, OUTDOORS } from './places.js';
import { actor2d, puppet } from './puppet.js';
import { drawPhoneScreen, swipeAt, poster } from './screens.js';
import { layReset, drawTexts, drawHud, drawCard, LAY, SERIF, COMIC } from './ui2d.js';

const LEG = {}; for (const n of ['scene', 'phone', 'clock', 'calendar', 'face', 'black', 'card', 'cta', 'graph']) LEG[n] = getTemplate(n);
export const SETS2 = ['bedroom', ...INTERIORS, ...OUTDOORS, 'void'];
const ST = new Map();
function prevHud(info) { const i = E.shots.indexOf(info.shot); for (let k = i - 1; k >= 0; k--) { const h = E.shots[k].args && E.shots[k].args.hud; if (h) return h; } return null; }
const gv = (v, lt, g) => (Array.isArray(v) ? lerp(v[0], v[1], ease.inOut(clamp((lt - (g.at ?? 0)) / (g.dur ?? 1.5)))) : v);
function toneOf(a, start) {
  const sa = a.setArgs || {}, day = ['day', 'dawn'].includes(sa.sky) || sa.time === 'day' || ['dusk', 'day', 'dawn'].includes(sa.time);
  const mus = ((E.story && E.story.music) || []).find((m) => start >= m.start - 0.01 && start < m.end);
  return a.tone || (day ? (mus && ['hope', 'rise', 'resolve'].includes(mus.bed) ? 'hope' : 'day') : 'night');
}
function setFor(name, o) {
  if (INTERIORS.includes(name)) return interior({ ...o, kind: name });
  if (OUTDOORS.includes(name)) return outdoor({ ...o, kind: name });
  if (['void', 'none', 'black'].includes(name)) return stage(o);
  return bedroom(o);
}
const canvas = (w, h) => { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; };
const SCREEN = { x: 0, y: 0, z: 1, r: 0 }; SCREEN.x = 960; SCREEN.y = 540;

function build(kind, info) {
  const a = info.args || {}, sa = a.setArgs || {}, tone = toneOf(a, info.start), setName = a.set || a.bg || 'bedroom';
  const st = { kind, tone, setName, Rs: {}, actors: [], plan: (info.shot && info.shot.__plan) || plan(kind, a, info.dur) };
  st.getR = (angle = 'eye') => st.Rs[angle] || (st.Rs[angle] = setFor(setName, { key: info.shot.id, tone, angle, clock: sa.clock ?? a.time, laptop: sa.laptop, lamp: sa.lamp, doorOpen: sa.doorOpen }));
  st.cur = st.getR('eye');
  const place = Object.assign((x, lt) => st.cur.place(x, lt), { rim: -1, rimC: st.cur.place.rimC });
  // ai noi luc nao (de nhan vat co cu chi khi noi)
  const talk = (who) => (a.texts || []).filter((t) => (t.kind === 'say' && (t.who || 'hero') === who) || (t.kind === 'tempt' && who === 'voice')).map((t) => [t.at ?? 0.3, Math.min(2.4, t.dur ?? 2)]);
  const list = kind === 'face' ? [{ who: a.who || 'hoodie', x: 'bed.sit', pose: a.pose || 'stand', poseAt: a.poseAt, face: a.face, faceAt: a.faceAt, hold: a.hold, blink: a.blink, look: a.look }, ...(a.actors || [])]
    : kind === 'calendar' ? [{ who: a.who || 'hoodie', x: 'poster', pose: 'stand', face: a.face || 'tired', back: true }]
    : kind === 'phone' ? [{ who: a.who || 'hoodie', x: 'bed.sit', pose: 'sitphone', hold: 'phone', face: a.face || 'tempted', faceAt: a.faceAt }]
    : kind === 'cta' ? [{ who: a.who || 'hoodie', x: [0.1, 0, 4.8], pose: 'stand', poseAt: [[0.8, 'wave'], [2.6, 'stand']], face: 'smile', front: true }] : a.actors || [];
  for (const ac of list) st.actors.push(actor2d({ ...ac, talk: ac.talk || talk(ac.who === 'voice' ? 'voice' : ac.who), yaw: ac.yaw ?? (ac.who === 'voice' ? -0.45 : 0.4) }, place));
  st.main = st.actors.find((x) => !x.voice) || null; st.voice = st.actors.find((x) => x.voice) || null;
  if (st.voice && st.voice.a.keepX !== true && setName === 'bedroom') {   // bong den: phia sau-canh nguoi hung, ve giua phong
    const m = st.main ? st.main.a.x : 'bed.sit', A = st.cur.anchors[typeof m === 'string' ? m : 'center'] || st.cur.anchors.center;
    const dx = A.x > 0.3 ? -0.8 : 0.75; st.voice.a.x = [A.x + dx, 0, A.z + 0.55]; st.voice.a.yaw = dx > 0 ? -0.5 : 0.5;
  }
  if (a.bed) {
    st.bed = a.bed; st.bedFace = actor2d({ who: a.bed.who || 'hoodie', x: 'bed.sit', face: a.bed.face || 'sleep', faceAt: a.bed.faceAt }, place);
    if (a.bed.up) { const u = a.bed.up; st.upAt = u.at ?? info.dur * 0.5; const s = actor2d({ who: a.bed.who || 'hoodie', x: 'bed.sit', pose: u.pose || 'sit', face: u.face || a.bed.face || 'tired', faceAt: a.bed.faceAt, at: st.upAt, yaw: 0.4 }, place); st.actors.push(s); st.sitter = s; }
  }
  if (kind === 'phone') { st.scr = canvas(540, 1170); st.scrKey = ''; }
  if (kind === 'calendar') { st.P = poster(a, E); st.pc = canvas(1024, 1400); st.pKey = ''; }
  if (kind === 'black' || kind === 'card' || kind === 'cta') {   // man den: hien dan canh ke tiep (hoac truoc) rat mo phia sau
    const i = E.shots.indexOf(info.shot), nb = [E.shots[i + 1], E.shots[i - 1], E.shots[i + 2]].find((x) => x && x.tpl === 'scene') || null;
    st.bgR = setFor(nb ? (nb.args || {}).set || 'bedroom' : 'bedroom', { key: info.shot.id + ':bg', tone: nb ? toneOf(nb.args || {}, nb.start) : 'night', angle: 'eye' });
  }
  return st;
}
function subAt(P, lt, d) { let i = 0; while (i + 1 < P.length && lt >= P[i + 1].at) i++; return { i, p: P[i], at: P[i].at, dur: Math.max(0.1, (i + 1 < P.length ? P[i + 1].at : d) - P[i].at) }; }

// ---------- nguoi nam (dau tren goi)
function sleeperHead(g, R, st, lt, big) {
  const V = R.V, [hx, hy] = big ? [E.W * 0.5, E.H * 0.47] : V.p(-1.75, 0.6, 5.55), r = big ? E.H * 0.2 : V.k(5.55) * 0.18;
  st.bedFace.update(lt, lt); const fs = st.bedFace.st;
  g.save(); g.translate(hx, hy); g.rotate(big ? -0.35 : -0.15);
  g.fillStyle = R.P.rimC; g.beginPath(); g.arc(-r * 0.05, -r * 0.04, r, 0, 7); g.fill(); g.fillStyle = '#09090a'; g.beginPath(); g.arc(0, 0, r, 0, 7); g.fill();
  const fv = fs.face, open = Math.max(0.06, fv[0] * (1 - 0.94 * fs.blink));
  for (const s of [-1, 1]) { g.fillStyle = '#efe6d2'; g.beginPath(); g.ellipse(s * r * 0.38, r * 0.1, r * 0.1, Math.max(r * 0.012, r * 0.15 * open), 0, 0, 7); g.fill(); g.save(); g.translate(s * r * 0.38, -r * 0.22 - fv[2] * r); g.rotate(s * fv[3]); g.strokeStyle = '#8f9498'; g.lineWidth = r * 0.05; g.lineCap = 'round'; g.beginPath(); g.moveTo(-r * 0.14, 0); g.quadraticCurveTo(0, -r * 0.035, r * 0.14, 0); g.stroke(); g.restore(); }
  g.restore();
  return { who: 'sleeper', head: [hx, hy, r], box: [hx - r, hy - r, hx + r, hy + r * 1.5] };
}
function sleeperPl(R) { const V = R.V, [hx, hy] = V.p(-1.75, 0.6, 5.55), h = V.k(5.55) * 1.55; return { x: hx, y: hy + h * 0.5, h, anchor: 'hip', z: 5.55 }; }
// ---------- tay den (POV)
function povHand(g, x, y, s, from = [-0.15, 1.15], press = 0) {
  const bx = E.W * from[0], by = E.H * from[1], ang = Math.atan2(y - by, x - bx);
  const ex = x - Math.cos(ang) * s * 0.9, ey = y - Math.sin(ang) * s * 0.9, nx = -Math.sin(ang), ny = Math.cos(ang), w0 = s * 0.95, w1 = s * 0.5;
  g.save(); g.fillStyle = '#09090a'; g.beginPath(); g.moveTo(bx + nx * w0, by + ny * w0); g.lineTo(ex + nx * w1 / 2, ey + ny * w1 / 2); g.lineTo(ex - nx * w1 / 2, ey - ny * w1 / 2); g.lineTo(bx - nx * w0, by - ny * w0); g.closePath(); g.fill();
  g.strokeStyle = '#09090a'; g.lineCap = 'round';
  g.translate(x, y); g.rotate(ang); g.scale(1 - press * 0.06, 1);
  g.fillStyle = '#09090a'; g.beginPath(); g.ellipse(-s * 0.85, 0, s * 0.55, s * 0.4, 0, 0, 7); g.fill();
  g.lineWidth = s * 0.17; g.beginPath(); g.moveTo(-s * 0.5, -s * 0.1); g.lineTo(0, 0); g.stroke();
  for (const [dy, l] of [[0.16, 0.42], [0.3, 0.38], [0.42, 0.3]]) { g.beginPath(); g.moveTo(-s * 0.55, s * dy); g.lineTo(-s * 0.55 + s * l, s * (dy + 0.04)); g.stroke(); }
  g.beginPath(); g.moveTo(-s * 0.8, -s * 0.3); g.lineTo(-s * 0.48, -s * 0.38); g.stroke(); g.restore();
}
// ---------- tien canh toi nhoe o mep khung (I12): la cay | khung cua | lung ghe | cot den — che 8–15% khung, troi nhanh hon (p 1.35)
function fgOccluder(kind, side, seed) {
  // lop tinh (ve 1 lan, luu ban nhoe) -> khong ton CPU moi khung
  return { key: `fg:${kind}:${side}:${seed}`, p: 1.35, order: 3, blur: 12 * (E.H / 1080), draw: (x) => {
    const X = side < 0 ? 0 : E.W, s = side < 0 ? 1 : -1, r = rng(seed); x.fillStyle = '#0b0c0e';
    if (kind === 'plant') { for (let i = 0; i < 9; i++) { const ax = X + s * E.W * (0.02 + r() * 0.09), ay = E.H * (0.55 + r() * 0.45), a = -Math.PI / 2 + s * (r() - 0.3) * 1.4; x.save(); x.translate(ax, ay); x.rotate(a); x.beginPath(); x.ellipse(0, -E.H * 0.12, E.H * 0.035, E.H * 0.13, 0, 0, 7); x.fill(); x.restore(); } x.fillRect(X + s * E.W * 0.04 - (s < 0 ? 0 : E.W * 0.06), E.H * 0.9, E.W * 0.06, E.H * 0.1); }
    else if (kind === 'frame') { x.fillRect(side < 0 ? 0 : E.W - E.W * 0.075, -20, E.W * 0.075, E.H + 40); }
    else if (kind === 'chair') { const w = E.W * 0.13, xx = side < 0 ? -w * 0.2 : E.W - w * 0.8; x.beginPath(); x.roundRect(xx, E.H * 0.52, w, E.H * 0.55, 18); x.fill(); }
    else { x.fillRect(side < 0 ? E.W * 0.035 : E.W * 0.95, -20, E.W * 0.022, E.H + 40); }
  } };
}

// bui troi trong vet sang (that, nhin thay duoc): hat nho sang nhap nhay, troi cham len / ngang, vi tri la ham thuan cua t
function dustLayer(night, seed, box = [0.05, 0.1, 0.6, 0.85]) {
  return { key: 'dust', p: 1.05, order: 2.5, dyn: true, add: 'screen', draw: (x, lt) => {
    const r = rng(seed), [x0, y0, x1, y1] = box.map((v, i) => v * (i % 2 ? E.H : E.W));
    for (let i = 0; i < 70; i++) {
      const bx = r(), by = r(), sp = 0.4 + r(), ph = r() * 6.28, sz = 1.5 + r() * 2.8;
      const px = x0 + (((bx + lt * 0.012 * sp + Math.sin(lt * 0.4 + ph) * 0.01) % 1) + 1) % 1 * (x1 - x0), py = y0 + (((by - lt * 0.02 * sp) % 1) + 1) % 1 * (y1 - y0);
      x.fillStyle = night ? `rgba(190,205,255,${0.25 + 0.2 * Math.sin(lt * 2 + ph)})` : `rgba(255,240,215,${0.3 + 0.2 * Math.sin(lt * 2 + ph)})`;
      x.beginPath(); x.arc(px, py, sz, 0, 7); x.fill();
    }
  } };
}

// vet sang luot qua tuong phia sau (dem: den xe ngoai cua so; ngay: bong may) -> nen cua can canh khong dung im
function sweepLayer(night, seed) {
  return { key: 'sweep', p: 1, order: 1.8, dyn: true, add: 'screen', cam: { x: 960, y: 540, z: 1, r: 0 }, draw: (x, lt) => {
    const per = 4.2, k = (((lt + seed * 0.7) / per) % 1 + 1) % 1, cx = lerp(-0.35, 1.35, k) * E.W, w = E.W * 0.32;
    const gr = x.createLinearGradient(cx - w, 0, cx + w, 0), c = night ? '255,226,180' : '255,255,255', a = night ? 0.13 : 0.1;
    gr.addColorStop(0, `rgba(${c},0)`); gr.addColorStop(0.5, `rgba(${c},${a})`); gr.addColorStop(1, `rgba(${c},0)`);
    x.save(); x.transform(1, 0, -0.35, 1, 0, 0); x.fillStyle = gr; x.fillRect(cx - w + E.H * 0.2, -40, w * 2 + E.H * 0.4, E.H + 80); x.restore();
  } };
}

function draw(st, lt, info, g) {
  const a = info.args || {}, S = subAt(st.plan, lt, info.dur), p = S.p, role = p.role, slt = lt - S.at, gt = info.globalT, hand = p.hand ?? 0.3;
  layReset();
  st.cur = role === 'wide' ? st.getR(p.angle || 'eye') : st.getR('eye');
  const R = st.cur;
  for (const x of st.actors) x.update(lt, gt);
  st.lying = st.bed ? (st.sitter ? lt < st.upAt : true) : false;
  const boxes = [];
  const actorLayer = (cam) => ({ key: 'actors', p: 1, order: 2, dyn: true, cam, draw: (x) => {
    if (st.lying && role !== 'top') boxes.push(sleeperHead(x, R, st, lt, false));
    for (const ac of [...st.actors].sort((q1, q2) => (q2.pl?.z ?? 0) - (q1.pl?.z ?? 0))) {
      if (!ac.vis || (st.sitter === ac && st.lying)) continue;
      const pl = ac.pl;
      if (R.night) { x.save(); x.globalCompositeOperation = 'screen'; glow(x, pl.x, pl.y - pl.h * (pl.anchor === 'hip' ? 0.35 : 0.6), pl.h * 0.55, '#5a6a8a', 0.22); x.restore(); }   // sang nhe sau lung (I8): khoi den khong chim vao tuong
      if (pl.anchor !== 'hip') { x.fillStyle = 'rgba(0,0,0,0.3)'; x.beginPath(); x.ellipse(pl.x, pl.y + 2, pl.h * 0.15, pl.h * 0.024, 0, 0, 7); x.fill(); }
      const r = ac.draw(x); if (r) boxes.push({ who: ac.who, voice: ac.voice, head: r.head, box: r.box, cam, crop: role !== 'wide' && role !== 'manual' && ac !== mainAc });   // goc can: nguoi phu bi cat khoi khung la co y
    }
  } });
  const mainAc = st.sitter && !st.lying ? st.sitter : st.main, mainPl = mainAc?.pl || (st.lying ? sleeperPl(R) : R.place({ x: 'center' }));   // khong ai dung: may nham nguoi nam
  const headY = (pl) => pl.y - pl.h * (pl.anchor === 'hip' ? 0.5 : 0.78);
  let layers = [...R.layers], cam = { x: E.W / 2, y: E.H / 2, z: 1, r: 0 }, aperture = 0, extraPost = {};
  const mv = p.move;
  if (role === 'wide' || role === 'manual') {
    const cx = clamp(mainPl.x, E.W * 0.38, E.W * 0.62), cy = E.H * 0.5;
    const A = { x: cx, y: cy, z: 1 }, B = { x: cx, y: cy, z: 1.12 };
    if (mv === 'truck' || mv === 'pan') { A.x = cx - E.W * 0.06; B.x = cx + E.W * 0.06; A.z = 1.07; B.z = 1.1; }
    else if (mv === 'lowAngleRise' || mv === 'tilt') { A.y = cy + E.H * 0.045; B.y = cy - E.H * 0.03; A.z = 1.05; B.z = 1.12; }
    else if (mv === 'pullBack' || mv === 'dollyOut') { A.z = 1.13; B.z = 1.0; }
    // nhieu nguoi: canh giua ca nhom va gioi han do day de khong ai bi cat (toan canh phai thay du nguoi)
    const vis = st.actors.filter((q) => q.vis && q.pl && !(st.sitter === q && st.lying));
    if (vis.length > 1) {
      const x0 = Math.min(...vis.map((q) => q.pl.x - q.pl.h * 0.2)), x1 = Math.max(...vis.map((q) => q.pl.x + q.pl.h * 0.2)), zmax = Math.max(1, (E.W * 0.9) / Math.max(1, x1 - x0)), mx = (x0 + x1) / 2;
      for (const C of [A, B]) { C.z = Math.min(C.z, zmax); C.x = clamp(C.x + (mx - cx), mx - E.W * (0.5 - 0.45 / C.z) + E.W * 0, mx + E.W * (0.5 - 0.45 / C.z)); }
    }
    cam = camAt(slt, S.dur, { from: A, to: B, ease: 'cubic', hand, gt }); aperture = 1.4;
    layers.push(actorLayer(null));
    if (st.kind === 'scene' && !['hill', 'void', 'none', 'black'].includes(st.setName)) layers.push(fgOccluder(st.setName === 'street' || st.setName === 'city' ? 'lamp' : ['frame', 'chair', 'lamp'][(info.shot.id.length + S.i + E.shots.indexOf(info.shot)) % 3], (E.shots.indexOf(info.shot) + S.i) % 2 ? 1 : -1, E.shots.indexOf(info.shot) + 3));
  } else if (role === 'push') {
    const hy = headY(mainPl);
    cam = camAt(slt, S.dur, { from: { x: mainPl.x + E.W * 0.05, y: hy, z: 1.6 }, to: { x: mainPl.x + E.W * 0.02, y: hy, z: 2.05 }, ease: 'cubic', hand, gt }); aperture = 5;
    layers.push(actorLayer(null));
  } else if (role === 'ots') {
    const hy = headY(mainPl);
    cam = camAt(slt, S.dur, { from: { x: mainPl.x + E.W * 0.09, y: hy, z: 1.58 }, to: { x: mainPl.x + E.W * 0.03, y: hy, z: 1.78 }, ease: 'cubic', hand, gt }); aperture = 5;
    const vo = st.voice; layers.push({ ...actorLayer(null), draw: (x) => { for (const ac of st.actors) if (ac !== vo && ac.vis) { const r = ac.draw(x); if (r) boxes.push({ who: ac.who, voice: false, head: r.head, box: r.box, crop: ac !== mainAc }); } } });
    if (vo && vo.vis) layers.push({ key: 'fgv', p: 1.4, order: 3, dyn: true, blur: 7, cam: SCREEN, draw: (x) => { const r = puppet(x, E.W * 0.86 - slt * 6, E.H * 1.42, E.H * 1.25, { ...vo.st, yaw: Math.PI - 0.3 }); boxes.push({ who: 'voice', voice: true, head: r.head, box: r.box, fg: true }); } });
  } else if (role === 'face' || role === 'faceSide' || role === 'closeMain') {
    const side = role === 'faceSide', bg = { x: E.W * (side ? 0.6 : 0.38), y: E.H * 0.36, z: 2.3, r: 0 }; layers = R.layers.map((L) => ({ ...L, cam: bg, blur: 9 * (E.H / 1080) }));
    const m = role === 'closeMain' ? mainAc : st.actors[0], k = ease.inOut(clamp(slt / S.dur));
    if (m) { m.pl = { x: E.W * (side ? 0.4 : 0.5) + Math.sin(lt * 0.9) * E.W * 0.006, y: E.H * 1.43, h: E.H * 1.24, anchor: 'feet', z: 1 }; m.st.yaw = (side ? 0.5 : 0) + fbm1(lt * 0.35, 4) * 0.18; m.st.look = [fbm1(lt * 0.5, 8) * 1.2, fbm1(lt * 0.4, 9) * 0.5]; m.st.tilt = (m.st.tilt || 0) + Math.sin(lt * 0.7) * 0.05; m.st.pose = { aF: [0.05, 0.3], aB: [0.05, 0.3], lF: [0, 0], lB: [0, 0], lean: m.st.pose.lean, head: m.st.pose.head }; }   // can mat: mat liec, dau nghieng / quay nhe (dang nghi)
    if (st.kind === 'phone') layers.push({ key: 'scrglow', p: 1, order: 2.6, dyn: true, add: 'screen', cam: SCREEN, draw: (x) => glow(x, E.W * 0.52, E.H * 0.62, E.H * 0.55, '#9fbcff', 0.22 + Math.sin(lt * 5) * 0.03) });   // anh man hinh hat len mat
    const c = camAt(slt, S.dur, { from: { x: E.W / 2, y: E.H / 2, z: 1 }, to: { x: E.W / 2 + (side ? -70 : 50), y: E.H / 2 - 50, z: 1.22 }, ease: 'cubic', hand: hand * 0.7, gt });
    layers.push({ key: 'face', p: 1, order: 2, dyn: true, cam: c, draw: (x) => { if (m && m.vis) { const r = m.draw(x); boxes.push({ who: m.who, head: r.head, box: r.box, cam: c }); } } });
  } else if (role === 'top') {
    layers = [{ key: 'top', p: 1, dyn: true, draw: (x) => {
      const P = R.P; x.fillStyle = P.sheet; x.fillRect(-60, -60, E.W + 120, E.H + 120); x.fillStyle = 'rgba(0,0,0,0.12)'; for (let i = 0; i < 6; i++) x.fillRect(-60, E.H * (0.1 + i * 0.16), E.W + 120, 2);
      x.fillStyle = 'rgba(255,255,255,0.12)'; x.beginPath(); x.roundRect(E.W * 0.22, E.H * 0.18, E.W * 0.56, E.H * 0.5, 60); x.fill();
      x.fillStyle = P.blanket; x.beginPath(); x.moveTo(-60, E.H * 0.66); x.bezierCurveTo(E.W * 0.3, E.H * 0.6 + Math.sin(lt * 1.6) * 4, E.W * 0.7, E.H * 0.7, E.W + 60, E.H * 0.62); x.lineTo(E.W + 60, E.H + 60); x.lineTo(-60, E.H + 60); x.fill();
      boxes.push(sleeperHead(x, R, st, lt, true));
      if (R.night) { x.globalCompositeOperation = 'multiply'; x.fillStyle = 'rgba(70,80,120,0.85)'; x.fillRect(-60, -60, E.W + 120, E.H + 120); x.globalCompositeOperation = 'source-over'; }
    } }];
    cam = camAt(slt, S.dur, { from: { z: 1, r: -0.03 }, to: { z: 1.12, r: 0.015 }, ease: 'cubic', hand, gt });
  } else if (role === 'pov' || role === 'povClose') {   // I1: dolly 6% + lia 1–2 do + cam tay 0,3%
    const sw = swipeAt(lt, a), key = (a.screen || 'feed') + sw.n.toFixed(4) + Math.floor(lt * 30);
    if (key !== st.scrKey) { st.scrKey = key; const x = st.scr.getContext('2d'); x.setTransform(1, 0, 0, 1, 0, 0); x.clearRect(0, 0, 540, 1170); drawPhoneScreen(x, 540, 1170, lt, a); }
    const close = role === 'povClose';
    layers = [{ key: 'pov', p: 1, dyn: true, draw: (x) => {
      const night = R.night, base = night ? '#2c2e33' : '#8d9499';
      x.fillStyle = base; x.fillRect(-60, -60, E.W + 120, E.H + 120); x.fillStyle = 'rgba(0,0,0,0.08)'; for (let i = 0; i < 16; i++) x.fillRect(-60, i * E.H / 14 - 30, E.W + 120, 3);
      glow(x, E.W * 0.86, E.H * 0.12, E.H * 0.5, night ? '#9fb0d0' : '#ffffff', 0.12 + Math.sin(lt * 2.4) * 0.01);
      const pw = E.H * 0.39, ph = pw * 2.13, cx = E.W * 0.52, cy = E.H * 0.5;
      x.save(); x.translate(cx, cy); x.rotate(-0.06);
      x.fillStyle = 'rgba(0,0,0,0.35)'; x.filter = `blur(${14 * E.PX}px)`; x.beginPath(); x.roundRect(-pw / 2 + 14, -ph / 2 + 18, pw, ph, pw * 0.13); x.fill(); x.filter = 'none';
      x.fillStyle = '#121317'; x.beginPath(); x.roundRect(-pw / 2, -ph / 2, pw, ph, pw * 0.13); x.fill();
      x.save(); x.beginPath(); x.roundRect(-pw / 2 + pw * 0.04, -ph / 2 + pw * 0.04, pw * 0.92, ph - pw * 0.08, pw * 0.1); x.clip(); x.drawImage(st.scr, -pw / 2 + pw * 0.04, -ph / 2 + pw * 0.04, pw * 0.92, ph - pw * 0.08); x.restore();
      x.restore();
      const scr = { x: cx, y: cy, w: pw, h: ph }; LAY.objs.push(['phone', cx - pw / 2, cy - ph / 2, cx + pw / 2, cy + ph / 2]);
      let fx = cx + pw * 0.05, fy = cy + ph * 0.12, press = 0;
      if ((a.screen || 'feed') === 'feed') { const k = sw.ph === 'swipe' ? sw.k : sw.ph === 'prep' ? -0.15 * sw.k : sw.ph === 'settle' ? 1 - sw.k : 0; fy = cy + ph * (0.25 - 0.3 * clamp(k, -0.2, 1)); fx = cx + pw * 0.12; }
      else if (a.pressAt !== undefined) { const k = clamp((lt - a.pressAt + 0.4) / 0.4); fy = cy + ph * (0.1 + 0.15 * (1 - ease.out(k))); press = lt >= a.pressAt ? 1 : 0; }
      else { fy = cy + ph * (0.33 + fbm1(lt * 0.9, 3) * 0.04); fx = cx + pw * (0.06 + fbm1(lt * 0.7, 5) * 0.05); }
      povHand(x, fx, fy, E.H * 0.11, [-0.05, 1.2], press); st.scrBox = scr;
    } }];
    const z0 = close ? 1.25 : 1, cy0 = close ? E.H * 0.44 : E.H / 2;
    cam = camAt(slt, S.dur, { from: { x: E.W * 0.48, y: cy0 + E.H * 0.01, z: z0, r: -0.02 }, to: { x: E.W * 0.55, y: cy0 - E.H * 0.02, z: z0 * 1.15, r: 0.03 }, ease: 'cubic', hand, gt });
  } else if (role === 'otsPoster' || role === 'insertPoster') {
    const k = st.P.key(lt); if (k !== st.pKey) { st.pKey = k; const x = st.pc.getContext('2d'); x.setTransform(1, 0, 0, 1, 0, 0); st.P.draw(x, 1024, 1400, lt); }
    const ins = role === 'insertPoster', P = R.P;
    layers = [{ key: 'wall', p: 0.9, dyn: true, draw: (x) => {
      x.fillStyle = P.wall; x.fillRect(-200, -200, E.W + 400, E.H + 400); glow(x, E.W * 0.2, E.H * 0.1, E.H * 0.9, R.night ? '#7d93c4' : '#ffd9a0', R.night ? 0.14 : 0.25);
      const ph = ins ? E.H * 0.86 : E.H * 0.6, pw = ph * st.P.aspect, px = ins ? E.W * 0.5 : E.W * 0.6, py = ins ? E.H * 0.5 : E.H * 0.4;
      x.save(); x.filter = `blur(${12 * E.PX}px)`; x.fillStyle = 'rgba(0,0,0,0.3)'; x.fillRect(px - pw / 2 + 12, py - ph / 2 + 16, pw, ph); x.restore();
      x.drawImage(st.pc, px - pw / 2, py - ph / 2, pw, ph); if (R.night) { x.fillStyle = 'rgba(30,40,70,0.3)'; x.fillRect(px - pw / 2, py - ph / 2, pw, ph); }
      for (const [dx, c] of [[-0.42, '#d64545'], [0.42, '#3e6ea8']]) { x.fillStyle = c; x.beginPath(); x.arc(px + pw * dx, py - ph * 0.46, ph * 0.012, 0, 7); x.fill(); }
      LAY.objs.push(['poster', px - pw / 2, py - ph / 2, px + pw / 2, py + ph / 2]);
      if (ins) { const [u, v] = st.P.pen(lt), on = lt >= (a.at ?? 0.3) - 0.3 && lt <= (a.at ?? 0.3) + (a.dur ?? 3) + 0.2; const tx = on ? px - pw / 2 + u * pw : E.W * 0.85, ty = on ? py - ph / 2 + v * ph : E.H * 0.95; x.save(); x.strokeStyle = '#09090a'; x.lineCap = 'round'; x.lineWidth = E.H * 0.06; x.beginPath(); x.moveTo(E.W * 1.05, E.H * 1.1); x.lineTo(tx + E.H * 0.05, ty + E.H * 0.06); x.stroke(); x.fillStyle = '#09090a'; x.beginPath(); x.ellipse(tx + E.H * 0.035, ty + E.H * 0.045, E.H * 0.04, E.H * 0.03, 0.6, 0, 7); x.fill(); x.strokeStyle = '#d64545'; x.lineWidth = E.H * 0.012; x.beginPath(); x.moveTo(tx, ty); x.lineTo(tx + E.H * 0.04, ty + E.H * 0.05); x.stroke(); x.restore(); }
    } }];
    if (!ins && st.main) { const m = st.main; m.pl = { x: E.W * 0.26, y: E.H * 1.32, h: E.H * 1.2, anchor: 'feet', z: 1 }; m.st.yaw = Math.PI; layers.push({ key: 'back', p: 1.2, order: 3, dyn: true, blur: 3, cam: SCREEN, draw: (x) => { const r = m.draw(x); boxes.push({ who: m.who, head: r.head, box: r.box, fg: true }); } }); }
    cam = camAt(slt, S.dur, ins ? { from: { z: 1.0, y: E.H * 0.52 }, to: { z: 1.1, y: E.H * 0.48 }, ease: 'cubic', hand: hand * 0.8, gt } : { from: { x: E.W * 0.44, z: 1.02 }, to: { x: E.W * 0.56, z: 1.09 }, ease: 'cubic', hand, gt });
  } else if (role === 'insertClock' || role === 'clockWide') {   // I2: dolly 5% + nghieng 1 do + glow nhip 1,2 s + bui + doi tieu diem tu tuong sang so luc doi phut
    let tv = a.time || '2:14', tc = null; for (const [s2, v] of a.timeAt || []) { if (tc === null) tc = s2; if (lt >= s2) tv = v; }
    const focusK = tc === null ? 1 : clamp((lt - (tc - 0.25)) / 0.4), wide = role === 'clockWide';
    const cw = E.W * (wide ? 0.3 : 0.46), ch = cw * 0.42, cx = E.W * (wide ? 0.58 : 0.5), cy = E.H * (wide ? 0.55 : 0.47);
    layers = [
      { key: 'clkbg', p: 0.85, dyn: true, blur: lerp(0, 5, focusK) * (E.H / 1080), draw: (x) => {
        const P = R.P; x.fillStyle = R.night ? '#191b20' : '#6e757a'; x.fillRect(-60, -60, E.W + 120, E.H + 120);
        if (wide) { x.fillStyle = R.night ? '#22252c' : '#7d8389'; x.fillRect(E.W * 0.06, E.H * 0.18, E.W * 0.26, E.H * 0.36); }   // khung tranh / cua so mo
        x.fillStyle = P.wood; x.fillRect(-60, E.H * (wide ? 0.66 : 0.62), E.W + 120, E.H); x.fillStyle = 'rgba(0,0,0,0.12)'; for (let i = 0; i < 7; i++) x.fillRect(-60, E.H * (0.66 + i * 0.055), E.W + 120, 2);
        const r = rng(17); x.fillStyle = 'rgba(255,190,170,0.5)'; for (let i = 0; i < 40; i++) { const px = cx + (r() - 0.5) * cw * 1.6 + Math.sin(lt * 0.3 + i) * 12, py = cy - ch + ((r() * E.H * 0.5 - lt * 14 * (0.5 + r())) % (E.H * 0.5) + E.H * 0.5) % (E.H * 0.5) - E.H * 0.15; x.beginPath(); x.arc(px, py, 1.6 + r() * 1.6, 0, 7); x.fill(); }   // bui trong quang do
      } },
      { key: 'clk', p: 1, order: 2, dyn: true, blur: lerp(3.5, 0, focusK) * (E.H / 1080), draw: (x) => {
        x.fillStyle = 'rgba(0,0,0,0.4)'; x.filter = `blur(${16 * E.PX}px)`; x.fillRect(cx - cw / 2 + 10, cy - ch / 2 + 30, cw, ch); x.filter = 'none';
        x.fillStyle = '#121214'; x.beginPath(); x.roundRect(cx - cw / 2, cy - ch / 2, cw, ch, ch * 0.12); x.fill(); x.fillStyle = '#060607'; x.beginPath(); x.roundRect(cx - cw * 0.44, cy - ch * 0.36, cw * 0.88, ch * 0.72, ch * 0.06); x.fill();
        const pulse = 1 + Math.sin(lt * 2 * Math.PI / 1.2) * 0.04;
        if (R.night) glow(x, cx, cy, cw * 0.6, '#ff3b30', 0.22 * pulse); seg7(x, tv, cx, cy, ch * 0.5, a.color || '#ff4a3d'); LAY.objs.push(['clock', cx - cw / 2, cy - ch / 2, cx + cw / 2, cy + ch / 2]);
      } }];
    cam = camAt(slt, S.dur, { from: { x: E.W / 2, y: E.H * 0.5, z: 1, r: 0 }, to: { x: E.W / 2 + E.W * 0.03, y: E.H * 0.47, z: 1.16, r: 0.0175 }, ease: 'cubic', hand, gt });
  } else {   // void: man den -> hien dan canh mo phia sau (I4 I5): toi <= 1,0 s dau, sang len 28%, dolly 5%, chu troi len
    const ramp = clamp((lt - 0.45) / 1.2), dim = 1 - 0.42 * ease.inOut(ramp);
    layers = [...(st.bgR ? st.bgR.layers : []), { key: 'veil', p: 1, order: 5, dyn: true, cam: SCREEN, draw: (x) => { x.fillStyle = `rgba(0,0,0,${dim})`; x.fillRect(-60, -60, E.W + 120, E.H + 120); } }];
    cam = camAt(lt, info.dur, { from: { z: 1.02, x: E.W * 0.44 }, to: { z: 1.14, x: E.W * 0.56 }, ease: 'cubic', hand: 0.35, gt });   // truot ngang -> lop xa / gan troi khac nhau (parallax) extraPost = { vignette: 0.45 + Math.sin(lt * 1.3) * 0.05 };
  }
  if (st.kind === 'cta') layers.push({ ...actorLayer(SCREEN), order: 6 });
  if (['face', 'faceSide', 'closeMain', 'insertClock', 'clockWide'].includes(role)) layers.push(sweepLayer(R.night, E.shots.indexOf(info.shot)));
  if (['wide', 'manual', 'push', 'ots', 'insertClock', 'clockWide', 'void'].includes(role)) layers.push({ ...dustLayer(R.night || role === 'void', E.shots.indexOf(info.shot) + 9, role === 'insertClock' || role === 'clockWide' ? [0.25, 0.15, 0.8, 0.7] : role === 'void' ? [0.1, 0.1, 0.9, 0.9] : undefined), order: role === 'void' ? 4 : 2.5 });
  renderLayers(g, layers, cam, { aperture, focus: 1 }, lt);
  const gr = a.grade || {};
  post(g, { vignette: 0.62, grain: 0.04, sat: gv(gr.sat ?? 1, lt, gr), dim: gv(gr.dim ?? 0, lt, gr), ...extraPost });
  // chu: dau tren man hinh (sau may)
  g.save(); g.setTransform(E.PX, 0, 0, E.PX, 0, 0);
  const scr = boxes.map((b) => { const c = b.fg ? SCREEN : b.cam || cam, [hx, hy] = toScreen([b.head[0], b.head[1]], c), z = c.z, [x0, y0] = toScreen([b.box[0], b.box[1]], c), [x1, y1] = toScreen([b.box[2], b.box[3]], c); return { ...b, head: [hx, hy, b.head[2] * z], box: [x0, y0, x1, y1] }; });
  const blk = role === 'void' && st.kind !== 'cta';
  if (st.kind === 'card') drawCard(g, lt, a);
  if (st.kind === 'cta') drawCta(g, lt, a);
  drawTexts(g, lt, a.texts, { actors: scr, black: blk, cy: a.cy, drift: blk ? -14 * ease.inOut(clamp(lt / info.dur)) : 0, hudRows: !blk && st.kind !== 'cta' && a.hud && a.hud.rows ? a.hud.rows.length : 0 });
  if (!blk && st.kind !== 'cta' && st.kind !== 'card') drawHud(g, lt, a.hud, prevHud(info));
  LAY.cam = { role, sub: S.i, n: st.plan.length, move: mv, angle: p.angle }; LAY.shot = info.shot.id;
  LAY.objs = LAY.objs.map((o) => { const [a0, b0] = toScreen([o[1], o[2]], cam), [a1, b1] = toScreen([o[3], o[4]], cam); return [o[0], a0, b0, a1, b1]; });   // do vat -> toa do man hinh (sau may) de do cat mep / de chu
  g.restore();
}
// the keu goi (ban dien anh): cau chinh serif, 2 nut vien manh, con tro bam; nhan vat vay tay
function drawCta(g, lt, a) {
  const k = ease.inOut(clamp((lt - 0.2) / 0.7)); g.save(); g.globalAlpha = k; g.textAlign = 'center'; g.textBaseline = 'middle';
  g.font = `italic 400 44px ${SERIF}`; g.fillStyle = '#f2f1ec'; g.fillText(a.line || 'If this hit, subscribe.', E.W / 2, E.H * 0.2);
  const sub = lt > 1.6; g.font = `700 26px ${COMIC}`;
  for (const [x, t, on] of [[E.W / 2 - 130, 'LIKE', lt > 1.2], [E.W / 2 + 130, sub ? 'SUBSCRIBED' : 'SUBSCRIBE', sub]]) { g.strokeStyle = 'rgba(240,240,236,0.8)'; g.lineWidth = 2; g.fillStyle = on ? 'rgba(240,240,236,0.92)' : 'rgba(0,0,0,0.35)'; g.beginPath(); g.roundRect(x - 100, E.H * 0.3 - 26, 200, 52, 26); g.fill(); g.stroke(); g.fillStyle = on ? '#111' : '#f2f1ec'; g.fillText(t, x, E.H * 0.3); }
  g.restore(); LAY.texts.push({ t: a.line || '', box: [E.W / 2 - 420, E.H * 0.2 - 30, E.W / 2 + 420, E.H * 0.3 + 30] });
}

// do thi (ban dien anh): phong mo phia sau + do thi legacy tron "lighten" (nen den cua do thi bien mat, duong sang noi len), day may + cam tay
const GC = new Map();
function drawGraph(lt, info, g) {
  let st = ST.get(info.shot.id); if (!st || st.kind !== 'graph') { st = build('black', info); st.kind = 'graph'; ST.set(info.shot.id, st); }
  const W = g.canvas.width, H = g.canvas.height; let oc = GC.get('g'); if (!oc || oc.width !== W || oc.height !== H) { oc = canvas(W, H); GC.set('g', oc); }
  const cam = camAt(lt, info.dur, { from: { z: 1.0, x: E.W * 0.46, y: E.H * 0.52 }, to: { z: 1.16, x: E.W * 0.54, y: E.H * 0.48 }, ease: 'cubic', hand: 0.4, gt: info.globalT });
  renderLayers(g, [...st.bgR.layers, { ...dustLayer(true, 3, [0.1, 0.1, 0.9, 0.9]), order: 4 }, { key: 'veil', p: 1, order: 5, dyn: true, cam: SCREEN, draw: (x) => { x.fillStyle = 'rgba(0,0,0,0.6)'; x.fillRect(-60, -60, E.W + 120, E.H + 120); } }], cam, { aperture: 3 }, lt);
  const x = oc.getContext('2d'); x.setTransform(1, 0, 0, 1, 0, 0); x.clearRect(0, 0, W, H); x.setTransform(E.PX, 0, 0, E.PX, 0, 0); LEG.graph.draw(x, lt, info);
  g.save(); g.setTransform(1, 0, 0, 1, 0, 0); g.globalCompositeOperation = 'lighten'; g.translate(W / 2, H / 2); g.scale(cam.z, cam.z); g.rotate(cam.r || 0); g.translate(-W / 2 - (cam.x - E.W / 2) * E.PX, -H / 2 - (cam.y - E.H / 2) * E.PX); g.drawImage(oc, 0, 0); g.restore();
  post(g, { vignette: 0.55, grain: 0.04 });
}
registerTemplate('graph', { phim: true, draw(g, lt, info) { if (E.cfg.mode !== 'cinematic' || (info.args || {}).look === '2d') return LEG.graph.draw(g, lt, info); drawGraph(lt, info, g); } });

for (const kind of ['scene', 'phone', 'calendar', 'clock', 'face', 'black', 'card', 'cta']) {
  registerTemplate(kind, {
    phim: true,
    draw(g, lt, info) {
      const a = info.args || {};
      if (E.cfg.mode !== 'cinematic' || a.look === '2d') return LEG[kind].draw(g, lt, info);   // lui ve legacy khi ep
      let st = ST.get(info.shot.id); if (!st || st.kind !== kind) { st = build(kind, info); ST.set(info.shot.id, st); if (ST.size > 4) ST.delete(ST.keys().next().value); }
      if (kind === 'cta' && !st.plan.some((q) => q.role === 'void')) st.plan = [{ at: 0, role: 'void', size: 'void', angle: 'eye', move: 'dollyIn' }];
      draw(st, lt, info, g);
    },
  });
}
