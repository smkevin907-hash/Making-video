"""series.py — ho so chuoi (R15): moi de tai / chuoi 1 file series/<slug>/SERIES.md trong thu muc nguoi dung. Chi can Python 3.8+.
  python series.py ghi  --thu-muc <..> --phim <01-PHIM> [--tap N] [--chuoi <ten>]   them / cap nhat 1 tap vao SERIES.md (chay sau khi giao tap do)
  python series.py kiem --thu-muc <..> --phim <01-PHIM> [--chuoi <ten>]             kiem tap moi voi ho so: giu nhan vat, mau nhan, bo dem;
                                                                                      khong lap cau cam do cu; nen doi khung / cau moc / nang uoc mo
Chuoi va tap lay tu dau file 01: CHUỖI, TẬP (khong ghi thi lay tu TITLE va "PART N" o THẺ KẾT).
"""
import argparse, datetime as dt, difflib, json, os, re, sys
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import doi_thu as DT, kiem_truyen as KT
try: sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except (AttributeError, ValueError): pass
kd = DT.khong_dau
AI_VI = [("nhan vat chinh", "@main"), ("nhan vat", "@main"), ("cau bang do", "band"), ("cau hoodie", "hoodie"), ("cau trum mu", "hooded"), ("cau tran", "hero"), ("cau", "@main"),
         ("ban be", "friend"), ("ban 2", "friend2"), ("ban 3", "friend3"), ("ban", "friend"), ("co gai", "girl"), ("me", "mom"), ("bo", "dad"), ("em nho", "kid"), ("em be", "kid"),
         ("bong mo", "ghost"), ("bong den", "voice")] + [(x, x) for x in ("hero", "band", "hoodie", "hooded", "friend2", "friend3", "friend", "girl", "mom", "dad", "kid", "ghost", "voice")]

def chuan(s): return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9 ]", " ", kd(s))).strip()
def ho_so(p, chuoi=None, tap=None):   # rut ho so 1 tap tu file 01
    meta, sc, tot, moc_b, _ = KT.doc_phim(p); main = (meta.get("nhan vat") or "hero").strip().lower()
    card = next((KT.tag(c, "the ket", "card") for c in sc if KT.tag(c, "the ket", "card") is not None), "") or ""
    word = re.sub(r"\s*part\s*\d+", "", card.split("/")[0], flags=re.I).strip(" .") or meta.get("title", "")
    mp = re.search(r"part\s*(\d+)", card, re.I)
    ten = (chuoi or meta.get("chuoi") or meta.get("title") or word).strip().upper(); tp = int(tap or meta.get("tap") or (mp.group(1) if mp else 1))
    presets, ten_nguoi = [], {}
    for c in sc:
        for ent in (KT.tag(c, "ai") or "").split(";"):
            e = kd(ent).strip()
            w = next((v for k, v in sorted(AI_VI, key=lambda kv: -len(kv[0])) if e.startswith(k) and not e[len(k):len(k) + 1].isalnum()), None)
            if w: w = main if w == "@main" else w; presets.append(w) if w not in presets else None
        for x in c["chu"]:
            m = re.match(r"^@\s*([^:]+):", x)
            if m and m.group(1).strip().lower() != "me": ten_nguoi[m.group(1).strip().lower()] = ten_nguoi.get(m.group(1).strip().lower(), 0) + 1
    hud = [KT.tag(c, "hud") for c in sc if KT.tag(c, "hud") not in (None, "", "-")]
    nhan = []
    for h in hud:
        for r in h.split(";"):
            lab = re.split(r"\s*\d", r.strip(), 1)[0].strip().upper()
            if lab and lab not in nhan: nhan.append(lab)
    vat = [KT.rest(x, "vat") for c in sc for x in KT.tok(c, "vat")]
    return {"tap": tp, "file": os.path.basename(p), "chuoi": ten, "the_ket": card.strip(), "tieu_de": meta.get("title", ""), "nhan_vat": main, "presets": presets, "nguoi": sorted(ten_nguoi),
            "mau": (meta.get("accent") or "red").lower(), "bo_dem": nhan, "bo_dem_dau_cuoi": [hud[0], hud[-1]] if hud else [], "khung": DT.ma("khung_truyen", meta.get("khung")) or meta.get("khung", ""),
            "ket": DT.ma("kieu_ket", meta.get("ket")) or meta.get("ket", ""), "moc": DT.ma("kieu_cau_moc", meta.get("moc")) or meta.get("moc", ""), "uoc_mo": meta.get("uoc mo", ""),
            "vat": meta.get("vat", ""), "vat_trang_thai": [re.sub(r"^\d+\s*", "", v) for v in vat], "de_tai": DT.ma("de_tai", meta.get("de tai")) or "",
            "cam_do": [x[1:].strip() for c in sc for x in c["chu"] if x.startswith("~")], "dai": round(tot), "ngay": dt.date.today().isoformat()}
def duong_dan(D, ten): return os.path.join(D, "series", chuan(ten).replace(" ", "-") or "chuoi", "SERIES.md")
def doc_series(p):
    if not os.path.exists(p): return None
    m = re.search(r"<!-- series (\{.*?\}) -->", open(p, encoding="utf-8").read(), re.S)
    return json.loads(m.group(1)) if m else None
def viet_md(S):
    T = sorted(S["tap"], key=lambda x: x["tap"]); last = T[-1]; KH = DT.KHUNG
    nv = f"{last['nhan_vat']}" + (f" (cùng: {', '.join(x for x in last['presets'] if x not in (last['nhan_vat'], 'voice'))})" if len(last["presets"]) > 1 else "")
    L = [f"# CHUỖI: {S['ten']}", "", f"<!-- series {json.dumps(S, ensure_ascii=False)} -->", "",
         "> Hồ sơ chuỗi, cập nhật bằng `tools/series.py ghi` sau mỗi tập. Tập sau **đọc file này trước khi viết**: giữ nhân vật, màu nhấn, bộ đếm, vật biểu tượng; **không lặp câu cám dỗ** đã dùng; nên đổi khung và câu móc để khán giả không đoán được.", "",
         "| Mục | Giá trị |", "|---|---|",
         f"| Nhân vật | {nv} |", f"| Người thật (tên trong tin nhắn) | {', '.join(sorted({n for t in T for n in t['nguoi']})) or '—'} |", f"| Màu nhấn | {last['mau']} |",
         f"| Bộ đếm | {', '.join(dict.fromkeys(l for t in T for l in t['bo_dem']))} — tập {last['tap']} kết ở `{last['bo_dem_dau_cuoi'][-1] if last['bo_dem_dau_cuoi'] else '—'}` |",
         f"| Vật biểu tượng | {last['vat']} — tập {last['tap']}: {' → '.join(last['vat_trang_thai']) or '—'} |",
         "| Ước mơ | " + " · ".join(f"tập {t['tap']}: {t['uoc_mo']}" for t in T) + " |",
         "| Khung đã dùng | " + " · ".join(f"tập {t['tap']}: {KH.get(t['khung'], t['khung'])}" for t in T) + " |",
         "| Câu móc đã dùng | " + " · ".join(f"tập {t['tap']}: {DT.MOC.get(t['moc'], t['moc'])}" for t in T) + " |",
         "| Kết | " + " · ".join(f"tập {t['tap']}: {DT.KET.get(t['ket'], t['ket'])}" for t in T) + " |",
         "", "## Các tập", "| Tập | Thẻ kết | Khung | Dài | File | Ghi ngày |", "|---|---|---|---|---|---|"]
    L += [f"| {t['tap']} | {t['the_ket'].replace('|', '¦')} | {KH.get(t['khung'], t['khung'])} | {DT.mmss(t['dai'])} | {t['file']} | {t['ngay']} |" for t in T]
    L += ["", "## Câu cám dỗ đã dùng (tập sau không lặp lại)"] + [f"- tập {t['tap']}: " + " · ".join(t["cam_do"]) for t in T]
    con = [v for k, v in KH.items() if k not in {t["khung"] for t in T} and k != "khac"]
    L += ["", "## Gợi ý tập sau", f"- Tập {last['tap'] + 1}: thẻ kết `{S['ten']}. PART {last['tap'] + 1}`; giữ {last['nhan_vat']}, màu {last['mau']}, bộ đếm {', '.join(last['bo_dem'][:2])}; vật {last['vat']} đi tiếp từ trạng thái '{(last['vat_trang_thai'] or ['—'])[-1]}'.",
          f"- Khung chưa dùng: {', '.join(con)} (vd tái nghiện → vòng lặp; nhìn lại cả chuỗi → thư gửi bản thân).",
          "- Nâng ước mơ lên chặng mới (không lặp ước mơ tập trước); cám dỗ đổi giọng (hợp lý hơn, khó nhận ra hơn)."]
    return "\n".join(L) + "\n"

def cmd_ghi(a):
    h = ho_so(a.phim, a.chuoi, a.tap); p = duong_dan(a.thu_muc, h["chuoi"]); S = doc_series(p) or {"ten": h["chuoi"], "tap": []}
    S["tap"] = [t for t in S["tap"] if t["tap"] != h["tap"]] + [h]
    os.makedirs(os.path.dirname(p), exist_ok=True); open(p, "w", encoding="utf-8").write(viet_md(S))
    print(f"Da ghi tap {h['tap']} vao {p}: {len(h['cam_do'])} cau cam do, bo dem {h['bo_dem']}, vat '{h['vat']}' ({len(h['vat_trang_thai'])} trang thai)")
def cmd_kiem(a):
    h = ho_so(a.phim, a.chuoi); p = duong_dan(a.thu_muc, h["chuoi"]); S = doc_series(p); LOI, CB = [], []
    if not S: print(f"LOI: chưa có hồ sơ chuỗi {p} → ghi tập trước bằng: series.py ghi --phim <01 tập trước>"); sys.exit(1)
    cu = sorted([t for t in S["tap"] if t["tap"] < h["tap"]], key=lambda t: t["tap"])
    if not cu: print(f"LOI: hồ sơ chưa có tập nào trước tập {h['tap']} (TẬP / PART N ở thẻ kết)"); sys.exit(1)
    tr = cu[-1]
    if h["nhan_vat"] != tr["nhan_vat"]: LOI.append(f"nhân vật chính '{h['nhan_vat']}' khác chuỗi '{tr['nhan_vat']}' (dòng NHÂN VẬT)")
    for x in tr["presets"]:
        if x not in h["presets"] and x != "voice": CB.append(f"tập trước có '{x}', tập này không dùng (được nếu cố ý)")
    if h["mau"] != tr["mau"]: LOI.append(f"màu nhấn '{h['mau']}' khác chuỗi '{tr['mau']}' (ACCENT)")
    goc = [l for t in cu for l in t["bo_dem"]]
    if goc and not any(l in goc for l in h["bo_dem"]): LOI.append(f"bộ đếm {h['bo_dem']} không giữ nhãn của chuỗi ({', '.join(dict.fromkeys(goc))})")
    if tr["vat"] and chuan(h["vat"]) != chuan(tr["vat"]): CB.append(f"vật biểu tượng '{h['vat']}' khác chuỗi '{tr['vat']}' — nên giữ vật, cho nó đi tiếp trạng thái")
    da = [(t["tap"], c) for t in cu for c in t["cam_do"]]
    for c in h["cam_do"]:
        for tp, o in da:
            r = difflib.SequenceMatcher(None, chuan(c), chuan(o)).ratio()
            ngan, dai = sorted([set(chuan(c).split()), set(chuan(o).split())], key=len)
            # cau ngan nam tron trong cau dai = lap
            if chuan(c) == chuan(o) or r >= 0.85 or (len(ngan) >= 2 and ngan <= dai): LOI.append(f"câu cám dỗ '{c}' lặp lại tập {tp} ('{o}', giống {r:.0%})"); break
    if h["khung"] == tr["khung"]: CB.append(f"cùng khung với tập {tr['tap']} ({DT.KHUNG.get(h['khung'], h['khung'])}) — đổi khung để khó đoán")
    if h["moc"] and h["moc"] == tr["moc"]: CB.append(f"cùng kiểu câu móc với tập {tr['tap']}")
    if chuan(h["uoc_mo"]) == chuan(tr["uoc_mo"]): CB.append("ước mơ y hệt tập trước — nên nâng lên chặng mới")
    if not re.search(rf"part\s*{h['tap']}\b", h["the_ket"], re.I) and h["tap"] > 1: CB.append(f"thẻ kết nên có 'PART {h['tap']}'")
    print(f"KIEM CHUOI {S['ten']} — tập {h['tap']} ({os.path.basename(a.phim)}) so với {len(cu)} tập trước")
    print(f"  Nhân vật {h['nhan_vat']} · màu {h['mau']} · bộ đếm {', '.join(h['bo_dem'])} · vật {h['vat']} · khung {DT.KHUNG.get(h['khung'], h['khung'])}")
    print(f"  Câu cám dỗ: {len(h['cam_do'])} câu mới, so với {len(da)} câu đã dùng")
    if LOI: print(f"\nLOI ({len(LOI)}):"); [print("  " + x) for x in LOI]
    if CB: print(f"\nCANH BAO ({len(CB)}):"); [print("  " + x) for x in CB]
    print("=> SACH LOI." if not LOI else f"=> CON {len(LOI)} LOI.")
    sys.exit(1 if LOI else 0)

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("lenh", choices=["ghi", "kiem"]); ap.add_argument("--thu-muc", default="."); ap.add_argument("--phim", required=True)
    ap.add_argument("--tap", type=int); ap.add_argument("--chuoi")
    a = ap.parse_args(); (cmd_ghi if a.lenh == "ghi" else cmd_kiem)(a)

if __name__ == "__main__": main()
