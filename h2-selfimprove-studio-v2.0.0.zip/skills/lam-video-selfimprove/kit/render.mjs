// render.mjs — H2 2D Studio: ve tung khung hinh bang Chromium chay ngam roi ghep bang ffmpeg.
// Cach dung:
//   node render.mjs --project projects/<ten> --sheet [--scale 0.5]          anh tong hop: 1 khung / shot
//   node render.mjs --project projects/<ten> --stills 3.2,7.5 [--scale 0.5] anh tai cac thoi diem
//   node render.mjs --project projects/<ten> --from 0 --to 30 [--scale 0.5] video xem truoc (build/preview.mp4, co voice)
//   node render.mjs --project projects/<ten> [--workers N]                  ban cuoi (build/video_silent.mp4)
//   node render.mjs --project projects/<ten> --thumb                        anh thumbnail tu canh 'thumb' -> out/thumbnail.png
//   node render.mjs --project projects/<ten> --check --scale 0.25        quet loi toan video, khong xuat file
//   node render.mjs --project projects/<ten> --serve [--scale 0.5]       mo may chu xem trong trinh duyet: ?frame=N (1 khung) | ?live=1 (phat truc tiep)
// Tuy chon: --style <id> (thu style khac), --at 0.45 (vi tri lay khung trong shot cho --sheet), --crf 18, --gl swiftshader|auto
import http from 'node:http';
import fs from 'node:fs';
import path from 'node:path';
import os from 'node:os';
import { spawn, spawnSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import { launchChromium } from './tools/chromium.mjs';

const ROOT = path.dirname(fileURLToPath(import.meta.url));
const args = {}; process.argv.slice(2).forEach((a, i, arr) => { if (a.startsWith('--')) { const k = a.slice(2); const v = arr[i + 1]; args[k] = v && !v.startsWith('--') ? v : true; } });
if (!args.project) { console.error('Thieu --project projects/<ten>'); process.exit(1); }
const PROJ = path.resolve(args.project);
const SCALE = +(args.scale || 1);
const BUILD = path.join(PROJ, 'build'); fs.mkdirSync(BUILD, { recursive: true });
const MIME = { '.js': 'text/javascript', '.mjs': 'text/javascript', '.json': 'application/json', '.html': 'text/html', '.css': 'text/css', '.woff2': 'font/woff2', '.woff': 'font/woff', '.png': 'image/png', '.jpg': 'image/jpeg', '.jpeg': 'image/jpeg', '.webp': 'image/webp', '.svg': 'image/svg+xml' };

// ---------- may chu tinh
function listScenes(dir) {
  const out = []; const base = path.join(dir, 'scenes');
  const walk = (d) => { if (!fs.existsSync(d)) return; for (const f of fs.readdirSync(d).sort()) { const p = path.join(d, f); if (fs.statSync(p).isDirectory()) walk(p); else if (f.endsWith('.js') && !f.startsWith('_')) out.push(path.relative(dir, p).split(path.sep).join('/')); } };
  walk(path.join(base, 'sets')); walk(path.join(base, 'shots'));
  for (const f of fs.existsSync(base) ? fs.readdirSync(base).sort() : []) { if (f.endsWith('.js') && !f.startsWith('_') && f !== 'cast.js') out.push('scenes/' + f); }
  return out;
}
const server = http.createServer((req, res) => {
  const u = new URL(req.url, 'http://x');
  if (u.pathname === '/__assets') { const d = path.join(PROJ, 'anh'); const list = fs.existsSync(d) ? fs.readdirSync(d).filter((f) => /\.(png|jpe?g|webp)$/i.test(f)).sort().map((f) => ({ id: path.parse(f).name, file: 'anh/' + f })) : []; res.writeHead(200, { 'content-type': 'application/json' }); return res.end(JSON.stringify(list)); }
  if (u.pathname === '/__manifest') { res.writeHead(200, { 'content-type': 'application/json' }); return res.end(JSON.stringify(listScenes(PROJ))); }
  let file = u.pathname.startsWith('/proj/') ? path.join(PROJ, decodeURIComponent(u.pathname.slice(6))) : path.join(ROOT, decodeURIComponent(u.pathname));
  if (!fs.existsSync(file) || fs.statSync(file).isDirectory()) { res.writeHead(404); return res.end('not found'); }
  res.writeHead(200, { 'content-type': MIME[path.extname(file)] || 'application/octet-stream', 'cache-control': 'no-store' });
  fs.createReadStream(file).pipe(res);
});
await new Promise((r) => server.listen(0, '127.0.0.1', r));
const PORT = server.address().port;

// ---------- trinh duyet
// SwiftShader chi can cho canh 3D (nguoi que What If). Du an dung pack 2D (doodle, dem...) ve bang CPU nhanh hon nhieu lan.
let _cfg = {}; try { _cfg = JSON.parse(fs.readFileSync(path.join(PROJ, 'config.json'), 'utf8')); } catch {}
// che do cinematic (WebGL): Chromium chay ngam mac dinh ve WebGL bang phan mem (SwiftShader, do: ~3,6 khung/giay o 960x540).
// 'gpu' = ep dung GPU that (Windows: Direct3D 11, macOS: Metal); Linux khong GPU: SwiftShader. --gl swiftshader|auto|gpu de chon tay.
const cine = _cfg.mode === 'cinematic';
const gl = args.gl || (cine ? (process.platform === 'linux' ? 'swiftshader' : 'gpu') : process.platform === 'linux' && !_cfg.pack ? 'swiftshader' : 'auto');
const GPU = { win32: ['--use-angle=d3d11'], darwin: ['--use-angle=metal'] }[process.platform] || [];
const LAUNCH = { args: ['--disable-dev-shm-usage', '--font-render-hinting=none', ...(gl === 'swiftshader' ? ['--use-angle=swiftshader', '--enable-unsafe-swiftshader'] : gl === 'gpu' ? [...GPU, '--enable-gpu', '--ignore-gpu-blocklist'] : [])] };
// tim Chromium o moi kieu thu muc (chrome-linux64, chrome-win64, headless shell...): xem tools/chromium.mjs
const launch = () => launchChromium(LAUNCH);
async function openPlayer(browser, style) {
  const page = await browser.newPage();
  page.on('console', (m) => { if (m.type() === 'error') console.log('  [trinh duyet]', m.text().slice(0, 300)); });
  page.on('response', (r) => { if (r.status() >= 400 && !r.url().includes('/timeline/')) console.log('  [404]', r.url().slice(0, 200)); });
  page.on('pageerror', (e) => console.log('  [loi trang]', String(e).slice(0, 300)));
  const qs = new URLSearchParams({ proj: '/proj', scale: String(SCALE) });
  await page.goto(`http://127.0.0.1:${PORT}/player.html?${qs}`);
  await page.waitForFunction(() => window.__ready || window.__bootError, null, { timeout: 120000 });
  const err = await page.evaluate(() => window.__bootError); if (err) throw new Error('Khong khoi dong duoc player: ' + err);
  if (style) await page.evaluate((s) => { window.__setStyle && window.__setStyle(s); }, style);
  const info = await page.evaluate(() => window.__info);
  await page.setViewportSize({ width: Math.min(info.W, 4000), height: Math.min(info.H, 4000) });
  return { page, info };
}
const b64 = (d) => Buffer.from(d.slice(d.indexOf(',') + 1), 'base64');
function report(info) {
  const miss = info.shots.filter((s) => !s.has).map((s) => s.id);
  if (miss.length) console.log(`  THIEU ${miss.length} shot: ${miss.slice(0, 30).join(', ')}${miss.length > 30 ? ' ...' : ''}`);
  if (info.missingImages && info.missingImages.length) console.log(`  THIEU ${info.missingImages.length}/${info.images} anh AI (dat vao <du an>/anh/): ${info.missingImages.slice(0, 40).join(', ')}${info.missingImages.length > 40 ? ' ...' : ''}`);
  if (info.importErrors.length) { console.log('  LOI NAP FILE CANH:'); info.importErrors.forEach((e) => console.log('   - ' + e)); }
}
const voicePath = () => { for (const f of ['build/mix.wav', 'timeline/voice.wav']) { const p = path.join(PROJ, f); if (fs.existsSync(p)) return p; } return null; };
function ff(argv) { const r = spawnSync('ffmpeg', ['-v', 'error', '-y', ...argv], { stdio: 'inherit' }); if (r.status) throw new Error('ffmpeg loi'); }

// ---------- che do
// --serve: chi mo may chu de xem trong trinh duyet that: 1 khung (?frame=N) hoac phat truc tiep (?live=1&from=giay). Ctrl+C de dung.
if (args.serve) {
  const base = `http://127.0.0.1:${PORT}/player.html?proj=/proj`;
  console.log(`Xem 1 khung:  ${base}&frame=0\nPhat truc tiep: ${base}&live=1&from=0\n(Ctrl+C de dung)`);
  await new Promise(() => {});
}
const browser = await launch();
try {
  if (args.thumb) {
    const { page } = await openPlayer(browser, args.style);
    const d = await page.evaluate((t) => window.renderThumb(t), +(args.at || 1));
    if (!d) throw new Error("Chua co canh 'thumb' (registerShot('thumb', ...) trong scenes/shots/).");
    fs.mkdirSync(path.join(PROJ, 'out'), { recursive: true }); const p = path.join(PROJ, 'out', 'thumbnail.png'); fs.writeFileSync(p, b64(d));
    spawnSync('ffmpeg', ['-v', 'error', '-y', '-i', p, '-vf', 'scale=1280:-2', path.join(PROJ, 'out', 'thumbnail_1280.jpg')]); console.log('  ' + p);
  } else if (args.check) {
    // quet nhanh toan video tim loi (khong xuat file): moi 3 khung ve 1 lan o kich thuoc nho
    const { page, info } = await openPlayer(browser, args.style); report(info);
    const errs = new Set(); page.on('console', (m) => { if (m.type() === 'error' && /SHOT|IMPORT/.test(m.text())) errs.add(m.text().slice(0, 200)); });
    // bo cuc + chuyen dong (goi ve co ghi window.__lay, vd dem): nguoi sai moc / ra ngoai khung, chu de mat / nguoi / do vat, chan truot, nhac hut, doi tu the giat
    const issues = new Map(), add = (id, t, lvl, msg) => { const k = id + '|' + msg; if (!issues.has(k)) issues.set(k, { id, t, lvl, msg }); };
    const area = (b) => Math.max(0, b[2] - b[0]) * Math.max(0, b[3] - b[1]), ovl = (a, b) => Math.max(0, Math.min(a[2], b[2]) - Math.max(a[0], b[0])) * Math.max(0, Math.min(a[3], b[3]) - Math.max(a[1], b[1]));
    const feet = new Map(), W = 1920 * (info.W > info.H ? 1 : 1080 / 1920), Hh = W * info.H / info.W, cut = (s) => String(s).replace(/\s+/g, ' ').slice(0, 28);
    // 1.10 dung hinh: so anh thu nho 160x90 giua 2 lan do (cach 3 khung); khung gan nhu khong doi lien tuc >= 1,5 giay = dung hinh (doi thu: 0 giay)
    let still = 0, stillFrom = null, stillShot = null; const STILL_D = +(process.env.H2_STILL || 0.1);   // do thuc te (anh 160x90, cach 3 khung): khung tinh + bui 0,01–0,03; doan ffmpeg freezedetect (n=0.002) bat duoc tren canh toi: 0,04–0,13
    const sigDiff = () => { const c = document.getElementById('c'), q = (window.__sc = window.__sc || document.createElement('canvas')); q.width = 160; q.height = 90; const x = q.getContext('2d', { willReadFrequently: true }); x.drawImage(c, 0, 0, 160, 90); const d = x.getImageData(0, 0, 160, 90).data, o = new Float32Array(14400); for (let i = 0; i < 14400; i++) o[i] = (d[i * 4] * 3 + d[i * 4 + 1] * 6 + d[i * 4 + 2]) / 10; const p = window.__psig; window.__psig = o; if (!p) return -1; let s = 0; for (let i = 0; i < 14400; i++) s += Math.abs(o[i] - p[i]); return s / 14400; };
    // 2.0 cinematic: man chu den / the ket duoc giu yen (phim tham khao giu 3–4 giay); canh co hinh van do
    let tplOf = {}; try { tplOf = Object.fromEntries((JSON.parse(fs.readFileSync(path.join(PROJ, 'story', 'shots.json'), 'utf8')).shots || []).map((s) => [s.id, s.tpl])); } catch {}
    const holdOk = (id) => _cfg.mode === 'cinematic' && ['black', 'card'].includes(tplOf[id]);
    const flushStill = (endT) => { if (stillShot && still >= 1.5 && !holdOk(stillShot.id)) { const lvl = still >= 2.5 ? 'LOI' : 'CANH BAO'; add(stillShot.id, +(stillFrom - stillShot.start).toFixed(1), lvl, `dung hinh ${still.toFixed(1)} giay (khong co gi chuyen dong) -> them cam day cham, bui, nhan vat tho / chop mat; man chu den: rut con 2–4 giay`); } still = 0; stillFrom = null; stillShot = null; };
    // 2.0 cinematic: do tren diem anh that — glow chay trang tren dau (ti le diem gan trang trong hop dau), tuong phan chu (nen = phan vi 25% do sang trong vet toi dang hien; bo qua luc chu dang hien / tat dan)
    const probe = () => {
      const c = document.getElementById('c'), k = c.width / 1920, x = c.getContext('2d', { willReadFrequently: true }), L = window.__lay; if (!L) return null;
      const reg = (b) => { const x0 = Math.max(0, Math.floor(b[0] * k)), y0 = Math.max(0, Math.floor(b[1] * k)), w = Math.min(c.width - x0, Math.ceil((b[2] - b[0]) * k)), h = Math.min(c.height - y0, Math.ceil((b[3] - b[1]) * k)); if (w < 2 || h < 2) return null; const d = x.getImageData(x0, y0, w, h).data, a = []; for (let i = 0; i < d.length; i += 8) a.push(d[i] * 0.299 + d[i + 1] * 0.587 + d[i + 2] * 0.114); return a; };
      const heads = (L.actors || []).map((a) => { if (!a.head) return 0; const [hx, hy, r] = a.head, v = reg([hx - r * 0.8, hy - r * 0.8, hx + r * 0.8, hy + r * 0.8]); return v ? v.filter((q) => q > 245).length / v.length : 0; });
      const texts = (L.texts || []).filter((t) => !t.hud).map((t) => { if (t.vis === null || t.a < 0.9) return null; const b = t.vis || t.box, dx = (b[2] - b[0]) * 0.12, dy = (b[3] - b[1]) * 0.2, v = reg([b[0] + dx, b[1] + dy, b[2] - dx, b[3] - dy]); if (!v) return null; v.sort((p, q) => p - q); return v[Math.floor(v.length * 0.25)]; });   // loi duoi chu (bo le hop chu)
      return { heads, texts };
    };
    const cineQA = _cfg.mode === 'cinematic';
    for (let f = 0; f < info.frames; f += 3) {
      const res = await page.evaluate(([f, sig, pr]) => window.renderFrame(f, { q: 0.3, blur: false }).then(() => ({ lay: window.__lay ? JSON.parse(JSON.stringify(window.__lay)) : null, diff: new Function('return (' + sig + ')()')(), px: pr ? new Function('return (' + pr + ')()')() : null })), [f, sigDiff.toString(), cineQA ? probe.toString() : null]);
      const lay = res.lay, t = f / info.fps, si0 = Math.max(0, info.shots.findIndex((s) => t < s.end)), sh0 = info.shots[si0], diff = res.diff;
      if (diff >= 0) { if (diff < STILL_D && stillShot && stillShot.id === sh0.id) still += 3 / info.fps; else if (diff < STILL_D) { flushStill(t); stillShot = sh0; stillFrom = t; still = 3 / info.fps; } else flushStill(t); }
      if (process.env.H2_SIGLOG) console.log('SIG', t.toFixed(2), sh0.id, diff.toFixed(3));
      if (!lay) continue;
      const si = si0, sh = sh0, lt = +(t - sh.start).toFixed(1);
      if (cineQA) {
        for (const o of lay.objs || []) if (o[0] === 'poster' && (o[1] < -4 || o[2] < -4 || o[3] > W + 4 || o[4] > Hh + 4)) add(sh.id, lt, 'LOI', `poster bi mep khung cat -> giam do day may / coverage insertPoster`);
        (res.px?.heads || []).forEach((r, i) => { if (r > 0.02) add(sh.id, lt, 'LOI', `glow chay trang dau ${lay.actors[i]?.who} (${Math.round(r * 100)}% diem gan trang) -> giam glow / vien sang`); });
        const tx = (lay.texts || []).filter((t) => !t.hud);
        (res.px?.texts || []).forEach((bg, i) => { if (bg === null || bg === undefined || (lay.shot && lay.shot !== sh.id)) return; const lum = (v) => { v /= 255; return v <= 0.03928 ? v / 12.92 : ((v + 0.055) / 1.055) ** 2.4; }, cr = (0.85 + 0.05) / (lum(bg) + 0.05); if (cr < 4.5) add(sh.id, lt, 'CANH BAO', `chu "${cut(tx[i]?.t || '')}" tuong phan ~${cr.toFixed(1)}:1 (< 4.5) -> nen duoi chu qua sang, doi pos / dam vet toi`); });
      }
      lay.actors.forEach((a, i) => {
        if (!a.ok) { add(sh.id, lt, 'LOI', `nhan vat ${a.who}: moc "${a.anchor}" khong co trong boi canh nay -> nhan vat khong hien / sai cho. Dung so 0..1 hoac moc dung boi canh`); return; }
        const vis = Math.max(0, Math.min(a.box[2], W) - Math.max(a.box[0], 0)) / Math.max(1, a.box[2] - a.box[0]);
        if (vis < 0.6 && !a.moving && !a.fg) add(sh.id, lt, 'LOI', `nhan vat ${a.who} nam ngoai khung ${Math.round((1 - vis) * 100)}% -> dat x vao 0.1..0.9`);
        if (a.feet && a.still === false && !a.inPlace) {   // chan truot (chi khi dang di / chay that; chay tai cho thi nen troi theo chan): ban chan cham dat dich ngang giua 2 lan do
          const k = si + '|' + i, prev = feet.get(k), gy = Math.max(...a.feet.map((p) => p[1]));
          if (prev) a.feet.forEach((p, j) => { const q = prev.feet[j]; if (q && Math.abs(p[1] - gy) < 2 && Math.abs(q[1] - prev.gy) < 2 && Math.abs(p[1] - q[1]) < 2 && Math.abs(p[0] - q[0]) > 5) prev.slip = (prev.slip || 0) + 1; });
          const n = { feet: a.feet, gy, slip: prev ? prev.slip || 0 : 0 }; feet.set(k, n); if (n.slip >= 2) add(sh.id, lt, 'LOI', `chan ${a.who} truot tren san (ban chan cham dat bi dich ngang) -> kiem tra walk / run, scroll`);
        }
      });
      for (const tx of lay.texts) {
        const A = Math.max(1, area(tx.box));
        if (tx.box[0] < -2 || tx.box[2] > W + 2 || tx.box[1] < -2 || tx.box[3] > Hh + 2) add(sh.id, lt, 'LOI', `chu "${cut(tx.t)}" bi cat mep khung -> bo x / y de chu tu dat, hoac rut ngan chu`);   // 1.10
        for (const a of lay.actors) if (a.ok && a.head) { const [hx, hy, r] = a.head; if (ovl(tx.box, [hx - r * 0.9, hy - r * 0.9, hx + r * 0.9, hy + r * 0.9]) > A * 0.04) add(sh.id, lt, 'LOI', `chu "${cut(tx.t)}" de len mat ${a.who} -> bo x / y de chu tu tranh, hoac pos khac`); }
        for (const a of lay.actors) if (a.ok && !a.voice && ovl(tx.box, [a.box[0], a.box[1] + (a.box[3] - a.box[1]) * 0.45, a.box[2], a.box[3]]) > A * 0.08) add(sh.id, lt, 'LOI', `chu "${cut(tx.t)}" de len nguoi / chan ${a.who}`);
        for (const o of lay.objs) if (ovl(tx.box, o.slice(1)) > A * 0.08) add(sh.id, lt, 'LOI', `chu "${cut(tx.t)}" de len ${o[0]}`);
      }
      lay.texts.forEach((p, i) => lay.texts.slice(i + 1).forEach((q) => { if (ovl(p.box, q.box) > 0.08 * Math.max(1, Math.min(area(p.box), area(q.box)))) add(sh.id, lt, 'LOI', `chu "${cut(p.t)}" va chu "${cut(q.t)}" de len nhau -> bo x / y de chu tu xep, hoac doi at`); }));
      // nguoi bi che: nguoi ve sau (dung truoc) phu > 30% than nguoi ve truoc (than = giua hop, bo tay)
      const body = (a) => { const c = (a.box[0] + a.box[2]) / 2, w = (a.box[2] - a.box[0]) * 0.3; return [c - w, a.box[1], c + w, a.box[3]]; };
      const okA = lay.actors.filter((a) => a.ok && a.box);
      okA.forEach((p, i) => okA.slice(i + 1).forEach((q) => { if ((p.moving && q.moving) || p.fg || q.fg) return; const k = ovl(body(p), body(q)) / Math.max(1, area(body(p))); if (k > 0.3) add(sh.id, lt, 'LOI', `${q.who} dung chan truoc ${p.who} (che ${Math.round(k * 100)}%) -> doi x, hoac them "keepX": true neu co y`); }));   // fg: tien canh (qua vai) che la co y
    }
    flushStill(info.duration);
    // kiem tinh tu kich ban: doi tu the giat 1 khung, nhac hut (khoang trong giua hai doan nhac khong ghi none)
    let story = {}; try { story = JSON.parse(fs.readFileSync(path.join(PROJ, 'story', 'shots.json'), 'utf8')); } catch {}
    for (const s of story.shots || []) for (const ac of (s.args || {}).actors || []) for (const e of ac.poseAt || []) if (ac.poseDur === 0 || e[2] === 0) add(s.id, e[0], 'CANH BAO', `${ac.who} doi tu the sang ${e[1]} trong 1 khung (poseDur 0) -> bo poseDur 0 neu khong co y giat`);
    const mus = (story.music || []).slice().sort((p, q) => p.start - q.start);
    for (let i = 1; i < mus.length; i++) if (mus[i].start - mus[i - 1].end > 0.3) { const s = (story.shots || []).find((x) => mus[i - 1].end < x.end) || {}; add(s.id || '?', +(mus[i - 1].end - (s.start || 0)).toFixed(1), 'LOI', `nhac hut giay ${mus[i - 1].end}-${mus[i].start} (khong co doan nhac) -> noi lien doan nhac hoac ghi bed: none neu muon im`); }
    const list = [...issues.values()], lines = list.map((x) => `[${x.lvl}] ${x.id} @${x.t}s: ${x.msg}`);
    if (errs.size) lines.unshift('LOI VE / NAP FILE:', ...errs);
    fs.writeFileSync(path.join(BUILD, 'check.txt'), (lines.length ? lines.join('\n') : 'Khong co loi') + '\n');
    console.log(lines.length ? `${list.filter((x) => x.lvl === 'LOI').length} loi, ${list.filter((x) => x.lvl !== 'LOI').length} canh bao (build/check.txt):\n` + lines.join('\n') : 'Khong co loi trong ' + info.frames + ' khung.');
  } else if (args.sheet || args.stills) {
    const { page, info } = await openPlayer(browser, args.style); report(info);
    const items = [];
    if (args.sheet) {
      const at = +(args.at || 0.45), sel = args.ids ? String(args.ids).split(',') : null;
      for (let i = 0; i < info.shots.length; i++) {
        const s = info.shots[i]; if (sel && !sel.includes(s.id)) continue;
        const t = s.start + (s.end - s.start) * at, f = Math.min(info.frames - 1, Math.round(t * info.fps));
        const src = await page.evaluate((f) => window.renderFrame(f), f);
        items.push({ src, label: `${s.id} ${s.start.toFixed(1)}s ${s.line}` });
      }
    } else {
      for (const t of String(args.stills).split(',').map(Number)) { const f = Math.round(t * info.fps); const src = await page.evaluate((f) => window.renderFrame(f, { png: true }), f); fs.mkdirSync(path.join(BUILD, 'stills'), { recursive: true }); const p = path.join(BUILD, 'stills', `t_${t.toFixed(2)}.png`); fs.writeFileSync(p, b64(src)); console.log('  ' + p); items.push({ src, label: `${t}s` }); }
    }
    const dir = path.join(BUILD, 'sheets'); fs.mkdirSync(dir, { recursive: true });
    for (let k = 0, n = 1; k < items.length; k += 16, n++) {
      const sheet = await page.evaluate(([it]) => window.makeSheet(it, 4, 480), [items.slice(k, k + 16)]);
      const p = path.join(dir, `${args.stills ? 'stills' : 'sheet'}${args.style ? '_' + args.style : ''}_${String(n).padStart(2, '0')}.jpg`); fs.writeFileSync(p, b64(sheet)); console.log('  ' + p);
    }
  } else {
    // video: xem truoc hoac ban cuoi
    const { page: p0, info } = await openPlayer(browser, args.style); report(info); await p0.close();
    const preview = args.from !== undefined || args.to !== undefined;
    const f0 = Math.max(0, Math.round(+(args.from || 0) * info.fps)), f1 = Math.min(info.frames, Math.round((args.to !== undefined ? +args.to : info.duration) * info.fps));
    const total = f1 - f0;
    const W = Math.max(1, Math.min(+(args.workers || Math.max(1, Math.min(6, Math.floor(os.cpus().length / 2)))), Math.ceil(total / 48)));
    console.log(`Render ${total} khung (${(total / info.fps).toFixed(1)} giay) ${info.W}x${info.H} @${info.fps}fps, ${W} luong`);
    const parts = []; let done = 0; const t0 = Date.now();
    const tick = setInterval(() => { const el = (Date.now() - t0) / 1000, fps = done / Math.max(el, 0.1); console.log(`  ${done}/${total} khung  ${fps.toFixed(2)} khung/giay  da chay ${Math.floor(el / 60)}p${Math.round(el % 60)}s  con lai ~${Math.round((total - done) / Math.max(fps, 0.01) / 60)} phut`); }, 15000);
    const chunk = Math.ceil(total / W);
    await Promise.all(Array.from({ length: W }, async (_, k) => {
      const a = f0 + k * chunk, b = Math.min(f1, a + chunk); if (a >= b) return;
      const out = path.join(BUILD, `part_${String(k).padStart(2, '0')}.mp4`); parts[k] = out;
      const br = k === 0 ? browser : await launch();
      const { page } = await openPlayer(br, args.style);
      const enc = spawn('ffmpeg', ['-v', 'error', '-y', '-f', 'image2pipe', '-framerate', String(info.fps), '-c:v', 'mjpeg', '-i', '-', '-c:v', 'libx264', '-preset', preview ? 'veryfast' : 'medium', '-crf', String(args.crf || 20), '-maxrate', '8M', '-bufsize', '16M', '-tune', 'animation', '-pix_fmt', 'yuv420p', '-r', String(info.fps), out], { stdio: ['pipe', 'inherit', 'inherit'] });
      for (let f = a; f < b; f++) {
        const d = await page.evaluate((f) => window.renderFrame(f, { q: 0.93 }), f);
        if (!enc.stdin.write(b64(d))) await new Promise((r) => enc.stdin.once('drain', r));
        done++;
      }
      enc.stdin.end(); await new Promise((r) => enc.on('close', r));
      if (br !== browser) await br.close();
    }));
    clearInterval(tick);
    const list = path.join(BUILD, 'parts.txt'); fs.writeFileSync(list, parts.filter(Boolean).map((p) => `file '${p.replace(/'/g, "'\\''")}'`).join('\n'));
    const silent = path.join(BUILD, preview ? 'preview_silent.mp4' : 'video_silent.mp4');
    ff(['-f', 'concat', '-safe', '0', '-i', list, '-c', 'copy', silent]);
    parts.filter(Boolean).forEach((p) => fs.unlinkSync(p)); fs.unlinkSync(list);
    if (preview) {
      const vp = voicePath(), outp = path.join(BUILD, 'preview.mp4');
      if (vp) ff(['-i', silent, '-ss', String(f0 / info.fps), '-t', String(total / info.fps), '-i', vp, '-map', '0:v', '-map', '1:a', '-c:v', 'copy', '-c:a', 'aac', '-b:a', '192k', '-shortest', outp]);
      else fs.copyFileSync(silent, outp);
      console.log(`\nXong: ${outp}`);
    } else console.log(`\nXong: ${silent}  (${((Date.now() - t0) / 60000).toFixed(1)} phut). Buoc tiep: python tools/mix.py --project ${args.project}`);
  }
} finally { await browser.close(); server.close(); }
