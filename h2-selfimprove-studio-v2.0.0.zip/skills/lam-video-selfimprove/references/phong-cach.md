# Luật hình ngách Self-Improvement — chế độ legacy (bộ `dem`)

> Từ 2.0, dự án mới mặc định dùng **chế độ cinematic** (2.5D minh hoạ): luật hình ở `cinematic.md`. File này là luật của chế độ legacy (sân khấu 2D, dự án cũ / 9:16). Phần chữ, giọng cám dỗ, bộ đếm, nội dung nhạy cảm vẫn áp dụng cho cả hai chế độ.

Học từ các kênh "An Animated Short Film" dẫn đầu ngách. Chỉ học **phong cách và nhịp**, mọi hình đều do code của mình vẽ.

## Cấu hình dự án
- `config.json`: `"pack": "dem"`, `"style": "flat"`, `"accent": "red" | "pink" | "amber" | "teal"` (lấy từ file 01).
- **16:9 dùng TOÀN KHUNG, không dải đen** (từ 1.10; đo 3/3 video đối thủ: 0 dải đen). Dải đen 2.39:1 làm mất ~26% khung, nhân vật nhỏ trên điện thoại, cắt mép cửa sổ và đẩy chữ cám dỗ ra xa bóng đen. Chỉ bật khi người dùng yêu cầu: `"bars": "scope"`.
- 9:16: không dải đen, chữ to hơn, nhân vật đặt giữa (`x` 0.35–0.65).

## Số đo đối thủ (DISCIPLINE, DOPAMINE, LUST VS LOVE): chuẩn phải đạt
| Chỉ số | Đối thủ | Lỗi đã gặp ("Five More Minutes", 1.9.0) |
|---|---|---|
| Dải đen | 0% thời lượng | 100% thời lượng |
| Đứng hình ≥ 1,5 giây | 0 giây | 34 giây, 14 đoạn (10 màn đen + thẻ kết + CTA) |
| Độ dài | 2:38–2:51 | 4:31 |
| Màn đen | 3–4, mỗi màn 2–5 giây | 10 màn, 4–5 giây, đứng im |
| Mở đầu | màn đen 1–2 câu nghịch lý (dòng 2 đậm) | vào cảnh ngay, chữ nhỏ lệch góc |
| Màu | đổi theo nhịp: thế giới mất màu → màu trở lại | một tông navy suốt 4 phút |
| Kết | thẻ kết, không màn kêu gọi | màn kêu gọi 10 giây đứng im |

## Màu và nét
- Nền rất tối (#141418 → #1d1e24). Đồ vật tô phẳng xám xanh tối, **nét viền mảnh màu sáng** (#c9ccd4). Không viền đen dày.
- Nhân vật màu kem #ece6d6, dáng **hạt đậu** (đầu nhỏ dính liền thân, eo thon dưới đầu, đáy tròn, tay chân thon, đầu tay chân tròn không có bàn tay riêng), viền xám đậm rất mảnh, bóng mềm một bên. Mặt: mắt chấm đen nhỏ, mí nặng, lông mày đậm cong; cảm xúc nằm ở mí + lông mày + miệng + độ nghiêng đầu.
- Nét vẽ tay: nhân vật rung nét rất nhẹ theo nhịp 10 lần/giây; đứng yên thì gần như không cử động (chỉ chớp mắt), không đung đưa liên tục.
- Ánh sáng là các vầng tròn mềm: đèn bàn vàng, màn hình xanh, trăng, cửa neon. Mỗi cảnh **1 nguồn sáng chính**.
- **Màu nhấn chỉ dùng cho:** bóng đen cám dỗ, chữ cám dỗ, số bộ đếm sau khi sụp / lúc vừa đổi, gạch chân thẻ kết, dòng phụ 2 thẻ kết, băng đô khi tập, đường đồ thị. Không tô màu nhấn lên vật khác. **Màn đen không có vạch màu nhấn** (đối thủ không dùng; bật lại: `"line": true`).
- **Màu kể chuyện (1.10, kiểu DOPAMINE / LUST):** bối cảnh mất màu dần theo nhịp sa ngã, gần như xám ở đáy, rồi **màu trở lại** ở bước ngoặt; người, bóng đen, màn hình điện thoại và chữ luôn giữ màu → cám dỗ càng nổi trong thế giới xám. `phim.py` tự gán `grade` theo NHẠC (`sad` 85% → `dark` 40% + tối 10% → `none` 25% + tối 15% → `hope`/`rise` đủ màu, cảnh đầu tiên hồi màu dần 1,5 giây). Ghi tay trong file 01: `MÀU: xám | nhạt | đủ màu | hồi màu`. Tắt cả phim: `"colorArc": false`.

## Nhân vật
- Nhân vật chính giống đối thủ: **đầu tròn trơn màu kem, không tóc, không đội gì trên đầu**. `hoodie` là mũ hạ sau cổ; chỉ dùng `hooded` (trùm mũ) khi cảnh thật sự cần.
- Đề tài thức đêm / nghiện / kiệt sức: dùng mắt đỏ gân máu (`face: "bloodshot"` hoặc `"bloodshot": true`) ở các cảnh đáy và cận mặt, giống thumbnail.
- Nhân vật chính 1 preset suốt phim: `hoodie` (nghiện, đêm), chuyển `band` khi bắt đầu tập luyện (nhịp đứng lên) — đó là dấu hiệu thay đổi. Hoặc `hero` trần cho đề tài kỷ luật.
- **Tuổi (1.10):** bộ đếm `AGE` ≥ 55 hoặc CẢNH có "già / tóc bạc" → `age: "old"` tự gán: hơi khom, đầu cúi, lông mày bạc, 2 nếp nhăn trán, vệt tóc bạc sát đỉnh đầu. Quay về tuổi trẻ thì tự bỏ.
- **Bóng đen (`voice`)**: luôn cao hơn nhân vật chính một chút, đứng sau / cạnh (không bao giờ chắn trước người hùng: tự dời sang cạnh), **luôn quay mặt về phía người hùng** (kể cả người nằm giường), mắt đỏ xếch không miệng, viền phát sáng (nhịp sáng ở quầng, thân luôn đặc), tự cúi người về phía người hùng, đầu lắc chậm. **Tay vươn (`reach` / `point`) tự nhắm vào vai người hùng** (không chọc vào mặt, không chỉ vào khoảng không; tắt: `"aim": false`). Mờ dần / hiện dần vẽ qua lớp riêng → không lộ khớp tay chân. **Không khói** (trông như bong bóng; bật: `"smoke": true`). Cảnh gương: bóng đen đứng TRONG gương (`x: "mirror.in"`, `behind`, `inMirror`), gương nứt (`crackAt`) khi chữ cám dỗ hiện. Nhịp sa ngã: to, gần, tay đặt lên vai (`reach`). Nhịp đứng lên: nhỏ dần (`scale` 0.8 → 0.5), mờ dần (`out`), cuối cùng tan biến: `vanish` kiểu `burst` (vỡ tung khi người hùng phản đòn, + `vanish_burst`) hoặc `ash` (rã thành tro khi người hùng lặng lẽ buông, + `vanish_ash`). Chữ cám dỗ vỡ cùng.
- Bạn bè đội mũ màu, cô gái tóc bob khăn vàng: chỉ xuất hiện ở khoảnh khắc người thật (bước ngoặt), luôn trong ánh sáng ấm.

## Bố cục
- Nhân vật chính ở 1/3 trái hoặc phải, không đứng chính giữa trừ cảnh cô đơn (`void`, `hill`).
- Chữ kể chuyện **căn giữa** ở trên, không đè lên mặt. Hết chỗ ở trên thì tự xuống giữa dưới (không đẩy lệch sang bên). Nếu vẫn đè, đặt `pos: "bottom"`.
- Chữ cám dỗ sát đầu bóng đen, không đè lên mặt nhân vật chính; câu dài tự xuống 2 dòng; không bao giờ cắt mép khung. Khi gõ từng chữ, mép trái cố định (chữ không trượt).
- Bộ đếm luôn ở góc trên trái, cùng cỡ, cùng chỗ suốt phim. **Số đổi so với cảnh trước thì tự nảy + lóe màu nhấn 0,8 giây** (AGE 20 → 23, DAY 1 → DAY 2); người xem thấy thời gian trôi mà không cần đọc kỹ. Tắt: `hud.bump: false`.

## Máy quay và nhịp
- **Mọi cảnh đều có chuyển động**: đẩy chậm (`cam` zoom 1.0 → 1.1–1.3), nhân vật thở / chớp mắt / dồn trọng tâm (tự động, không đều), bóng đen nhịp sáng, chữ gõ.
- **Máy quay sống:** máy luôn trôi nhẹ như cầm tay (`hand`), cảnh có lớp xa/gần. Cảnh chạy: máy bám người (`follow`) hoặc người chạy tại chỗ + `scroll: "sync"` (kiểu đối thủ: nền trôi, vệt gió `fx: speed`). Pha nhanh tự nhòe.
- **Diễn bằng chuyển động, không bằng lật hình**: đổi tư thế, biểu cảm, hướng nhìn đều tự chuyển dần. Khoảnh khắc quan trọng thì cho nhân vật *làm* một việc: quay người (`facingAt`), quay lưng bỏ đi (`facingAt` + `walk`), gục đầu (`poseAt` → `headhold` → `knees`). Đi / chạy chân bám đất, có lấy đà và dừng có quán tính.
- Cảnh 3–8 giây; montage (lịch, bộ đếm chạy, chạy bộ) 4–6 giây; khoảnh khắc lặng 4–6 giây trên cận mặt.
- **Màn đen: 3–4 màn mỗi phim, 2–5 giây** (1 dòng ~2s, 2 dòng ~4–5s). Màn đen tự đẩy máy đều 8%, chữ hiện dần 0,8 giây + bụi trôi nên không đứng hình, nhưng 10 màn vẫn làm phim mất nhịp. Thẻ kết và màn kêu gọi cũng tự đẩy chậm. Màn kêu gọi ≤ 4 giây (đối thủ không có).
- **Mở đầu = màn đen 2–4 giây, 1–2 câu nghịch lý** (`>` dòng thường, `!` dòng đậm), rồi mới vào hình. Đối thủ 3/3 làm vậy.
- **Số liệu (1.10):** dùng mẫu `graph` (đồ thị cảm xúc vẽ dần, đầu phát sáng, đường nền nét đứt, điện thoại ở mỗi đỉnh) cho câu kiểu "Every cheap high comes with a crash." Tối đa 1–2 lần mỗi phim.
- Lặp lại **cùng một bố cục phòng ngủ** 4–8 lần trong phim, chỉ đổi giờ đồng hồ, lịch, ánh sáng, vị trí bóng đen → người xem thấy thời gian trôi.
- Cắt cứng là chính. `dip` (mờ đen 0,5–0,7 giây) giữa các nhịp lớn. `flash` 1 lần ở bước ngoặt.

## Cận cảnh
- Điện thoại: chiếm gần hết chiều cao, 2 tay cầm (1.10: mặc định tay tự nhiên: 4 ngón ngắn tròn màu kem, ngón cái lướt; tay cũ trông như công tắc gạt: `"hands": "classic"`), chữ kể chuyện tự đặt bên phải. Feed lướt nhanh cho "nghiện", chat cho "người thật", email cho "cái giá".
- Đồng hồ / lịch: dùng cho thời gian trôi và cú sụp (`timeAt`, `reset`).
- Cận mặt: dùng 2–4 lần mỗi phim, ở câu đau nhất và lúc quyết định.

## Nội dung nhạy cảm
- Lust: chỉ màn hình phát sáng, khối màu mờ, bóng neon. Không vẽ cơ thể, không chữ thô.
- Tự hại / tự tử: không minh hoạ thuốc, dao, độ cao, dây. Chọn hình ẩn dụ (bóng tối, căn phòng trống) và luôn kết bằng ánh sáng, người thật.
