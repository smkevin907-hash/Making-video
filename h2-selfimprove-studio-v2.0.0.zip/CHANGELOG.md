# Nhật ký thay đổi

## 2.0.0 — Chế độ CINEMATIC: hoạt hình 2D vector kiểu điện ảnh (mặc định), giữ legacy

Nguồn: phân tích khung hình + đo ffmpeg 2 phim tham khảo ("1-MINUTE", "Just 5 More Minutes"; chỉ học phong cách — không chép cảnh, thoại, bố cục, nhân vật) và 1 vòng chấm của giám khảo (I1–I12). Tên skill, lời gọi, lệnh, định dạng đầu ra giữ nguyên. Dự án cũ (không có `"mode"` trong `config.json`) dựng **y hệt 1.10 từng điểm ảnh**.

### Skill `lam-video-selfimprove`

| Thay đổi | File | Lý do | Kiểm bằng |
|---|---|---|---|
| Hai chế độ: `config.json` `"mode": "cinematic"` (mặc định khi tạo dự án mới; bộ `phim` 2D, 30 fps) và legacy (không ghi `mode`, bộ `dem` như 1.10). `"render": "3d"` = bộ `cine` (Three.js, tuỳ chọn) | `engine/player.js`, `tools/new_project.py` (`--mode`, `--render 2d\|3d`) | Phim tham khảo là hoạt hình 2D vector kiểu điện ảnh; giữ đường lui | md5 ảnh legacy khớp 1.10; `selfimprove-mau` không đổi |
| Bộ máy 2D: máy {x, y, z, r} có đường dịu + cầm tay theo seed, lớp + parallax, nhoè theo lớp (lớp tĩnh nướng sẵn, lớp động nhoè ở nửa độ phân giải), phối cảnh một điểm tụ vẽ tay, vầng sáng, vignette, hạt, chỉnh màu | `engine/flat/stage.js`, `engine/flat/persp.js` (mới) | Chiều sâu / ánh sáng như phim tham khảo mà vẫn tô phẳng | 62 s 1080p dựng ~100 s CPU; tất định (md5 2 lần dựng trùng) |
| Nhân vật rối: khối đen, viền xám lệch về phía sáng (2 phía), mắt bầu dục kem, lông mày xám, 37 biểu cảm; diễn xuất: nghiêng theo cảm xúc, cử chỉ khi nói, vuốt điện thoại, gõ phím, bóng đen lắc, dồn trọng tâm | `packs/phim/puppet.js` (mới) | Giám khảo I9–I10: nhân vật cứng, đầu kem lẫn lộn | ảnh tổng hợp; `--check` 0 lỗi |
| Bối cảnh cùng một kiểu vẽ: phòng ngủ (đêm / ngày / hy vọng, vệt nắng xiên, bóng tiếp đất), 10 nội thất, phố / thành phố / đồi, sân khấu tối `void` | `packs/phim/sets.js`, `packs/phim/places.js` (mới) | Không còn cảnh lùi kiểu legacy giữa phim | `selfimprove-phim` đủ mọi bối cảnh, 0 lỗi |
| Mẫu cảnh cùng tên / cùng args legacy, mỗi góc máy là một bố cục: toàn (cao / ngang / thấp), trung → cận, qua vai bóng đen, cận mặt nền nhoè, từ trên xuống, POV điện thoại + tay đen, poster, đồng hồ đổi tiêu điểm, màn đen hiện dần phòng mờ, đồ thị trộn lên phòng, CTA | `packs/phim/templates.js`, `screens.js`, `pack.js` (mới) | `shots.json` từ `phim.py` dùng ngay | `c2d-fivemin`, `selfimprove-phim` |
| Đạo diễn: coverage + chuyển cảnh có lý do (`iris`, `fadeThroughBlack`, `smashCut`, `matchCut`, `whipPan`, `zoomIntoProp`); tách góc dài > 2,8 s thành góc ~2,3 s, mọi góc có chuyển động, luân phiên góc, không 2 góc liền cùng cỡ + cùng góc | `packs/cine/director.js`, `packs/phim/director2d.js` (mới), `engine/player.js` | Giám khảo I1–I3: máy đứng, khung tĩnh | `do_nhip`: chuyển động 1.275, thay đổi lớn 0.84/s |
| Chữ 2 font theo phim tham khảo: thoại Comic Neue trên vệt tối theo phần chữ đang gõ (đậm theo độ sáng nền), màn đen / thẻ kết Lora; tự né đầu / thân / HUD; HUD góc trái, narration hạ khi có HUD | `packs/phim/ui2d.js` (mới) | Giám khảo I6, I11 | `--check` đo tương phản ≥ 4,5:1 |
| `--check` cinematic: glow cháy trắng trên đầu, poster cắt mép, tương phản chữ đo trên điểm ảnh thật (bỏ lúc chữ đang hiện / chuyển cảnh); màn đen / thẻ kết được giữ yên; người tiền cảnh bỏ qua kiểm che | `render.mjs` | QA tự động GĐ4 | 3 dự án thử 0 lỗi 0 cảnh báo |
| Nhoè (`ctx.filter`) nhân theo tỉ lệ dựng | `packs/phim/ui2d.js`, `sets.js`, `templates.js` | Dựng nháp `--scale 0.25` nhoè gấp 4 lần → đo sai | ảnh 0.25 / 1080p cùng bố cục |
| `tools/do_nhip.py` (mới): đo nhịp kiểu giám khảo (chuyển động TB, thay đổi lớn/s, khung trùng, đứng hình dài nhất ngoài màn chữ, khung gần đen), trả mã 1 nếu chưa đạt | `tools/do_nhip.py` | Tiêu chí nghiệm thu của giám khảo | fivemin: đạt 5/5 |
| `phim.py`: dòng `MÁY:` mới (cỡ / góc / chuyển động → `args.shot`, chỉ cinematic) và `CHUYỂN:` (kiểu + lý do → `in`); tóm tắt in góc máy + chuyển cảnh; chọn bộ theo `render` | `tools/phim.py` | Kịch bản điều khiển được máy | 5 kịch bản legacy cho `shots.json` trùng byte 1.10 |
| Dự án mẫu `projects/selfimprove-phim` (cinematic, cùng nội dung `selfimprove-mau`); `three` vào `dependencies` | `kit/projects/`, `package.json` | Tự thử sau cài đặt | `--check` 2460 khung 0 lỗi |
| Tài liệu: `SKILL.md` (2 chế độ, bước cinematic, đo nhịp), `references/cinematic.md`, `mau-canh-cinematic.md` (mới), `kiem-tra.md` (mục Cinematic), `cai-dat.md` (GPU chỉ cho 3D, tự thử cinematic), `phong-cach.md` (ghi rõ legacy) | `SKILL.md`, `references/` | | |

Còn biết: 9:16 dựng bằng legacy; mẫu `note` còn vẽ kiểu legacy; chưa có dáng già, nước mắt, bóng đen tan (`vanish`), `fx`, `act` dựng sẵn ở cinematic; quán cà phê chưa có ghế; nâng tạ chưa vẽ thanh tạ.

### Skill `kich-ban-selfimprove`

| Thay đổi | File | Lý do |
|---|---|---|
| Kho cảnh sinh lại: mục 8 `MÁY` (cỡ / góc / chuyển động mới) và mục 8b `CHUYỂN` (kiểu chuyển cảnh + lý do) | `references/kho-canh.md` | Trường mới của bộ dựng 2.0 |

## 1.10.0 — Sửa theo đối sánh "Five More Minutes" với 3 video đối thủ (DISCIPLINE, DOPAMINE, LUST VS LOVE)

Nguồn: phân tích khung hình + đo bằng ffmpeg trên "Five More Minutes" (dựng bằng 1.9.0, 4:31, 1080p) và 3 video đối thủ. Mỗi dòng dưới đây là một lỗi thấy được trong video, nguyên nhân trong mã và cách sửa. Dự án cũ muốn giữ y hệt: `"look": "classic"` (+ `"bars": "scope"` nếu muốn giữ dải đen).

### Skill `lam-video-selfimprove`

| Lỗi thấy trong video | Nguyên nhân | Sửa | File |
|---|---|---|---|
| Dải đen trên dưới 100% thời lượng; đối thủ 0/98 mẫu có dải đen. Mất ~26% khung, nhân vật nhỏ, cắt mép cửa sổ | `pack.js` mặc định `bars: "scope"` | Mặc định toàn khung; dải đen chỉ khi ghi `"bars": "scope"`. Dự án mẫu bỏ `bars` | `packs/dem/pack.js`, `projects/selfimprove-mau/config.json` |
| 34 giây đứng hình (14 đoạn ≥ 1,5s), toàn bộ ở 10 màn đen + thẻ kết + CTA; đối thủ 0 giây | Mẫu `black` / `card` / `cta` vẽ tĩnh hoàn toàn | Đẩy máy đều (màn đen 8%, thẻ kết / CTA 6%; tuyến tính, không có đoạn gần đứng yên), chữ màn đen hiện dần 0,8 giây, bụi trôi bật sẵn; CTA nhân vật to hơn + bụi + đẩy | `packs/dem/templates.js` |
| Vạch cam dưới mọi màn đen; đối thủ không có | `black.line` mặc định bật | Mặc định tắt (`"line": true` để bật) | `templates.js` |
| Dòng nhấn thứ 2 trên màn đen nhòe, phình (viền xám 11% cỡ chữ) | `big()` vẽ viền xám dày | Chữ trắng đậm sạch + bóng mềm, cỡ 92 (= 1,2 lần dòng đầu, như đối thủ) | `packs/dem/ink.js`, `templates.js` |
| Hai cụm "zzz", một cụm mọc từ đầu **bóng đen** | `fx: zzz` không ghi x/y lấy đầu bóng đen; `bed.zzz` vẽ thêm lần nữa | zzz không ghi x/y bay từ người đang ngủ; có `fx: zzz` thì bỏ `bed.zzz` | `templates.js` |
| Chữ kể chuyện lệch góc trái ("He had time.") | Né đồ vật bằng cách đẩy ngang 24% khung (phạt nhẹ) | Phạt lệch ngang nặng: hết chỗ ở trên thì xuống giữa dưới, chữ luôn căn giữa | `templates.js` |
| Chữ cám dỗ xa bóng đen ("five more minutes." cách ~450px), câu dài sát / tràn mép | Dải đen chặn vị trí trên đầu bóng đen; không có bước đẩy vào khung | Bỏ dải đen; thêm vị trí sát cạnh đầu theo bề rộng câu; câu > ½ khung tự xuống 2 dòng; mọi chữ tự đẩy vào trong khung | `templates.js`, `ink.js` |
| Chữ đang gõ trượt sang trái từng chữ cái | Gõ căn giữa theo phần đã hiện | Mép trái cố định theo cả dòng (chữ cám dỗ + kể chuyện) | `ink.js` |
| Bóng đen mờ dần lộ đường viền tay chân bên trong ("X-quang"); thân nhấp nháy | Vẽ từng bộ phận với độ mờ < 1, nhịp sáng bằng độ mờ thân | Mờ dần vẽ qua lớp riêng rồi dán; nhịp sáng chuyển sang quầng (`glowK`), thân luôn đặc | `templates.js`, `ink.js` (`asLayer`), `packs/dem/bean.js` |
| Khói trên đầu bóng đen trông như bong bóng | Chi tiết R24 bật mặc định | Tắt mặc định (`"smoke": true` / `"voiceSmoke": true` để bật) | `templates.js` |
| Tay bóng đen chọc vào mặt người hùng hoặc chỉ vào khoảng không | Tư thế `reach` là góc cố định ngang vai | Tay tự nhắm vào vai người hùng (IK 2 đoạn, khuỷu chùng), có tính người ngồi / nằm giường (`"aim": false` để tắt) | `bean.js`, `templates.js` |
| Bóng đen quay lưng với người nằm giường | `phim.py` lấy giữa khung làm vị trí người hùng khi người hùng nằm giường | Lấy đầu giường; bộ dựng tự quay bóng đen về người hùng khi không ghi `facing` | `tools/phim.py`, `templates.js` |
| Ngón tay cầm điện thoại như công tắc gạt / xấp giấy; ngón cái có "miếng dán" chữ nhật | Mặc định tay 1.3.0 (ngón xám viền đen + móng); hàm vẽ ngón viền nhầm hình bình hành đổ bóng thay vì viền ngón | Sửa lỗi viền (Path2D); mặc định tay tự nhiên: 4 ngón ngắn tròn màu kem, không móng / vạch khớp, ngón cái tự lướt ở feed; bỏ viền mép gốc ngón cái. Tay cũ: `"hands": "classic"` | `packs/dem/phone.js`, `templates.js` |
| Đồng hồ LED "1: 12" hở | Số 1 chiếm đủ bề rộng ô | Số 1 hẹp, dịch sát | `ink.js` |
| Bộ đếm AGE / DAY nhỏ, đổi số không ai để ý ("DAY 1" suốt phim) | Không có hiệu ứng khi đổi | Số khác cảnh trước tự nảy + lóe màu nhấn + gạch chân 0,8 giây; bóng mềm dễ đọc. Màn đen / đồ thị không hiện bộ đếm | `templates.js`, `tools/phim.py` |
| Một tông navy suốt 4 phút; đối thủ dùng màu kể chuyện (DOPAMINE rút màu → trả màu, LUST thế giới xám + cám dỗ hồng) | Không có cơ chế màu theo nhịp | `grade` (bão hoà / tối / nhuộm, đổi dần được) áp lên bối cảnh, người + bóng đen + màn hình + chữ giữ màu. `phim.py` tự gán theo NHẠC (sad 85% → dark 40% → none 25% → hope/rise đủ màu, cảnh đầu hồi màu dần 1,5s); `MÀU:` ghi tay; `"colorArc": false` tắt | `ink.js` (`worldGrade`), `templates.js`, `tools/phim.py` |
| Nhân vật 64 tuổi y hệt 20 tuổi | Không có dáng già | `age: "old"`: khom, đầu cúi, lông mày bạc, nếp nhăn, vệt tóc bạc; tự gán khi AGE ≥ 55 / CẢNH "già" | `bean.js`, `templates.js`, `tools/phim.py` |
| Không có cách thể hiện số liệu (đối thủ: đồ thị "cheap high → crash") | Thiếu mẫu | Mẫu mới `graph` (crash / spikes / climb / flat / điểm tự do; trục, đường nền, điện thoại ở đỉnh, nhãn); `phim.py` nhận "đồ thị / biểu đồ" | `templates.js`, `tools/phim.py` |
| Phim 4:31, 10 màn đen, không mở bằng câu nghịch lý, CTA 10 giây | Không có kiểm nhịp toàn phim; `phim.py` còn khuyên "cảnh cuối nên là KÊU GỌI" | `phim.py` cảnh báo: mở đầu không phải màn đen, > 3:20, > 4 màn đen, màn đen > 5s, KÊU GỌI > 4s, đồ thị < 4s; bỏ lời khuyên KÊU GỌI | `tools/phim.py` |
| `--check` không bắt được đứng hình hay chữ cắt mép | Chỉ kiểm bố cục | Đo đứng hình bằng điểm ảnh (160x90, cách 3 khung; ≥ 1,5s cảnh báo, ≥ 2,5s lỗi; ngưỡng `H2_STILL`); lỗi chữ cắt mép | `render.mjs` |

Tài liệu: `SKILL.md` (khung 16:9 toàn khung, luật vàng "đạt chuẩn đối thủ", việc tự có từ 1.10, quét lỗi mới), `references/phong-cach.md` (bảng số đo đối thủ, màu kể chuyện, tuổi, bóng đen, bố cục chữ, nhịp màn đen), `references/mau-canh.md` (`grade`, `graph`, `aim`, `smoke`, `age`, bộ đếm nảy, tham số mới của `black` / `card` / `cta` / `phone`), `references/kiem-tra.md` (lỗi mới, danh sách kiểm, cách giữ bản cũ).

### Skill `kich-ban-selfimprove`

| Thay đổi | File | Lý do |
|---|---|---|
| Thời lượng mặc định 3,5 → **3 phút** (đối thủ 2:38–2:51); > 3:20 chỉ khi người dùng yêu cầu | `SKILL.md` | "Five More Minutes" 4:31, các hồi tuổi 33–56 lặp nhau. |
| Nhịp hình theo đối thủ: mở bằng màn đen 2–4s 1–2 câu nghịch lý (`>` + `!`), 3–4 màn đen cả phim (2–5s), gộp các hồi giống nhau thành chuỗi dựng nhanh, dùng `NỀN: đồ thị` cho câu số liệu cảm xúc, KÊU GỌI ≤ 4s, `MÀU:` tuỳ chọn; mục tự kiểm tương ứng | `SKILL.md` | Một nửa lỗi nhịp sinh ra từ kịch bản. |
| Kho cảnh sinh lại: thêm `đồ thị, biểu đồ` → `graph` | `references/kho-canh.md` | Mẫu mới của bộ dựng. |

Đã đo: phim thử `tests/p3/01-PHIM-fivemin.txt` (12 cảnh, tái hiện đủ lỗi cũ, cố ý ghi cả `bed.zzz` lẫn `fx: zzz`). ffmpeg `freezedetect` (cùng ngưỡng đã đo bản gốc): **0 đoạn đứng hình** (bản gốc 14 đoạn / 34s); không dải đen; `--check` 0 cảnh báo đứng hình, còn 1 lỗi đúng (câu cám dỗ 7 từ đè cửa sổ). Hồi quy `phim.py` (1.9.0 → 1.10.0) trên 3 kịch bản cũ (82 cảnh): khác biệt duy nhất là `grade` mới thêm; chữ, thời lượng, nhân vật giữ nguyên. Dự án mẫu `selfimprove-mau`: `--check` 0 lỗi / 1.968 khung, mọi mẫu cảnh vẽ đúng.

## 1.9.0 — Nâng cấp kịch bản, nhóm P2: kênh và chuỗi (R14–R16)

### Skill `kich-ban-selfimprove`

| Mã | Thay đổi | File | Lý do |
|---|---|---|---|
| R14 | `KENH.md` trong thư mục người dùng: tên kênh, đuôi tiêu đề, câu ký tên cố định (dòng đầu màn KÊU GỌI hoặc thẻ kết), màu chủ đạo, màu nhấn riêng theo đề tài / chuỗi. Lần đầu dùng skill tạo file này (`kenh.py mau`). Công thức tiêu đề cân bằng: ≥ 5/10 tiêu đề mang dấu ấn kênh, ≥ 7/10 có từ khoá ngách, tối đa 3 tiêu đề theo mẫu đối thủ, ≤ 60 ký tự. `kenh.py kiem` kiểm tiêu đề trong 02, câu ký tên, màu nhấn. | `tools/kenh.py` (mới), `references/kenh-chuoi.md` (mới), `references/cau-truc.md`, `SKILL.md` | Tiêu đề 70% theo mẫu đối thủ, kênh không có dấu ấn riêng. |
| R15 | `series/<chuỗi>/SERIES.md` ghi hồ sơ từng tập (nhân vật, màu, bộ đếm, vật + trạng thái, khung, câu móc, câu cám dỗ đã dùng, thẻ kết). PART 2 đọc trước khi viết; `series.py kiem` báo lỗi khi đổi nhân vật / màu / nhãn bộ đếm, lặp câu cám dỗ (giống ≥ 85% hoặc câu ngắn nằm trọn trong câu dài), nhắc khi trùng khung / câu móc / thẻ kết. `series.py ghi` sau khi giao. | `tools/series.py` (mới), `SKILL.md` | PART 2 dễ lặp lại tập 1. |
| R16 | Tự chấm 1–5 theo 6 tiêu chí (câu móc, độ rõ ước mơ, cú sụp, khoảnh khắc người thật, độ mới so với đối thủ, độ đọc được khi tắt tiếng). Máy chấm `cham_diem.py` (dựa trên `kiem_truyen`, kiểm trùng, thời gian đọc chữ); dưới 4 phải sửa trước khi giao; `--ghi` thêm mục "Tự chấm" vào 02. | `tools/cham_diem.py` (mới), `SKILL.md` | Không có thước đo chất lượng trước khi giao. |
| — | Nhãn bộ đếm có số ≤ 9 ký tự; quy trình thêm bước 10–12 (kiểm kênh, kiểm chuỗi, tự chấm) và mục trong bảng tự kiểm. | `references/cau-truc.md`, `SKILL.md` | Gom luật mới vào quy trình. |

### Skill `lam-video-selfimprove` (chỉ `kit/tools/phim.py`)

| Thay đổi | Lý do |
|---|---|
| Màn KÊU GỌI: dòng chữ thứ hai thành dòng phụ của nút kêu gọi (dòng 1 = câu ký tên kênh). File chỉ có 1 dòng vẫn dựng như cũ. | Cần chỗ cho câu ký tên cố định của kênh. |

Đã đo: KENH.md mẫu "Rewired Mind" (đuôi "Rewired Mind Animated Short", ký tên "Rewire one night at a time.", màu teal). T8 — RESPAWN PART 2 (khung Vòng lặp, khác tập 1; câu móc hình ảnh mạnh + B câu hỏi; 39 cảnh, đúng 210 giây): giữ nhân vật hoodie, màu teal, bộ đếm DAY, quả bóng rổ; 8 câu cám dỗ mới không trùng 9 câu tập 1. `kiem_truyen`, `--dry-run`, kiểm trùng đối thủ, `series kiem`, `kenh kiem` đều sạch (dấu ấn kênh 7/10, từ khoá 10/10, mẫu đối thủ 1); tự chấm 6/6 tiêu chí 5/5. Làm hỏng có chủ đích (ACCENT pink, "just one more match." thay câu mới, bỏ câu ký tên, 7 tiêu đề mẫu đối thủ): máy bắt đủ cả 4. Mẫu TOMORROW vẫn ra y hệt.

## 1.8.0 — Nâng cấp kịch bản, nhóm P1b: đa dạng và chiều sâu câu chuyện (R9–R13)

### Skill `kich-ban-selfimprove`

| Mã | Thay đổi | File | Lý do |
|---|---|---|---|
| R9 | Thư viện 5 khung: Vực dậy (khung 6 nhịp cũ + nhịp Ước mơ), Tiếc nuối / cảnh tỉnh (bộ đếm tuổi chỉ tăng, kết bằng cái giá, hy vọng trao cho người xem), Hai cuộc đời song song (xen kẽ A / B, bộ đếm 2 dòng), Vòng lặp (kết ở cảnh mở đầu, khác 1 chi tiết), Thư gửi bản thân (lời thư là chữ trong phim nên chữ kể chuyện vẫn quá khứ ngôi ba). Mỗi khung: bảng nhịp %, bộ đếm, kết, vật biểu tượng gợi ý, luật máy kiểm. Bảng chọn khung theo đề tài (skill đề xuất + lý do, người dùng đổi được). Thủ pháp học từ thư viện phân tích (ẩn dụ nhìn thấy được, bộ đếm kèm tên việc, đếm theo giờ, màn hình tắt phản chiếu, đoạn giải thích giữa phim, gài – trả bằng người + vật). Danh sách vật biểu tượng bộ dựng vẽ được. | `references/khung-truyen.md` (mới) | Mọi phim cùng 1 đường đi, không làm được kết tiếc nuối. |
| R10 | Bắt buộc: ước mơ cụ thể gài bằng hình trong 15% đầu; 1 vật biểu tượng ≥ 3 lần, đổi trạng thái; ≥ 1 cặp gài – trả (trả ở 40% cuối, nghĩa mới). Hồ sơ đầu file `ƯỚC MƠ`, `VẬT`. | `references/cau-truc.md`, `SKILL.md` | Chỉ có bộ đếm gánh cả phim. |
| R11 | 5 kiểu câu móc (chữ màn đen, hình ảnh mạnh, cuối lên đầu, bộ đếm sụp rồi tua lại, câu hỏi thẳng). Mỗi kịch bản 2 câu móc khác kiểu: A trong phim, B là khối `# MÓC B` sẵn để thay (bộ dựng bỏ qua dòng `#`). | `references/cau-truc.md`, `SKILL.md` | Câu móc chỉ có 1 kiểu. |
| R12 | Mặc định 3,5 phút, cho phép 3–5 phút (`DÀI`); bản > 3 phút có ≥ 1 điểm móc lại ở 35–70%; không quá 40 giây liền không có biến cố mới. | `references/cau-truc.md`, `SKILL.md` | Phim dài hơn bị hụt hơi giữa phim. |
| R13 | Trước khi viết: bảng 3 hướng kể (khác khung hoặc góc nhìn), đánh dấu hướng nên chọn, dừng chờ người dùng chọn (trừ khi đã chỉ định khung / "viết luôn"). Đề tài tự hại / tuyệt vọng chỉ đưa khung kết hy vọng. | `SKILL.md` | Mỗi đề tài chỉ có 1 cách kể. |
| R9–R12 | Máy kiểm truyện `kiem_truyen.py`: đọc bảng nhịp + luật của khung thẳng từ `khung-truyen.md` (sửa bảng là sửa luật); đọc dòng `# TRUYỆN:` trong file 01 (nhịp, ước mơ, vật, gài, trả, sụp, người thật, móc lại, biến cố, khác, nhánh, tua lại); kiểm thứ tự + vị trí nhịp (±10%), ước mơ ≤ 15%, vật ≥ 3 lần đổi trạng thái, gài – trả, bộ đếm đúng kiểu khung, sụp, người thật, kiểu kết, câu "you" cuối, 2 câu móc + cấu trúc câu móc A, tổng thời lượng ±5%, móc lại, quãng 40 giây. Bảng tự kiểm áp theo khung (bỏ yêu cầu chung "đếm lại / đứng lên"). | `tools/kiem_truyen.py` (mới), `SKILL.md` | Không có cách kiểm câu chuyện. |
| — | `phan_tich.py`: gộp các khoảng im lặng sát nhau khi báo nhạc. | `tools/phan_tich.py` | Báo im lặng vụn (39–39%, 40–40%…). |

### Skill `lam-video-selfimprove` (chỉ `kit/tools/phim.py`)

| Thay đổi | Lý do |
|---|---|
| `--dry-run` cảnh báo nhãn bộ đếm có số dài hơn 9 ký tự (số bị dính vào chữ khi dựng). | Dựng thử "HOURS PLAYED 5,500" ra "HOURS PLAYED5,500". |
| Cảnh báo "động tác chưa hỗ trợ" trong CẢNH chỉ xét cảnh có người (bỏ báo nhầm "đồng hồ nhảy giờ", "tay viết chữ" ở cận cảnh). | Báo nhầm. |

Đã đo: thư viện phân tích thêm DOPAMINE (Day One, 495K, ×5,3; video người dùng gửi): 55 cảnh, 0/12 dòng chữ dài lọt vào file. T5 — cùng đề tài game, cùng ước mơ (đội bóng rổ trường), cùng vật (quả bóng rổ): RESPAWN khung Vực dậy 3:32 (42 cảnh) và LATER khung Tiếc nuối 5:00 (50 cảnh) khác nhau ở cả 7 nhịp, kiểu bộ đếm (DAY 231 → 0 → DAY 1 / AGE 16 → 31 chỉ tăng), câu móc (bộ đếm sụp / chữ màn đen), số phận quả bóng (về lại tay cậu / trao cho đứa trẻ), kết (hy vọng / tiếc nuối + "You still have time."); cả hai có ước mơ gài ≤ 3%, vật 4 lần, 1–2 cặp gài – trả, `kiem_truyen` + `--dry-run` + kiểm trùng sạch, dựng thật `--check` sạch 5.103 và 7.215 khung. T7 — LATER đúng 300 giây, móc lại ở 49% và 57%, quãng dài nhất không biến cố 18 giây. Làm hỏng có chủ đích 4 kiểu (bỏ móc lại, quãng 61 giây trống, vật 2 lần, ước mơ gài ở 24%): máy bắt đủ 4. Mẫu TOMORROW vẫn ra y hệt 1.5.0.

## 1.7.0 — Nâng cấp kịch bản, nhóm P1a: theo dõi kênh lớn (R4–R8)

Chỉ sửa skill `kich-ban-selfimprove`. Skill `lam-video-selfimprove` (bộ dựng) không đổi file nào. Hai công cụ mới chỉ cần Python 3.8+ (không cài thêm gói); phân tích video cần thêm ffmpeg.

### Skill `kich-ban-selfimprove`

| Mã | Thay đổi | File | Lý do |
|---|---|---|---|
| R4 | Thư mục `DOI-THU-SELFIMPROVE/` trong thư mục người dùng; `kenh.txt` tự tạo với Day One Films + Monk Mode Films, người dùng thêm / bớt dòng. | `tools/doi_thu.py` | Danh sách kênh cứng trong SKILL.md. |
| R5 | Tầng 1: `doi_thu.py quet` (RSS) → khi hỏng tự báo chuyển nguồn; Claude đọc trang `/videos` bằng trình duyệt (chữ hiển thị + thẻ link chuẩn, không đọc ytInitialData) rồi `nhap --nguon trinh-duyet`; trình duyệt hỏng thì tìm kiếm web `nhap --nguon tim-kiem` (tự loại video kênh khác theo thẻ tác giả). Mọi nguồn có mã video được làm giàu từ thẻ schema.org trên trang xem video (lượt xem, thích, ngày đăng, thời lượng, tag, ảnh); không đọc được thì giữ số ước tính (`ngay_uoc = 1`). Tính lượt xem / ngày, điểm vượt trội (÷ trung vị của chính kênh, tách video dài / short), đánh dấu `VUOT TROI` ≥ 2, `HUT` ≤ 0,5 (video < 7 ngày ghi "mới"). `video.csv` cộng dồn (không xoá video cũ, ghi ngày thấy đầu / cập nhật), `lich-su.csv` lưu mỗi lần quét, `lan-quet.csv` ghi nguồn + số video + lỗi. Cờ thử `--gia-lap-loi rss,trang-video`. | `tools/doi_thu.py` | Chỉ lấy tiêu đề + lượt xem bằng dữ liệu nội bộ trang, đổi giao diện là hỏng. |
| R6 | Tầng 2: `phan_tich.py cat` cắt cảnh tự động (so khung cách 0,25 giây, ngưỡng theo chính video vì phim nền tối đổi cảnh nhẹ), lấy khung (cảnh dài thêm 1 khung / 2,5 giây), ảnh tổng hợp 4×3 có nhãn, đo âm lượng / im lặng / nhịp ước; Claude đọc chữ trên ảnh (OCR bằng mắt), sửa ranh giới cảnh trong `doc.json`; `phan_tich.py ghi` dựng lại dàn cảnh (chỉ in ra, không lưu), phân loại theo bảng cố định (đề tài, khung truyện, câu móc, bộ đếm, cú sụp %, người thật, kết, vật biểu tượng, số cảnh, nhịp, công thức tiêu đề, chữ thumbnail), nối với `video.csv`, ghi `phan-tich/*.md` chỉ gồm bảng + tóm tắt lời mình + ≤ 3 câu trích ≤ 12 từ; từ chối ghi nếu lọt dòng chữ ≥ 4 từ hoặc cụm 6 từ của video; xoá bản chép tạm. Nhận cả ảnh chụp màn hình. | `tools/phan_tich.py` | Không phân tích được đối thủ kể chuyện thế nào. |
| R7 | `doi_thu.py bao-cao`: lần quét + nguồn, video mới từ lần quét trước, top vượt trội 90 ngày, đề tài / công thức tiêu đề đang ăn (số video, số kênh, ×TV trung vị, video tốt nhất), khung / kết / câu móc / bộ đếm từ thư viện phân tích, khoảng trống (ít người làm mà nổ, kênh làm dở trong khi kênh khác nổ, đề tài đang dày, đề tài đối thủ chưa làm), đề tài kênh mình đã làm (`projects/`), gợi ý lịch quét tuần (chỉ tạo khi người dùng đồng ý). Lưu `bao-cao/bao-cao-<ngày>.md`. | `tools/doi_thu.py`, `references/doi-thu.md` | Không có báo cáo xu hướng. |
| R8 | Gợi ý đề tài kèm bằng chứng (video đối thủ, lượt xem, ×TV) + góc khác biệt; tiêu chí sao thứ 5. File 01 thêm 4 dòng đầu `ĐỀ TÀI / KHUNG / KẾT / VẬT` (bộ dựng bỏ qua). `doi_thu.py trung-lap`: trùng 4/4 với 1 video đã phân tích → báo + gợi ý đổi ≥ 2 trong 4 (khung, kết, vật, đề tài gần mà đối thủ chưa dùng); dùng lại câu trích của đối thủ (cả ở thẻ kết) → lỗi; trùng tiêu đề → cảnh báo. Bước kiểm trùng thêm vào quy trình và bảng tự kiểm; kết quả ghi đầu 02-PACKAGE. | `SKILL.md`, `references/cau-truc.md`, `references/doi-thu.md`, `tools/doi_thu.py` | Dữ liệu đối thủ chỉ dùng lúc gợi ý đề tài. |

Đã đo (2026-10-26): RSS của YouTube trả 404 thật cho cả 2 kênh (trình duyệt cũng 404) → tự chuyển sang trình duyệt: Day One Films 14 video, Monk Mode Films 14 video (1 sắp công chiếu), 27/27 video lấy số chính xác từ trang video. Giả lập trang video hỏng: 14 video giữ số ước tính, điểm vượt trội lệch ≤ 0,01. Tìm kiếm web: 10 link, loại đúng 6 video kênh khác. Phân tích DISCIPLINE (Day One, 5,1M view, ×54,6): máy cắt 37 cảnh, người đọc tách thêm 7 → 44 cảnh, cắt mất 6,5 giây; file lưu 0/8 dòng chữ dài của video ngoài 3 câu trích; thử cố tình chép 1 câu vào tóm tắt → từ chối ghi. Kịch bản cố tình giống DISCIPLINE: bắt trùng 4/4 + chép câu ở thẻ kết + trùng tiêu đề với 2 kênh; bản đổi khung, kết, vật: không trùng.

## 1.6.0 — Nâng cấp kịch bản, nhóm P0: kịch bản khớp bộ dựng (R1–R3)

Plugin có 1 nhật ký chung; mục này ghi riêng phần của từng skill. Bộ dựng chỉ sửa `kit/tools/phim.py` (không đụng `engine/`, `packs/`, `render.mjs`, tài liệu của bộ dựng). Chỉ thêm: file 01 cũ chạy được, mẫu TOMORROW trong `cau-truc.md` ra `shots.json` y hệt bản 1.5.0.

### Skill `lam-video-selfimprove` (chỉ `kit/tools/phim.py`)

| Mã | Thay đổi | Lý do |
|---|---|---|
| R1 | Đọc thêm 4 trường tuỳ chọn ở dòng đầu cảnh: `NỀN` (bối cảnh / mẫu cận cảnh + chi tiết), `AI` (ai, vị trí số hoặc mốc, tư thế, biểu cảm, cầm đồ, chuyển động, `A → B` đổi giữa cảnh), `ĐỘNG TÁC` (động tác theo giây), `MÁY`. Có trường thì dùng đúng giá trị đó, không đoán từ `CẢNH`. Dòng đầu file `NHÂN VẬT: <preset>` = preset của "cậu". Thêm màn hình điện thoại màn khoá / đếm ngày / màn tắt, nền mờ sau điện thoại và cận mặt. | Mô tả văn xuôi bị đoán sai bằng từ khoá. |
| R1 | Sửa đường đoán cũ: (1) từ yếu (mưa, hoàng hôn, cửa, đèn rọi) xét sau tên nơi chốn → "quán cà phê đêm mưa" ra `cafe`; thêm khoảng trống → `void`, phòng khách / sofa → `sofa`, phòng tắm → `mirror`. (2) Tách mệnh đề theo chủ ngữ: hành động / biểu cảm của bạn bè, cô gái, mẹ, bố không gán cho nhân vật chính; người phụ đi tới thì người hùng đứng lệch trái, không đè nhau. (3) Cận mặt giữ biểu cảm (khóc, mắt đỏ, nước mắt, mồ hôi, ánh màn hình). (4) "đấm bao cát" ở phòng tập → thủ thế + đấm liên tục, bao cát đặt đúng tầm. (5) `THẺ KẾT: LUST. PART 2 / …` → `PART 2` sang ô `part`. | 4 lỗi đã kiểm chứng ở VẤN ĐỀ 4. |
| R2 | `--dry-run`: chỉ đọc, không ghi file, không cần numpy. In từng cảnh bộ dựng hiểu thành gì, rồi `LOI` (giá trị không có trong kho kèm gợi ý gần nhất, động tác chưa hỗ trợ kèm cách thay, mốc sai bối cảnh, không nhận ra bối cảnh, chữ không đủ giờ đọc, tin nhắn đặt ngoài cảnh điện thoại, SFX / nhạc sai tên, giây động tác vượt cảnh, trùng mã cảnh) và `CANH BAO` (nhiều bối cảnh trong 1 câu, CẢNH có tư thế / biểu cảm mà bộ đoán không ra, ngồi chỗ không có ghế, đầu ra ngoài khung, chữ quá 9 từ, cám dỗ viết hoa, thiếu bóng đen, thiếu KÊU GỌI, lệch thời lượng mục tiêu `--dai`). Có `LOI` thì trả mã 1. Khi dựng thật các lỗi này in thành `CANH BAO`. | Skill viết kịch bản không chạy thử bộ đọc. |
| R3 | `--kho [--kho-out file]`: in kho cảnh đọc thẳng từ mã bộ dựng (`packs/dem`: bối cảnh, mẫu cảnh, nhân vật, tư thế, biểu cảm, động tác, đồ cầm, màn hình điện thoại, ảnh feed, SFX), tách **tư thế tĩnh** / **động tác có chuyển động** / **chưa hỗ trợ + cách thay**, và đối chiếu `references/mau-canh.md` (hiện khớp 5/5 nhóm). | Kho cảnh viết tay hứa nhiều hơn bộ dựng làm được. |

### Skill `kich-ban-selfimprove`

| Mã | Thay đổi | File |
|---|---|---|
| R1 | Định dạng file 01 mới: mỗi cảnh ghi `CẢNH` + `NỀN` + `AI` (+ `ĐỘNG TÁC`, `MÁY`), dòng `NHÂN VẬT:` đầu file; ví dụ TOMORROW viết lại (đã qua `--dry-run` sạch lỗi). SFX bóng đen vỡ dùng `vanish_burst` / `vanish_ash`. | `references/cau-truc.md` |
| R2 | Quy trình thêm bước tự kiểm bằng máy (`phim.py --dry-run --dai`), chỉ giao khi `SACH LOI`, ghi 1 dòng kết quả kiểm. | `SKILL.md`, `references/cau-truc.md` |
| R3 | Bỏ kho cảnh viết tay; thay bằng `references/kho-canh.md` sinh từ `phim.py --kho` (tóm tắt ngắn còn trong `cau-truc.md`). Ghi rõ chỗ có ghế để ngồi, quán cà phê chưa có ghế. | `references/kho-canh.md` (mới), `references/cau-truc.md` |

Đã đo: mẫu TOMORROW 7/7 cảnh y hệt 1.5.0; file cũ tổng hợp 16 cảnh chỉ khác 1 cảnh (nụ cười của cô gái không còn gán cho người hùng); file R17 khác 2 cảnh ("khoảng trống" ra `void` thay vì mặc định phòng ngủ). 4 cảnh lỗi: bản cũ sai 4/4 + thẻ kết; bản mới (định dạng mới) đúng 5/5, cùng file cũ chạy phim.py mới đúng 4/5 và `--dry-run` báo đúng cảnh còn lại (không có tên bối cảnh). File thử 19 cảnh dùng mọi trường mới: `--dry-run` sạch, `render.mjs --check` sạch 2439 khung. File cố ý viết sai: bắt 13 lỗi kèm gợi ý.

## 1.5.0 — Đợt 4: giống phim mẫu DISCIPLINE (R19–R24)

Mặc định đổi sang kiểu vẽ mới. Ba công tắc quay về bản cũ: `"look": "classic"` (dáng, mặt, bối cảnh, đồng hồ, thẻ, chữ cám dỗ y hệt 1.4.0 — đã so từng điểm ảnh), `"anim": "smooth"`, `"details": false`. Không đụng `engine/`; `render.mjs` chỉ thêm luật cho `--check`.

| Mã | Thay đổi | File | Lý do |
|---|---|---|---|
| R19 | Chữ đặt sau né chữ đặt trước (chữ kể chuyện trước, chữ cám dỗ sau, tính cả chữ chưa / đã tắt nên không nhảy chỗ); cảnh không có bóng đen thì chữ cám dỗ đặt cạnh đầu người hùng. Bóng đen che > 30% thân người hùng thì tự đứng sang cạnh, quay mặt về phía người (`keepX: true` giữ chỗ). `--check` thêm luật "chữ đè chữ", "người bị che"; bỏ báo nhầm chân trượt khi chạy tại chỗ. Tay điện thoại mặc định về tay 1.3.0 (`hands: "new"` = tay 1.4.0). | `kit/packs/dem/templates.js`, `kit/render.mjs`, `kit/packs/dem/phone.js` | Phim mẫu: chữ đè chữ (s007), bóng đen che người (s008), bộ quét không bắt; tay 1.4.0 trông giả. |
| R23 | Chữ cám dỗ chữ tròn đỏ (`temptFont: "hand"` = viết tay). Đồng hồ số LED 7 đoạn. Thẻ kết chữ dày viền sáng, gạch chân lượn sóng. Gương oval trên bệ, nứt được (`crack`, `crackAt`), bóng đen đứng trong gương (`mirror.in` + `inMirror`). Cầu thang bậc bo tròn, núi đồi mềm màu nâu, phố bớt tím / ít cửa sáng, phòng ngủ tối giản (lịch / bàn chỉ hiện khi ghi), trăng hắt mạnh hơn. Bối cảnh mới `sofa`. Sửa người lơ lửng trên đồi (mốc `top` cao hơn đỉnh ~100 px). | `ink.js` (temptFont, seg7, wave), `phone.js`, `sets.js`, `templates.js`, `vanish.js` | Khác phim mẫu ở chữ, đồng hồ, thẻ, gương, bối cảnh; thiếu sofa; lỗi mốc đồi. |
| R20 | Dáng hạt đậu: đầu nhỏ hơn 16% dính liền thân (viền chung), eo thon, đáy tròn, tay chân thon, đầu tay tròn, viền mảnh hơn. Mặt mới: mắt chấm đen + mí nặng (xiên theo cảm xúc), lông mày cong dày, 17 biểu cảm mới (tổng 37), 10 kiểu miệng mới (nghiến răng, hét, ngáp, lè lưỡi, mím…), cử động nhỏ: liếc, chớp chậm, môi run, mày giật, đầu nghiêng, mở to mắt trước khi giật mình, dấu "!". Bóng đen mắt đỏ xếch không miệng, bỏ vòng đỏ dưới chân. Tay với đồng hồ trên giường chui ra từ chăn, luồn dưới cằm. | `bean.js`, `templates.js` | Đầu tròn tách thân như cây kẹo mút; mắt như đeo kính; biểu cảm nhạt; bóng đen cười trông vui. |
| R22 | Chạy: đổ người ~19°, gối nâng cao, tay đánh mạnh, vệt tốc độ sau lưng. Thủ thế / đấm: chân rộng gối chùng (chân chạm đúng sàn), xoay vai, đổ người; bao cát lõm, nét sọc, chớp sáng + tia đúng chỗ nắm đấm. Bóng đen cúi về phía người, đầu lắc chậm, tay vươn ra thu vào. | `bean.js` (GAIT2, POSES2, twist), `sets.js` (punchBag), `templates.js` | Chạy như đi nhanh, đấm thân cứng chân khép, bóng đen đứng như que. |
| R24 | Chi tiết tự bật: ánh màn hình hắt lên mặt khi cầm điện thoại, mồ hôi văng, bụi dưới chân khi chạy / ngã, hơi thở khi trời lạnh / mưa, khói đỏ mỏng quanh bóng đen, số đếm khi đấm / nâng tạ ≥ 3 lần, bụi trong luồng sáng, mưa bắn, đèn đường chập chờn, kim đồng hồ chạy. | `templates.js`, `sets.js`, `bean.js` | Hình sạch nhưng thiếu sống động. |
| R21 | Nhân vật rung nét theo nhịp 10 lần/giây (xoay rất nhẹ quanh bàn chân + độ dày viền), bụi trong cảnh nhảy theo nhịp đó; đứng yên thì gần như bất động; ngoại lệ vẫn thở nhanh + run: chạy, thở dốc, mặt `scared worried panic cry sob shock embarrassed`. Góc tối đậm hơn. Hạt nhiễu phim có nhưng **mặc định tắt** (`grain: 7` để bật). | `templates.js`, `bean.js`, `sets.js` | Phim mẫu: nét / bụi đổi mỗi 3 khung, nhân vật đứng yên; bản cũ đung đưa trơn liên tục. |
| Tài liệu | Kiểu vẽ + 3 công tắc, biểu cảm mới, bối cảnh sofa, gương, `keepX`, `count`, `hands`, luật quét mới. | `SKILL.md`, `references/mau-canh.md`, `phong-cach.md`, `kiem-tra.md` | Khớp mã mới. |

Đã đo: `--check` bản GỐC bắt 2/2 lỗi mới, bản mới sạch; dự án lỗi `t22` vẫn bắt đủ 6; phim mẫu sạch (1968 khung). Tay điện thoại trùng khít 1.3.0 (lệch 0,0). `look: classic` trùng khít 1.4.0 ở 32 tư thế. Chân trượt: đi 0,5 px, chạy 1,0 px (bằng GỐC). Nhịp nét khi đứng yên: đổi mạnh mỗi 2–3 khung như phim mẫu (GỐC: trôi đều từng khung). Phim mẫu dựng 62,9 / 62,9 giây so với 68,6 / 64,7 giây bản 1.4.0. Hạt nhiễu phim nếu bật: chậm thêm ~40% (do khâu nén video) nên để tắt.

## 1.4.0 — Đợt 3: tay cầm điện thoại, chữ tự né, quét lỗi, phim.py, cài gọn (R14–R18)

Tham số mới đều tuỳ chọn; `shots.json` cũ chạy được. Không đụng `engine/`. `tools/` dùng chung chỉ **thêm** (`--check`, `--gon`, `--sfx-only`, dòng "Kieu cai"); cài đầy đủ vẫn y như cũ.

| Mã | Thay đổi | File | Lý do |
|---|---|---|---|
| R16 | `node render.mjs --project … --check --scale 0.25`: dựng nhanh 1/3 số khung, đọc vị trí người / chữ / đồ vật, báo theo mã cảnh + giây kèm cách sửa, lưu `build/check.txt`. `LOI`: mốc không có trong bối cảnh, người ra ngoài khung (trừ khi đang đi ra), chữ đè mặt / người / đồ vật, chân trượt khi đi chạy, nhạc hụt. `CANH BAO`: `poseDur: 0`. | `kit/render.mjs`, `kit/packs/dem/templates.js` (ghi vị trí `LAY`), `kit/packs/dem/bean.js` (vị trí chân), `kit/packs/dem/sets.js` (vùng đồ vật) | Lỗi chỉ thấy khi xem phim; `--check` cũ luôn báo "Khong co loi". |
| R15 | Chữ kể chuyện và chữ cám dỗ tự tìm chỗ trống: né mặt, thân người (theo cả quãng đi trong cảnh), đầu trên giường, đồ vật của bối cảnh (cửa sổ, đồng hồ, lịch, gương, bảng, rổ…). Chữ cám dỗ bám quanh đầu bóng đen. Có `x`/`y` thì giữ nguyên chỗ ghi. Tắt: `"textAvoid": false`. | `templates.js` (pickSpot), `sets.js` (avoidOf) | Chữ đặt theo ô cố định nên đè người / đồ vật khi bố cục đổi. |
| R14 | Tay cầm điện thoại vẽ lại: da kem như nhân vật, lòng bàn tay, ống tay áo, 4 ngón có đốt + móng, ngón cái thon cong có móng; tay run nhẹ; ngón cái lướt (ấn → kéo → nhấc) khớp nhịp lướt feed. Điện thoại to và cân hơn. `"hands": "left"` một tay, `"classic"` tay cũ. | `kit/packs/dem/phone.js` (phoneHand), `templates.js` (mẫu phone) | Tay cũ là khối xám đặc, ngón không đốt, không chuyển động. |
| R17 | `phim.py` hiểu thêm: ném điện thoại (ngồi thì đứng dậy rồi ném), đứng dậy, gục, ngã, thở dốc sau chạy, bỏ đi, ngồi dậy trên giường, bóng đen vỡ / tan thành tro (có "đấm" thì tự thêm thế thủ + cú đấm), máy bám theo. Vai dang theo hướng khi quay người (hết dính tay vào thân lúc nhìn thẳng). Đầu người trên giường bằng cỡ đầu nhân vật. Nhạc mặc định khi không ghi: `curious`. | `kit/tools/phim.py`, `bean.js`, `templates.js` (BED_R), `kit/tools/mix.py` | Mô tả mới phải tự sửa tay `shots.json`; tay dính thân khi quay; đầu trên giường bé hơn hẳn. |
| R18 | Cài gọn ~260 MB (mặc định ngách này): `npm install --omit=optional`, `npx playwright install --only-shell chromium`, `python audio/build_audio.py --gon` (chỉ SFX, nhạc tự sinh khi trộn). `three`, bản đồ chuyển sang gói tuỳ chọn. Đầy đủ (~860 MB) = 3 lệnh cũ. `doctor.py` nhận ra kiểu cài. | `kit/package.json`, `kit/audio/build_audio.py`, `kit/packs/dem/audio.py`, `kit/tools/doctor.py`, `kit/tools/chromium.mjs` | Bản cũ tải ~860 MB, phần lớn gói `dem` không dùng. |
| Tài liệu | Cài gọn / đầy đủ, `--check`, chữ tự né, tay mới, cỡ đầu giường, câu `phim.py` hiểu. | `SKILL.md`, `references/cai-dat.md`, `kiem-tra.md`, `mau-canh.md`, `README.md` | Khớp mã mới. |

Đã đo: `--check` bắt 6/6 lỗi cài sẵn (bản cũ 0/6), phim mẫu sạch (1968 khung); chữ đè người / đồ vật 0/5 cảnh thử (bản cũ 2/5, đè tới 19,9%); 8/8 câu mô tả mới ra đúng động tác; cài gọn 256 MB (gói Node 18 + Chromium rút gọn 206 + SFX 32), dựng và trộn được, lên đầy đủ không cần xoá gì; phim mẫu dựng 66,5 / 69,7 giây so với 65,5 / 68,1 giây bản cũ (+2%); chân trượt khi đi tối đa 0,5 px; kịch bản cũ không có chữ ra gần như y hệt bản 1.3.0.

## 1.3.0 — Bonus: bóng đen tan biến chân thật

| Thay đổi | File | Lý do |
|---|---|---|
| Hiệu ứng tan biến mới `vanish` trên actor `voice`, kiểu `burst`: 0,35 giây lấy đà (vết nứt sáng gấp khúc lan xuyên tâm từ điểm bị đánh, bóng phồng nhẹ, chữ cám dỗ rung) → chớp trắng có tâm + tia sáng + vòng sóng + máy rung → **chụp đúng hình bóng đen lúc đó, cắt thành ~50 mảnh méo không đều** (khít nhau như chưa vỡ), bay ra theo hướng bị đánh, lực cản, xoay khác nhau, hơi bay lên, mép cháy nguội dần, tan thành tàn lửa trôi theo gió, khói mỏng → **chữ cám dỗ vỡ từng chữ cái** (trắng loá rồi về màu nhấn, xoay, trôi, tàn lệch nhịp). Tự nhòe chuyển động lúc vỡ. Mỗi phim vỡ một kiểu (hạt ngẫu nhiên theo vị trí + giây). | `kit/packs/dem/vanish.js` (mới), `kit/packs/dem/templates.js` (drawActor bọc, chữ, chớp, rung, nhòe), `kit/packs/dem/ink.js` (`tempt` có `shake`) | Bản cũ: 26 tam giác rỗng giống hệt bay ra từ 1 điểm cạnh đầu, thân bóng chỉ mờ đều, chớp trắng phẳng, chữ chỉ mờ đi, phim nào cũng vỡ y hệt. |
| Kiểu `ash`: rã dần từ chân lên thành tro (cả quầng sáng), mép đang rã cháy sáng mềm, tro bay theo gió, chữ trôi theo gió. | `vanish.js` | Khoảnh khắc lặng cần cách tan khác. |
| `fx: shards` (kịch bản cũ) **tự dùng `burst`**; `"style": "classic"` ra y hệt bản cũ. | `templates.js` | Phim cũ đẹp lên không cần sửa; vẫn quay về được. |
| Tiếng mới `vanish_burst` (nứt → nổ trầm → vỡ vụn → hút ngược, tự canh đúng giây vỡ) và `vanish_ash`. Tạo sau cùng nên mọi tiếng / nhạc cũ giữ nguyên từng byte. | `kit/packs/dem/audio.py` | Tiếng vỡ kính không hợp bóng tối tan biến. |
| Tài liệu. | `SKILL.md`, `references/mau-canh.md`, `phong-cach.md`, `am-thanh.md` | Khớp mã mới. |

Đã đo: cùng kịch bản `fx: shards`, cặp khung lệch nhất chiếm 19,7% chuyển động đoạn vỡ (bản cũ 45,7%, chớp trắng phẳng 1 khung); `style: classic` trùng khít bản 1.2.0; 58 file tiếng/nhạc cũ không đổi.

## 1.2.0 — Đợt 2: động tác kể chuyện, giường, máy quay, nhòe, nhạc (R8–R13)

Tham số mới đều tuỳ chọn; `shots.json` cũ chạy được. `engine/` chỉ **thêm** đường nhòe chuyển động (gói khác không khai báo thì vẽ y như cũ). `tools/mix.py` (dùng chung) có tuỳ chọn `"music": {"flow": false}` để trộn như cũ.

| Mã | Thay đổi | File | Lý do |
|---|---|---|---|
| R13 | Nhạc lặp nối liền (bỏ đoạn nhỏ/lớn dần có sẵn trong file, nối đuôi vào đầu bằng hoà âm); đổi loại nhạc thì hoà dần 2,5 giây quanh mốc, vào nhạc mới đúng đầu ô nhịp; quay lại loại nhạc cũ thì phát tiếp chỗ dở; đoạn liền nhau cùng loại gộp lại, đổi `gainDb` thì đổi dần; `none` vào/ra 1,5 giây. Tuỳ chọn `xfade`, `resume`, `flow`. Sửa phép làm mềm chạy chậm (`np.convolve` → trung bình trượt bằng tổng tích luỹ). | `kit/tools/mix.py` | File nhạc có sẵn đoạn tắt dần 3 giây → lặp thì im ~mỗi 77 giây; mỗi đoạn phát từ đầu bài; đoạn trước tắt hẳn rồi đoạn sau mới lên → hụt 8–27 dB; trộn phim 3 phút mất 537 giây. |
| R12 | Sinh nhạc `sad dark rise resolve hope` riêng cho từng phim theo tên phim (+ `music.seed`): giọng ±3 cung, vòng hợp âm, giai điệu, nhịp ±8%, nhạc cụ; lặp liền; san đều độ to theo ô nhịp (±3 dB). Lưu `build/music/`, tạo 1 lần. `"unique": false` dùng nhạc chung. | `kit/packs/dem/audio.py`, `kit/tools/mix.py` (gọi) | Mọi phim dùng chung 5 file nhạc (hạt ngẫu nhiên cố định). |
| R10 | Máy quay: bối cảnh chia lớp (trời 0.2, nhà xa 0.35, nhà gần 0.55, tường sau 0.88, đồ vật 1) trôi lệch khi máy đẩy/lia/rung; rung tay nhẹ liên tục `cam.hand` (`camHand`); `cam.follow` + `lead` bám người; tiền cảnh mờ `fg`; `city`/`street` nhà + đèn + đường trôi theo `scroll`, `scroll: "sync"` khớp bước chạy tại chỗ. | `kit/packs/dem/templates.js` (camera, drawFg), `kit/packs/dem/ink.js` (depth), `kit/packs/dem/sets.js` | Máy quay dời cả khung như 1 tấm phẳng, không rung tay, không bám người. |
| R11 | Nhòe chuyển động: vẽ 3–5 khung phụ trong nửa khoảng 1 khung rồi lấy trung bình, **chỉ ở pha nhanh** (chạy, rung máy, `fx: speed`, đấm/ném/đổ). Tuỳ chọn `blur`, `motionBlur`. Bao cát văng khi trúng đòn (`hits`, tự lấy từ `poseAt` `punch`). | `kit/engine/player.js` (chỉ thêm), `templates.js` (blurFrames), `sets.js` | Mỗi khung vẽ 1 thời điểm → pha nhanh nhảy cóc. |
| R9 | `bed`: chăn ôm theo thân và phồng theo nhịp thở; `side`/`rollAt` trở mình; `at`/`out`; `up` ngồi dậy (thân nhổm quanh hông, chăn tuột về chân, trượt ra mép giường). | `templates.js` (blanketBody, khối bed) | Người nằm chỉ là cái đầu + chăn cố định; không ngồi dậy được (ghép 2 cảnh → 2 người cùng hiện). |
| R8 | `act`: `standUp`, `sitDown`, `collapse`, `fall` (đổ sập, nảy, nằm), `throwPhone` (điện thoại bay vòng cung, xoay, rơi, tắt màn hình), `walkAway`, `pant` (thở dốc). Tư thế mới `pant throw release sitfwd lie`. `walk`/`run` nhận danh sách nhiều quãng, tự quay khi đổi hướng. | `templates.js` (buildActs, walkList, drawProps, actorState, drawActor), `kit/packs/dem/bean.js` (POSES, lift, heavy) | Không có động tác kể chuyện; điện thoại dính tay; một quãng đi mỗi cảnh. |
| Tài liệu | Tham số mới, bảng `act`, máy quay, nhạc. | `SKILL.md`, `references/mau-canh.md`, `am-thanh.md`, `phong-cach.md` | Khớp mã mới. |

Đã đo: phim 4 lần đổi nhạc và 1 loại nhạc 3 phút: 0 chỗ tụt quá 6 dB (bản cũ 4 và 2 chỗ, sâu tới 27 dB); hai phim khác tên: độ giống phổ nhạc 0,44 (bản cũ 1,00); trộn phim 3 phút 7,5 giây (lần đầu ~45 giây do sinh nhạc; bản cũ 537 giây); lia máy 192 px: nhà xa dịch 58 px, nhà gần 96 px (bản cũ đều 192); phim mẫu dựng 80 giây so với 87 giây bản cũ.

## 1.1.0 — Đợt 1: chuyển động mượt (R1–R7)

Chỉ sửa skill `lam-video-selfimprove`. Skill `kich-ban-selfimprove` giữ nguyên. Mọi tham số mới đều tuỳ chọn; `shots.json` cũ chạy được không cần sửa. Không đụng `engine/`.

| Mã | Thay đổi | File | Lý do |
|---|---|---|---|
| R1 | Khi nhân vật đứng yên, không truyền cả cụm `walk`/`run` `{to, at, dur}` vào nữa; nhân vật chỉ nhận tốc độ là con số. `run: {speed}` không có `to` = chạy tại chỗ. | `kit/packs/dem/templates.js` (drawActor), `kit/packs/dem/bean.js` | Cả cụm bị dùng làm tốc độ nên góc tay chân tính ra giá trị không hợp lệ → trước và sau quãng đi chỉ còn đầu + thân. |
| R2 | Tìm Chromium ở mọi kiểu thư mục (`chrome-linux64`, `chrome-linux`, `chrome-win64`, `chrome-win`, mac, headless shell), trong `PLAYWRIGHT_BROWSERS_PATH` và thư mục mặc định, bản mới thử trước. Thêm biến `H2_CHROMIUM`. `doctor.py` mở thử Chromium thật bằng đúng cách tìm đó. | `kit/tools/chromium.mjs` (mới), `kit/render.mjs` (hàm launch), `kit/tools/doctor.py` | Bản cũ chỉ tìm `chrome-linux`. `doctor.py` báo OK hễ có biến `PLAYWRIGHT_BROWSERS_PATH`, kể cả khi không có Chromium (lỗi thứ tự phép tính). |
| R3 | Tư thế (`poseAt`) chuyển dần 0,3–0,75 giây tuỳ độ lớn: lấy đà 6% → tới đích → vượt ~10% → dội về; đầu theo trễ nhịp 0,07 giây; đổi mốc khi đang chuyển thì nối tiếp. Tuỳ chọn: số thứ 3 trong mốc, `poseDur` (0 = như cũ). Áp dụng cho actor, mẫu `face`, nhân vật vẫy tay ở `cta`. | `bean.js` (easePose, poseDur), `templates.js` (poseNow) | Bản cũ đổi tư thế trong 1 khung. |
| R4 | Biểu cảm (`faceAt`) chuyển dần ~0,32 giây: mí, mày, con ngươi, hướng mắt chuyển đều; miệng nét uốn dần, miệng há mở/khép dần; nước mắt, mồ hôi, quầng thâm hiện dần; chớp mắt đúng lúc đổi mặt. Chớp mắt ngẫu nhiên 2,2–6 giây, thỉnh thoảng chớp đôi, nhắm nhanh mở chậm, có khung nhắm dở, mỗi nhân vật lệch nhịp nhau; lông mày vẫn hiện khi chớp. Tuỳ chọn: `faceDur`, `blink: false`. Có cả ở `bed`. | `bean.js` (face, blinkAt), `templates.js` (faceNow) | Bản cũ đổi mặt trong 1 khung, chớp đều đúng 3,7 giây, mắt nhắm/mở tức thì, mất lông mày lúc chớp. |
| R5 | Đi/chạy mới: nhịp bước tính theo quãng đường nên chân trụ đứng yên trên sàn; chân bước nhấc lên rồi đặt xuống; gối gập; hông thấp khi hai chân chạm đất, cao khi chân lướt qua; tay vung ngược chân, trễ nhịp. Độ dài bước tự chỉnh để dừng đúng lúc hai chân khép. Tăng tốc lúc đầu, giảm tốc lúc cuối (`ramp`, `ease`). Bước đầu chân sau nhấc lên rồi mới đưa đi. Vào/ra dáng đi không để chân lún xuống sàn. Thêm `walk.back` (đi lùi). | `bean.js` (gait, ik, footRel, hipAt), `templates.js` (travel, actorState, drawActor) | Bản cũ: nhịp bước chạy theo đồng hồ, không theo quãng đường → chân trượt tới 80 px, lơ lửng trung bình 9 px (chạy 22 px). Hông nhô cao nhất đúng lúc chân dạng rộng (ngược thực tế), vọt lên 70% tốc độ trong 1 khung. |
| R6 | Hướng nhìn đổi dần trong 0,3 giây (mặt trượt qua chính diện, tay chân thu vào rồi sang bên kia, nhún gối nhẹ). `facingAt`, `turnDur`. Có `facing` ngược hướng đi thì tự quay trước khi bước. | `templates.js` (facingNow), `bean.js` (squat: nhún gối giữ chân tại chỗ) | Bản cũ lật trái/phải tức thì, không quay được trong cảnh; mặt ngược hướng đi thì trượt lùi. |
| R7 | Chuyển động phụ: thở không đều; đứng yên thì dồn trọng tâm, đầu nhích rất nhẹ (`idle: false` để tắt); lấy đà (khuỵu gối, ngả nhẹ) 0,25 giây trước khi đi; nghiêng theo gia tốc; tới nơi chúi nhẹ rồi lấy lại thăng bằng; đầu nảy trễ nhịp khi đi; đuôi băng đô bay theo tốc độ. | `bean.js`, `templates.js` | Bản cũ thở đều 1 nhịp, băng đô đứng hay chạy cũng bay như nhau, không có quán tính. |
| Tài liệu | Tham số mới, ví dụ "quay lưng bỏ đi", ghi chú Chromium, lỗi thường gặp. | `SKILL.md`, `references/mau-canh.md`, `references/cai-dat.md`, `references/kiem-tra.md`, `references/phong-cach.md` | Khớp với mã mới. |

Đã đo: chân trụ trượt tối đa 0,5 px (đi tới, đi lùi, chạy) so với 80 px bản cũ; dựng phim mẫu 82 giây 1080p không chậm hơn (56,6 giây so với 58,6 giây bản cũ, cùng máy).
