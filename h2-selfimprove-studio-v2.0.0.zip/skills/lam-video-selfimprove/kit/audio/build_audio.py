"""build_audio.py — tao thu vien SFX va nen nhac bang code (chay 1 lan sau khi cai). Can numpy, scipy, soundfile.
Sau synth.py + music.py, chay them packs/<ten>/audio.py cua tung bo phong cach (neu co) de tao nhac/SFX rieng cua ngach.
--gon (cai gon cho goi dem): chi tao SFX (chung + rieng goi); nhac sinh rieng tung phim luc tron (tools/mix.py), khong tao san."""
import glob, os, subprocess, sys
D = os.path.dirname(os.path.abspath(__file__)); GON = "--gon" in sys.argv
extra = sorted(glob.glob(os.path.join(os.path.dirname(D), "packs", "*", "audio.py")))
if GON: extra = [f for f in extra if "--sfx-only" in open(f, encoding="utf-8").read()]
for f in [os.path.join(D, "synth.py")] + ([] if GON else [os.path.join(D, "music.py")]) + extra:
    print(">>", os.path.relpath(f, os.path.dirname(D))); r = subprocess.run([sys.executable, f] + (["--sfx-only"] if GON and f in extra else []), cwd=D)
    if r.returncode: sys.exit(f"Loi khi chay {f}")
print("Xong: audio/sfx" + ("" if GON else " va audio/music"))
