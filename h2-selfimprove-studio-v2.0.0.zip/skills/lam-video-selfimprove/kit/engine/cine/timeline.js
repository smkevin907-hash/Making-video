// timeline.js — che do cinematic: thoi gian la ham thuan cua t (giay). Khong doc gio that, khong Math.random.
// track(t, keys): moc [[giay, gia tri, easing?], ...] (gia tri so hoac mang so; easing cua doan KET THUC o moc do)
// spring(s, o): buoc nhay co lo xo (vuot qua roi doi ve) tinh dong theo giay da troi s -> cung t luon cung ket qua
// quant(t, fps): luong tu hoa thoi gian (vd 12 fps cho nhan vat phu / do vat: "animation co chu dich"); KHONG dung cho may, chu, anh sang
import { clamp, lerp } from '../core.js';

export const EASE = {
  linear: (k) => k,
  in: (k) => k * k,
  out: (k) => 1 - (1 - k) * (1 - k),
  inOut: (k) => (k < 0.5 ? 2 * k * k : 1 - Math.pow(-2 * k + 2, 2) / 2),
  cubic: (k) => (k < 0.5 ? 4 * k * k * k : 1 - Math.pow(-2 * k + 2, 3) / 2),          // easeInOutCubic: mac dinh cua may
  cubicOut: (k) => 1 - Math.pow(1 - k, 3),
  cubicIn: (k) => k * k * k,
  sine: (k) => 0.5 - 0.5 * Math.cos(Math.PI * k),
  expoOut: (k) => (k >= 1 ? 1 : 1 - Math.pow(2, -10 * k)),
  // lay da nhe (lui 4%) roi vuot qua va doi ve: cu chuyen dong co anticipation + overshoot
  antic: (k) => (k <= 0 ? 0 : k >= 1 ? 1 : k < 0.18 ? -0.04 * Math.sin(Math.PI * k / 0.18) : spring01((k - 0.18) / 0.82, 0.55)),
  spring: (k) => spring01(k, 0.45),
};
export const easeOf = (n) => (typeof n === 'function' ? n : EASE[n] || EASE.cubic);

// dap ung buoc cua lo xo tat dan (zeta < 1), chuan hoa: k 0..1 -> 0..1 (vuot qua roi doi ve, ket thuc dung 1)
function spring01(k, zeta = 0.45) {
  if (k <= 0) return 0; if (k >= 1) return 1;
  const w = 9.5, s = k, wd = w * Math.sqrt(1 - zeta * zeta);
  const y = 1 - Math.exp(-zeta * w * s) * (Math.cos(wd * s) + (zeta / Math.sqrt(1 - zeta * zeta)) * Math.sin(wd * s));
  return lerp(y, 1, k * k * k);   // ep ve dung 1 o cuoi doan
}
// lo xo theo giay thuc: s = giay tu luc bat dau, omega = do cung (rad/s), zeta = giam chan
export function spring(s, o = {}) {
  const { omega = 14, zeta = 0.42 } = o;
  if (s <= 0) return 0;
  if (zeta >= 1) return 1 - Math.exp(-omega * s) * (1 + omega * s);
  const wd = omega * Math.sqrt(1 - zeta * zeta);
  return 1 - Math.exp(-zeta * omega * s) * (Math.cos(wd * s) + (zeta / Math.sqrt(1 - zeta * zeta)) * Math.sin(wd * s));
}

export function track(t, keys, def = 'cubic') {
  if (!keys || !keys.length) return undefined;
  if (t <= keys[0][0]) return keys[0][1];
  for (let i = 1; i < keys.length; i++) {
    if (t <= keys[i][0]) {
      const [t0, a] = keys[i - 1], [t1, b, e] = keys[i], k = easeOf(e || def)(clamp((t - t0) / Math.max(1e-6, t1 - t0)));
      return Array.isArray(a) ? a.map((x, j) => lerp(x, b[j], k)) : lerp(a, b, k);
    }
  }
  return keys[keys.length - 1][1];
}

export const quant = (t, fps = 12) => Math.floor(t * fps + 1e-6) / fps;

// noise mem 1 chieu co seed (gia tri -1..1), dung cho may cam tay, nhap nhay anh sang, rem bay
export function noise1(x, seed = 0) {
  const h = (n) => { const s = Math.sin(n * 127.1 + seed * 311.7) * 43758.5453; return s - Math.floor(s); };
  const i = Math.floor(x), f = x - i, u = f * f * f * (f * (f * 6 - 15) + 10);
  return lerp(h(i), h(i + 1), u) * 2 - 1;
}
// tong 2 quang tan so (mem, khong lap)
export const fbm1 = (x, seed = 0) => noise1(x, seed) * 0.7 + noise1(x * 2.13 + 17.3, seed + 5) * 0.3;

// PRNG co seed (mulberry32): rng(seed)() -> 0..1
export function rng(seed = 1) {
  let a = (Math.floor(seed * 2654435761) >>> 0) || 1;
  return () => { a = (a + 0x6d2b79f5) >>> 0; let t = a; t = Math.imul(t ^ (t >>> 15), t | 1); t ^= t + Math.imul(t ^ (t >>> 7), t | 61); return ((t ^ (t >>> 14)) >>> 0) / 4294967296; };
}
// chop mat tat dinh: 0 = mo, 1 = nham. Khoang cach 2–5 giay theo seed, thinh thoang chop doi
export function blink(t, seed = 1) {
  const r = rng(seed * 7 + 3); let at = 0.6 + r() * 2;
  while (at < t + 0.3) {
    const d = t - at;
    if (d >= 0 && d < 0.2) return d < 0.06 ? d / 0.06 : d < 0.09 ? 1 : 1 - (d - 0.09) / 0.11;
    const dbl = r() < 0.18; if (dbl) { const d2 = t - (at + 0.28); if (d2 >= 0 && d2 < 0.2) return d2 < 0.06 ? d2 / 0.06 : d2 < 0.09 ? 1 : 1 - (d2 - 0.09) / 0.11; }
    at += 2 + r() * 3;
  }
  return 0;
}
