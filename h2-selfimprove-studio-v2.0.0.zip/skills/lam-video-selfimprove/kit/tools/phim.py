"""phim.py — phim KHONG LOI DOC: doc file kich ban canh (01-PHIM-<slug>.txt) -> story/shots.json nhap (thoi luong, chu, bo dem, nhac, SFX, mau canh doan san).
  python tools/phim.py --project projects/<ten> --phim "<01-PHIM-<slug>.txt>" [--force]
  python tools/phim.py --phim "<01-PHIM-<slug>.txt>" --dry-run [--dai 3.5]    chi kiem tra, KHONG ghi file: bao canh hieu sai, chu thieu gio doc,
                                                                                gia tri khong co trong kho, tong thoi luong. Con LOI thi tra ma 1.
  python tools/phim.py --kho [--kho-out <file.md>]                              in kho canh doc thang tu ma bo dung (packs/dem) + doi chieu references/mau-canh.md

Dinh dang 01-PHIM (moi canh 1 dong dau + cac dong chu):
  TITLE: DISCIPLINE                (dau file, tuy chon)
  ACCENT: red | pink | amber | teal
  NHÂN VẬT: hoodie                 (dau file, tuy chon: preset cua "cậu" trong truong AI va can mat; mac dinh hero)
  [B07] 5s | CẢNH: phòng ngủ đêm, đồng hồ 5:00 kêu, cậu nằm ngủ | HUD: DAY 1 | NHẠC: sad | SFX: alarm_beep@0.3, whoosh_mid
  > Every day started the same.        chu ke chuyen (trang)
  ~ just five more minutes...          giong cam do (chu viet tay mau nhan)
  " [girl] hi.                         bong bong loi noi ([ai] tuy chon, mac dinh hero)
  ! 30 minutes later...                chu to giua man hinh
  @ jay: day 150!!                     tin nhan den (canh dien thoai)
  @me: i relapsed.                     tin nhan minh gui
  {2.5} > He didn't.                   {giay} = hien o giay thu may cua canh (tuy chon)
  # ghi chu                            bo qua
Truong ghi ro (tu 1.6.0, deu tuy chon; co thi dung dung gia tri ghi, khong doan tu CẢNH; danh sach gia tri: --kho):
  NỀN: quán cà phê[, chi tiết]         boi canh hoac mau can canh: cận điện thoại, chat | cận đồng hồ, 11:59 -> 12:00 | cận lịch | cận mặt | sổ tay | màn đen
  AI: hoodie@0.35 ngồi, buồn; friend@0.9 đi tới 0.5, vui     moi nguoi 1 cum (cach nhau ";"): preset[@x | @moc] tu the, bieu cam, cam do, chuyen dong
  ĐỘNG TÁC: hoodie đứng dậy 1.5s; friend vẫy tay 2s; bóng đen vỡ 3.2s     moc theo giay cua canh
  MÁY: đẩy chậm vào mặt | đẩy chậm | kéo ra | lia trái | lia phải | bám theo | rung 2s | cầm tay | đứng yên
       2.0 (chỉ cinematic): toàn cảnh rộng | toàn thân | trung cảnh | cận trung | cận cảnh | đặc tả ; qua vai | góc thấp | góc cao | từ trên xuống | ngang mắt | pov ;
       dolly vào | dolly ra | trượt ngang | xoay quanh | nâng máy | nghiêng máy | đẩy vào cận
  CHUYỂN: cắt | cắt sốc | match cut | iris | lia nhanh | zoom vào đồ vật | qua đen | mờ đen | chớp trắng  [+ "vì <lý do>"]   (2.0; không ghi: cinematic tự chọn)
HUD: "DAY 47" | "DAY 3..30" (dem dan) | "DAY 412 -> 0" (gach ve 0) | "SEEN 1,388; KNOWN 0" (2 dong) | "-" (tat). Khong ghi = giu nhu canh truoc.
NHẠC: sad | dark | rise | resolve | hope | none. Khong ghi = giu nhac dang chay.
Dau dong dac biet: "THẺ KẾT: WORD. [PART 2] / dong phu / dong phu mau nhan" (PART N tu tach sang o part), "KÊU GỌI" -> mau card / cta
  (KÊU GỌI: dong chu 1 = cau chinh, dong chu 2 neu co = dong mau nhan ben duoi nut).
"""
import argparse, difflib, json, os, re, sys, unicodedata
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
try: from common import read_json, write_json
except ImportError:   # may chi viet kich ban (khong co numpy): --dry-run / --kho van chay
    def read_json(path, default=None):
        if not os.path.exists(path): return default
        with open(path, encoding="utf-8") as f: return json.load(f)
    def write_json(path, obj):
        os.makedirs(os.path.dirname(os.path.abspath(path)), exist_ok=True)
        with open(path, "w", encoding="utf-8") as f: json.dump(obj, f, ensure_ascii=False, indent=1)
try: sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except (AttributeError, ValueError): pass

ap = argparse.ArgumentParser(); ap.add_argument("--project"); ap.add_argument("--phim"); ap.add_argument("--force", action="store_true")
ap.add_argument("--dry-run", action="store_true", help="chi kiem tra, khong ghi file"); ap.add_argument("--dai", type=float, help="thoi luong muc tieu (phut)")
ap.add_argument("--kho", action="store_true", help="in kho canh cua bo dung"); ap.add_argument("--kho-out")
a = ap.parse_args(); P = a.project; DRY = a.dry_run
nfc = lambda s: unicodedata.normalize("NFC", s)
low = lambda s: nfc(s).lower()

# ---------- kho: doc thang tu ma bo dung (packs/dem) nen luon khop ban dang cai; khong thay packs/dem thi dung danh sach ban 1.5.0
PACK = os.path.normpath(os.path.join(HERE, "..", "packs", "dem"))
def _src(n):
    try:
        with open(os.path.join(PACK, n), encoding="utf-8") as f: return f.read()
    except OSError: return ""
def _body(src, head):
    i = src.find(head); return src[i:src.find("\n}\n", i)] if i >= 0 else ""
def _arr(src, name):
    m = re.search(r"export const " + name + r"\s*=\s*\[(.*?)\];", src, re.S); return re.findall(r"'(\w+)'", m.group(1)) if m else []
def _obj(src, name):
    i = src.find("export const " + name + " = {"); return re.findall(r"^  (\w+)\s*:", src[i:src.find("\n};", i)], re.M) if i >= 0 else []
_B, _T, _S, _A, _F = (_src(n) for n in ("bean.js", "templates.js", "sets.js", "art.js", "phone.js"))
_D = {
    "set": "black void bedroom city street lockers classroom court cafe gym stairs hill mirror sofa kitchen doorway",
    "tpl": "scene phone clock calendar face note black card cta graph",
    "who": "hero band hoodie hooded friend friend2 friend3 girl mom dad kid ghost voice",
    "pose": "stand relaxed slump phone reach point wave cheer fist headhold facepalm arms shrug hug guard punch lift sit sitphone sitdesk sitsad knees kneel crouch climb open umbrella carry pant throw release sitfwd lie",
    "face": "neutral tired sleepy sleep sad cry worried scared shock angry determined effort smile happy smirk empty guilty bloodshot haunted grin hopeful relieved proud embarrassed disgusted annoyed skeptical exhausted yawn dazed panic sob shout thinking tempted grit lonely",
    "act": "standUp sitDown collapse fall throwPhone walkAway pant",
    "hold": "phone umbrella book ball bag cup",
    "screen": "feed reel chat email lock counter off",
    "art": "ramen car burger pizza sneakers dog cat beach mountain sunset gym watch money game coffee city party selfie girl donut cake",
}
_L = {"set": re.findall(r"case '(\w+)':", _body(_S, "export function set(")), "tpl": _arr(_T, "TEMPLATE_LIST"), "who": _obj(_B, "CAST"), "pose": _obj(_B, "POSES"),
      "face": _arr(_B, "FACES"), "act": re.findall(r"e\.do === '(\w+)'", _body(_T, "function buildActs(")), "hold": re.findall(r"what === '(\w+)'", _body(_B, "function holdItem(")),
      "screen": sorted(set(re.findall(r"\b(?:screen|sc|s|scr) === '(\w+)'", _F))), "art": _arr(_A, "ARTS")}
KHO = {k: (_L[k] or _D[k].split()) for k in _D}; LIVE = all(_L[k] for k in _D)
_SFX_D = ("alarm_beep alarm_long boom_deep breath_in cash_register clock_tick crowd_cheer ding_high ding_soft door_open downer flash_hit footsteps glass_shatter glitch heartbeat "
          "impact_heavy impact_light impact_punch msg_sent notif_msg page_flip phone_ring phone_vibrate pop pop_low punch_bag rain_loop riser_2s riser_4s slowmo_ring sting_low "
          "tempt_swell tempt_whisper terminal_blip terminal_typing thud_soft tick ting_idea type_key typing_2s ui_click vanish_ash vanish_burst whoosh_fast whoosh_long whoosh_mid whoosh_reverse whoosh_tiny").split()
try: SFX = sorted({re.sub(r"_hitAt\d+ms$|_\d+chars$", "", os.path.splitext(f)[0]) for f in os.listdir(os.path.join(HERE, "..", "audio", "sfx")) if f.endswith(".wav")}) or _SFX_D
except OSError: SFX = _SFX_D
MUSIC = ["sad", "dark", "rise", "resolve", "hope", "none"]; MUSIC_FULL = ["curious", "wonder", "tension", "emotional", "triumph", "mystery"]   # MUSIC_FULL: chi co khi cai day du
GLOW = "#9fb6ff"

# ---------- ten tieng Viet -> ma bo dung (cum dai khop truoc). Kiem tra lai bang --kho: ma nao khong con trong bo dung thi bao
NEN_VI = [("phòng ngủ", "bedroom"), ("giường", "bedroom"), ("thành phố", "city"), ("đường phố", "city"), ("đường chạy", "city"), ("phố mưa", "street"), ("trạm xe buýt", "street"),
          ("trạm xe", "street"), ("phố", "street"), ("hành lang tủ đồ", "lockers"), ("tủ đồ", "lockers"), ("hành lang", "lockers"), ("lớp học", "classroom"), ("lớp", "classroom"),
          ("sân bóng rổ", "court"), ("sân bóng", "court"), ("quán cà phê", "cafe"), ("cà phê", "cafe"), ("quán", "cafe"), ("phòng tập", "gym"), ("cầu thang", "stairs"),
          ("đồi hoàng hôn", "hill"), ("đỉnh đồi", "hill"), ("đồi", "hill"), ("núi", "hill"), ("gương phòng tắm", "mirror"), ("phòng tắm", "mirror"), ("gương", "mirror"),
          ("phòng khách", "sofa"), ("bếp đêm", "kitchen"), ("bếp", "kitchen"), ("cửa mở hắt sáng", "doorway"), ("khung cửa", "doorway"), ("cửa ra vào", "doorway"), ("cửa", "doorway"),
          ("khoảng tối có đèn rọi", "void"), ("khoảng tối", "void"), ("đèn rọi", "void"), ("khoảng trống", "void"), ("màn đen", "black"), ("nền đen", "black"),
          ("cận điện thoại", "@phone"), ("màn hình điện thoại", "@phone"), ("điện thoại", "@phone"), ("cận đồng hồ", "@clock"), ("đồng hồ", "@clock"), ("cận lịch", "@calendar"),
          ("lịch", "@calendar"), ("cận mặt", "@face"), ("sổ tay", "@note"), ("đồ thị", "@graph"), ("biểu đồ", "@graph")]
NEN_TB = NEN_VI + [(s, s) for s in KHO["set"]] + [(t, "@" + t) for t in ("phone", "clock", "calendar", "face", "note", "graph")]
SET_DESC = {"bedroom": "giường, tủ đầu giường có đồng hồ LED, cửa sổ", "city": "nhà cao tầng, đường, đèn đường", "street": "phố mưa: đèn đường, trạm xe buýt có ghế",
            "lockers": "hành lang tủ đồ trường học, bảng ghim giấy note", "classroom": "bảng đen có chữ, cửa sổ, bàn học", "court": "sân bóng rổ hoàng hôn: rổ, ghế băng, hàng rào",
            "cafe": "quán cà phê: cửa kính thấy mưa và phố đêm, đèn treo, 1 bàn, chậu cây (không có ghế)", "gym": "bao cát đỏ (lõm khi trúng đấm), đèn rọi",
            "stairs": "cầu thang 9 bậc, ánh sáng trên đỉnh", "hill": "đồi hoàng hôn, dãy núi mềm", "mirror": "gương oval trên bệ", "sofa": "phòng khách tối có sofa",
            "kitchen": "bếp đêm: tủ lạnh, kệ bếp, cửa sổ", "doorway": "khung cửa mở hắt sáng", "void": "khoảng tối, đèn rọi từ trên xuống", "black": "nền đen, chữ to giữa màn"}
SET_ARG_VI = {"bedroom": "đêm trăng / bình minh / mưa / ngày / tối om; đồng hồ 5:00 (kêu, nhấp nháy); lịch tháng oct tô 12; đèn bàn; laptop; bàn học; cửa phòng",
              "city": "hoàng hôn / đêm / bình minh / ngày; chim bay", "street": "cửa neon; không mưa; không trạm xe", "classroom": "bảng: <chữ>", "gym": "tạ; không bao cát",
              "mirror": "gương nứt", "sofa": "cửa sổ; đèn cây", "kitchen": "đèn bếp", "doorway": "cửa đóng / cửa hé", "void": "", "black": ""}
TPL_DESC = {"phone": "cận điện thoại 2 tay cầm. Chi tiết: feed: mì, xe, burger… · video · chat (dòng @) · email · màn khoá (dòng @ = thông báo) · đếm ngày (số lấy từ HUD) · màn tắt · nền <bối cảnh>",
            "clock": "cận đồng hồ báo thức LED. Chi tiết: 11:59 -> 12:00, kêu, nhấp nháy", "calendar": "cận lịch to. Chi tiết: tháng nov, 0 tới 24, tô màu (mặc định gạch X), xoá về 0",
            "face": "cận mặt từ ngực lên (ai, biểu cảm lấy từ AI). Chi tiết: nền <bối cảnh>", "note": "sổ tay, tay viết chữ (dòng chữ của cảnh)", "black": "màn đen + chữ to giữa màn",
            "graph": "đồ thị cảm xúc vẽ dần (kiểu DOPAMINE). Chi tiết: sụp đổ (mặc định) / nhiều đỉnh / đi lên chậm / phẳng; nhãn \"<chữ>\""}
MAIN = "hero"   # preset cua "cậu" (dong NHÂN VẬT: dau file)
WHO_VI = [("nhân vật chính", "@main"), ("nhân vật", "@main"), ("cậu băng đô", "band"), ("cậu hoodie", "hoodie"), ("cậu trùm mũ", "hooded"), ("cậu trần", "hero"), ("cậu", "@main"), ("anh ta", "@main"),
          ("main", "@main"), ("băng đô", "band"), ("trùm mũ", "hooded"), ("bạn bè", "@friends"), ("bạn mũ vàng", "friend"), ("bạn 1", "friend"), ("bạn mũ xanh", "friend2"),
          ("bạn 2", "friend2"), ("bạn mũ đỏ", "friend3"), ("bạn 3", "friend3"), ("bạn", "friend"), ("cô gái", "girl"), ("mẹ", "mom"), ("bố", "dad"), ("em nhỏ", "kid"),
          ("em bé", "kid"), ("đứa trẻ", "kid"), ("bóng mờ", "ghost"), ("hồi tưởng", "ghost"), ("bóng đen", "voice"), ("cám dỗ", "voice")]
WHO_TB = WHO_VI + [(w, w) for w in KHO["who"]]
WHO_DESC = {"hero": "cậu trai đầu tròn màu kem (trần)", "band": "người hùng quấn băng đô màu nhấn (khi tập)", "hoodie": "người hùng mặc hoodie xám, mũ hạ sau cổ",
            "hooded": "hoodie trùm mũ lên đầu (đêm, nghiện)", "friend": "bạn mũ lưỡi trai vàng", "friend2": "bạn mũ xanh", "friend3": "bạn mũ đỏ", "girl": "cô gái tóc bob khăn vàng",
            "mom": "mẹ (búi tóc)", "dad": "bố (đeo kính)", "kid": "em nhỏ", "ghost": "bóng mờ (hồi tưởng, bản thân cũ)", "voice": "bóng đen cám dỗ (mắt đỏ, khói đỏ)"}
ANCH_VI = [("mép giường", "bed.sit"), ("đầu giường", "bed.head"), ("ghế bàn", "desk.seat"), ("bàn học", "desk.seat"), ("ghế xe buýt", "bus.seat"), ("trạm xe", "bus.seat"),
           ("ghế băng", "bench"), ("ghế sân", "bench"), ("bàn trái", "table.left"), ("bàn phải", "table.right"), ("đỉnh đồi", "top"), ("trong gương", "mirror.in"), ("gương", "mirror"),
           ("ghế sofa", "sofa.seat"), ("sofa trái", "sofa.left"), ("sofa phải", "sofa.right"), ("sofa", "sofa.seat"), ("cửa neon", "neon"), ("cửa", "door")]
ANCH_SET = {"bed.sit": "bedroom", "bed.head": "bedroom", "desk.seat": "bedroom", "bus.seat": "street", "neon": "street", "bench": "court", "table.left": "cafe", "table.right": "cafe",
            "top": "hill", "mirror": "mirror", "mirror.in": "mirror", "sofa.seat": "sofa", "sofa.left": "sofa", "sofa.right": "sofa", "door": "doorway"}
ANCH_XY = {"bed.sit": (0.475, 0.8), "bed.head": (0.30, 0.67), "desk.seat": (0.82, 0.8), "bus.seat": (0.72, 0.8), "neon": (0.32, 0.8), "bench": (0.3, 0.74), "table.left": (0.40, 0.8),
           "table.right": (0.6, 0.8), "top": (0.45, 0.745), "mirror": (0.55, 0.8), "mirror.in": (0.55, 0.7), "sofa.seat": (0.405, 0.8), "sofa.left": (0.366, 0.8), "sofa.right": (0.516, 0.8), "door": (0.62, 0.8)}
ANCH_TB = ANCH_VI + [(k, k) for k in ANCH_SET]
POSE_VI = [("đứng", "stand"), ("đứng thả lỏng", "relaxed"), ("thả lỏng", "relaxed"), ("cúi gục", "slump"), ("đứng gục", "slump"), ("gục", "slump"), ("cầm điện thoại", "phone"),
           ("nhìn điện thoại", "phone"), ("lướt điện thoại", "phone"), ("với tay", "reach"), ("vươn tay", "reach"), ("chỉ tay", "point"), ("chỉ", "point"), ("vẫy tay", "wave"),
           ("vẫy", "wave"), ("giơ hai tay", "cheer"), ("ăn mừng", "cheer"), ("reo", "cheer"), ("siết nắm đấm", "fist"), ("nắm đấm", "fist"), ("ôm đầu", "headhold"),
           ("úp mặt", "facepalm"), ("ôm mặt", "facepalm"), ("khoanh tay", "arms"), ("nhún vai", "shrug"), ("ôm", "hug"), ("thủ thế", "guard"), ("đấm", "punch"),
           ("nâng tạ", "lift"), ("ngồi", "sit"), ("ngồi cầm điện thoại", "sitphone"), ("ngồi lướt điện thoại", "sitphone"), ("ngồi bàn", "sitdesk"), ("ngồi viết", "sitdesk"),
           ("ngồi học", "sitdesk"), ("ngồi gục", "sitsad"), ("ngồi cúi đầu", "sitsad"), ("ngồi ôm gối", "knees"), ("ngồi bó gối", "knees"), ("ôm gối", "knees"), ("bó gối", "knees"),
           ("quỳ", "kneel"), ("khom", "crouch"), ("ngồi xổm", "crouch"), ("cúi người", "crouch"), ("leo", "climb"), ("dang tay", "open"), ("cầm ô", "umbrella"), ("che ô", "umbrella"),
           ("ôm đồ", "carry"), ("bê đồ", "carry"), ("chống gối", "pant"), ("vung tay", "throw"), ("buông tay", "release"), ("chồm người", "sitfwd"), ("ngồi chồm", "sitfwd"),
           ("nằm sàn", "lie"), ("nằm dưới sàn", "lie")]
FACE_VI = [("bình thường", "neutral"), ("mệt", "tired"), ("buồn ngủ", "sleepy"), ("ngủ", "sleep"), ("buồn", "sad"), ("khóc nấc", "sob"), ("khóc", "cry"), ("lo lắng", "worried"),
           ("lo", "worried"), ("sợ", "scared"), ("sốc", "shock"), ("tức giận", "angry"), ("giận", "angry"), ("quyết tâm", "determined"), ("gồng sức", "effort"), ("gồng", "effort"),
           ("mỉm cười", "smile"), ("cười đùa", "happy"), ("cười nhếch", "smirk"), ("cười gian", "grin"), ("cười", "smile"), ("vui", "happy"), ("trống rỗng", "empty"), ("có lỗi", "guilty"),
           ("tội lỗi", "guilty"), ("thức trắng", "bloodshot"), ("ám ảnh", "haunted"), ("hy vọng", "hopeful"), ("nhẹ nhõm", "relieved"), ("tự hào", "proud"), ("xấu hổ", "embarrassed"), ("ngượng", "embarrassed"),
           ("ghê", "disgusted"), ("bực", "annoyed"), ("nghi ngờ", "skeptical"), ("kiệt sức", "exhausted"), ("ngáp", "yawn"), ("thẫn thờ", "dazed"), ("hoảng loạn", "panic"),
           ("hoảng", "panic"), ("hét", "shout"), ("suy nghĩ", "thinking"), ("bị cám dỗ", "tempted"), ("thèm", "tempted"), ("nghiến răng", "grit"), ("cô đơn", "lonely")]
HOLD_VI = [("cầm sách", "book"), ("ôm sách", "book"), ("cầm bóng", "ball"), ("ôm bóng", "ball"), ("đeo cặp", "bag"), ("đeo balo", "bag"), ("cầm cặp", "bag"), ("cầm cốc", "cup"),
           ("cầm ly", "cup"), ("cầm cà phê", "cup")]
EXTRA_VI = [("mắt đỏ gân máu", {"bloodshot": True}), ("mắt đỏ", {"bloodshot": True}), ("gân máu", {"bloodshot": True}), ("nước mắt", {"tears": True}), ("mồ hôi", {"sweat": True}),
            ("ánh màn hình", {"glowFace": GLOW}), ("phía sau", {"behind": True}), ("đứng sau", {"behind": True}), ("trong gương", {"inMirror": True, "behind": True}),
            ("nhìn trái", {"facing": -1}), ("nhìn phải", {"facing": 1}), ("quay trái", {"facing": -1}), ("quay phải", {"facing": 1}), ("giữ chỗ", {"keepX": True}), ("mờ dần", {"fade": 0.8})]
BED_VI = ["nằm trong chăn", "ngủ trong chăn", "nằm ngủ", "nằm"]
PH = sorted([(k, ("pose", v)) for k, v in POSE_VI] + [(k, ("face", v)) for k, v in FACE_VI] + [(k, ("hold", v)) for k, v in HOLD_VI] + [(k, ("x", v)) for k, v in EXTRA_VI]
            + [(k, ("bed", None)) for k in BED_VI] + [(p, ("pose", p)) for p in KHO["pose"]] + [(f, ("face", f)) for f in KHO["face"]], key=lambda kv: -len(kv[0]))
STOP = ["một mình", "lặng lẽ", "đang", "và", "vẫn", "hơi", "rất"]
DT_VI = [("đứng dậy", "standUp"), ("đứng lên", "standUp"), ("ngồi xuống", "sitDown"), ("quỵ xuống", "collapse"), ("khuỵu xuống", "collapse"), ("gục xuống", "collapse"),
         ("quỵ", "collapse"), ("ngã", "fall"), ("đổ sập", "fall"), ("ném điện thoại", "throwPhone"), ("quăng điện thoại", "throwPhone"), ("vứt điện thoại", "throwPhone"),
         ("quay lưng bỏ đi", "walkAway"), ("bỏ đi", "walkAway"), ("rời đi", "walkAway"), ("chạy đi", "walkAway!"), ("thở dốc", "pant")]
CAM_VI = [("đẩy chậm vào mặt", "pushface"), ("đẩy vào mặt", "pushface"), ("đẩy nhanh vào mặt", "pushfast"), ("đẩy nhanh", "pushfast"), ("đẩy chậm", "push"), ("đẩy vào", "push"),
          ("đẩy", "push"), ("kéo ra", "pull"), ("lùi ra", "pull"), ("lia trái", "panL"), ("lia phải", "panR"), ("bám theo", "follow"), ("máy theo", "follow"), ("theo", "follow"),
          ("rung mạnh", "shake2"), ("rung", "shake"), ("cầm tay", "hand"), ("đứng yên", "still"), ("cố định", "still"), ("góc rộng", "wide"), ("toàn cảnh", "wide"),
          # 2.0 che do cinematic (2.5D): co khung (s:), goc may (a:), chuyen dong 3D (m:) -> args.shot cho goc chinh cua canh
          ("toàn cảnh rộng", "s:ews"), ("toàn thân", "s:full"), ("trung cảnh", "s:ms"), ("cận trung", "s:mcu"), ("cận cảnh", "s:cu"), ("đặc tả", "s:ecu"),
          ("qua vai", "a:ots"), ("góc thấp", "a:low"), ("góc cao", "a:high"), ("từ trên xuống", "a:top"), ("ngang mắt", "a:eye"), ("góc nhìn nhân vật", "a:pov"), ("pov", "a:pov"),
          ("dolly vào", "m:dollyIn"), ("dolly ra", "m:dollyOut"), ("trượt ngang", "m:truck"), ("xoay quanh", "m:orbit"), ("nâng máy", "m:lowAngleRise"), ("nghiêng máy", "m:tilt"), ("đẩy vào cận", "m:pushToCloseUp")]
# 2.0 CHUYỂN: kieu chuyen canh vao canh nay (+ "vì <ly do>"). Khong ghi: che do cinematic tu chon theo noi dung (director.js), legacy = cat
TRANS_VI = [("cắt sốc", "smashCut"), ("cắt", "cut"), ("match cut", "matchCut"), ("khớp hình", "matchCut"), ("iris", "iris"), ("vòng tròn", "iris"), ("lia nhanh", "whipPan"),
            ("zoom vào đồ vật", "zoomIntoProp"), ("zoom vào", "zoomIntoProp"), ("qua màn đen", "fadeThroughBlack"), ("qua đen", "fadeThroughBlack"), ("mờ đen", "dip"), ("chớp trắng", "flash")]
# dong tac bo dung CHUA lam (khong co chuyen dong that) -> cach thay bang tu the + cat canh
UNSUP = [(r"đẩy cửa|mở cửa", "cắt 2 cảnh: NỀN: cửa, cửa đóng → NỀN: cửa (mở sẵn, hắt sáng), người đứng @cửa; SFX door_open"),
         (r"đóng cửa|đóng sập", "cắt sang cảnh NỀN: cửa, cửa đóng + SFX door_open / impact_heavy"),
         (r"\bnhảy\b", "tư thế giơ hai tay (cheer) + MÁY: rung, hoặc cắt cảnh"),
         (r"hít đất|chống đẩy|gập bụng|plank", "phòng tập: ĐỘNG TÁC đấm liên tục (có số đếm), hoặc tư thế khom + bộ đếm tăng"),
         (r"nâng tạ (liên tục|\d+ lần)|tập tạ|đẩy tạ", "chưa vẽ thanh tạ trên tay khi nâng: dùng tư thế nâng tạ tĩnh + NỀN: phòng tập, tạ; cần số đếm thì đấm liên tục"),
         (r"leo cầu thang|bước lên cầu thang|đi lên cầu thang", "cầu thang: cắt 3 cảnh @step:1 → @step:4 → @step:7, tư thế leo"),
         (r"ôm chầm|chạy tới ôm|lao vào ôm", "2 người đi tới gần nhau (đi tới x) rồi ĐỘNG TÁC: ôm <giây>"),
         (r"đánh nhau|xô đẩy|đẩy ngã", "tư thế chỉ tay / khoanh tay + cắt cảnh; ngã: ĐỘNG TÁC ngã"),
         (r"\băn\b|\buống\b|\bnhai\b", "đứng / ngồi + cầm cốc; ăn uống vô độ: cận điện thoại feed ảnh đồ ăn"),
         (r"lái xe|đạp xe|xe máy", "thành phố + chạy tại chỗ (đường cuộn), hoặc cận điện thoại ảnh xe"),
         (r"gõ phím|đánh máy", "ngồi bàn + NỀN: phòng ngủ, laptop"),
         (r"\bviết\b(?! chữ)", "NỀN: sổ tay (tay viết chữ) hoặc ngồi bàn"),
         (r"lắc đầu|gật đầu", "đổi biểu cảm theo giây (ĐỘNG TÁC: buồn 2s) hoặc quay người"),
         (r"đánh răng|đi tắm|đang tắm|tắm rửa|rửa mặt", "NỀN: gương, đứng trước gương, đổi biểu cảm"),
         (r"gọi điện|nghe điện thoại|áp tai", "tư thế cầm điện thoại + cắt sang cận điện thoại chat"),
         (r"cầm tay nhau|nắm tay", "2 người đứng sát (@x cách 0.08), tư thế đứng / ôm"),
         (r"vò giấy|xé giấy|vứt rác", "ném điện thoại (throwPhone) hoặc cắt cảnh"),
         (r"ngủ gật", "biểu cảm buồn ngủ → ngủ theo giây (ĐỘNG TÁC: ngủ 2s)"),
         (r"mở tủ lạnh", "NỀN: bếp, đèn bếp, đứng"),
         (r"nhìn đồng hồ đeo tay", "NỀN: cận đồng hồ")]
SCREEN_VI = [("feed", "feed"), ("lướt", "feed"), ("video", "reel"), ("reel", "reel"), ("chat", "chat"), ("tin nhắn", "chat"), ("email", "email"), ("hộp thư", "email"),
             ("màn khoá", "lock"), ("màn khóa", "lock"), ("thông báo", "lock"), ("lock", "lock"), ("đếm ngày", "counter"), ("ứng dụng đếm", "counter"), ("counter", "counter"),
             ("màn tắt", "off"), ("màn hình tắt", "off"), ("phản chiếu", "off"), ("off", "off")]
ART = [("mì", "ramen"), ("ramen", "ramen"), ("xe", "car"), ("ô tô", "car"), ("burger", "burger"), ("hamburger", "burger"), ("pizza", "pizza"), ("giày", "sneakers"), ("chó", "dog"), ("mèo", "cat"), ("biển", "beach"), ("núi", "mountain"), ("hoàng hôn", "sunset"),
       ("tạ", "gym"), ("gym", "gym"), ("đồng hồ đeo tay", "watch"), ("tiền", "money"), ("game", "game"), ("cà phê", "coffee"), ("thành phố", "city"), ("tiệc", "party"), ("selfie", "selfie"), ("cô gái", "girl"), ("gái", "girl"), ("donut", "donut"), ("bánh kem", "cake")]

LOI, CB = [], []; CUR = [""]   # loi / canh bao (ma canh, noi dung)
def err(m): LOI.append((CUR[0], m))
def warn(m): CB.append((CUR[0], m))
def num(x): return float(x.replace(",", "."))
TN = r"(\d+(?:[.,]\d+)?)"
def tsec(s):   # "2.5s" / "lúc 2.5" -> (giay, phan con lai)
    m = re.search(r"(?:lúc\s+|từ\s+)?" + TN + r"\s*s\b", s) or re.search(r"(?:lúc|từ)\s+" + TN, s)
    return (num(m.group(1)), re.sub(r"\s+", " ", s[:m.start()] + " " + s[m.end():]).strip()) if m else (None, s)
def pick(txt, table):   # cum dai nhat khop o dau chuoi (tron tu) -> (gia tri, phan con lai)
    t = txt.strip()
    for k, v in sorted(table, key=lambda kv: -len(kv[0])):
        if t.startswith(k) and not t[len(k):len(k) + 1].isalnum(): return v, t[len(k):].strip(" ,:")
    return None, t
def near(w, keys):
    m = difflib.get_close_matches(w, keys, n=3, cutoff=0.55); return f" (gần nhất: {', '.join(m)})" if m else ""
def unsup(s):
    return next(((re.search(rx, s).group(0), alt) for rx, alt in UNSUP if re.search(rx, s)), None)

def kho_md():
    rows = lambda pairs, vals, col: "\n".join(f"| {', '.join(k for k, v in pairs if v == x) or '—'} | `{x}` |" + (f" {col.get(x, '')} |" if col is not None else "") for x in vals)
    ver = (read_json(os.path.join(HERE, "..", "..", "..", "..", ".claude-plugin", "plugin.json"), {}) or {}).get("version", "?")
    L = ["# Kho cảnh của bộ dựng (sinh tự động)", "",
         f"Sinh bằng `python tools/phim.py --kho` từ mã bộ dựng `packs/dem` (plugin {ver}{'' if LIVE else ', KHÔNG đọc được packs/dem: đang dùng danh sách dựng sẵn'}). "
         "Đừng sửa tay: bộ dựng đổi thì chạy lại lệnh. `--dry-run` luôn kiểm theo đúng bản đang cài.", "",
         "Cách ghi trong file 01: `[B07] 5s | CẢNH: <mô tả cho người đọc> | NỀN: … | AI: … | ĐỘNG TÁC: … | MÁY: … | HUD | NHẠC | SFX`. "
         "Cột trái là chữ ghi được (tiếng Việt hoặc mã), cột giữa là mã bộ dựng nhận.", "",
         "## 1. NỀN — bối cảnh", "", "| Ghi | Mã | Trông thế nào | Chi tiết ghi sau dấu phẩy |", "|---|---|---|---|"]
    for s in KHO["set"]: L.append(f"| {', '.join(k for k, v in NEN_VI if v == s) or s} | `{s}` | {SET_DESC.get(s, '')} | {SET_ARG_VI.get(s, '')} |")
    L += ["", "## 2. NỀN — mẫu cận cảnh", "", "| Ghi | Mã | Chi tiết |", "|---|---|---|"]
    for t in ("phone", "clock", "calendar", "face", "note", "graph"): L.append(f"| {', '.join(k for k, v in NEN_VI if v == '@' + t)} | `{t}` | {TPL_DESC[t]} |")
    L += ["", "Màn hình điện thoại (`screen`): " + ", ".join(f"`{x}`" for x in KHO["screen"]) + ". Ảnh bài đăng feed: " + ", ".join(f"{k} (`{v}`)" for k, v in ART if v in KHO["art"]) + ".",
          "", "## 3. AI — nhân vật", "", "Mỗi người 1 cụm, cách nhau `;`: `preset[@x | @mốc] tư thế, biểu cảm, cầm đồ, chuyển động`. `x`: 0..1 theo bề ngang khung (0.5 = giữa). "
          "`cậu` / `nhân vật` = preset ghi ở dòng `NHÂN VẬT:` đầu file (mặc định `hero`). `bạn bè` = 2 người (`friend`, `friend2`).", "", "| Ghi | Mã | Là ai |", "|---|---|---|"]
    L.append(rows(WHO_VI, KHO["who"], WHO_DESC))
    L += ["", "**Mốc đặt người (`@`)** — chỉ dùng đúng bối cảnh:", "", "| Ghi | Mã | Bối cảnh |", "|---|---|---|"]
    for k, s in ANCH_SET.items(): L.append(f"| {', '.join(x for x, v in ANCH_VI if v == k)} | `{k}` | `{s}` |")
    L.append("| bậc N | `step:N` (0–8; bóng đen từ bậc 3 trở lên nên ghi `cao 0.36` để không mất đầu) | `stairs` |")
    L += ["", "Ngồi chỉ đẹp ở mốc có ghế: mép giường, ghế bàn (phòng ngủ, tự bật bàn học), sofa, ghế xe buýt, ghế băng sân bóng. Quán cà phê chưa có ghế (ngồi sẽ lơ lửng): đứng @bàn trái / @bàn phải."]
    L += ["", "## 4. Tư thế tĩnh (đứng yên ở tư thế đó cả cảnh, chỉ thở / chớp mắt)", "", "| Ghi | Mã |", "|---|---|", rows(POSE_VI, KHO["pose"], None),
          "", "Cầm đồ: " + "; ".join(f"{', '.join(k for k, v in HOLD_VI if v == h) or ('cầm điện thoại' if h == 'phone' else 'cầm ô' if h == 'umbrella' else h)} (`{h}`)" for h in KHO["hold"]) + ".",
          "Chi tiết thêm: " + "; ".join(f"{k}" for k, _ in EXTRA_VI) + ". Người nằm trong chăn (chỉ NỀN phòng ngủ): " + ", ".join(BED_VI) + ".",
          "", "## 5. Biểu cảm", "", "| Ghi | Mã |", "|---|---|", rows(FACE_VI, KHO["face"], None),
          "", "## 6. Động tác có chuyển động (bộ dựng diễn thật)", "", "Ghi trong `ĐỘNG TÁC:` (`[ai] <động tác> <giây>s`, cách nhau `;`; không ghi ai = nhân vật chính) hoặc ngay trong cụm AI (chuyển động bắt đầu từ đầu cảnh).", "",
          "| Ghi | Bộ dựng làm gì | Mã |", "|---|---|---|",
          "| đi tới 0.7 [từ 1s] [trong 3s] | đi bộ, chân bám đất, tự quay theo hướng đi, dừng hai chân khép | `walk` |",
          "| chạy tới 0.85 | chạy: đổ người, vệt tốc độ, bụi chân | `run` |", "| đi lùi tới 0.3 | đi lùi, mặt giữ hướng | `walk.back` |",
          "| đi ngang / đi qua | đi băng ngang khung từ mép này sang mép kia | `walk` |", "| chạy tại chỗ | chạy tại chỗ, đường và nhà trôi (hợp NỀN thành phố) | `run: 1.6` + `scroll` |",
          "| đứng dậy | đang ngồi: chồm người rồi đứng dậy | `act standUp` |", "| ngồi xuống | ngồi xuống | `act sitDown` |",
          "| quỵ xuống | gục người → ôm đầu → quỵ gối (~1,5 giây) | `act collapse` |", "| ngã | đổ sập xuống sàn, nảy nhẹ, nằm yên | `act fall` |",
          "| ném điện thoại | vung tay ném, điện thoại bay vòng cung, rơi, tắt màn hình (đang ngồi thì tự đứng dậy trước) | `act throwPhone` |",
          "| bỏ đi / chạy đi | quay lưng rồi đi / chạy ra khỏi khung | `act walkAway` |", "| thở dốc | chống tay lên gối thở dốc rồi đứng thẳng | `act pant` |",
          "| đấm liên tục / đấm 4 cú | thủ thế rồi đấm từng cú; bao cát lõm, chớp sáng; số đếm khi ≥ 3 cú | `poseAt guard↔punch` |",
          "| quay trái / quay phải / quay lại | quay người trong 0,3 giây | `facingAt` |", "| <tư thế> 2s (vd: ôm đầu 2s) | đổi sang tư thế đó, chuyển dần có lấy đà | `poseAt` |",
          "| <biểu cảm> 2s (vd: khóc 2s) | đổi biểu cảm, chớp mắt đúng lúc đổi | `faceAt` |", "| hiện 1s / biến mất 4s | xuất hiện / mờ đi | `at` / `out` |",
          "| bóng đen vỡ 3s | nứt, vỡ thành mảnh, chữ cám dỗ vỡ từng chữ (SFX `vanish_burst` đúng giây) | `vanish burst` |",
          "| bóng đen tan tro 3s | rã dần từ chân thành tro bay theo gió (SFX `vanish_ash`) | `vanish ash` |",
          "| ngồi dậy 1.5s (người nằm giường) | thân nhổm dậy, chăn tuột, trượt ra mép giường | `bed.up` |", "| với tay 1s (người nằm giường) | tay chui ra khỏi chăn với tắt đồng hồ | `bed.arm` |",
          "| trở mình 2s / nằm ngửa 3s (người nằm giường) | nằm nghiêng co gối ↔ nằm ngửa | `bed.rollAt` |",
          "", "Trong cụm AI, `A → B` đổi tư thế / biểu cảm giữa cảnh (vd `đứng → ôm đầu 2s`, `lo → khóc`).",
          "", "## 7. Chưa hỗ trợ → cách thay", "", "Bộ dựng chưa có chuyển động này. Ghi vào `ĐỘNG TÁC` / `AI` sẽ bị `--dry-run` báo LỖI; ghi trong `CẢNH` thì bị bỏ qua.", "", "| Động tác | Thay bằng |", "|---|---|"]
    for rx, alt in UNSUP: L.append(f"| {rx.replace(chr(92) + 'b', '').replace('|', ' / ').replace('(?! chữ)', '')} | {alt} |")
    L += ["", "## 8. MÁY", "", "| Ghi | Làm gì |", "|---|---|", "| đẩy chậm | đẩy vào người chính (zoom 1 → 1,15) |", "| đẩy chậm vào mặt | đẩy vào mặt người chính (→ 1,4; cận mặt → 1,2) |",
          "| đẩy nhanh vào mặt | đẩy vào mặt trong ~1 giây |", "| kéo ra | từ gần lùi ra toàn cảnh |", "| lia trái / lia phải | lia ngang |",
          "| bám theo | bám người chính đang đi / chạy |", "| rung 2s / rung mạnh 2s | rung máy ở giây đó |", "| cầm tay | rung tay rõ (hoảng loạn) |", "| đứng yên / góc rộng | không đẩy |",
          "", "Ghi `<cách> <giây>s` để bắt đầu ở giây đó (vd `đẩy chậm vào mặt 2s`). Nhiều cách cách nhau dấu phẩy.",
          "", "**Chế độ cinematic (2.0)** — thêm cỡ khung / góc máy / chuyển động 3D cho góc chính của cảnh (không ghi: bộ dựng tự chia 1–3 góc và tự đổi cỡ khung giữa các cảnh):",
          "", "| Ghi | Làm gì |", "|---|---|", "| toàn cảnh rộng / toàn thân / trung cảnh / cận trung / cận cảnh / đặc tả | cỡ khung |",
          "| qua vai / góc thấp / góc cao / từ trên xuống / ngang mắt / pov | góc máy |", "| dolly vào / dolly ra / trượt ngang / xoay quanh / nâng máy / nghiêng máy / đẩy vào cận | chuyển động máy |",
          "", "## 8b. CHUYỂN (2.0)", "", "`CHUYỂN: <kiểu> vì <lý do>` — kiểu chuyển vào cảnh này: " + ", ".join(f"`{k}`" for k, _ in TRANS_VI) + ". Không ghi: chế độ cinematic tự chọn theo nội dung (vào điện thoại = zoom vào đồ vật, rời điện thoại = iris, sang màn đen = qua đen, trước cú sụp = cắt sốc, cùng bố cục = match cut), legacy = cắt.",
          "", "## 9. NHẠC, SFX", "", "NHẠC: " + ", ".join(f"`{m}`" for m in MUSIC) + " (`tension` … chỉ có khi cài đầy đủ).", "",
          "SFX: " + ", ".join(f"`{x}`" for x in SFX) + ". Ghi `tên@giây`."]
    # doi chieu
    L += ["", "## Đối chiếu", ""]
    miss = [f"`{x}`" for k, tb in (("pose", POSE_VI), ("face", FACE_VI)) for x in KHO[k] if x not in [v for _, v in tb]]
    gone = [f"`{v}` ({k})" for k, v in POSE_VI if v not in KHO["pose"]] + [f"`{v}` ({k})" for k, v in FACE_VI if v not in KHO["face"]] + [f"`{v}`" for _, v in NEN_VI if not v.startswith("@") and v not in KHO["set"]] \
         + [f"`{v}`" for _, v in WHO_VI if not v.startswith("@") and v not in KHO["who"]]
    L.append("- Mã chỉ ghi được bằng tên mã (chưa có tên tiếng Việt): " + (", ".join(miss) or "không có") + ".")
    L.append("- Tên tiếng Việt trỏ tới mã bộ dựng KHÔNG còn: " + (", ".join(sorted(set(gone))) or "không có") + ".")
    mc = os.path.join(HERE, "..", "..", "references", "mau-canh.md")
    if os.path.exists(mc):
        t = open(mc, encoding="utf-8").read(); res = []
        def seen(pat): m = re.search(pat, t); return {w for sp in re.findall(r"`([^`]+)`", m.group(1)) for w in sp.split() if re.fullmatch(r"\w+", w)} - {"who", "classic"} if m else set()
        doc = {"pose": seen(r"\*\*Tư thế \(`pose`\):\*\*(.*)"), "face": seen(r"\*\*Biểu cảm \(`face`\):\*\*(.*)") | seen(r"Thêm từ 1\.5\.0 \(dạng `classic`[^)]*\)(.*)"),
               "set": set(re.findall(r"^\| `(\w+)` \|", t, re.M)) & (set(KHO["set"]) | set(_D["set"].split()) | {"sofa"}), "who": seen(r"\| `who` \|(.*)"), "act": set(re.findall(r"^\| `(\w+)` \| ", t, re.M)) & set(_D["act"].split() + KHO["act"])}
        for k, d in doc.items():
            if not d: continue
            x, y = sorted(set(KHO[k]) - d), sorted(d - set(KHO[k]))
            res.append(f"  - `{k}`: " + ("khớp" if not x and not y else (f"có trong bộ dựng, mau-canh.md chưa ghi: {', '.join(x)}. " if x else "") + (f"mau-canh.md ghi nhưng bộ dựng không có: {', '.join(y)}." if y else "")))
        L.append("- Đối chiếu `lam-video-selfimprove/references/mau-canh.md`:\n" + "\n".join(res))
    return "\n".join(L) + "\n"

if a.kho:
    md = kho_md()
    if a.kho_out:
        os.makedirs(os.path.dirname(os.path.abspath(a.kho_out)), exist_ok=True)
        with open(a.kho_out, "w", encoding="utf-8") as f: f.write(md)
        print(f"Da ghi kho canh -> {a.kho_out}" + ("" if LIVE else " (KHONG doc duoc packs/dem, dung danh sach dung san)"))
    else: print(md)
    sys.exit(0)
if not a.phim or not (P or DRY): sys.exit("Can --phim <file 01> va --project <du an> (hoac --dry-run de chi kiem tra).")
out = os.path.join(P, "story", "shots.json") if P else None
if out and not DRY and os.path.exists(out) and not a.force: sys.exit("Da co story/shots.json (them --force de ghi de).")
raw = open(a.phim, encoding="utf-8-sig").read()

meta = {}; beats = []; cur = None
HEAD = re.compile(r"^\s*\[?\s*(B\d+[A-Za-z]?)\s*\]?\s*(\d+(?:[.,]\d+)?)\s*s?\s*(\|.*)?$", re.I)
for ln, line in enumerate(raw.splitlines(), 1):
    s = nfc(line.rstrip())
    if not s.strip() or s.strip().startswith("#"): continue
    m = HEAD.match(s)
    if m:
        cur = {"id": m.group(1).lower(), "dur": float(m.group(2).replace(",", ".")), "tags": {}, "texts": [], "ln": ln}
        for part in (m.group(3) or "").split("|")[1:]:
            if ":" in part: k, v = part.split(":", 1); cur["tags"][low(k).strip()] = v.strip()
            elif part.strip(): cur["tags"][low(part).strip()] = ""
        beats.append(cur); continue
    mm = re.match(r"^\s*([A-ZÀ-Ỹ][A-ZÀ-Ỹ ]*?)\s*:\s*(.+)$", s)
    if not cur and mm: meta[low(mm.group(1))] = mm.group(2).strip(); continue
    if not cur: continue
    t_at = None; body = s.strip()
    mt = re.match(r"^\{(\d+(?:[.,]\d+)?)\}\s*(.*)$", body)
    if mt: t_at = float(mt.group(1).replace(",", ".")); body = mt.group(2)
    if body.startswith("@me:"): cur["texts"].append({"kind": "chat", "me": True, "t": body[4:].strip(), "at": t_at}); continue
    if body.startswith("@"): nm, _, tx = body[1:].partition(":"); cur["texts"].append({"kind": "chat", "me": False, "name": nm.strip(), "t": tx.strip(), "at": t_at}); continue
    k = {">": "narr", "~": "tempt", '"': "say", "“": "say", "!": "big"}.get(body[:1])
    if not k: cur["texts"].append({"kind": "narr", "t": body, "at": t_at}); continue
    tx = body[1:].strip(); who = None
    mw = re.match(r"^\[([^\]]+)\]\s*(.*)$", tx)
    if mw: who, tx = mw.group(1).strip(), mw.group(2)
    item = {"kind": k, "t": tx, "at": t_at}
    if who: item["who"] = who
    cur["texts"].append(item)
if not beats: sys.exit("Khong doc duoc canh nao. Dong dau canh dang: [B01] 5s | CẢNH: ...")
if meta.get("nhân vật"):
    mv0 = low(meta["nhân vật"]).split()[0]
    if mv0 in KHO["who"]: MAIN = mv0
    else: err(f"NHÂN VẬT: không có preset '{meta['nhân vật']}'{near(mv0, KHO['who'])}")

def tag(b, *names):
    for n in names:
        for k, v in b["tags"].items():
            if k.startswith(n): return v
    return None
# boi canh doan tu CẢNH: theo thu tu danh sach; tu "yeu" (thoi tiet, gio, cua) dat cuoi nen "quán cà phê đêm mưa" ra cafe chu khong ra pho mua
SETS = [("phòng ngủ", "bedroom"), ("giường", "bedroom"), ("bedroom", "bedroom"), ("thành phố", "city"), ("city", "city"), ("phố", "street"), ("trạm xe", "street"), ("street", "street"),
        ("tủ đồ", "lockers"), ("hành lang", "lockers"), ("locker", "lockers"), ("lớp", "classroom"), ("class", "classroom"), ("sân bóng", "court"), ("court", "court"), ("quán", "cafe"), ("cà phê", "cafe"), ("cafe", "cafe"),
        ("phòng tập", "gym"), ("gym", "gym"), ("bao cát", "gym"), ("cầu thang", "stairs"), ("stairs", "stairs"), ("đồi", "hill"), ("núi", "hill"), ("hill", "hill"), ("gương", "mirror"), ("mirror", "mirror"),
        ("bếp", "kitchen"), ("kitchen", "kitchen"), ("khoảng tối", "void"), ("void", "void"), ("phòng tắm", "mirror"), ("phòng khách", "sofa"), ("sofa", "sofa"), ("khoảng trống", "void"),
        ("mưa", "street"), ("hoàng hôn", "hill"), ("cửa", "doorway"), ("door", "doorway"), ("đèn rọi", "void")]
SETS_WEAK = {"mưa", "hoàng hôn", "cửa", "door", "đèn rọi"}
def guess(scene, info=None):
    s = low(scene or ""); info = info if info is not None else {}
    if re.search(r"(cận|close).{0,12}(điện thoại|phone|màn hình)|tin nhắn|chat|feed|lướt|email|hộp thư", s): info["why"] = "phone"; return "phone", None
    if re.search(r"(cận|close).{0,12}(đồng hồ|clock)", s): return "clock", None
    if re.search(r"(cận|close).{0,12}(lịch|calendar)", s): return "calendar", None
    if re.search(r"sổ tay|notebook|viết chữ", s): return "note", None
    if re.search(r"(cận|close).{0,12}(mặt|face)", s): return "face", None
    if re.search(r"đồ thị|biểu đồ|\bgraph\b|\bchart\b", s): return "graph", None
    if re.search(r"màn đen|nền đen|black", s): return "black", None
    pick_ = next((v for k, v in SETS if k in s), None)
    # de bao "nhieu boi canh": bo tu nam trong tu dai hon ("phố" trong "thành phố"), bo tu yeu neu da co ten noi chon
    sp = [(m.start(), m.start() + len(k), k, v) for k, v in SETS for m in re.finditer(re.escape(k), s)]
    real = [x for x in sp if not any(y[0] <= x[0] and x[1] <= y[1] and y[1] - y[0] > x[1] - x[0] for y in sp)]
    strong = [x for x in real if x[2] not in SETS_WEAK]; hits = []
    for x in sorted(strong or real): hits.append(x[3]) if x[3] not in hits else None
    info["hits"] = [pick_] + [h for h in hits if h != pick_] if pick_ else []
    return ("scene", pick_) if pick_ else ("scene", "bedroom")

def hud_of(v):
    v = (v or "").strip()
    if v in ("-", "—", "none", "tắt", "off", ""): return None
    rows = []
    for part in re.split(r"[;/]", v):
        part = part.strip()
        m = re.match(r"^([A-Za-zÀ-ỹ ]+?)\s+(\d[\d,]*)\s*(?:(\.\.|→|->)\s*(\d[\d,]*))?\s*$", part)
        if not m: rows.append({"label": part, "n": ""}); continue
        num = lambda x: int(re.sub(r"[^\d]", "", x)) if re.sub(r"[^\d]", "", x) else 0
        r = {"label": m.group(1).strip().upper(), "n": num(m.group(2))}
        if m.group(3) == "..": r = {"label": r["label"], "from": r["n"], "to": num(m.group(4))}
        elif m.group(3): r["reset"] = {"at": None, "to": num(m.group(4))}
        rows.append(r)
    return rows

FACE_KW = [("khóc", "cry"), ("sợ", "scared"), ("sốc", "shock"), ("buồn", "sad"), ("mệt", "tired"), ("quyết tâm", "determined"), ("gồng", "effort"), ("cười", "smile"), ("trống rỗng", "empty"), ("lo", "worried"), ("giận", "angry")]
def face_of(s): return next((f for k, f in FACE_KW if k in s), "neutral")
SEC = [(r"bạn bè", "friend"), (r"cô gái", "girl"), (r"\bmẹ\b", "mom"), (r"\bbố\b", "dad")]; SEC_VI = {"friend": "bạn bè", "girl": "cô gái", "mom": "mẹ", "dad": "bố"}
def clauses(s):   # menh de (dau phay, cham phay, "và"): chu ngu = nguoi duoc nhac dau tien; khong nhac ai thi giu chu ngu menh truoc
    out, subj = [], "hero"
    for c in re.split(r"[,;]|\s+và\s+", s):
        c = c.strip()
        if not c: continue
        hit = [(m.start(), w) for k, w in SEC + [(r"\bcậu\b|nhân vật|anh ta|\bhe\b", "hero")] for m in [re.search(k, c)] if m]
        if hit: subj = min(hit)[1]
        out.append((subj, c))
    return out
def punches(at0, end, n=None):   # dam lien tuc: the thu -> dam -> thu (bao cat tu lom, so dem khi >= 3 cu)
    P_, t = [], at0
    while t <= end - 0.45 and (n is None or len(P_) < 2 * n): P_ += [[round(t, 2), "punch", 0.12], [round(t + 0.3, 2), "guard", 0.2]]; t += 0.85
    return P_

def set_hints(scene, st):
    s = low(scene or ""); sa = {}
    m = re.search(r"(\d{1,2}[:h]\d{2})", s)
    if m and st == "bedroom": sa["clock"] = m.group(1).replace("h", ":")
    if st == "bedroom" and re.search(r"kêu|reo|ring", s): sa["ring"] = True
    m = re.search(r"lịch(?: tháng)? ?([a-z]{3})?[^,;]*?tô (\d+)", s)
    if m and st == "bedroom": sa["calendar"] = {"month": (m.group(1) or "oct").upper(), "fill": int(m.group(2))}
    if "đèn bàn" in s and not re.search(r"đèn bàn tắt", s): sa["lamp"] = True
    if "laptop" in s or "máy tính" in s: sa["laptop"] = True
    if "bình minh" in s: sa["sky" if st == "bedroom" else "time"] = "dawn"
    elif "hoàng hôn" in s and st == "city": sa["time"] = "dusk"
    elif re.search(r"\bđêm\b", s) and st == "city": sa["time"] = "night"
    if "mưa" in s and st == "bedroom": sa["sky"] = "rain"
    if "cửa neon" in s or "neon" in s and st == "street": sa["neonDoor"] = 0.3
    if "chim" in s and st == "city": sa["birds"] = True
    return sa
def set_extra(s, st):   # chi tiet them trong truong NỀN (khong dung cho CẢNH doan nhu cu)
    s = low(s); sa = {}
    if st == "bedroom":
        if "tối om" in s: sa["sky"] = "dark"
        elif re.search(r"\bngày\b|ban ngày", s): sa["sky"] = "day"
        if "bàn học" in s: sa["desk"] = True
        if re.search(r"cửa phòng|cửa mở", s): sa["door"] = True; sa["doorOpen"] = 0.6
        if re.search(r"\blịch\b", s) and "calendar" not in set_hints(s, st): sa["calendar"] = True
        if "nhấp nháy" in s: sa["blink"] = True
    if st == "city" and re.search(r"\bngày\b|ban ngày", s): sa["time"] = "day"
    if st == "street":
        if "không mưa" in s: sa["rain"] = False
        if re.search(r"không (có )?trạm", s): sa["busstop"] = False
    if st == "gym":
        if re.search(r"\btạ\b", s): sa["barbell"] = True
        if "không bao cát" in s: sa["bag"] = False
    if st == "mirror" and "nứt" in s: sa["crack"] = True
    if st == "sofa":
        if "cửa sổ" in s: sa["window"] = True
        if "đèn" in s: sa["lamp"] = True
    if st == "kitchen" and "đèn" in s: sa["lamp"] = True
    if st == "doorway":
        if "cửa đóng" in s: sa["doorOpen"] = 0
        elif "cửa hé" in s: sa["doorOpen"] = 0.3
    if st == "classroom" and (m := re.search(r"bảng:\s*(.+)$", s)): sa["board"] = m.group(1).strip()
    return sa

def hints(scene, st, texts, d=5.0):
    """doan san nhan vat tu mo ta canh tieng Viet (Claude se sua lai cho dung). Nguoi phu (ban be, co gai, me, bo) giu hanh dong / bieu cam cua menh de minh."""
    s = low(scene or ""); acts = {}; actors = []; sa = {}
    cl = clauses(s); hs = s if all(w == "hero" for w, _ in cl) else ", ".join(c for w, c in cl if w == "hero")
    who = "band" if "băng đô" in s else "hooded" if "trùm mũ" in s else "hoodie" if "hoodie" in s else MAIN
    face = face_of(hs); hero = None
    if st == "bedroom" and re.search(r"nằm|ngủ trong chăn|trong chăn", hs):
        acts["bed"] = {"face": "sleep" if "ngủ" in hs and "không ngủ" not in hs else face}
        if "với tay" in hs: acts["bed"]["arm"] = {"at": 0.8}
    elif re.search(r"ngồi mép giường|ngồi trên giường", hs): hero = {"who": who, "x": "bed.sit", "pose": "sitphone" if "điện thoại" in hs else "sitsad" if face in ("sad", "cry", "empty") else "sit", "face": face, **({"hold": "phone", "glowFace": GLOW} if "điện thoại" in hs else {})}
    elif re.search(r"ngồi bàn|ngồi ở bàn", hs) and st == "bedroom": hero = {"who": who, "x": "desk.seat", "pose": "sitdesk", "face": face, "facing": 1}
    elif re.search(r"chạy", hs): hero = {"who": who, "x": 0.15, "run": {"to": 0.85}, "face": "determined"}
    elif re.search(r"đi bộ|bước đi|đi ngang", hs): hero = {"who": who, "x": 0.2, "walk": {"to": 0.75}, "face": face}
    elif re.search(r"ôm gối|ngồi bó gối", hs): hero = {"who": who, "x": 0.5, "pose": "knees", "face": face}
    elif re.search(r"\bcậu\b|nhân vật|anh ta|\bhe\b", s): hero = {"who": who, "x": 0.45, "pose": "phone" if "điện thoại" in hs else "slump" if face in ("sad", "tired", "empty") else "stand", "face": face, **({"hold": "phone", "glowFace": GLOW} if "điện thoại" in hs else {})}
    if hero: actors.append(hero)
    walkers = any(re.search(r"đi ngang|đi qua|đi bộ|bước đi|đi tới|đi lại|chạy", ", ".join(c for ww, c in cl if ww == w)) for k, w in SEC if re.search(k, s))
    if hero and walkers and hero["x"] == 0.45 and not (hero.get("walk") or hero.get("run")): hero["x"] = 0.2; hero.setdefault("facing", 1)   # nguoi phu di toi / ngang: nguoi hung dung le trai, nhin ve phia ho, khong de len nhau
    if "bóng đen" in s or any(x["kind"] == "tempt" for x in texts):
        actors.append({"who": "voice", "x": 0.62 if not actors else min(0.85, (actors[0]["x"] if isinstance(actors[0]["x"], float) else 0.55) + 0.14), "pose": "reach" if "vai" in s or "với" in s else "stand", "facing": -1, "at": 0.3})
    hx = hero["x"] if hero and isinstance(hero["x"], float) else 0.45
    for k, w in SEC:
        if not re.search(k, s): continue
        mine = ", ".join(c for ww, c in cl if ww == w); f2 = face_of(mine) if mine else "neutral"
        if re.search(r"cười đùa|vui vẻ|cười lớn", mine): f2 = "happy"
        mv = re.search(r"đi ngang|đi qua|đi bộ|bước đi|đi tới|đi lại|chạy", mine)
        if not mv: actors.append({"who": w, "x": 0.72, "pose": "stand", "face": f2, "facing": -1}); continue
        run = mv.group(0) == "chạy"; grp = ["friend", "friend2"] if w == "friend" else [w]
        x0, x1 = (0.84, 0.12) if hx <= 0.6 else (0.16, 0.88)
        if hero: x0, x1 = (0.88, round(hx + 0.26, 2)) if hx < 0.5 else (0.12, round(hx - 0.26, 2))   # co nguoi hung: di toi gan roi dung, khong di xuyen qua nguoi
        if mv.group(0) in ("đi tới", "đi lại"): x1 = round(hx + (0.17 if x0 > hx else -0.17), 2)   # di toi cho nguoi hung roi dung
        for i, ww in enumerate(grp):
            sg = 1 if x1 < x0 else -1
            actors.append({"who": ww, "x": round(x0 + sg * 0.09 * i, 2), ("run" if run else "walk"): {"to": round(x1 + sg * 0.09 * i, 2), "at": round(0.15 * i, 2)}, "face": f2, "facing": -sg})
    # dong tac ke chuyen (act), nguoi nam ngoi day (bed.up), bong den tan bien (vanish), may theo nguoi
    if hero is None: hero = next((x for x in actors if x["who"] != "voice" and not (x.get("walk") or x.get("run"))), None)
    hs_h = hs if hero is None or hero.get("who") in (MAIN, "band", "hooded", "hoodie", "hero") else ", ".join(c for ww, c in cl if ww == next((w for k, w in SEC if hero["who"].startswith(w)), "")) or s
    at = lambda k: round(max(0.4, d * k), 2)
    if hero:
        A = []
        sitting = str(hero.get("pose", "")).startswith("sit")
        if re.search(r"ném điện thoại|quăng điện thoại|vứt điện thoại", hs_h):
            hero["hold"] = "phone"
            if sitting: A.append({"do": "standUp", "at": at(0.2), "pose": "phone"}); A.append({"do": "throwPhone", "at": at(0.5)})   # dang ngoi: dung day roi nem
            else: hero["pose"] = "phone"; A.append({"do": "throwPhone", "at": at(0.4)})
        elif re.search(r"đứng dậy|đứng lên", hs_h) and sitting: A.append({"do": "standUp", "at": at(0.35)})
        if re.search(r"quỵ xuống|khuỵu|gục đầu", hs_h): A.append({"do": "collapse", "at": at(0.3)})
        if re.search(r"ngã|đổ sập|gục xuống sàn|nằm vật", hs_h): A.append({"do": "fall", "at": at(0.55)})
        if re.search(r"thở dốc|thở hổn hển|thở gấp", hs_h):
            mv = hero.get("run") or hero.get("walk")
            if mv: mv["dur"] = round(d * 0.45, 2); A.append({"do": "pant", "at": at(0.5), "dur": round(d * 0.4, 2)})   # chay / di xong moi dung tho
            else: A.append({"do": "pant", "at": at(0.25), "dur": round(d * 0.5, 2)})
        if re.search(r"quay lưng|bỏ đi|bước đi khỏi|rời đi", hs_h): A.append({"do": "walkAway", "at": at(0.3), "dur": round(max(1.5, d * 0.6), 2)}); hero.pop("walk", None); hero.pop("run", None)
        if A: hero["act"] = A
    if acts.get("bed") and re.search(r"ngồi dậy|bật dậy|tỉnh dậy ngồi", hs): acts["bed"]["up"] = {"at": at(0.35)}
    voice = next((x for x in actors if x["who"] == "voice"), None)
    if voice and re.search(r"vỡ|tan biến|biến mất|nổ tung|tan thành tro|tan dần", s):
        voice["vanish"] = {"at": at(0.6), "style": "ash" if re.search(r"tro|tan dần|tan biến dần", s) else "burst"}
        if hero and re.search(r"đấm|tung cú|đánh", hs_h): hero.update({"pose": "guard", "poseAt": [[round(voice["vanish"]["at"] - 0.16, 2), "punch", 0.12]]})   # dam trung luc bong den vo
    if hero and st == "gym" and "poseAt" not in hero and not hero.get("act") and re.search(r"đấm|tung cú", hs_h):   # dam bao cat: the thu + dam lien tuc (bao cat tu lom)
        hero.update({"pose": "guard", "face": "effort" if hero.get("face") == "neutral" else hero.get("face"), "poseAt": punches(0.6, d)}); hero.pop("hold", None); hero.pop("glowFace", None)
        sa["bagX"] = round((hero["x"] if isinstance(hero["x"], float) else 0.45) + 0.11, 2)
    if hero and (hero.get("run") or hero.get("walk")) and re.search(r"máy theo|camera theo|bám theo", s): acts["cam"] = {"from": [0.5, 0.55, 1.15], "follow": hero["who"], "lead": 0.08}
    if actors: acts["actors"] = actors
    if sa: acts["sa"] = sa
    return acts

def no_place(s):   # bo ten noi chon truoc khi do bieu cam ("phòng ngủ" khong phai mat "ngủ")
    for k, _ in sorted(NEN_VI, key=lambda kv: -len(kv[0])): s = s.replace(k, " ")
    return s
def miss_guess(scene, hm):   # CẢNH co tu the / bieu cam ma bo doan khong ra -> canh bao, de ghi AI cho chac
    s = no_place(low(scene)); cl = clauses(s); hs = s if all(w == "hero" for w, _ in cl) else ", ".join(c for w, c in cl if w == hm["who"] or (w == "hero" and hm["who"] not in SEC_VI))
    has = lambda k: re.search(r"(?<!\w)" + re.escape(k) + r"(?!\w)", hs)
    pv = next((v for k, v in sorted(POSE_VI, key=lambda kv: -len(kv[0])) if len(k) > 2 and k != "đứng" and has(k)), None)
    fam = lambda p: "sit" if str(p).startswith("sit") else p
    if pv and not (hm.get("act") or hm.get("poseAt") or hm.get("walk") or hm.get("run")) and fam(pv) != fam(hm.get("pose", "stand")) and not (pv == "phone" and hm.get("hold") == "phone"):
        warn(f"CẢNH có tư thế '{pv}' nhưng bộ đoán ra '{hm.get('pose', 'stand')}' → ghi AI: {hm['who']} <tư thế>")
    fv = next((v for k, v in sorted(FACE_VI, key=lambda kv: -len(kv[0])) if has(k)), None)
    if fv and fv != hm.get("face", "neutral") and not hm.get("faceAt") and not (fv == "smile" and hm.get("face") == "happy"):
        warn(f"CẢNH có biểu cảm '{fv}' nhưng bộ đoán ra '{hm.get('face', 'neutral')}' → ghi AI: {hm['who']} <biểu cảm>")

# ---------- truong ghi ro: AI, ĐỘNG TÁC, MÁY
def words(sg, ac, d, t=None, where="AI"):
    s = sg.strip()
    while s:
        m = re.match(r"(đi lùi|đi|chạy)\s+(?:tới|đến|sang|về)\s+(-?" + TN + r")", s)
        if m:
            seg = {"to": num(m.group(2)), "at": t if t is not None else 0}
            if m.group(1) == "đi lùi": seg["back"] = True
            for rx, k in ((r"\s+trong\s+" + TN + r"\s*s", "dur"), (r"\s+(?:từ|lúc)\s+" + TN + r"\s*s?", "at"), (r"\s+trong\s+" + TN + r"\s*s", "dur")):
                mt = re.match(rx, s[m.end():])
                if mt: seg[k] = num(mt.group(1)); s = s[:m.end()] + s[m.end() + mt.end():]
            if not seg["at"]: seg.pop("at")
            k = "run" if m.group(1) == "chạy" else "walk"; old = ac.get(k)
            ac[k] = seg if not old else ([old] if isinstance(old, dict) else old) + [seg]
            s = s[m.end():].strip(" ,"); continue
        m = re.match(r"chạy tại chỗ", s)
        if m: ac["run"] = 1.6; ac["_scroll"] = True; s = s[m.end():].strip(" ,"); continue
        m = re.match(r"(đi|chạy) (ngang|qua)|đi bộ|bước đi", s)
        if m: ac["_cross"] = "run" if s.startswith("chạy") else "walk"; s = s[m.end():].strip(" ,"); continue
        m = re.match(r"đấm (liên tục|bao cát|(\d+) cú)", s)
        if m: ac["_punch"] = (t or 0.6, int(m.group(2)) if m.group(2) else None); s = s[m.end():].strip(" ,"); continue
        m = re.match(r"(hiện|biến mất|mất|vỡ|tan biến|tan thành tro|tan tro|cao)\s+" + TN + r"\s*s?", s)
        if m:
            v, w = num(m.group(2)), m.group(1)
            if w == "hiện": ac["at"] = v
            elif w in ("biến mất", "mất"): ac["out"] = v
            elif w == "cao": ac["h"] = v
            else: ac["vanish"] = {"at": v, "style": "ash" if "tro" in w else "burst"}
            s = s[m.end():].strip(" ,"); continue
        u = unsup(s[:40])
        if u and s.startswith(u[0]): err(f"{where}: '{u[0]}' bộ dựng chưa làm được → {u[1]}"); s = s[len(u[0]):].strip(" ,"); continue
        v, r = pick(s, PH)
        if v:
            kind, val = v
            if kind == "x": ac.update(val)
            elif kind == "bed": ac["_bed"] = True
            elif kind == "hold": ac["hold"] = val
            elif t is None: ac[kind] = "sitphone" if kind == "pose" and {ac.get("pose"), val} == {"sit", "phone"} else val   # "ngồi, cầm điện thoại" = ngoi cam dien thoai
            else: ac.setdefault(kind + "At", []).append([round(t, 2), val])
            s = r; continue
        st_, r = pick(s, [(w, 1) for w in STOP])
        if st_: s = r; continue
        w = s.split(" ", 1); err(f"{where}: không hiểu '{w[0]}' trong '{sg.strip()}'{near(w[0], [k for k, _ in PH])}"); s = w[1] if len(w) > 1 else ""

def xnum(x):   # x gan dung cua moc (de dat bong den / quay mat / may)
    if isinstance(x, (int, float)): return x
    if isinstance(x, str) and x.startswith("step"): return 0.1 + 0.0944 * (int(x.split(":")[1]) + 0.5)
    return ANCH_XY.get(x, (0.5,))[0]
def ai_parse(v, st, d):
    actors, bed = [], None
    for ent in [x.strip() for x in low(v).split(";") if x.strip()]:
        who, rest = pick(ent, WHO_TB)
        if not who: err(f"AI: không rõ là ai ở '{ent}' (ghi preset: {', '.join(KHO['who'])} hoặc cậu, bạn bè, cô gái, mẹ, bố, bóng đen){near(ent.split('@')[0].strip(), [k for k, _ in WHO_TB])}"); continue
        ac = {"who": MAIN if who == "@main" else "friend" if who == "@friends" else who}
        if who == "@friends": ac["_grp"] = True
        if rest.startswith("@"):
            r = rest[1:].strip(); m = re.match(r"(-?\d+(?:[.,]\d+)?)", r); ms = re.match(r"(?:step:|bậc\s*)(\d)", r)
            if ms: ac["x"] = f"step:{ms.group(1)}"; rest = r[ms.end():]
            elif m: ac["x"] = num(m.group(1)); rest = r[m.end():]
            else:
                an, rr = pick(r, ANCH_TB)
                if an: ac["x"] = an; rest = rr
                else: err(f"AI: không có mốc '@{r.split(' ')[0]}'{near(r.split(' ')[0], [k for k, _ in ANCH_TB])}"); rest = r.split(" ", 1)[1] if " " in r else ""
        for tok in [x.strip() for x in rest.split(",") if x.strip()]:
            segs = re.split(r"\s*(?:→|->)\s*", tok)
            for i, sg in enumerate(segs):
                t = None
                if i:
                    t, sg = tsec(sg)
                    if t is None: t = round(d * i / len(segs), 2)
                words(sg, ac, d, t)
        actors.append(ac)
    # sau khi doc: cam dien thoai, giuong, vi tri mac dinh, nguoi phu nhin ve nguoi chinh
    for ac in actors:
        if ac.get("hold") == "phone": ac["pose"] = {"sit": "sitphone", None: "phone", "stand": "phone"}.get(ac.get("pose"), ac.get("pose"))
        if ac.get("pose") in ("phone", "sitphone"): ac.setdefault("hold", "phone"); ac.setdefault("glowFace", GLOW)
        if ac.get("pose") == "umbrella": ac.setdefault("hold", "umbrella")
    for ac in [x for x in actors if x.pop("_bed", False)]:
        if st == "bedroom" and bed is None:
            bed = {"who": ac["who"], "face": ac.get("face", "sleep")}
            if ac.get("faceAt"): bed["faceAt"] = ac["faceAt"]
            actors.remove(ac)
        else: ac["pose"] = "lie"
    hum = [x for x in actors if x["who"] != "voice"]; main = hum[0] if hum else None
    for i, ac in enumerate(hum):
        if "x" not in ac: ac["x"] = 0.45 if i == 0 else [0.72, 0.25, 0.6, 0.85][(i - 1) % 4]
    mx = xnum(main["x"]) if main else ANCH_XY["bed.head"][0] if bed else 0.5   # 1.10: nguoi nam giuong -> bong den quay ve dau giuong (truoc: lay 0.5 -> quay lung)
    for ac in actors:
        if ac["who"] == "voice":
            ac.setdefault("x", round(min(0.85, mx + 0.14), 2)); ac.setdefault("pose", "stand"); ac.setdefault("facing", -1 if xnum(ac["x"]) >= mx else 1); ac.setdefault("at", 0.3)
        cr = ac.pop("_cross", None)
        if cr:
            x0 = ac["x"] if isinstance(ac["x"], (int, float)) else 0.84; ac[cr] = {"to": 0.12 if x0 > 0.5 else 0.88}
        p = ac.pop("_punch", None)
        if p: ac.setdefault("pose", "guard"); ac["poseAt"] = ac.get("poseAt", []) + punches(p[0], d, p[1]); ac.setdefault("face", "effort")
    for ac in [x for x in actors if x.pop("_grp", False)]:   # ban be = 2 nguoi
        b2 = json.loads(json.dumps(ac)); b2["who"] = "friend2"
        if isinstance(b2.get("x"), (int, float)):
            sg = 1 if b2["x"] >= mx else -1; b2["x"] = round(b2["x"] + sg * 0.09, 2)
            for k in ("walk", "run"):
                for seg in ([b2[k]] if isinstance(b2.get(k), dict) else b2.get(k) or []):
                    seg["to"] = round(seg["to"] + sg * 0.09, 2); seg["at"] = round(seg.get("at", 0) + 0.15, 2)
        actors.insert(actors.index(ac) + 1, b2)
    for ac in actors:
        if ac is main or ac["who"] == "voice" or not isinstance(ac.get("x"), (int, float)): continue
        mv = ac.get("walk") or ac.get("run")
        if "facing" not in ac and not mv: ac["facing"] = -1 if ac["x"] > mx else 1
        if mv and main and "behind" not in ac:
            to = (mv[-1] if isinstance(mv, list) else mv)["to"] if not isinstance(mv, (int, float)) else ac["x"]
            if min(ac["x"], to) < mx < max(ac["x"], to): ac["behind"] = True   # di ngang qua nguoi chinh: di phia sau
    if main and "facing" not in main and isinstance(main.get("x"), (int, float)):
        o = next((x for x in hum if x is not main and isinstance(x.get("x"), (int, float))), None)
        if o and not (main.get("walk") or main.get("run")): main["facing"] = 1 if o["x"] > main["x"] else -1
    return actors, bed

def dt_parse(v, actors, bed, d, args, st):
    for ent in [x.strip() for x in low(v).split(";") if x.strip()]:
        who, rest = pick(ent, WHO_TB); rest = rest.lstrip(": ").strip()
        t, rest = tsec(rest)
        if t is None: t = round(d * 0.4, 2); warn(f"ĐỘNG TÁC '{ent}': không ghi giây, lấy {t}s")
        if t > d: err(f"ĐỘNG TÁC '{ent}': giây {t} quá dài so với cảnh {d}s")
        w = None if not who else MAIN if who == "@main" else who
        if bed is not None and (w is None or w == bed["who"]):
            m = re.match(r"ngồi dậy|bật dậy|tỉnh dậy|với tay|tắt báo thức|trở mình|nằm nghiêng|nằm ngửa", rest)
            if m:
                k = m.group(0)
                if k in ("ngồi dậy", "bật dậy", "tỉnh dậy"): bed["up"] = {"at": t}
                elif k in ("với tay", "tắt báo thức"): bed["arm"] = {"at": t}
                else: bed.setdefault("rollAt", []).append([t, "back" if k == "nằm ngửa" else "side"])
                continue
            fv, r = pick(rest, [(k, x) for k, x in PH if x[0] == "face"])
            if fv and not r and not [x for x in actors if x["who"] != "voice"]: bed.setdefault("faceAt", []).append([t, fv[1]]); continue
        tg = [x for x in actors if x["who"] in ("friend", "friend2")] if who == "@friends" else [x for x in actors if x["who"] == w] if w else [x for x in actors if x["who"] != "voice"][:1]
        if not tg: err(f"ĐỘNG TÁC '{ent}': không có người này trong AI (hoặc CẢNH)"); continue
        for ac in tg: dt_one(ac, rest, t, d, args, st, ent)

def dt_one(ac, rest, t, d, args, st, ent):
    A = ac.setdefault("act", [])
    m = re.match(r"(đi lùi|đi|chạy)\s+(?:tới|đến|sang|về)\s+(-?" + TN + r")(?:\s+trong\s+" + TN + r"\s*s)?", rest)
    if m:
        seg = {"to": num(m.group(2)), "at": t}
        if m.group(4): seg["dur"] = num(m.group(4))
        if m.group(1) == "đi lùi": seg["back"] = True
        k = "run" if m.group(1) == "chạy" else "walk"; old = ac.get(k)
        ac[k] = seg if not isinstance(old, (dict, list)) else ([old] if isinstance(old, dict) else old) + [seg]
    elif re.match(r"chạy tại chỗ", rest): ac["run"] = 1.6; (args.setdefault("setArgs", {}).__setitem__("scroll", "sync") if st == "city" else None)
    elif (m := re.match(r"đấm(?: (liên tục|bao cát|(\d+) cú))?$", rest)): ac.setdefault("pose", "guard"); ac["poseAt"] = ac.get("poseAt", []) + punches(t, d, int(m.group(2)) if m.group(2) else None if m.group(1) else 1)
    elif (m := re.match(r"quay (trái|phải|lại|người|đi)$", rest)):
        f0 = ac.get("facing", 1); ac.setdefault("facingAt", []).append([t, -1 if m.group(1) == "trái" else 1 if m.group(1) == "phải" else -f0])
    elif re.match(r"hiện( ra)?$|xuất hiện$", rest): ac["at"] = t
    elif re.match(r"biến mất$|mất$|mờ đi$", rest): ac["out"] = t
    elif re.match(r"(vỡ|tan biến|nổ tung|vỡ tan)$", rest):
        if ac["who"] != "voice": err(f"ĐỘNG TÁC '{ent}': chỉ bóng đen mới vỡ / tan biến")
        else: ac["vanish"] = {"at": t, "style": "burst"}
    elif re.match(r"tan (thành )?tro$|tan dần$", rest):
        if ac["who"] != "voice": err(f"ĐỘNG TÁC '{ent}': chỉ bóng đen mới tan thành tro")
        else: ac["vanish"] = {"at": t, "style": "ash"}
    else:
        v, r = pick(rest, DT_VI)
        if v and not r.strip():
            e = {"do": v.rstrip("!"), "at": t}
            if v == "walkAway!": e["run"] = True
            if v == "pant": e["dur"] = round(min(2.0, max(0.8, d - t - 0.6)), 2)
            if v == "throwPhone":
                ac["hold"] = "phone"
                if str(ac.get("pose", "")).startswith("sit"): A.append({"do": "standUp", "at": round(max(0.2, t - 0.9), 2), "pose": "phone"})
            if v.startswith("walkAway"): ac.pop("walk", None); ac.pop("run", None)
            A.append(e)
        else:
            pv, r2 = pick(rest, [(k, x) for k, x in PH if x[0] in ("pose", "face")])
            if pv and not r2.strip(): ac.setdefault(pv[0] + "At", []).append([round(t, 2), pv[1]])
            else:
                u = unsup(rest)
                if u: err(f"ĐỘNG TÁC '{ent}': '{u[0]}' bộ dựng chưa làm được → {u[1]}")
                else: err(f"ĐỘNG TÁC '{ent}': không hiểu '{rest}'{near(rest, [k for k, _ in DT_VI] + [k for k, x in PH if x[0] in ('pose', 'face')])}")
    if not A: ac.pop("act", None)

def focus(args, tp, cfg):   # diem nhin cua may: (x, giua nguoi, mat) cua nhan vat chinh
    if tp != "scene": return 0.5, 0.5, 0.42
    gy = 0.7 if (cfg or {}).get("aspect") == "9:16" else 0.8
    if args.get("bed"): return 0.32, 0.66, 0.66
    m = next((x for x in args.get("actors", []) if x["who"] != "voice"), None)
    if not m: return 0.5, 0.5, 0.45
    x = m.get("x", 0.45)
    if isinstance(x, str): x, gy = ANCH_XY.get(x, (0.5, gy)) if not x.startswith("step") else (0.1 + 0.0944 * (int(x.split(":")[1]) + 0.5), gy - int(x.split(":")[1]) * 0.069)
    h = m.get("h", 0.42); low_ = str(m.get("pose", "")).startswith("sit") or m.get("pose") in ("knees", "kneel", "crouch", "lie")
    hy = gy - h * (0.6 if low_ else 0.86)
    return round(x, 3), round((gy + hy) / 2, 3), round(hy, 3)
def cam_parse(v, args, tp, d, cfg):
    cam = {}; shake = []; cx, cy, hy = focus(args, tp, cfg)
    main = next((x for x in args.get("actors", []) if x["who"] != "voice"), None)
    for tok in [x.strip() for x in low(v).split(",") if x.strip()]:
        t, tok2 = tsec(tok); k, r = pick(tok2, CAM_VI)
        if not k or r.strip(): err(f"MÁY: không hiểu '{tok}'{near(tok2, [x for x, _ in CAM_VI])}"); continue
        if k[:2] in ("s:", "a:", "m:"):   # 2.0: chi che do cinematic hieu (co khung / goc / chuyen dong 3D)
            if (cfg or {}).get("mode") != "cinematic": warn(f"MÁY: '{tok}' chỉ dùng ở chế độ cinematic (config.json \"mode\": \"cinematic\") → bỏ qua"); continue
            args.setdefault("shot", {})[{"s:": "size", "a:": "angle", "m:": "move"}[k[:2]]] = k[2:]; continue
        if k == "push": cam.update({"from": [cx, 0.5, 1.0], "to": [cx, round(min(cy, 0.52), 3), 1.15]})   # giu dau nguoi duoi dong chu ke chuyen
        elif k == "pushface": cam.update({"from": [cx, cy, 1.0], "to": [cx, hy, 1.4 if tp == "scene" else 1.2]})
        elif k == "pushfast": cam.update({"from": [cx, cy, 1.0], "to": [cx, hy, 1.45 if tp == "scene" else 1.25], "dur": round(min(1.2, d * 0.4), 2)})
        elif k == "pull": cam.update({"from": [cx, hy, 1.35 if tp == "scene" else 1.2], "to": [0.5, 0.5, 1.0]})
        elif k in ("panL", "panR"): sg = 1 if k == "panL" else -1; cam.update({"from": [round(cx + sg * 0.06, 3), 0.5, 1.1], "to": [round(cx - sg * 0.06, 3), 0.5, 1.1]})
        elif k == "follow":
            if not main or not (main.get("walk") or main.get("run")): err("MÁY: bám theo cần người chính đang đi / chạy (AI: ... đi tới x / chạy tới x)"); continue
            cam.update({"from": [0.5, 0.55, 1.15], "follow": main["who"], "lead": 0.08})
        elif k in ("shake", "shake2"): shake.append({"at": t if t is not None else round(d * 0.5, 2), "amt": 1 if k == "shake" else 1.6, "dur": 0.45}); continue
        elif k == "hand": cam["hand"] = 2
        elif k == "still": cam.update({"from": [0.5, 0.5, 1.0], "to": [0.5, 0.5, 1.0], "hand": 0})
        elif k == "wide": cam.update({"from": [0.5, 0.5, 1.0], "to": [0.5, 0.5, 1.0]})
        if t is not None and k.startswith("push"): cam["at"] = t
    if cam: args["cam"] = cam
    if shake: args["shake"] = shake

def nen_of(v):
    val, rest = pick(low(v), NEN_TB)
    if not val:
        err(f"NỀN: không có bối cảnh / mẫu cảnh '{v}'{near(low(v).split(',')[0].strip(), [k for k, _ in NEN_TB])}"); return None, None, ""
    if val.startswith("@"): return val[1:], None, rest
    return ("black", None, rest) if val == "black" else ("scene", val, rest)

TEMPT_CPS = 16
def read_time(tx):
    w = len(tx["t"].split())
    if tx["kind"] == "tempt": return 0.9 + len(tx["t"]) / TEMPT_CPS + 0.6
    if tx["kind"] == "say": return 1.6
    if tx["kind"] == "chat": return 1.0 + w * 0.22
    return max(1.8, min(4.5, 1.0 + w * 0.32))

cfg0 = read_json(os.path.join(P, "config.json"), {}) if P else {}
shots = []; music = []; t = 0.0; hud = None; bed = None; warn_old = []; seen_ids = set(); explicit = 0; n_black = 0; last_g = (1.0, 0.0)
GRADE = {"sad": (0.85, 0.0), "dark": (0.4, 0.1), "none": (0.25, 0.15), "tension": (0.5, 0.08), "mystery": (0.55, 0.08), "emotional": (0.75, 0.0)}   # bao hoa, toi them; nhac khac = du mau
for b in beats:
    CUR[0] = b["id"]; d = b["dur"]; scene = tag(b, "cảnh", "canh", "scene") or ""
    if b["id"] in seen_ids: err(f"trùng mã cảnh {b['id']}")
    seen_ids.add(b["id"])
    nen = tag(b, "nền", "nen", "set"); ai = tag(b, "ai", "cast"); dtac = tag(b, "động tác", "dong tac", "act"); may = tag(b, "máy", "may", "cam")
    if any(x is not None for x in (nen, ai, dtac, may)): explicit += 1
    tk = tag(b, "thẻ kết", "the ket", "card"); cta = any(k.startswith(("kêu gọi", "keu goi", "cta")) for k in b["tags"])
    h = tag(b, "hud");
    if h is not None: hud = hud_of(h)
    for r in (hud_of(h) or []) if h is not None else []:
        if len(str(r.get("label", ""))) > 9 and (r.get("n") not in ("", None) or "from" in r): warn(f"nhãn bộ đếm '{r['label']}' dài hơn 9 ký tự: số dễ dính vào chữ → rút ngắn (vd HOURS, AGE)")
    mz = tag(b, "nhạc", "nhac", "music")
    if mz is not None:
        name = low(mz).split()[0] if mz.strip() else "none"; name = {"tắt": "none", "drop": "none", "off": "none", "buồn": "sad", "tối": "dark", "lên": "rise", "kết": "resolve"}.get(name, name)
        if name in MUSIC_FULL: warn(f"NHẠC '{name}' chỉ có khi cài đầy đủ (cài gọn sẽ im); dùng {', '.join(MUSIC[:-1])}")
        elif name not in MUSIC: err(f"NHẠC: không có '{mz}'{near(name, MUSIC + MUSIC_FULL)}")
        if music: music[-1]["end"] = round(t, 3)
        music.append({"start": round(t, 3), "end": None, "bed": name})
    sfx = []
    for x in (tag(b, "sfx") or "").split(","):
        x = x.strip()
        if not x: continue
        nm, _, tt = x.partition("@"); nm = nm.strip()
        try: at_ = float(tt.replace(",", ".")) if tt else 0.2
        except ValueError: err(f"SFX '{x}': giây sai"); at_ = 0.2
        if not any(k == nm or k.startswith(nm) for k in SFX): err(f"SFX: không có '{nm}'{near(nm, SFX)}")
        if at_ > d: warn(f"SFX {nm}@{at_} sau khi cảnh đã hết ({d}s)")
        sfx.append({"at": at_, "name": nm, "gain": -8})
    # chu: xep lan luot
    texts = []; cursor = 0.35; chats = []
    for tx in b["texts"]:
        if tx["kind"] == "chat": chats.append(tx); continue
        at = tx["at"] if tx["at"] is not None else cursor
        item = {"kind": tx["kind"], "t": tx["t"], "at": round(at, 2)}
        if tx.get("who"): item["who"] = tx["who"]
        texts.append(item); cursor = at + read_time(tx)
    # man den co tu 2 dong ke chuyen tro len: dong cuoi thanh dong nhan to (big), giong kenh mau
    if re.search(r"màn đen|nền đen|black", low(scene)) and not any(x["kind"] == "big" for x in texts):
        nar = [x for x in texts if x["kind"] == "narr"]
        if len(nar) >= 2: nar[-1]["kind"] = "big"
    # thoi luong: chu ke chuyen giu toi chu ke chuyen ke tiep / het canh; cam do va bong bong co thoi luong rieng
    for i, it in enumerate(texts):
        nxt = next((x["at"] for x in texts[i + 1:] if x["kind"] == it["kind"]), None)
        if it["kind"] in ("narr", "big"): it["dur"] = round((nxt if nxt is not None else d) - it["at"] - 0.15, 2)
        else: it["dur"] = round(min(read_time(it), (nxt if nxt is not None else d) - it["at"] - 0.1), 2)
        need = read_time(it); have = it["dur"] + (0.15 if it["kind"] in ("narr", "big") else 0.1)
        if have < need - 0.3: err(f"chữ '{it['t'][:40]}' cần {need:.1f}s đọc nhưng chỉ có {max(0, have):.1f}s → tăng giây cảnh / bớt chữ / dời {{giây}}")
        if it["kind"] == "narr" and len(it["t"].split()) > 9: warn(f"chữ kể chuyện quá 9 từ: '{it['t']}'")
        if it["kind"] == "tempt" and (len(it["t"].split()) > 7 or it["t"][:1].isupper()): warn(f"giọng cám dỗ nên viết thường, 2–7 từ: '{it['t']}'")
    if cursor > d + 0.3: warn_old.append(f"{b['id']}: chu can {cursor:.1f}s nhung canh chi {d}s"); err(f"chữ cần {cursor:.1f}s nhưng cảnh chỉ {d}s")
    if sum(1 for x in texts if x["kind"] == "narr") > 2: warn("quá 2 câu kể chuyện trong 1 cảnh")
    if not (tk is not None or cta) and not (2 <= d <= 9): warn(f"cảnh {d}s (nên 2–9s)")
    sh = {"id": b["id"], "start": round(t, 3), "end": round(t + d, 3), "line": " / ".join(x["t"] for x in b["texts"])[:120], "scene": scene, "in": {"type": "cut"}, "sfx": sfx, "notes": ""}
    if tk is not None:
        parts = [x.strip() for x in tk.split("/")]
        args = {"word": parts[0] if parts else "", "texts": []}
        mp = re.search(r"\s*\bpart\s*(\d+)\b", parts[0], re.I) if parts else None
        if mp: args["word"] = (parts[0][:mp.start()] + parts[0][mp.end():]).strip(); args["part"] = f"PART {mp.group(1)}"   # "LUST. PART 2" -> word + part
        if len(parts) > 1: args["sub"] = parts[1]
        if len(parts) > 2: args["sub2"] = parts[2]; args["sub2At"] = round(min(d - 1.0, 3.0), 2)
        if len(parts) < 3: warn("THẺ KẾT nên có dạng WORD. / dòng phụ / dòng phụ màu nhấn")
        sh.update({"tpl": "card", "args": args}); sh["in"] = {"type": "dip", "dur": 0.6}
    elif cta:
        if d > 4.0: warn(f"KÊU GỌI {d}s: đối thủ không có màn kêu gọi, kết bằng thẻ kết; giữ ≤ 4s kẻo người xem thoát trước")
        sh.update({"tpl": "cta", "args": {"line": (texts[0]["t"] if texts else "If this hit, like and subscribe.")}})
        if len(texts) > 1: sh["args"]["line2"] = texts[1]["t"]   # dong 2 (mau nhan): vd cau ky ten kenh o dong 1, loi moi o dong 2
    else:
        gi = {}; rest = ""
        if nen is not None:
            tp, st, rest = nen_of(nen)
            if tp is None: tp, st = guess(scene, gi)
            else:
                g2 = {}; tg, sg = guess(scene, g2)
                if scene and tg == "scene" and tp == "scene" and g2.get("hits") and st not in g2["hits"]: warn(f"CẢNH gợi ý '{g2['hits'][0]}' nhưng NỀN là '{st}' (đang dùng NỀN)")
        else:
            tp, st = guess(scene, gi)
            if tp == "scene" and not gi.get("hits"): err(f"không nhận ra bối cảnh trong CẢNH '{scene[:50]}' → đang mặc định phòng ngủ; ghi NỀN:")
            elif tp == "scene" and len(gi["hits"]) > 1: warn(f"CẢNH có nhiều bối cảnh {gi['hits']} → chọn '{st}'; ghi NỀN: cho chắc")
            elif gi.get("why") == "phone" and not re.search(r"cận|close", low(scene)): warn(f"đoán là cận điện thoại (vì có chữ tin nhắn / lướt / feed…); nếu là cảnh người cầm điện thoại thì ghi NỀN:")
        if tp == "scene" and ai is None and dtac is None and (u := unsup(low(scene))): warn(f"CẢNH có '{u[0]}' nhưng bộ dựng chưa làm động tác này → {u[1]}")
        args = {"texts": texts}
        if hud and tp not in ("black", "graph"): args["hud"] = {"rows": json.loads(json.dumps(hud))}
        for r in (args.get("hud") or {}).get("rows", []):
            if "reset" in r and r["reset"]["at"] is None: r["reset"]["at"] = round(min(d * 0.5, 1.5), 2)
            if "from" in r: r["at"] = 0.3; r["dur"] = round(max(0.6, d - 0.8), 2)
        if tp == "scene":
            args["set"] = st; sa = set_hints(((rest + ", ") if rest else "") + scene, st)
            if nen is not None: sa.update(set_extra(rest, st))
            if ai is not None:
                acts_l, bd = ai_parse(ai, st, d); acts = {"actors": acts_l} if acts_l else {}
                if bd: acts["bed"] = bd
                if [x.pop("_scroll") for x in acts_l if "_scroll" in x] and st == "city": sa["scroll"] = "sync"
                for k, w in SEC:
                    if re.search(k, low(scene)) and not any(x["who"].startswith(w) for x in acts_l): warn(f"CẢNH nhắc '{SEC_VI[w]}' nhưng AI không có {w}")
            else:
                acts = hints(scene, st, texts, d); sa.update(acts.pop("sa", {}))
                hm = next((x for x in acts.get("actors", []) if x["who"] != "voice"), None)
                if hm and dtac is None: miss_guess(scene, hm)
            if dtac is not None: dt_parse(dtac, acts.setdefault("actors", []), acts.get("bed"), d, {"setArgs": sa}, st)
            if not acts.get("actors"): acts.pop("actors", None)
            if st == "gym" and "bagX" not in sa:   # dam bao cat: dat bao cat ngay tam dam cua nguoi dam
                p0 = next((x for x in acts.get("actors", []) if any(e[1] == "punch" for e in x.get("poseAt", [])) and isinstance(x.get("x"), (int, float))), None)
                if p0: sa["bagX"] = round(p0["x"] + 0.11 * (1 if p0.get("facing", 1) > 0 else -1), 2)
            for x in acts.get("actors", []):   # moc phai dung boi canh; moc can do vat thi tu bat do vat
                an = x.get("x")
                if isinstance(an, str):
                    need = "stairs" if an.startswith("step") else ANCH_SET.get(an)
                    if need and need != st: err(f"{x['who']}: mốc '{an}' chỉ có ở bối cảnh '{need}', cảnh này là '{st}'")
                    if an == "desk.seat" and not (sa.get("desk") or sa.get("lamp") or sa.get("laptop")): sa["desk"] = True
                    if an == "neon" and "neonDoor" not in sa: sa["neonDoor"] = 0.3
                    ay = 0.8 - int(an.split(":")[1]) * 0.069 if an.startswith("step") else ANCH_XY.get(an, (0, 0.8))[1]
                    if ay - x.get("h", 0.48 if x["who"] == "voice" else 0.42) < 0.12 and not x.get("inMirror"): warn(f"{x['who']} ở '{an}' cao quá, đầu ra ngoài khung → hạ bậc / MÁY: kéo ra")
                    if str(x.get("pose", "")).startswith("sit") and an in ("table.left", "table.right"): warn("quán cà phê chưa có ghế: người ngồi sẽ lơ lửng → đứng @bàn trái, hoặc ngồi ở chỗ có ghế (mép giường, ghế bàn, sofa, ghế xe buýt, ghế băng)")
                elif isinstance(an, (int, float)) and not (-0.2 <= an <= 1.2): warn(f"{x['who']}: x = {an} nằm ngoài khung")
                if x["who"] not in KHO["who"]: err(f"không có preset '{x['who']}'")
                if x.get("pose") and x["pose"] not in KHO["pose"]: err(f"{x['who']}: không có tư thế '{x['pose']}'")
                if x.get("face") and x["face"] not in KHO["face"]: err(f"{x['who']}: không có biểu cảm '{x['face']}'")
                if str(x.get("pose", "")).startswith("sit") and isinstance(an, (int, float)) and st in ("bedroom", "cafe", "sofa", "court", "street"): warn(f"{x['who']} ngồi ở x số (không có ghế) → dùng mốc ngồi của '{st}'")
            if sa: args["setArgs"] = sa
            if acts.get("bed"): args["bed"] = acts.pop("bed")
            if acts.get("cam"): args["cam"] = acts.pop("cam")
            if acts.get("actors"): args["actors"] = acts["actors"]
            if ai is not None and any(x["kind"] == "tempt" for x in texts) and not any(x["who"] == "voice" for x in args.get("actors", [])): warn("có giọng cám dỗ (~) nhưng AI không có bóng đen → chữ đặt cạnh đầu người hùng")
        if tp == "face":
            s = low(scene); fa = {}
            if ai is not None:
                al, _ = ai_parse(ai, None, d)
                if dtac is not None: dt_parse(dtac, al, None, d, {}, None)
                m0 = next((x for x in al if x["who"] != "voice"), None)
                if m0: fa = {k: v for k, v in m0.items() if k in ("who", "face", "faceAt", "pose", "poseAt", "facing", "facingAt", "hold", "tears", "sweat", "bloodshot", "glowFace", "look")}
                if any(x["who"] == "voice" for x in al): warn("cận mặt: bóng đen chưa đặt được trong mẫu cận mặt, bỏ qua")
            else:   # cận mặt doan tu CẢNH: giu bieu cam ("cận mặt cậu khóc" -> cry)
                fa = {"who": "band" if "băng đô" in s else "hooded" if "trùm mũ" in s else "hoodie" if "hoodie" in s else MAIN, "face": face_of(s)}
                if fa["face"] == "neutral": fa["face"] = next((v for k, v in sorted(FACE_VI, key=lambda kv: -len(kv[0])) if re.search(r"(?<!\w)" + re.escape(k) + r"(?!\w)", no_place(s))), "neutral")
                if re.search(r"mắt đỏ|gân máu", s): fa["bloodshot"] = True
                if "nước mắt" in s: fa["tears"] = True
                if "mồ hôi" in s: fa["sweat"] = True
                if re.search(r"ánh màn hình|điện thoại", s): fa["glowFace"] = GLOW
            bgv, _ = pick(re.sub(r"^.*?nền\s+", "", rest) if "nền" in rest else "", NEN_TB)
            if bgv and not bgv.startswith("@") and bgv != "black": fa["bg"] = bgv
            args.update(fa)
        if tp == "clock":
            sl = low(rest + " " + scene); tms = re.findall(r"(\d{1,2}:\d{2})", sl)
            if tms: args["time"] = tms[0]
            if len(tms) > 1: args["timeAt"] = [[round(d * 0.4, 2), tms[1]]]
            if re.search(r"kêu|reo|ring", sl): args["ring"] = True
            if "nhấp nháy" in sl: args["blink"] = True
        if tp == "calendar":
            sl = low(rest + " " + scene); mm = re.search(r"tháng\s+([a-z]{3})", sl); nn = re.findall(r"(\d+)\s*(?:tới|đến|->|→)\s*(\d+)", sl)
            args["month"] = (mm.group(1) if mm else "oct").upper()
            if nn: args["from"], args["to"] = int(nn[0][0]), int(nn[0][1])
            else: args["from"], args["to"] = 0, 20
            args["mode"] = "fill" if "tô màu" in sl else "x"
            if re.search(r"xoá|xóa|về 0", sl): args["reset"] = {"at": round(d * 0.6, 2)}
        if tp == "note":
            nt = [x["t"] for x in texts if x["kind"] == "narr"]
            if nen is not None and nt: args["text"] = "\n".join(nt); args["texts"] = [x for x in texts if x["kind"] != "narr"]   # NỀN: sổ tay -> dong chu viet vao so
        if tp == "graph":   # 1.10 do thi cam xuc (kieu DOPAMINE)
            sl = low(rest + " " + scene)
            args["kind"] = ("climb" if re.search(r"đi lên|tăng dần|lên chậm|leo dần|climb|hồi phục", sl) else "spikes" if re.search(r"nhiều đỉnh|spikes|lên xuống liên tục", sl)
                            else "flat" if re.search(r"phẳng|flat|đi ngang", sl) else "crash")
            lb = re.search(r'nhãn\s*["“]([^"”]+)["”]', rest + " " + scene)
            if lb: args["label"] = {"t": lb.group(1), "at": 0.12 if args["kind"] == "climb" else 0.6}
            args["at"] = 0.6; args["dur"] = round(max(1.2, d - 1.6), 2)
            if d < 4: warn(f"đồ thị {d}s: cần ≥ 4s để vẽ xong và kịp đọc")
        if tp == "phone":
            s = low(scene); r0 = low(rest)
            sv, _ = pick(r0, SCREEN_VI) if r0 else (None, "")
            if not sv: sv = next((v for k, v in SCREEN_VI if k in r0), None) if r0 else None
            scr = sv or ("chat" if (chats or "tin nhắn" in s or "chat" in s) else "email" if ("email" in s or "hộp thư" in s) else "lock" if re.search(r"màn khoá|màn khóa", s)
                         else "counter" if re.search(r"đếm ngày|ứng dụng đếm", s) else "off" if re.search(r"màn (hình )?tắt|phản chiếu", s) else "reel" if ("video" in s or "xem" in s) else "feed")
            args["screen"] = scr; s = r0 + " " + s
            found = []
            for k, v in ART:
                i = s.find(k)
                if i >= 0 and v not in [f[1] for f in found]: found.append((i, v))
            found = [v for _, v in sorted(found)]
            if scr == "feed" and found: args["posts"] = found
            if scr == "reel" and found: args["art"] = found[0]
            if scr == "feed" and re.search(r"lướt nhanh|nhanh", s): args["hold"] = 0.6
            if scr == "counter" and hud and isinstance(hud[0].get("n", hud[0].get("to")), int): args["n"] = hud[0].get("to", hud[0].get("n"))
            if scr == "off": args["reflect"] = True
            if scr == "lock":
                tm = re.search(r"(\d{1,2}:\d{2})", s)
                if tm: args["time"] = tm.group(1)
                if chats: args["notes"] = [{"app": c.get("name") or "Messages", "text": c["t"], "at": round(c["at"] if c["at"] is not None else 0.6 + 0.9 * i, 2)} for i, c in enumerate(chats)]
            if "nền" in r0:
                bgv, _ = pick(re.sub(r"^.*?nền\s+", "", r0), NEN_TB)
                if bgv and not bgv.startswith("@") and bgv != "black": args["bg"] = bgv
            if chats and scr == "chat":
                c0 = 0.4; msgs = []
                for c in chats:
                    at = c["at"] if c["at"] is not None else c0; msgs.append({"text": c["t"], "me": c["me"], "at": round(at, 2)}); c0 = at + read_time(c)
                    if not c["me"] and c.get("name"): args["name"] = c["name"]
                args["messages"] = msgs
                if c0 > d + 0.3: err(f"tin nhắn cần {c0:.1f}s nhưng cảnh chỉ {d}s")
        if chats and not (tp == "phone" and args.get("screen") in ("chat", "lock")): err("dòng tin nhắn (@) chỉ hiện ở cảnh điện thoại chat / màn khoá → ghi NỀN: cận điện thoại, chat")
        if may is not None: cam_parse(may, args, tp, d, cfg0)
        # 1.10 mau the gioi theo nhip nhac (kieu DOPAMINE / LUST): sa nga mat mau dan, day gan nhu xam, buoc ngoat mau tro lai. Ghi tay: MÀU: xám | đủ màu | hồi màu
        cur = (music[-1]["bed"] if music else "sad")
        gs, gd = GRADE.get(cur, (1.0, 0.0))
        mt = tag(b, "màu", "mau", "grade")
        if mt is not None:
            ml = low(mt)
            if re.search(r"hồi màu|trả màu|color ?back", ml): gs, gd = 1.0, 0.0; last_g = (min(last_g[0], 0.35), max(last_g[1], 0.1))
            elif re.search(r"xám|mất màu|grey|gray", ml): gs, gd = 0.15, 0.12
            elif re.search(r"nhạt|bớt màu", ml): gs, gd = 0.6, 0.05
            elif re.search(r"đủ màu|full|giữ màu", ml): gs, gd = 1.0, 0.0
            else: warn(f"MÀU: không hiểu '{mt}' (xám / nhạt / đủ màu / hồi màu)")
        if tp in ("scene", "phone", "face") and cfg0.get("colorArc") is not False:
            if gs >= 0.99 and gd <= 0.001 and last_g[0] < 0.6:   # vua thoat khoi doan toi: mau tro lai dan trong 1,5 giay
                args["grade"] = {"sat": [last_g[0], 1.0], "dim": [last_g[1], 0.0], "at": 0.2, "dur": 1.5}
            elif gs < 0.99 or gd > 0.001: args["grade"] = {"sat": gs, "dim": gd}
            last_g = (gs, gd)
        # 1.10 tuoi gia: bo dem AGE >= 55 hoac CẢNH noi "già / tóc bạc" -> nguoi hung khom, nep nhan, toc bac
        age_n = next((r.get("n") for r in (hud or []) if str(r.get("label", "")).upper() in ("AGE", "TUỔI", "TUOI") and isinstance(r.get("n"), int)), None)
        if (age_n is not None and age_n >= 55) or re.search(r"(?<!\w)già(?!\w)|ông lão|tóc bạc", low(scene)):
            for x in args.get("actors", []):
                if x.get("who") in ("hero", "band", "hoodie", "hooded"): x["age"] = "old"
            if args.get("bed"): args["bed"]["age"] = "old"
            if tp == "face": args["age"] = "old"
        if tp == "black":
            n_black += 1
            if d > 5.0: warn(f"màn đen {d}s: đối thủ giữ màn chữ 2–5s (1 dòng ~2s, 2 dòng ~4–5s); dài hơn là đứng hình → rút giây hoặc tách thành cảnh có hình")
        sh.update({"tpl": tp, "args": args})
        if nen is not None or ai is not None: sh["notes"] = "doc tu truong ghi ro (NEN/AI)"
        # nhan vat goi y theo chu
        if tp == "scene" and ai is None and any(x["kind"] == "tempt" for x in texts): sh["notes"] = "co giong cam do: them actor who=voice"
    if hud and sh.get("tpl") not in ("card", "cta"):
        # bo dem da gach ve 0 thi canh sau giu so moi
        for r in hud:
            if "reset" in r: r["n"] = r["reset"]["to"]; r.pop("reset", None)
            if "from" in r: r["n"] = r.pop("to"); r.pop("from", None)
    trn = tag(b, "chuyển", "chuyen", "trans")
    if trn is not None:   # 2.0 CHUYỂN: iris vì rời điện thoại
        tv, _, why = low(trn).partition(" vì "); tk_, rest_ = pick(tv.strip(), TRANS_VI)
        if not tk_ or rest_.strip(): err(f"CHUYỂN: không hiểu '{trn}'{near(tv.strip(), [x for x, _ in TRANS_VI])}")
        else: sh["in"] = {"type": tk_, "why": why.strip() or "ghi tay trong file 01"}
    shots.append(sh); t += d
CUR[0] = ""
if music: music[-1]["end"] = round(t, 3)
else: music = [{"start": 0, "end": round(t, 3), "bed": "sad"}]
dur = round(t + 0.6, 3); shots[-1]["end"] = dur
mmss = lambda x: f"{int(x // 60)}:{int(round(x % 60)):02d}"
# 1.10 nhip toan phim, do tu 3 video doi thu (2:38–2:51, 0 giay dung hinh, mo bang man den 1–2 cau nghich ly)
if shots and shots[0].get("tpl") != "black": warn("mở đầu: 3/3 video đối thủ mở bằng màn đen 2–4s với 1–2 câu nghịch lý (dòng 2 đậm) trước khi vào hình")
if t > 200: warn(f"phim dài {mmss(t)}: 3 video đối thủ dài 2:38–2:51; trên 3:20 dễ tụt giữ chân → gộp các hồi giống nhau thành 1 chuỗi dựng nhanh")
if n_black > 4: warn(f"{n_black} màn đen: đối thủ dùng 2–4 màn mỗi phim; nhiều hơn làm phim đứng hình, mất nhịp → đổi bớt sang cảnh có hình")

def actor_s(x):
    s = f"{x['who']}@{x.get('x', '?')} {x.get('pose', 'stand')}" + ("" if x["who"] == "voice" and not x.get("face") else f" {x.get('face', 'neutral')}")
    for k in ("walk", "run"):
        mv = x.get(k)
        if isinstance(mv, (int, float)): s += f" {k} tại chỗ"
        elif mv: s += "".join(f" {k}→{m['to']}" + (f"@{m['at']}s" if m.get("at") else "") for m in ([mv] if isinstance(mv, dict) else mv))
    if x.get("act"): s += " [" + ", ".join(f"{e['do']}@{e['at']}s" for e in x["act"]) + "]"
    if x.get("poseAt"): s += " tư thế:" + "→".join(f"{e[1]}@{e[0]}" for e in x["poseAt"][:6]) + ("…" if len(x["poseAt"]) > 6 else "")
    if x.get("faceAt"): s += " mặt:" + "→".join(f"{e[1]}@{e[0]}" for e in x["faceAt"])
    if x.get("facingAt"): s += " quay@" + ",".join(str(e[0]) for e in x["facingAt"])
    if x.get("vanish"): s += f" {x['vanish']['style']}@{x['vanish']['at']}s"
    for k in ("hold", "bloodshot", "tears", "behind", "inMirror"):
        if x.get(k): s += f" {k}" + (f"={x[k]}" if k == "hold" else "")
    return s
def summ(sh):
    A = sh.get("args", {}); tp = sh.get("tpl")
    if tp == "card": return f"card '{A.get('word')}'" + (f" part='{A['part']}'" if A.get("part") else "") + f" / {A.get('sub', '—')} / {A.get('sub2', '—')}"
    if tp == "cta": return "cta"
    p = [tp + ("/" + A["set"] if A.get("set") else "")]
    if tp == "face": p.append(f"{A.get('who')} {A.get('face')}" + (" bloodshot" if A.get("bloodshot") else "") + (f" mặt:{A['faceAt']}" if A.get("faceAt") else ""))
    if tp == "phone": p.append(A.get("screen", "") + (f" {A['posts']}" if A.get("posts") else ""))
    if A.get("setArgs"): p.append(json.dumps(A["setArgs"], ensure_ascii=False))
    if A.get("bed"): p.append(f"giường:{A['bed'].get('who', 'hero')} {A['bed'].get('face')}" + (f" up@{A['bed']['up']['at']}" if A["bed"].get("up") else ""))
    p += [actor_s(x) for x in A.get("actors", [])]
    if A.get("cam"): p.append("máy:" + json.dumps(A["cam"], ensure_ascii=False))
    if A.get("shake"): p.append("rung@" + ",".join(str(x["at"]) for x in A["shake"]))
    if A.get("shot"): p.append("góc máy:" + json.dumps(A["shot"], ensure_ascii=False))   # 2.0 cinematic
    if (sh.get("in") or {}).get("why"): p.append(f"vào bằng {sh['in']['type']} ({sh['in']['why']})")
    return " | ".join(p)

if DRY:
    print(f"KIEM TRA {os.path.basename(a.phim)} (chi doc, KHONG ghi file){'' if LIVE else ' — khong thay packs/dem, kiem theo kho dung san 1.5.0'}")
    for sh in shots:
        print(f"{sh['id']:<5}{mmss(sh['start']):>5} {sh['end'] - sh['start']:>4.1f}s  {summ(sh)}")
    if LOI: print(f"\nLOI ({len(LOI)}):"); [print(f"  {i or 'file'}: {m}") for i, m in LOI]
    if CB: print(f"\nCANH BAO ({len(CB)}):"); [print(f"  {i or 'file'}: {m}") for i, m in CB]
    tot = round(t, 1)
    nc = sum(1 for sh in shots if sh.get("tpl") not in ("card", "cta"))
    line = f"\nTong: {len(shots)} canh, {tot} giay ({mmss(tot)}); {explicit}/{nc} canh hinh ghi ro truong NEN/AI/DONG TAC/MAY, {nc - explicit} canh doan tu CANH."
    if a.dai:
        dv = (tot / 60 - a.dai) / a.dai * 100; line += f" Muc tieu {a.dai:g} phut: lech {dv:+.1f}%."
        if abs(dv) > 5: CB.append(("", "lệch thời lượng mục tiêu quá 5%"))
    print(line)
    print("=> SACH LOI." if not LOI else f"=> CON {len(LOI)} LOI: sua file 01 roi chay lai.")
    sys.exit(1 if LOI else 0)

cfg_p = os.path.join(P, "config.json"); cfg = read_json(cfg_p, {}) or {}
if meta.get("accent"): cfg["accent"] = meta["accent"].lower()
if meta.get("title") and not cfg.get("title"): cfg["title"] = meta["title"]
# 2.0: che do cinematic dung bo "phim" (2D vector kieu dien anh, mac dinh) hoac "cine" ("render": "3d"); mau canh cung ten voi legacy
cine_pack = "cine" if cfg.get("render") == "3d" else "phim"
cfg["duration"] = dur; cfg.setdefault("pack", cine_pack if cfg.get("mode") == "cinematic" else "dem")
if cfg.get("mode") == "cinematic" and cfg.get("pack") in ("dem", "cine", "phim"): cfg["pack"] = cine_pack
write_json(cfg_p, cfg)
write_json(out, {"title": cfg.get("title", meta.get("title", "")), "duration": dur, "shots": shots, "music": music})
print(f"Xong: {len(shots)} canh, dai {dur:.1f} giay ({dur/60:.1f} phut), {len(music)} doan nhac -> {out}")
for w in warn_old: print("CANH BAO:", w)
for i, m in LOI + CB:
    if not m.startswith("chữ cần"): print("CANH BAO:", (i + ": " if i else "") + m)
