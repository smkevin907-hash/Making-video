// director.js — dao dien tu dong cho che do cinematic (tat dinh, chi doc shots.json):
// 1) plan(): chia moi canh thanh 1–3 goc may (coverage) theo noi dung canh. Ma canh giu nguyen (b04 van la b04).
// 2) planFilm(): luat GIUA cac canh — khong 2 goc lien tiep cung co khung + cung goc (tru match cut co chu y), chon kieu chuyen canh
//    co ly do ke chuyen, khong dung 1 kieu (khac cat) qua 2 lan lien.
// Ghi de tay: args.coverage = [{ at, size, angle, move, ... }]; args.shot = { size, angle, move } (tu MÁY trong file 01) cho goc chinh;
//            shot.in = { type, why } (tu CHUYỂN trong file 01) -> giu nguyen.
// Co khung: ews ws full ms mcu cu ecu. Goc: eye low high top ots pov. Chuyen dong: xem engine/cine/camera.js MOVE_NAMES.

const WANT = 0.55;   // huong dat may trong phong (rad, the gioi): phia truoc - phai, de may luon o trong phong nhin vao
const rel = (sub, w = WANT) => w - (sub.face ?? 0);
const SIZES = ['ews', 'ws', 'full', 'ms', 'mcu', 'cu', 'ecu'];

// MÁY kieu cu (2D: from/to zoom) -> chuyen dong 3D tuong duong
function legacyCam(c) {
  if (!c) return {};
  const z0 = c.from ? c.from[2] ?? 1 : 1, z1 = c.to ? c.to[2] ?? z0 : z0, o = {};
  if (c.follow) o.move = 'truck'; else if (z1 > z0 + 0.25) o.move = 'pushToCloseUp'; else if (z1 > z0 + 0.02) o.move = 'dollyIn'; else if (z1 < z0 - 0.02) o.move = 'pullBack';
  else if (c.from && c.to && Math.abs(c.from[0] - c.to[0]) > 0.05) o.move = 'pan'; else if (c.hand === 0) o.move = 'hold';
  if (c.hand !== undefined) o.hand = c.hand === 0 ? 0 : c.hand >= 2 ? 0.6 : 0.35;
  return o;
}

// ke hoach goc may (chua co toa do): [{ at, role, size, angle, move, ... }]
export function plan(kind, a = {}, d = 5) {
  if (a.coverage) return a.coverage.map((c, i, L) => ({ at: c.at ?? (i * d) / L.length, role: 'manual', size: c.size || 'ms', angle: c.angle || 'eye', ...c }));
  const voice = (a.actors || []).some((x) => x.who === 'voice'), main = (a.actors || []).some((x) => x.who !== 'voice'), up = a.bed && a.bed.up;
  const split = (k) => (d >= 4.5 ? Math.max(2, Math.round(d * k * 10) / 10) : d), L = [];
  if (kind === 'scene') {
    const lying = !main && a.bed;
    L.push({ at: 0, role: 'wide', size: lying ? 'full' : 'ws', angle: 'high', move: 'dollyIn' });
    if (up) L.push({ at: Math.max(0.6, up.at ?? d * 0.5), role: 'push', size: 'mcu', angle: 'eye', move: 'pushToCloseUp', why: 'cat dung dong tac ngoi day' });
    else if (split(0.45) < d) {
      if (voice && main) L.push({ at: split(0.45), role: 'ots', size: 'mcu', angle: 'ots', move: 'overShoulder' });
      else if (lying) L.push({ at: split(0.45), role: 'top', size: 'cu', angle: 'top', move: 'dollyIn' });
      else L.push({ at: split(0.45), role: 'push', size: 'mcu', angle: 'eye', move: 'pushToCloseUp' });
    }
  } else if (kind === 'face') L.push({ at: 0, role: 'face', size: 'cu', angle: 'eye', move: 'dollyIn' });
  else if (kind === 'phone') L.push({ at: 0, role: 'pov', size: 'ecu', angle: 'pov', move: 'povHands' });
  else if (kind === 'calendar') { const s = split(0.38); if (s < d) L.push({ at: 0, role: 'otsPoster', size: 'mcu', angle: 'ots', move: 'overShoulder' }); L.push({ at: s < d ? s : 0, role: 'insertPoster', size: 'ecu', angle: 'eye', move: 'dollyIn' }); }
  else if (kind === 'clock') L.push({ at: 0, role: 'insertClock', size: 'ecu', angle: 'eye', move: 'dollyIn' });
  else L.push({ at: 0, role: 'void', size: 'ms', angle: 'eye', move: 'dollyIn' });
  // MÁY trong file 01: kieu moi (args.shot) hoac kieu cu (args.cam) -> ap vao goc chinh (goc dau)
  const ov = { ...legacyCam(a.cam), ...(a.shot || {}) };
  if (Object.keys(ov).length && L[0].role !== 'void') Object.assign(L[0], ov, { manual: true });
  return L;
}

// luat giua cac canh + chuyen canh co ly do. shots: E.shots (da co tpl / args). Ghi shot.__plan va shot.in (neu chua ghi ro)
const CINE = ['scene', 'phone', 'calendar', 'clock', 'face', 'black', 'card'];
export function planFilm(shots, story = {}) {
  const bedAt = (t) => { const m = (story.music || []).find((x) => t >= x.start - 0.01 && t < x.end); return m ? m.bed : null; };
  let prev = null, prevIn = [];
  shots.forEach((s, i) => {
    const kind = CINE.includes(s.tpl) ? s.tpl : null; if (!kind) { prev = null; return; }
    const a = s.args || {}, P = plan(kind, a, s.end - s.start); s.__plan = P;
    const p = i > 0 ? shots[i - 1] : null, pk = p && p.__plan ? p.tpl : null;
    // ---- chuyen canh (chi khi file 01 khong ghi CHUYỂN)
    const tin = s.in || { type: 'cut' };
    if (!tin.why && (tin.type || 'cut') === 'cut' && p) {
      const pa = p.args || {}, sameSet = (a.set || 'bedroom') === (pa.set || 'bedroom');
      const hasPhone = (pa.actors || []).some((x) => x.hold === 'phone');
      const shock = /dark|tension/.test(bedAt(s.start) || '') && !/dark|tension/.test(bedAt(p.start) || '') || (a.hud && (a.hud.rows || []).some((r) => r.reset)) || (a.actors || []).some((x) => ['shock', 'panic'].includes(x.face));
      let t = { type: 'cut', why: 'cat cung: nhip chinh cua phim' };
      if (kind === 'phone' && hasPhone) t = { type: 'zoomIntoProp', why: 'di vao man hinh nhan vat dang nhin', dur: 0.45, x: 0.5, y: 0.55 };
      else if (pk === 'phone' && kind !== 'phone') t = { type: 'iris', why: 'roi the gioi trong dien thoai ve phong that', dur: 0.6 };
      else if (kind === 'black' && pk && pk !== 'black') t = { type: 'fadeThroughBlack', why: 'ngat hoi: chuyen sang cau chu', dur: 0.5 };
      else if (shock) t = { type: 'smashCut', why: 'cat soc truoc cu sup', dur: 0.12 };
      else if (pk === kind && sameSet && kind !== 'black') t = { type: 'matchCut', why: 'cung bo cuc, thoi gian troi' };
      else if ((a.actors || []).some((x) => x.run) || (pa.actors || []).some((x) => x.run)) t = { type: 'whipPan', why: 'noi chuyen dong nhanh', dur: 0.35 };
      // khong 1 kieu (khac cat) qua 2 lan lien
      if (t.type !== 'cut' && prevIn.length >= 2 && prevIn.slice(-2).every((x) => x === t.type)) t = { type: 'cut', why: 'tranh lap kieu chuyen canh' };
      s.in = { ...tin, ...t, auto: true };
    }
    if (s.in && s.in.type === 'dip' && !s.in.why) s.in.why = 'mo vao the ket';
    prevIn.push(s.in ? s.in.type : 'cut');
    // ---- khong 2 goc lien tiep cung co + cung goc (match cut: co y giu nguyen bo cuc)
    if (prev && P.length && kind !== 'black' && kind !== 'card') {
      const f = P[0], l = prev[prev.length - 1];
      if (s.in.type === 'matchCut') { if (f.role === l.role) Object.assign(f, { size: l.size, angle: l.angle, match: true }); }   // giu y bo cuc canh truoc
      else if (f.size === l.size && f.angle === l.angle && !f.manual) {
        const k = SIZES.indexOf(f.size);
        if (f.role === 'wide') Object.assign(f, { size: 'full', angle: 'eye', move: 'truck' });
        else if (f.role === 'face') Object.assign(f, { size: 'mcu', angle: 'low' });
        else if (f.role === 'insertClock' || f.role === 'insertPoster') Object.assign(f, { angle: 'high' });
        else if (f.role === 'push') Object.assign(f, { size: SIZES[Math.max(0, k - 1)], move: 'dollyIn' });
        else Object.assign(f, { angle: f.angle === 'eye' ? 'low' : 'eye' });
        f.fixed = 'doi co / goc: trung goc canh truoc';
      }
    }
    prev = kind === 'black' || kind === 'card' ? null : P;
  });
  return shots;
}

// goc may cu the (co toa do) cho mau canh: dung ke hoach (shot.__plan neu da qua planFilm) + chu the trong st
export function coverage(kind, info, st) {
  const d = info.dur, a = info.args || {}, P = (info.shot && info.shot.__plan) || plan(kind, a, d);
  const main = st.main, voice = st.voice, sub = () => (main ? main.subject() : st.sleeperSub ? st.sleeperSub() : { at: [0, 0, 0], h: 1.6 });
  const ANG = { eye: 0.04, low: -0.3, high: 0.45, top: 1.3 };
  return P.map((p, i) => {
    const hand = p.hand, mv = p.move, seed = 3 + i;
    let spec;
    if (p.role === 'manual') spec = () => ({ subject: sub(), ...p });
    else if (p.role === 'wide') spec = () => {   // toan canh: dong khung ca nguoi hung + bong den (tam giua 2 nguoi), khong de ai troi ra mep
      const s = sub(), v = voice ? voice.subject() : null, mid = (x, y) => x.map((q, j) => (q + y[j]) / 2);
      const g = v ? { ...s, at: mid(s.at, v.at), head: mid(s.head || s.at, v.head || v.at), h: Math.max(s.h ?? 1.6, v.h ?? 1.6) } : s;
      return { subject: g, size: p.size, angle: p.angle, yaw: rel(s), move: mv, amt: 0.9, hand: hand ?? 0.3, seed, distK: v ? 1.15 : 1 };
    };
    else if (p.role === 'ots') spec = () => ({ subject: main.subject(), over: voice.subject(), back: 0.95, offset: 0.48, up: 0.1, mix: 0.2, move: mv, hand: hand ?? 0.35, seed });
    else if (p.role === 'top') spec = () => ({ subject: sub(), size: p.size, angle: 'top', yaw: 0, move: mv, amt: 0.5, hand: hand ?? 0.2, seed });
    else if (p.role === 'push') spec = () => { const s = (st.sitter || main) ? (st.sitter || main).subject() : sub(); return { subject: s, size: p.size, from: 'ms', angle: p.angle, elev: ANG[p.angle], yaw: rel(s, 0.35), move: mv, hand: hand ?? 0.35, seed }; };
    else if (p.role === 'face') spec = () => { const s = sub(); return { subject: s, size: p.size, angle: p.angle, elev: ANG[p.angle], yaw: rel(s, 0.4), move: mv, amt: 0.45, hand: hand ?? 0.25, aperture: 1.5, seed }; };
    else if (p.role === 'pov') spec = () => ({ keys: [[0, st.povCam], [d, st.povCam]], hand: hand ?? 0.25, aperture: 1.6, focus: st.povFocus, seed });
    else if (p.role === 'otsPoster') spec = () => ({ subject: st.posterSub, over: main.subject(), back: 1.0, offset: 0.6, up: 0.08, mix: 0.42, fov: 36, move: mv, hand: hand ?? 0.3, focusOn: st.posterSub.at, seed });
    else if (p.role === 'insertPoster') spec = () => ({ subject: st.posterSub, size: 'ecu', yaw: 0, elev: p.angle === 'high' ? 0.3 : 0.03, dist: st.posterDist, fov: 30, move: mv, amt: 0.25, hand: hand ?? 0.2, focusOn: st.posterSub.at, aperture: 1.0, seed });
    else if (p.role === 'insertClock') spec = () => ({ subject: st.clockSub, size: 'ecu', yaw: 0, elev: p.angle === 'high' ? 0.4 : 0.08, dist: 0.42, fov: 30, move: mv, amt: 0.35, hand: hand ?? 0, focusOn: st.clockSub.at, aperture: 1.4, seed });
    else spec = () => ({ subject: { at: [0, 1.2, -1], prop: true }, size: 'ms', yaw: 0, dist: 3.2, fov: 40, move: 'dollyIn', amt: 0.5, hand: 0, aperture: 0.6, profile: 'slow', seed });
    return { at: p.at, plan: p, spec };
  });
}
// goc may dang dung o giay lt: { i, at, dur, spec }
export function subShot(cov, lt, d) {
  let i = 0; while (i + 1 < cov.length && lt >= cov[i + 1].at) i++;
  const at = cov[i].at, end = i + 1 < cov.length ? cov[i + 1].at : d;
  return { i, at, dur: Math.max(0.1, end - at), spec: cov[i].spec };
}
