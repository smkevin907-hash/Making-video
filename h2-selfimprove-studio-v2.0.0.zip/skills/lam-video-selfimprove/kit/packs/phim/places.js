// places.js — cac boi canh khac phong ngu, CUNG kieu minh hoa phang (de ca phim chung 1 nhan vat, 1 cach ve — khong lui ve kieu legacy):
// noi that chung (vo phong + do dac theo loai): cafe, kitchen, classroom, gym, sofa (phong khach), mirror, doorway, lockers, court, stairs
// ngoai troi: street / city (pho dem / ngay, mot diem tu), hill (doi xanh, troi). Moi boi canh tra cung dang voi bedroom().
import { E, lerp } from '/engine/core.js';
import { view, box, wallRect, sideRect, quad, poly, shade, floorGlow, floorLines } from '/engine/flat/persp.js';
import { glow, vgrad, rgba } from '/engine/flat/stage.js';
import { rng } from '/engine/cine/timeline.js';
import { PAL, windowPatch, contactShadow, ANGLE } from './sets.js';

export const INTERIORS = ['cafe', 'kitchen', 'classroom', 'gym', 'sofa', 'mirror', 'doorway', 'lockers', 'court', 'stairs'];
export const OUTDOORS = ['street', 'city', 'hill'];

// cua so tren tuong sau (troi + nha xa)
function windowOn(g, V, P, night, win, zb, seed = 9) {
  const [ax, ay] = V.p(win.x0, win.y1, zb), [bx, by] = V.p(win.x1, win.y0, zb);
  g.fillStyle = vgrad(g, 0, ay, 0, by, [[0, P.sky[0]], [1, P.sky[1]]]); g.fillRect(ax, ay, bx - ax, by - ay);
  g.save(); g.beginPath(); g.rect(ax, ay, bx - ax, by - ay); g.clip();
  const r = rng(seed); g.fillStyle = P.city; let cx = ax; while (cx < bx) { const w = (bx - ax) * (0.06 + r() * 0.1), hh = (by - ay) * (0.15 + r() * 0.4); g.fillRect(cx, by - hh, w - 2, hh); if (night) { g.fillStyle = rgba(P.lamp, 0.55); for (let k = 0; k < 3; k++) if (r() < 0.5) g.fillRect(cx + 4 + r() * Math.max(1, w - 12), by - hh + 6 + r() * Math.max(1, hh - 14), 4, 5); g.fillStyle = P.city; } cx += w; }
  g.restore(); g.strokeStyle = shade(P.wall, night ? 0.15 : -0.25); g.lineWidth = Math.max(3, V.k(zb) * 0.045); g.strokeRect(ax, ay, bx - ax, by - ay);
}
function shell(g, V, P, night, R) {
  const { x0, x1, H, zb, zf } = R;
  g.fillStyle = P.wall; g.fillRect(-400, -400, E.W + 800, E.H + 800);
  quad(g, V, [[x0, 0, zf], [x1, 0, zf], [x1, 0, zb], [x0, 0, zb]], P.floor); quad(g, V, [[x0, H, zf], [x1, H, zf], [x1, H, zb], [x0, H, zb]], P.ceil);
  sideRect(g, V, x0, zf, zb, 0, H, P.side); sideRect(g, V, x1, zf, zb, 0, H, shade(P.side, -0.05)); wallRect(g, V, x0, x1, 0, H, zb, P.wall);
  floorLines(g, V, x0, x1, zf, zb, { dx: R.tile ? 0.5 : 0.24, dz: R.tile ? 0.5 : 0, color: P.line, lw: 1.3 });
  wallRect(g, V, x0, x1, 0, 0.09, zb - 0.001, shade(P.wall, -0.15));
}

// noi that chung. o: { kind, tone, angle, key }
export function interior(o = {}) {
  const kind = o.kind || 'cafe', tone = o.tone || 'night', P = PAL[tone], night = tone === 'night', ang = ANGLE[o.angle] || ANGLE.eye;
  const V = view({ eye: ang.eye, hz: E.H * ang.hz, f: E.H * 1.35, x0: 0.1 }), R = { x0: -2.4, x1: 2.4, H: 2.8, zb: 6.2, zf: 1.4, tile: ['cafe', 'kitchen', 'gym', 'lockers', 'court'].includes(kind) };
  const win = kind === 'cafe' ? { x0: -2.0, x1: 0.6, y0: 0.8, y1: 2.3 } : { x0: -1.4, x1: -0.2, y0: 1.0, y1: 2.1 }, key = `${o.key || kind}:${tone}:${o.angle || 'eye'}`;
  const dark = night ? '#262a32' : '#6c7378', top = night ? '#353a44' : '#8d9499';
  const far = (g) => {
    shell(g, V, P, night, R); const zb = R.zb;
    if (!['lockers', 'mirror', 'doorway'].includes(kind)) windowOn(g, V, P, night, win, zb, 11);
    if (kind === 'classroom') { wallRect(g, V, 0.6, 2.1, 1.0, 2.0, zb - 0.01, '#2f4a3c'); }
    if (kind === 'mirror') { const [cx, cy] = V.p(0, 1.45, zb), rx = V.k(zb) * 0.45, ry = V.k(zb) * 0.62; g.fillStyle = shade(P.wall, night ? 0.25 : 0.18); g.beginPath(); g.ellipse(cx, cy, rx * 1.06, ry * 1.04, 0, 0, 7); g.fill(); g.fillStyle = night ? '#4a5568' : '#c9d4dc'; g.beginPath(); g.ellipse(cx, cy, rx, ry, 0, 0, 7); g.fill(); }
    if (kind === 'doorway' || kind === 'stairs') { wallRect(g, V, -0.45, 0.45, 0, 2.05, zb - 0.01, shade(P.wall, -0.25)); if ((o.doorOpen ?? 0.3) > 0) wallRect(g, V, -0.45, -0.45 + 0.9 * (o.doorOpen ?? 0.3), 0, 2.05, zb - 0.02, night ? '#e9d3a0' : '#f5f0e6'); }
    if (kind === 'lockers') for (let i = 0; i < 8; i++) { const x = -2.2 + i * 0.55; wallRect(g, V, x, x + 0.52, 0.1, 1.9, zb - 0.02, i % 2 ? shade(P.wall, -0.12) : shade(P.wall, -0.18)); }
    if (kind === 'gym') { wallRect(g, V, 0.4, 2.2, 0.3, 1.9, zb - 0.01, night ? '#3e4a5a' : '#cfd8de'); }
    if (kind === 'kitchen') { box(g, V, -2.35, 2.35, 1.5, 2.1, zb - 0.35, zb, shade(P.wall, -0.12)); }
    // chi tiet treo tuong chung: khung tranh tuong ben, den tran, cong tac (de phong khong trong tron)
    { const fc = shade(P.wall, night ? 0.12 : -0.2); sideRect(g, V, R.x1 - 0.005, 3.2, 4.1, 1.2, 1.85, fc); sideRect(g, V, R.x1 - 0.01, 3.27, 4.03, 1.27, 1.78, night ? '#3d4658' : '#9aa6b0'); box(g, V, -0.25, 0.25, R.H - 0.06, R.H, 3.9, 4.4, shade(P.ceil, night ? 0.2 : -0.1)); wallRect(g, V, 1.05, 1.13, 1.1, 1.22, R.zb - 0.005, shade(P.wall, night ? 0.25 : -0.15)); }
    if (!night) { g.save(); g.globalCompositeOperation = 'multiply'; g.fillStyle = 'rgba(138,160,200,0.14)'; g.fillRect(-400, -400, E.W + 800, E.H + 800); g.restore(); }
  };
  const mid = (g) => {
    const zb = R.zb;
    if (kind === 'cafe') {
      box(g, V, 0.9, 2.35, 0, 1.0, 4.9, 5.6, dark, { top });
      for (const [x, z] of [[-1.1, 4.3], [0.9, 3.6]]) { contactShadow(g, V, x - 0.45, x + 0.45, z - 0.35, z + 0.35, 0.3); box(g, V, x - 0.05, x + 0.05, 0, 0.72, z - 0.05, z + 0.05, '#202227'); box(g, V, x - 0.45, x + 0.45, 0.72, 0.76, z - 0.35, z + 0.35, top, { top: shade(top, 0.15) }); }
    } else if (kind === 'kitchen') { contactShadow(g, V, -2.35, 2.35, zb - 0.65, zb); box(g, V, -2.35, 1.2, 0, 0.9, zb - 0.65, zb, dark, { top }); box(g, V, 1.3, 2.3, 0, 1.95, zb - 0.75, zb, night ? '#4a5260' : '#dde2e6'); }
    else if (kind === 'classroom') { for (let i = 0; i < 3; i++) for (let j = 0; j < 2; j++) { const x = -1.6 + i * 1.3, z = 3.6 + j * 1.2; contactShadow(g, V, x - 0.4, x + 0.4, z - 0.25, z + 0.25, 0.25); box(g, V, x - 0.4, x + 0.4, 0.7, 0.74, z - 0.25, z + 0.25, top, { top: shade(top, 0.12) }); box(g, V, x - 0.36, x - 0.32, 0, 0.7, z + 0.2, z + 0.24, dark); box(g, V, x + 0.32, x + 0.36, 0, 0.7, z + 0.2, z + 0.24, dark); } }
    else if (kind === 'gym' || kind === 'court') { contactShadow(g, V, -1.8, -0.6, 4.6, 5.0); box(g, V, -1.8, -0.6, 0.35, 0.45, 4.6, 5.0, dark, { top }); box(g, V, 1.4, 2.2, 0, 1.1, zb - 0.6, zb - 0.2, dark, { top }); const [hx, hy] = V.p(0.9, 2.8, 4.8), [bx, by] = V.p(0.9, 1.1, 4.8); g.strokeStyle = '#222'; g.lineWidth = 3; g.beginPath(); g.moveTo(hx, hy); g.lineTo(bx, by); g.stroke(); g.fillStyle = night ? '#5a2f2f' : '#8a3d3d'; g.beginPath(); g.roundRect(bx - V.k(4.8) * 0.18, by, V.k(4.8) * 0.36, V.k(4.8) * 0.85, V.k(4.8) * 0.15); g.fill(); }
    else if (kind === 'sofa') { contactShadow(g, V, -1.4, 1.0, zb - 0.95, zb - 0.1, 0.4); box(g, V, -1.4, 1.0, 0, 0.45, zb - 0.95, zb - 0.1, night ? '#3d4658' : '#7a8696', { top: night ? '#475166' : '#8d98a8' }); box(g, V, -1.4, 1.0, 0.45, 0.9, zb - 0.3, zb - 0.1, night ? '#363e50' : '#6f7b8b'); box(g, V, -0.6, 0.4, 0, 0.4, 3.9, 4.4, dark, { top }); }
    else if (kind === 'mirror') { box(g, V, -0.5, 0.5, 0, 0.85, zb - 0.45, zb, dark, { top }); }
    else if (kind === 'lockers' || kind === 'stairs' || kind === 'doorway') { contactShadow(g, V, -1.5, 0.3, 4.4, 4.7, 0.25); box(g, V, -1.5, 0.3, 0.4, 0.45, 4.4, 4.7, dark, { top }); }
  };
  const light = (g) => {
    if (!['lockers', 'mirror', 'doorway'].includes(kind)) windowPatch(g, V, win, R.zb, night ? P.winLight : '#ffd9a0', night ? 0.25 : 0.45);
    if (kind === 'cafe') for (const [x, z] of [[-1.1, 4.3], [0.9, 3.6]]) { const [lx, ly] = V.p(x, 1.9, z); g.strokeStyle = '#1a1a1d'; g.lineWidth = 2; g.beginPath(); g.moveTo(lx, V.p(x, 2.8, z)[1]); g.lineTo(lx, ly); g.stroke(); glow(g, lx, ly, V.k(z) * 1.4, P.lamp, night ? 0.45 : 0.25); floorGlow(g, V, x, z, 0.8, 0.6, P.lamp, night ? 0.25 : 0.12); }
    else { const [lx, ly] = V.p(0, 2.75, 4.2); glow(g, lx, ly, V.k(4.2) * 1.6, night ? P.lamp : '#ffffff', night ? 0.3 : 0.25); }
  };
  const A = { center: { x: 0.0, z: 3.6 }, 'table.left': { x: -1.1, z: 3.75, seat: 0.46 }, 'table.right': { x: 0.9, z: 3.1, seat: 0.46 }, mirror: { x: 0, z: 4.6 }, 'mirror.in': { x: 0, z: 6.0 }, door: { x: 0, z: 5.6 }, bench: { x: -1.2, z: 4.4, seat: 0.45 }, 'sofa.seat': { x: -0.2, z: 5.5, seat: 0.45 }, 'sofa.left': { x: -0.9, z: 5.5, seat: 0.45 }, 'sofa.right': { x: 0.5, z: 5.5, seat: 0.45 }, top: { x: 0, z: 4.5 } };
  return finish(V, P, night, key, far, mid, light, A);
}

// ngoai troi: pho (dem: den duong cam + cua so sang; ngay: xam) | doi xanh (hy vong)
export function outdoor(o = {}) {
  const kind = o.kind === 'hill' ? 'hill' : 'street', tone = o.tone || (kind === 'hill' ? 'hope' : 'night'), P = PAL[tone], night = tone === 'night', ang = ANGLE[o.angle] || ANGLE.eye;
  const V = view({ eye: ang.eye + 0.2, hz: E.H * (ang.hz + 0.02), f: E.H * 1.2, x0: 0.6 }), key = `${o.key || kind}:${tone}:${o.angle || 'eye'}`, Z = 60;
  const sky = night ? ['#0e1424', '#232c44'] : kind === 'hill' ? ['#7fa9d1', '#d6e6ef'] : ['#aeb8c0', '#dfe5e9'];
  const far = (g) => {
    g.fillStyle = vgrad(g, 0, 0, 0, V.hz, [[0, sky[0]], [1, sky[1]]]); g.fillRect(-400, -400, E.W + 800, V.hz + 400);
    if (kind === 'hill') {
      g.fillStyle = '#9fbf6a'; g.fillRect(-400, V.hz, E.W + 800, E.H + 400);
      g.fillStyle = '#7d994a'; g.beginPath(); g.moveTo(-400, V.hz + 40); g.bezierCurveTo(E.W * 0.3, V.hz - 90, E.W * 0.7, V.hz - 40, E.W + 400, V.hz + 30); g.lineTo(E.W + 400, E.H + 400); g.lineTo(-400, E.H + 400); g.fill();
      g.fillStyle = '#94b55b'; g.beginPath(); g.moveTo(-400, E.H * 0.75); g.bezierCurveTo(E.W * 0.25, E.H * 0.5, E.W * 0.6, E.H * 0.52, E.W + 400, E.H * 0.7); g.lineTo(E.W + 400, E.H + 400); g.lineTo(-400, E.H + 400); g.fill();
      g.strokeStyle = '#e4d9b8'; g.lineWidth = 18; g.lineCap = 'round'; g.beginPath(); g.moveTo(E.W * 0.55, E.H + 20); g.bezierCurveTo(E.W * 0.4, E.H * 0.8, E.W * 0.62, E.H * 0.66, E.W * 0.5, E.H * 0.56); g.stroke();
      const r = rng(5); for (let i = 0; i < 7; i++) { const x = r() * E.W, y = V.hz + 10 + r() * 60, s = 18 + r() * 26; g.fillStyle = '#5f7a3a'; g.beginPath(); g.arc(x, y - s, s, 0, 7); g.fill(); g.fillRect(x - 2, y - s, 4, s); }
      glow(g, E.W * 0.82, E.H * 0.16, E.H * 0.35, '#fff3d8', 0.35); return;
    }
    // pho: duong + via he + nha 2 ben + cot den (mot diem tu)
    quad(g, V, [[-30, 0, 2], [30, 0, 2], [30, 0, Z], [-30, 0, Z]], night ? '#14161c' : '#7d8389');
    quad(g, V, [[-3.2, 0, 2], [3.2, 0, 2], [3.2, 0, Z], [-3.2, 0, Z]], night ? '#1c1f27' : '#6a7076');
    for (const sx of [-1, 1]) { quad(g, V, [[sx * 3.2, 0.02, 2], [sx * 5.2, 0.02, 2], [sx * 5.2, 0.02, Z], [sx * 3.2, 0.02, Z]], night ? '#2b2e35' : '#9aa0a5'); }
    g.strokeStyle = night ? 'rgba(220,220,210,0.35)' : 'rgba(255,255,255,0.6)'; g.lineWidth = 3; g.setLineDash([24, 26]); g.beginPath(); g.moveTo(...V.p(0, 0, 2.5)); g.lineTo(...V.p(0, 0, Z)); g.stroke(); g.setLineDash([]);
    const r = rng(7);
    for (let z = Z - 6; z > 4; z -= 6.5) for (const sx of [-1, 1]) { const x0 = sx * 6.2, x1 = sx * 11, h = 4.5 + r() * 3.5; box(g, V, Math.min(x0, x1), Math.max(x0, x1), 0, h, z, z + 5, night ? '#262a33' : '#a7adb2', { top: night ? '#2d313b' : '#b8bdc1', side: night ? '#20232b' : '#959ba0' });
      if (night) for (let k = 0; k < 4; k++) if (r() < 0.45) { const wy = 1.2 + (k % 2) * 1.8, wz = z + 0.6 + Math.floor(k / 2) * 2.2; quad(g, V, [[x0, wy, wz], [x0, wy, wz + 1], [x0, wy + 1, wz + 1], [x0, wy + 1, wz]], rgba(P.lamp, 0.85)); } }
  };
  const mid = (g) => { if (kind === 'hill') return; for (let z = 6; z < Z; z += 9) { const [bx, by] = V.p(3.6, 0, z), [tx, ty] = V.p(3.6, 4.2, z); g.strokeStyle = '#121317'; g.lineWidth = Math.max(1.5, V.k(z) * 0.12); g.beginPath(); g.moveTo(bx, by); g.lineTo(tx, ty); g.stroke(); g.fillStyle = night ? '#fff0c8' : '#d9dde0'; g.fillRect(tx - V.k(z) * 0.18, ty - V.k(z) * 0.1, V.k(z) * 0.36, V.k(z) * 0.3); } };
  const light = (g) => { if (kind === 'hill' || !night) return; for (let z = 6; z < Z; z += 9) { const [tx, ty] = V.p(3.6, 4.1, z); glow(g, tx, ty, V.k(z) * 3.2, P.lamp, 0.4); floorGlow(g, V, 3.2, z, 2.4, 2.0, P.lamp, 0.3); } };
  const A = { center: { x: 2.4, z: 9 }, top: { x: 0.6, z: 9 }, bench: { x: 4.2, z: 9, seat: 0.45 }, 'bus.seat': { x: 4.2, z: 9, seat: 0.45 }, neon: { x: 4.6, z: 12 } };
  const fin = finish(V, P, night, key, far, mid, light, A, (k) => ({ x: lerp(-0.5, 4.4, k), z: 7 }));
  return fin;
}

// san khau toi (set "void" / "none" / "black"): nen toi chuyen sac, vang den mo sau lung, san mo; so x (0..1) trai deu theo be ngang khung (nhieu nguoi dung hang khong chong nhau)
export function stage(o = {}) {
  const tone = o.tone || 'night', P = PAL[tone], night = tone !== 'hope' && tone !== 'day', ang = ANGLE[o.angle] || ANGLE.eye;
  const V = view({ eye: ang.eye, hz: E.H * (ang.hz + 0.12), f: E.H * 1.2 }), key = `${o.key || 'void'}:${tone}:${o.angle || 'eye'}`, Z = 6.5;
  const far = (g) => {
    g.fillStyle = vgrad(g, 0, 0, 0, E.H, night ? [[0, '#0f1116'], [0.6, '#1b1e25'], [1, '#121418']] : [[0, '#8d9499'], [0.6, '#b9c0c4'], [1, '#7d8389']]); g.fillRect(-400, -400, E.W + 800, E.H + 800);
    glow(g, E.W * 0.5, V.hz - E.H * 0.1, E.H * 0.75, night ? '#56637e' : '#ffffff', night ? 0.35 : 0.3);
  };
  const mid = (g) => { floorGlow(g, V, 0, Z, 6.5, 2.6, night ? '#56637e' : '#ffffff', night ? 0.22 : 0.18); };
  const light = () => {};
  const A = { center: { x: 0, z: Z }, left: { x: -2.2, z: Z }, right: { x: 2.2, z: Z } };
  return finish(V, P, night, key, far, mid, light, A, (k) => ({ x: (k - 0.5) * 2 * 0.44 * E.W * Z / V.f, z: Z }));
}

// dong goi: lop + dat nguoi (giong bedroom)
function finish(V, P, night, key, far, mid, light, A, numPos) {
  const place = (a) => {
    let q;
    if (Array.isArray(a.x)) q = { x: a.x[0], z: a.x[2] ?? 3.6, seat: a.x[1] || 0 };
    else if (typeof a.x === 'string' && (A[a.x] || A[a.x.split(':')[0]])) q = A[a.x] || A[a.x.split(':')[0]];
    else { const k = typeof a.x === 'number' ? (a.x > 1.5 ? a.x / 1920 : a.x) : 0.5; q = numPos ? numPos(k) : { x: lerp(-1.6, 1.7, k), z: a.z ?? 4.5 }; }
    const sit = q.seat && String(a.pose || '').startsWith('sit'), [sx, sy] = V.p(q.x, sit ? q.seat : 0, q.z), h = V.k(q.z) * 1.55 * (a.who === 'voice' ? 1.12 : 1) * (a.scale ?? 1);
    return { x: sx, y: sy, h, anchor: sit ? 'hip' : 'feet', z: q.z };
  };
  place.rim = -1; place.rimC = P.rimC;
  return { V, P, night, layers: [{ key: key + ':far', p: 0.85, draw: far }, { key: key + ':mid', p: 1, draw: mid }, { key: key + ':light', p: 0.95, draw: light, add: 'screen', order: 1.5 }], place, anchors: A };
}
