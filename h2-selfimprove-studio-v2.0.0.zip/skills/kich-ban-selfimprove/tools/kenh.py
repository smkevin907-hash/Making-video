"""kenh.py — dau an rieng cua kenh (R14). Chi can Python 3.8+.
  python kenh.py mau  --thu-muc <thu muc nguoi dung>                          tao KENH.md mau (neu chua co) de dien
  python kenh.py kiem --thu-muc <..> --phim <01-PHIM> [--goi <02-PACKAGE>]    kiem cau ky ten, mau nhan, 10 tieu de
KENH.md (o thu muc nguoi dung): ten kenh, hau to tieu de, cau ky ten, ky ten o (keu goi | the ket), mau nhan chu dao, mau nhan rieng theo de tai.
Tieu de (10 / phim): >= 4 co dau an kenh (hau to / ten kenh / ten chuoi), >= 8 co tu khoa ngach, <= 3 theo mau doi thu "WORD | An Animated Short Film",
dung 1 tieu de danh dau "nen dung", <= 60 ky tu, khong trung tieu de doi thu trong video.csv.
"""
import argparse, os, re, sys, unicodedata
HERE = os.path.dirname(os.path.abspath(__file__)); sys.path.insert(0, HERE)
import doi_thu as DT
try: sys.stdout.reconfigure(encoding="utf-8", errors="replace")
except (AttributeError, ValueError): pass
kd = DT.khong_dau
MAU = """# KÊNH

Dấu ấn riêng của kênh. Skill đọc file này mỗi lần viết; sửa ở đây là đổi cho mọi phim sau.

- **Tên kênh:** <tên kênh>
- **Hậu tố tiêu đề:** <hậu tố riêng, có từ khoá ngách, vd "<Tên kênh> Animated Short">
- **Câu ký tên:** <1 câu cố định, ≤ 9 từ, tiếng Anh, vd "Every night has a second wind.">
- **Ký tên ở:** kêu gọi
- **Màu nhấn chủ đạo:** <red | pink | amber | teal>
- **Màu nhấn riêng:** <đề tài = màu; đề tài = màu> (vd lust = pink)
- **Chuỗi đang sở hữu:** <tên chuỗi, đề tài>

## Công thức tiêu đề (10 tiêu đề mỗi phim)
- 4 tiêu đề **từ khoá + hậu tố kênh**: `WORD. | <hậu tố>`, `WORD PART 2 | <hậu tố>`.
- 3 tiêu đề **câu đâm thẳng có từ khoá ngách**: "Gaming Stole My Mornings.", "You're Not Lazy. You're Addicted."
- 2 tiêu đề **dấu ấn chuỗi / kênh**: `<Chuỗi>: <phụ đề>`, `<Tên kênh> · <WORD>`.
- Tối đa 1 tiêu đề theo mẫu đối thủ `WORD | An Animated Short Film` (để thử so sánh).
"""
TU_KHOA = r"animated|short film|disciplin|addict|dopamine|habit|motivat|self.?improve|lust|porn|gaming|\bgames?\b|phone|scroll|lazy|procrastinat|lonel|regret|comfort|sleep|tomorrow|later|focus|relapse|clean|sober|day \d|part \d"

def doc_kenh(D):
    p = os.path.join(D, "KENH.md")
    if not os.path.exists(p): return None, p
    K = {}
    for l in open(p, encoding="utf-8"):
        if l.startswith("## "): break
        s = re.sub(r"[*`]", "", l).strip().lstrip("-").strip()   # "- **Tên kênh:** X" -> "Tên kênh: X"
        if ":" in s and not s.startswith("#"):
            k, v = s.split(":", 1)
            if v.strip(): K[kd(k).strip()] = v.strip().strip('"“”')
    return K, p
def mau_rieng(K):
    return {kd(a).strip(): b.strip().lower() for a, b in (x.split("=", 1) for x in re.split(r"[;,]", K.get("mau nhan rieng", "")) if "=" in x)}
def ten_trong(t): return re.sub(r"\s+", " ", re.sub(r"[^a-z0-9 ]", " ", kd(t))).strip()
def doc_tieu_de(p):   # muc "## Tiêu đề" cua 02-PACKAGE: dong "1. Tieu de  ← nên dùng"
    out, on = [], False
    for l in open(p, encoding="utf-8"):
        if l.startswith("#"): on = kd(l.lstrip("#").strip()).startswith("tieu de"); continue
        m = re.match(r"^\s*(\d+)[.)]\s+(.+)$", l)
        if on and m:
            raw = m.group(2).strip(); nen = "nen dung" in kd(raw)
            t = re.split(r"\s+(?:←|<-)\s*|\s+\((?:nên dùng|khuyên dùng)[^)]*\)|\s+—\s+nên dùng", raw)[0].strip().strip("*`\"“”")
            out.append((t, nen))
    return out

def cmd_mau(a):
    p = os.path.join(a.thu_muc, "KENH.md")
    if os.path.exists(p): print(f"Da co {p} (khong ghi de)."); return
    open(p, "w", encoding="utf-8").write(MAU); print(f"Da tao {p}: dien cac dong <...> (hoi nguoi dung 1 lan).")
def cmd_kiem(a):
    K, p = doc_kenh(a.thu_muc); LOI, CB = [], []
    if K is None: print(f"LOI: chua co KENH.md ({p}) → chay: kenh.py mau, roi dien cung nguoi dung"); sys.exit(1)
    for k, lab in (("ten kenh", "Tên kênh"), ("hau to tieu de", "Hậu tố tiêu đề"), ("cau ky ten", "Câu ký tên"), ("mau nhan chu dao", "Màu nhấn chủ đạo")):
        if not K.get(k) or "<" in K.get(k, ""): LOI.append(f"KENH.md chưa điền '{lab}'")
    import kiem_truyen as KT
    meta, sc, tot, _, _ = KT.doc_phim(a.phim); kyten = K.get("cau ky ten", ""); o = kd(K.get("ky ten o", "keu goi"))
    if kyten and "<" not in kyten:
        if len(kyten.split()) > 9: CB.append("câu ký tên dài hơn 9 từ")
        cta = [c for c in sc if any(k.startswith(("keu goi", "cta")) for k in c["tags"])]; card = [c for c in sc if KT.tag(c, "the ket", "card") is not None]
        if o.startswith("the ket"):
            sub2 = (KT.tag(card[-1], "the ket", "card") or "").split("/")[2:3] if card else []
            if not sub2 or ten_trong(sub2[0]) != ten_trong(kyten): LOI.append(f"thẻ kết dòng 2 phải là câu ký tên: '{kyten}'")
        else:
            first = next((x.lstrip('>!~" ').strip() for x in (cta[-1]["chu"] if cta else [])), "")
            if ten_trong(first) != ten_trong(kyten): LOI.append(f"màn KÊU GỌI: dòng chữ đầu phải là câu ký tên '{kyten}' (dòng 2: lời mời like / subscribe)")
    acc, chu = (meta.get("accent") or "red").lower(), K.get("mau nhan chu dao", "").lower()
    rieng = mau_rieng(K); dtai = DT.ma("de_tai", meta.get("de tai")) or ""
    if chu and "<" not in chu and acc != chu and rieng.get(dtai) != acc and rieng.get(kd(meta.get("de tai", ""))) != acc:
        CB.append(f"ACCENT {acc} khác màu chủ đạo {chu} (được nếu là màu riêng của đề tài / chuỗi — ghi vào 'Màu nhấn riêng')")
    if a.goi:
        T = doc_tieu_de(a.goi); suf, ten = ten_trong(K.get("hau to tieu de", "")), ten_trong(K.get("ten kenh", ""))
        chuoi = [ten_trong(x.split("(")[0]) for x in re.split(r"[;,]", K.get("chuoi dang so huu", "")) if x.strip() and "<" not in x]
        word = ten_trong(meta.get("title", ""))
        if len(T) != 10: LOI.append(f"mục Tiêu đề có {len(T)} tiêu đề (cần 10, dạng '1. …')")
        mau_dt = [t for t, _ in T if re.search(r"\|\s*an animated short film\.?\s*$", t, re.I)]
        dau_an = [t for t, _ in T if (suf and suf in ten_trong(t)) or (ten and ten in ten_trong(t)) or any(c and c in ten_trong(t) for c in chuoi)]
        tukhoa = [t for t, _ in T if re.search(TU_KHOA, t, re.I) or (word and word in ten_trong(t)) or re.search(next((rx for m, _, rx in DT.DE_TAI if m == dtai), "$^"), t, re.I)]
        nen = [t for t, n in T if n]
        if len(mau_dt) > 3: LOI.append(f"{len(mau_dt)}/10 tiêu đề theo mẫu đối thủ 'WORD | An Animated Short Film' (tối đa 3)")
        if len(dau_an) < 4: LOI.append(f"chỉ {len(dau_an)}/10 tiêu đề có dấu ấn kênh (hậu tố / tên kênh / tên chuỗi), cần ≥ 4")
        if len(tukhoa) < 8: LOI.append(f"chỉ {len(tukhoa)}/10 tiêu đề có từ khoá ngách (để được tìm thấy), cần ≥ 8")
        if len(nen) != 1: LOI.append(f"cần đúng 1 tiêu đề đánh dấu '← nên dùng' (đang có {len(nen)})")
        elif nen[0] in mau_dt: CB.append("tiêu đề nên dùng đang theo mẫu đối thủ → chọn tiêu đề có dấu ấn kênh")
        for t, _ in T:
            if len(t) > 60: CB.append(f"tiêu đề dài {len(t)} ký tự (> 60): '{t}'")
        rows = DT.doc_csv(os.path.join(a.thu_muc, "DOI-THU-SELFIMPROVE", "video.csv"))
        doi = {ten_trong(r.get("tieu_de", "")): r for r in rows}
        for t, _ in T:
            if ten_trong(t) in doi: LOI.append(f"tiêu đề '{t}' trùng y hệt video của {doi[ten_trong(t)]['ten_kenh']}")
        print(f"  Tiêu đề: {len(T)} · dấu ấn kênh {len(dau_an)} · từ khoá ngách {len(tukhoa)} · mẫu đối thủ {len(mau_dt)} · nên dùng: {nen[0] if nen else '—'}")
    print(f"KIEM KENH {K.get('ten kenh', '?')} — {os.path.basename(a.phim)}" + (f" + {os.path.basename(a.goi)}" if a.goi else ""))
    print(f"  Ký tên ({K.get('ky ten o', 'kêu gọi')}): {kyten or '—'} · màu chủ đạo {K.get('mau nhan chu dao', '—')} · phim dùng {acc}")
    if LOI: print(f"\nLOI ({len(LOI)}):"); [print("  " + x) for x in LOI]
    if CB: print(f"\nCANH BAO ({len(CB)}):"); [print("  " + x) for x in CB]
    print("=> SACH LOI." if not LOI else f"=> CON {len(LOI)} LOI.")
    sys.exit(1 if LOI else 0)

def main():
    ap = argparse.ArgumentParser(); ap.add_argument("lenh", choices=["mau", "kiem"]); ap.add_argument("--thu-muc", default="."); ap.add_argument("--phim"); ap.add_argument("--goi")
    a = ap.parse_args()
    if a.lenh == "kiem" and not a.phim: sys.exit("kiem can --phim <file 01>")
    (cmd_mau if a.lenh == "mau" else cmd_kiem)(a)

if __name__ == "__main__": main()
