# Xem trước, xuất bản cuối, kiểm tra

> Chế độ cinematic (2.0):
> - Cùng các lệnh. `--check` đọc hộp bao chiếu từ 3D: chữ đè đầu / thân / HUD, chữ cắt mép, người ra ngoài khung.
> - Tiêu chí riêng của cinematic (máy, chiều sâu, glow cháy mặt, poster bị cắt, lý do chuyển cảnh, đứng hình nới cho giữ khung có chủ đích) xem mục **Cinematic** cuối file.
> - Xem trong trình duyệt: `--serve` (`?frame=N` / `?live=1`).

## Xuất
- **Quét lỗi nhanh:** `node render.mjs --project projects/<slug> --check --scale 0.25` — liệt kê lỗi theo mã cảnh + giây, kèm cách sửa (lưu `build/check.txt`):
  - `LOI`: nhân vật dùng mốc không có trong bối cảnh (không hiện / sai chỗ); nhân vật ra ngoài khung (trừ khi đang đi ra); chữ đè mặt, đè người / chân, đè đồ vật (đồng hồ, cửa sổ, gương, lịch…); **chữ đè chữ**; **chữ bị cắt mép khung** (1.10); **người đứng chắn trước người khác (che quá 30% thân)**; chân trượt khi đi / chạy (chạy tại chỗ có nền trôi không tính); nhạc hụt (khoảng trống giữa hai đoạn nhạc không ghi `none`); **đứng hình ≥ 2,5 giây** (1.10).
  - `CANH BAO`: đổi tư thế trong 1 khung (`poseDur: 0`) — để nguyên nếu cố ý giật mình; **đứng hình 1,5–2,5 giây** (1.10).
  - **Đứng hình (1.10)** đo bằng điểm ảnh thật: so ảnh thu nhỏ 160x90 giữa hai lần đo cách 3 khung; gần như không đổi liên tục thì báo. Đối thủ: 0 giây; "Five More Minutes" 1.9.0: 34 giây. Sửa: thêm `cam` đẩy, bụi, nhân vật thở / chớp mắt; màn chữ đen rút còn 2–5 giây. Ngưỡng: biến môi trường `H2_STILL` (mặc định 0.04, đo ở `--scale 0.25`).
- **`phim.py` cảnh báo nhịp toàn phim (1.10):** mở đầu không phải màn đen; phim > 3:20 (đối thủ 2:38–2:51); > 4 màn đen; màn đen > 5 giây; màn kêu gọi > 4 giây; đồ thị < 4 giây.
- **Ảnh tổng hợp:** `node render.mjs --project projects/<slug> --sheet --scale 0.5 --at 0.75` — 1 khung mỗi cảnh, lấy ở 75% thời lượng cảnh để chữ đã hiện đủ. Chỉ vẽ vài cảnh: `--ids b07,b08`. Đổi điểm lấy khung: `--at 0.3`.
- **Xem trước có tiếng:** chạy `python tools/mix.py --project projects/<slug> --no-video` trước, rồi `node render.mjs --project projects/<slug> --from 0 --to 30 --scale 0.5` → `build/preview.mp4`.
- **Bản cuối:**
  ```bash
  nohup node render.mjs --project projects/<slug> > projects/<slug>/build/render.log 2>&1 &
  ```
- **Trộn âm:** `python tools/mix.py --project projects/<slug>` → `out/<tiêu đề>.mp4`.
- **Tốc độ tham khảo:** bộ `dem` vẽ bằng CPU (render.mjs tự chọn khi dự án có `pack`): khoảng 20 khung/giây ở 1080p trên máy cloud 2 nhân → phim 3 phút mất 3–5 phút. 720p nhanh gấp đôi. Máy nhiều nhân: thêm `--workers 4`.

## Danh sách kiểm tra (mỗi ảnh tổng hợp)
- [ ] Không có khung "THIEU MAU", "THIEU SHOT" hay chữ đỏ "LOI".
- [ ] Hình khớp mô tả cảnh trong file 01. Chữ đúng nguyên văn file 01.
- [ ] Chữ kể chuyện không đè lên mặt nhân vật, đọc rõ trên nền (không nằm trên vùng sáng chói).
- [ ] Chữ cám dỗ nằm cạnh bóng đen, không đè lên nhân vật chính.
- [ ] Bộ đếm đúng số theo từng cảnh, cú sụp đúng cảnh, sau cú sụp các cảnh sau giữ số mới.
- [ ] Nhân vật chính cùng preset (hoặc đổi đúng chỗ đã ghi trong `bible.md`). Bóng đen dùng đúng màu nhấn.
- [ ] Mỗi cảnh có chuyển động (máy đẩy, nhân vật đi, chữ gõ, bộ đếm chạy). `--check` không còn dòng "dung hinh".
- [ ] Toàn khung 16:9, không dải đen (trừ khi người dùng yêu cầu). Không có vạch màu nhấn dưới màn đen.
- [ ] Mở đầu bằng màn đen 1–2 câu nghịch lý; 3–4 màn đen cả phim; phim ≤ 3:20.
- [ ] Màu đi theo nhịp: đoạn sa ngã / đáy xám dần, bước ngoặt màu trở lại. Bóng đen và chữ cám dỗ vẫn rực màu nhấn.
- [ ] Bóng đen quay mặt về người hùng, tay chạm vai (không chọc mặt, không chỉ khoảng không), không có khói bong bóng, không lộ khớp khi mờ dần.
- [ ] Không có 2 cụm "zzz"; zzz bay từ người ngủ.
- [ ] Bộ đếm nảy lóe màu nhấn khi đổi số (tuổi, ngày). Tuổi ≥ 55 thì nhân vật có dáng già.
- [ ] Tay cầm điện thoại: ngón tròn màu kem, không có khung chữ nhật / móng trắng trên ngón.
- [ ] Không quá 3 cảnh liền cùng bố cục, trừ chuỗi lặp cố ý (phòng ngủ qua các ngày).
- [ ] 9:16: nhân vật và chữ trong khoảng giữa, không sát mép.
- [ ] Âm thanh: có nhạc, có SFX khi bóng đen nói và ở cú sụp, có 1 khoảnh khắc im lặng, tổng khoảng −14 LUFS.
- [ ] Thumbnail: chữ 1–4 từ, không che mặt, không cắt mép; ảnh AI đúng nhân vật mẫu.

## Lỗi thường gặp
- **"THIEU MAU xxx":** `tpl` gõ sai tên. Xem `mau-canh.md`.
- **Muốn giữ y hệt bản ≤ 1.9 (dự án cũ đang dở):** `config.json` → `"look": "classic"` (giữ cả dải đen nếu ghi `"bars": "scope"`), hoặc tắt từng thứ: `"colorArc": false`, `"voiceLayer": false`, shot `"hands": "classic"`, black `"line": true`, `"push": false`.
- **Nhân vật đứng sai chỗ / lơ lửng:** `x` dùng mốc không có trong bối cảnh (vd `bed.sit` ở `city`). Dùng số 0..1.
- **Đổi tư thế / biểu cảm chậm hơn ý muốn:** tư thế chuyển dần 0,3–0,75 giây kể từ mốc `poseAt`. Muốn tới đích đúng giây X thì đặt mốc sớm hơn ~0,4 giây, hoặc ghi giây chuyển `[[X, "cheer", 0.25]]`. Cần giật cố ý (giật mình): `poseDur: 0` / `faceDur: 0`.
- **Nhân vật đi lùi khi `facing` ngược hướng đi:** bản mới tự quay người trước khi bước. Muốn đi lùi thật thì thêm `"back": true` trong `walk`.
- **"Chua co Chromium":** chạy `node tools/chromium.mjs --check` để xem lý do; chưa tải thì `npx playwright install chromium`; Chromium nằm chỗ lạ thì đặt `H2_CHROMIUM` (xem `cai-dat.md`).
- **Chữ hiện font mặc định:** thiếu gói font. Chạy `npm install` trong `h2-2d-studio` (cần `@fontsource/comic-neue`, `caveat`, `luckiest-guy`).
- **"Khong nap duoc pack dem":** thiếu `packs/dem`. Chép lại kit.
- **"Khong khoi dong duoc player":** `shots.json` hoặc `config.json` sai cú pháp JSON.
- **Không có tiếng / mix báo "khong co nhac 'sad'":** chưa chạy `python audio/build_audio.py` sau khi cài bộ `dem`.
- **Video dài/ngắn sai:** `story.duration` phải bằng `end` của cảnh cuối; `phim.py --force` tạo lại nếu chưa lên hình.
- **Xuất rất chậm (vài giây mỗi khung):** đang chạy GPU giả lập. Thêm `--gl auto` vào lệnh render.
- **Windows:** đặt đường dẫn có dấu cách trong ngoặc kép. Dùng `python` hoặc `py -3`.

## Cinematic
- `--check` đo:
  - chữ đè đầu / thân / HUD / chữ khác, chữ cắt mép (hộp bao thật);
  - người ra ngoài khung: không tính người ở tiền cảnh góc qua vai và người phụ bị cắt có chủ ý ở góc cận;
  - đứng hình (màn chữ đen / thẻ kết được giữ yên).
- **Đo nhịp theo cách giám khảo chấm:** `python tools/do_nhip.py build/preview.mp4 --project projects/<slug>`. Trả mã 1 nếu chưa đạt.

| Chỉ số | Nghiệm thu | Phim tham khảo |
|---|---|---|
| `mean_motion` (độ khác TB giữa 2 khung, 320×180) | ≥ 1,2 (nên ≥ 1,3: số giám khảo thấp hơn ~5%) | 1,7–2,0 |
| `big_changes_per_s` (cụm khung khác ≥ 1,5) | ≥ 0,6 | 0,7–1,0 |
| `longest_frozen_s` (ngoài màn chữ đen / thẻ kết) | ≤ 1,0 | — |
| `near_black_ratio` (độ sáng TB < 12) | ≤ 0,10 | 0,04–0,09 |
| đoạn tĩnh ≥ 2 s | 0 | — |

- Chưa đạt thì thử theo thứ tự:
  1. Chia góc dày hơn (director2d: mỗi góc ~2,3–2,6 s).
  2. Thêm chuyển động máy có chủ đích.
  3. Thêm diễn xuất (cử chỉ khi nói, vuốt điện thoại, gõ phím).
  4. Rút đoạn đen.
- Không tăng số bằng nháy sáng hay nhiễu.