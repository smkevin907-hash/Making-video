# Thư viện khung truyện

Mỗi phim chọn **1 khung** (7 khung: 5 khung gốc + 2 khung từ 2.1: Bước nhỏ, Giải mã). Bảng nhịp dưới đây vừa là hướng dẫn viết vừa là luật máy kiểm (`tools/kiem_truyen.py` đọc thẳng các bảng này, nên sửa bảng là sửa luật). Cột `%` = vị trí **bắt đầu** của nhịp tính theo tổng thời lượng; máy cho lệch ±10%.

Chung cho mọi khung:
- **Bộ đếm luôn có** (xương sống), nhưng mỗi khung một kiểu.
- Luật chữ trên hình giữ nguyên: kể chuyện thì quá khứ ngôi thứ ba, tối đa 9 từ, cặp câu đối, 1–3 câu cuối chuyển sang "you". Giọng cám dỗ dịu dàng, hợp lý, leo thang, yếu dần. **Riêng khung 6–7:** được dùng ngôi thứ nhất ở móc và kết, thoại `"` / tin nhắn `@` là xương sống, lý do bào chữa của chính nhân vật thay (hoặc đi cùng) bóng đen — xem `cau-truc.md` mục "Giọng người".
- Viết hay (cụ thể, ngầm ý, câu hỏi sắc, nhịp thở, người dẫn đường, thẻ khái niệm / trích dẫn, kết trung thực): `viet-hay.md`. Ý nghĩa mang đi (`BÀI HỌC`, `BƯỚC NHỎ`, `SỰ THẬT`): tuỳ chọn với khung 1–5, bắt buộc với khung 6–7.
- Chiều sâu cảm xúc (ước mơ gài đầu, vật biểu tượng 3 lần, gài – trả), câu móc, độ dài và giữ chân: xem `cau-truc.md`.
- Ghi tên nhịp vào dòng `# TRUYỆN: nhịp <tên>` ở cảnh mở nhịp (tên đúng như cột Nhịp).

**Chọn khung theo đề tài** (skill đề xuất 1 khung + lý do, người dùng đổi được):

| Đề tài | Hợp nhất | Cũng hợp |
|---|---|---|
| điện thoại / dopamine, lust, game | Vực dậy | Vòng lặp (tái nghiện), Hai cuộc đời, Giải mã (khi có gốc tâm lý rõ) |
| trì hoãn, sợ thất bại, vùng an toàn | Tiếc nuối | Thư gửi bản thân, Hai cuộc đời, Bước nhỏ |
| lười / dậy sớm, kỷ luật | Hai cuộc đời | Vực dậy, Bước nhỏ |
| cô đơn, người cũ | Thư gửi bản thân | Vực dậy, Bước nhỏ (bước nhỏ = 1 lời chào, 1 tin nhắn) |
| rượu / vape, ăn uống | Vòng lặp | Tiếc nuối |
| thời gian / tiếc nuối | Tiếc nuối | Thư gửi bản thân |
| **thói quen cần xây**: tập thể dục, đọc, ngủ đúng giờ, học | **Bước nhỏ** | Hai cuộc đời |
| **động lực**: chờ cảm hứng, chờ "sẵn sàng", bỏ giữa chừng | **Bước nhỏ** | Tiếc nuối, Giải mã |
| **đức tính**: kiên nhẫn, biết ơn, trung thực, lòng tốt, can đảm, khiêm tốn, giữ lời | Bước nhỏ (đức tính tập bằng việc nhỏ lặp lại) | Thư gửi bản thân, Hai cuộc đời (người có / không có đức tính đó) |
| **hành vi có gốc tâm lý rõ**: thức khuya để "lấy lại" thời gian, cuộn điện thoại để tránh lo âu, ăn khi buồn, né cuộc gọi | **Giải mã** | Vòng lặp, Vực dậy |

Lý do ghi 1 câu (vd: "trì hoãn không có cú sụp rõ ràng mà là mất dần → Tiếc nuối hợp hơn Vực dậy"). Tránh trùng khung + kết mà đối thủ đã dùng cho đề tài đó (xem `phan-tich/`).

**Khi nào chọn khung mới, khi nào giữ khung cũ:**
- Chọn **Bước nhỏ** khi vấn đề là *chưa bắt đầu / không duy trì* một việc tốt (không có "cơn nghiện" để sụp), và lời giải là thu nhỏ mục tiêu. Giữ **Vực dậy / Vòng lặp** khi có thứ kéo nhân vật xuống (nghiện, tái nghiện) và cú sụp về 0 là khoảnh khắc chính.
- Chọn **Giải mã** khi hành vi có một **động cơ hiểu được** (người xem sẽ "à ra thế") và có một **khái niệm có thật** để đặt tên. Không có khái niệm có thật hợp đề tài thì không dùng Giải mã.
- Đề tài tự hại / tuyệt vọng: vẫn chỉ Vực dậy, Thư gửi bản thân (SKILL.md mục 3, bước 0). Cô đơn (không có ý tự hại) dùng thêm được Bước nhỏ.
- Đức tính không phải "thói xấu" → không bắt có bóng đen. Cái đối lập (nóng vội, vô ơn, nói dối cho tiện) đóng vai lý do bào chữa / giọng cám dỗ.

---

## 1. Vực dậy (`vuc-day`)
Nhân vật sa vào thói xấu, chạm đáy, một khoảnh khắc người thật kéo dậy, làm lại. Kết hy vọng.
- **Bộ đếm:** DAY N tăng → gạch về 0 ở Đáy → đếm lại (DAY 1) ở Đứng lên. Biến thể: đếm ngày lãng phí rồi quay về DAY 1; DAY N kèm tên thói quen mới ("DAY 4 · RUN").
- **Kết:** hy vọng, câu cuối nói với "you".
- **Vật biểu tượng gợi ý:** mới / đang dùng → bỏ quên → dùng lại.

| Nhịp | % | Làm gì |
|---|---|---|
| Móc | 0 | Câu móc (xem kiểu câu móc). Chưa có bóng đen. |
| Ước mơ | 5 | 1–3 cảnh đời thường có ước mơ hiện bằng hình; vật biểu tượng lần 1; gài. |
| Sa ngã | 15 | Bóng đen thì thầm, nhượng bộ từng chút, bộ đếm chạy; 1 montage "ngày qua ngày"; vật lần 2 (bị bỏ quên). |
| Đáy | 40 | Cái giá hiện hình, bộ đếm gạch về 0 (sụp), 1 câu đau nhất rồi im lặng. |
| Bước ngoặt | 58 | Khoảnh khắc người thật; một việc nhỏ khác đi. |
| Đứng lên | 70 | Montage làm lại, bộ đếm đếm lại; bóng đen yếu dần rồi vỡ; vật lần 3 (dùng lại); trả. |
| Thẻ kết | 92 | THẺ KẾT + KÊU GỌI. |

Máy kiểm: dem=reset; ket=hy-vong,mo; sup=1; nguoi=1

## 2. Tiếc nuối / cảnh tỉnh (`tiec-nuoi`)
Nhân vật mãi "để mai", thời gian trôi tới khi nhận ra đã quá muộn cho chính giấc mơ đó. **Không** cho nhân vật vực dậy; cái giá được giữ nguyên. Hy vọng được **trao cho người xem** ở câu cuối ("you still have time.").
- **Bộ đếm:** thời gian sống tăng, không về 0: `AGE 17 → 34`, `YEARS LOST 0 → 12`, hoặc 2 dòng `AGE 17; YEARS LEFT 13`. Mỗi lần nhảy tuổi là 1 biến cố.
- **Kết:** tiếc nuối (cho nhân vật) + 1–2 câu "you" trao hy vọng cho người xem. Đề tài nặng: thêm dòng hỗ trợ ở mô tả.
- **Vật biểu tượng gợi ý:** mới tinh → phủ bụi → cho đi / thấy người khác dùng.
- **Không dùng:** cảnh tự hại, tuyệt vọng không lối ra.

| Nhịp | % | Làm gì |
|---|---|---|
| Móc | 0 | Câu móc. Thường là câu hứa hẹn ("He had plenty of time.") hoặc cảnh cuối đặt lên đầu. |
| Ước mơ | 5 | Tuổi trẻ, ước mơ hiện bằng hình, vật lần 1 (mới); gài. |
| Để mai | 15 | Vòng lặp "để mai": cám dỗ dịu ("next year."), tuổi nhảy, mỗi vòng ngắn hơn; vật lần 2 (bụi). |
| Nhận ra | 45 | Nhân vật thấy người khác sống giấc mơ đó / thấy mình trong gương; tuổi lớn; sụp (cái giá). |
| Cái giá | 65 | Thử lại nhưng quá muộn cho giấc mơ này; lặng; khoảnh khắc người thật (gia đình, bạn cũ) cho thấy điều đã mất; vật lần 3. |
| Trao lại | 85 | Quay sang người xem: 1–2 câu "you" trao hy vọng; trả (hình mở đầu lặp lại với nghĩa mới). |
| Thẻ kết | 94 | THẺ KẾT + KÊU GỌI. |

Máy kiểm: dem=tang; ket=tiec-nuoi; sup=1; nguoi=1

## 3. Hai cuộc đời song song (`song-song`)
Cùng một người, một ngã rẽ, hai lựa chọn chạy song song (X VS Y). Bộ dựng chưa chia đôi khung → **xen kẽ** cảnh nhánh A / nhánh B, cùng mốc thời gian, bộ đếm 2 dòng.
- **Bộ đếm:** 2 dòng đối nghịch, cùng hiện: `SCROLLED 2,140 HOURS; TRAINED 2,140 HOURS`, `A: DAY 300; B: DAY 300`, hoặc `SEEN 1,388; KNOWN 0`.
- **Kết:** mở (người xem chọn) hoặc hy vọng (hai nhánh hội tụ ở hiện tại). Tiêu đề hợp công thức X VS Y.
- **Vật biểu tượng gợi ý:** cùng 1 vật ở 2 nhánh, 2 số phận (bóng rổ bám bụi / bóng rổ mòn vì dùng).
- Ghi nhánh vào `# TRUYỆN: nhánh A` / `nhánh B`; màu nhấn có thể khác nhau nhờ đồ vật (đèn bàn ấm vs ánh điện thoại xanh).

| Nhịp | % | Làm gì |
|---|---|---|
| Móc | 0 | Một khoảnh khắc, hai lựa chọn ("One night. Two choices."). |
| Ngã rẽ | 6 | Cảnh rẽ nhánh; ước mơ chung hiện bằng hình; vật lần 1; gài. |
| Song song | 15 | Xen kẽ A / B cùng mốc giờ, bộ đếm 2 dòng tách dần; cám dỗ nói với nhánh A. |
| Phân kỳ | 55 | Khoảng cách lớn rõ; cả hai nhánh đều có cái giá (A mất bạn, B đau vì tập); sụp ở nhánh A; vật lần 2 hai số phận. |
| Hội tụ | 78 | Hai nhánh gặp nhau ở cùng 1 nơi (gương, cùng con phố); khoảnh khắc người thật; vật lần 3; trả. |
| Thẻ kết | 93 | THẺ KẾT dạng "X VS Y." + KÊU GỌI. |

Máy kiểm: dem=2dong; ket=mo,hy-vong; sup=1; nguoi=1

## 4. Vòng lặp (`vong-lap`)
Phim kết **đúng ở cảnh mở đầu**, chỉ khác **một chi tiết** (điện thoại đã cất vào ngăn kéo, báo thức tắt trước khi reo…). Hợp đề tài tái nghiện.
- **Bộ đếm:** bị gạch về DAY 1 nhiều lần (mỗi vòng 1 lần), mỗi vòng ngắn hơn; hoặc `LOOP 1 / 2 / 3`.
- **Kết:** vòng lặp — cảnh cuối = cảnh đầu (cùng bối cảnh, cùng góc) + 1 chi tiết khác, ghi `# TRUYỆN: khác <chi tiết>`. Chi tiết đó là câu trả lời; có thể kèm 1 câu "you".
- **Vật biểu tượng gợi ý:** cùng 1 vật ở cùng 1 chỗ mỗi vòng, vòng cuối khác vị trí / trạng thái.

| Nhịp | % | Làm gì |
|---|---|---|
| Mở vòng | 0 | Cảnh mở đầu cụ thể (bối cảnh, giờ, vật); câu móc; ước mơ hiện bằng hình; gài. |
| Vòng 1 | 12 | Cố gắng, cám dỗ, gục, quay về cảnh mở đầu; bộ đếm về DAY 1 (sụp). |
| Vòng 2 | 38 | Lặp nhanh hơn, cắt ngắn hơn; nhân vật bắt đầu nhận ra vòng lặp (móc lại); vật lần 2. |
| Lệch vòng | 62 | Khoảnh khắc người thật; một lựa chọn nhỏ khác đi. |
| Khép vòng | 85 | Cảnh mở đầu lặp lại y hệt, trừ 1 chi tiết (khác); vật lần 3; trả. |
| Thẻ kết | 93 | THẺ KẾT + KÊU GỌI. |

Máy kiểm: dem=lap; ket=vong-lap,hy-vong; sup=1; nguoi=1; vong=1

## 5. Thư gửi bản thân / nhìn lại (`thu-gui`)
Bản thân già hơn (hoặc tương lai) viết cho bản thân trẻ. Lời thư hiện như **chữ trong thế giới phim** (sổ tay viết tay, tin nhắn `@` từ "me, 2046") nên chữ kể chuyện `>` vẫn giữ thì quá khứ ngôi thứ ba.
- **Bộ đếm:** năm / tuổi: `2026 → 2046`, `AGE 20 → 40`, hoặc `YEARS SINCE 0 → 20`.
- **Kết:** hy vọng (bản thân trẻ nhận thư, làm 1 việc nhỏ) hoặc mở (người xem là người nhận).
- **Vật biểu tượng gợi ý:** vật người viết vẫn giữ (sổ tay, quả bóng cũ) → trong hồi tưởng còn mới → được trao lại.

| Nhịp | % | Làm gì |
|---|---|---|
| Móc | 0 | Lá thư / tin nhắn xuất hiện (sổ tay, chat). |
| Người viết | 8 | Lộ người viết (già hơn / tương lai); hồi tưởng ước mơ bằng hình; vật lần 1; gài. |
| Hồi tưởng | 20 | Lời thư (sổ tay / chat) xen cảnh tuổi trẻ phí thời gian; cám dỗ trong hồi tưởng; vật lần 2. |
| Điều ước | 55 | Người viết nói điều ước giá đã làm; cái giá lộ ra (sụp); khoảnh khắc người thật. |
| Trả lời | 78 | Bản thân trẻ đọc thư / người xem được hỏi; 1 việc nhỏ khác đi; vật lần 3; trả. |
| Thẻ kết | 93 | THẺ KẾT + KÊU GỌI. |

Máy kiểm: dem=tang; ket=hy-vong,mo; sup=1; nguoi=1; thu=1

## 6. Bước nhỏ (`buoc-nho`)
Nhân vật lập một kế hoạch lớn, bỏ dở bằng những lý do rất hợp lý, chạm đáy (từ bỏ, trả đồ), rồi một **người dẫn đường** thu nhỏ mục tiêu thành một việc làm được ngay. Lý do cũ quay lại và bị đáp bằng bước nhỏ. Kết hy vọng **lặng lẽ**, trao bước nhỏ cho người xem. Hợp: thói quen cần xây (tập thể dục, đọc, ngủ, học), động lực, đức tính. Không dùng cho cai nghiện (dùng Vực dậy / Vòng lặp).
- **Bộ đếm:** lịch (`lich`): `NỀN: cận lịch, tháng sep, 0 tới N, tô màu` hoặc gạch X, kèm HUD `DAY N · <việc>` (vd `DAY 3 · READ`); ngày thật đặt ở dòng `!` (`! Mon, Sep 22.`). Kế hoạch lớn đếm theo mục tiêu lớn rồi bị bỏ; sau người dẫn đường đếm lại từ `DAY 1 · <việc nhỏ>`.
- **Kết:** `bước nhỏ` (thắng lặng lẽ, có thể còn tái phạm nhỏ) hoặc `hy vọng`; câu cuối "you" ngắn + bước nhỏ cho người xem.
- **Vật biểu tượng gợi ý:** đồ của thói quen (sách, cặp, quả bóng, đồng hồ báo thức, đèn bàn): mới tinh → cất đi / trả lại → dùng lại theo cách nhỏ hơn.
- **Người dẫn đường:** người có lý do quan tâm (bạn, bố mẹ, huấn luyện viên, chủ tiệm, người lạ ở trạm xe); nói ≤ 3 câu, kết bằng câu hỏi hoặc đề nghị có thời lượng ("ten minutes?"). Ghi `# TRUYỆN: người dẫn đường`.
- **Lý do bào chữa** (thay hoặc đi cùng bóng đen): mỗi lý do gắn 1 ngày / 1 cảnh, leo thang (`viet-hay.md` mục f). Có thể giữ bóng đen thì thầm lý do; nếu bỏ bóng đen thì ghi lý do bằng `~` trên cảnh lịch / điện thoại / người.

| Nhịp | % | Làm gì |
|---|---|---|
| Móc | 0 | Châm ngôn nghịch lý trên màn đen hoặc lời thú nhận ngôi thứ nhất (`MÓC: châm ngôn nghịch lý trên màn đen` / `lời thú nhận ngôi thứ nhất`). |
| Kế hoạch lớn | 5 | Hào hứng lập mục tiêu to (poster, lịch, đồ mới); ước mơ bằng hình; vật lần 1; gài lý do sẽ quay lại. |
| Nhật ký bào chữa | 12 | Lịch có ngày, mỗi ngày một lý do nghe hợp lý, leo thang; ô lịch bị gạch dần; vật lần 2 (cất đi). |
| Đáy | 28 | Từ bỏ / trả đồ; một câu hỏi sắc từ người khác; sụp (bộ đếm gạch hoặc lịch xoá); im lặng. |
| Người dẫn đường | 38 | Người thật thu nhỏ mục tiêu bằng 1 câu hỏi / 1 đề nghị; nhân vật nghi ngờ rồi nhận lời. Điểm xoay 1. |
| Bước nhỏ | 50 | Montage thắng nhỏ, lịch mới đếm lại từ DAY 1; có thể đặt 1 thẻ trích dẫn (35–70%); móc lại. |
| Lý do cũ quay lại | 72 | Đúng lý do đã gài trở lại (cùng chữ / cùng cảnh) và bị đáp bằng bước nhỏ; trả; vật lần 3 (dùng lại). Điểm xoay 2. |
| Trao lại | 85 | Câu "you" ngắn; bước nhỏ hiện đúng 1 lần bằng hình + chữ; kết trung thực (chưa hoàn hảo). |
| Thẻ kết | 94 | THẺ KẾT + KÊU GỌI. |

Máy kiểm: dem=lich; ket=buoc-nho,hy-vong; sup=1; nguoi=1; dan=1; y=1; xoay=2; giu=25

## 7. Giải mã (`giai-ma`)
Một hành vi tưởng là lười / yếu đuối hoá ra có **động cơ hiểu được**. Phim đặt tên cho hiện tượng bằng một **khái niệm có thật**, cho thấy cái giá qua giọng những người xung quanh, rồi một người thật nói ra sự thật và đưa một **thoả thuận cụ thể**. Nhân vật tái phạm nhỏ (trung thực), rồi giữ được phần lớn. Hợp: hành vi có gốc tâm lý rõ (thức khuya để lấy lại thời gian, cuộn điện thoại để tránh lo âu, ăn khi buồn…). Chỉ dùng khi có khái niệm có thật hợp đề tài (`viet-hay.md` mục h).
- **Bộ đếm:** giờ (`gio`): giờ đồng hồ trong đêm / trong ngày (`NỀN: cận đồng hồ, 1:59 -> 2:00`, `cận điện thoại, màn khoá 2:14`) kèm HUD đếm đêm / ngày (`NIGHT 12`, `DAY 3`). Mỗi lần giờ nhảy là 1 biến cố.
- **Kết:** `bước nhỏ` hoặc `hy vọng`, luôn có **tái phạm nhỏ** trước khi kết.
- **Vật biểu tượng gợi ý:** vật đổi chỗ theo thoả thuận (điện thoại trên giường → sạc ngoài phòng; đèn bàn bật lúc 2 giờ sáng → tắt lúc 11 giờ).
- **Giọng người xuyên suốt:** ít nhất 3 người nói khác nhau (thoại / tin nhắn), mỗi người một chức năng (kéo / hỏi / thương / đo). Người nói sự thật là người dẫn đường (`# TRUYỆN: người dẫn đường`).

| Nhịp | % | Làm gì |
|---|---|---|
| Móc | 0 | Lời thú nhận ngôi thứ nhất (`MÓC: lời thú nhận ngôi thứ nhất`), giờ cụ thể trên hình. |
| Lịch trình ép | 8 | Danh sách có nhịp 3–4 việc rồi 1 câu chốt: nguồn gốc của hành vi (không phải lười). Ước mơ bằng hình; vật lần 1; gài. |
| Thẻ khái niệm | 17 | Tên hiện tượng + định nghĩa 1 câu trên màn đen (`# TRUYỆN: khái niệm <tên>`). Khái niệm có thật, nguồn ở `SỰ THẬT:`. |
| Cái giá | 24 | Cái giá hiện qua giọng người thật (huấn luyện viên, bạn, gia đình — thoại / tin nhắn), không qua lời kể; sụp; vật lần 2. |
| Sự thật | 46 | Một người thật hiểu động cơ, nói thẳng điều nhân vật né; một câu hỏi sắc. Điểm xoay 1. |
| Thỏa thuận | 56 | Thoả thuận cụ thể có giờ / việc (kế hoạch "nếu… thì…"); vật đổi chỗ; móc lại. |
| Tái phạm nhỏ | 70 | Lách luật nhẹ (một lần, có lý do nghe hợp lý), nhận ra, quay lại. Điểm xoay 2. |
| Trao lại | 84 | Câu "you" ngắn, ấm; bước nhỏ hiện đúng 1 lần; trả (vật / câu đầu phim với nghĩa mới); vật lần 3. |
| Thẻ kết | 94 | THẺ KẾT + KÊU GỌI. |

Máy kiểm: dem=gio; ket=buoc-nho,hy-vong; sup=1; nguoi=1; dan=1; khai=1; y=1; xoay=2; giu=25

Khoá máy kiểm mới (chỉ khung 6–7 dùng; khung 1–5 không đổi): `dem=lich` (có cảnh `cận lịch` hoặc HUD `DAY N · việc`, và ≥ 1 dòng `!` ghi thứ / ngày), `dem=gio` (≥ 2 cảnh có giờ hh:mm), `dan=1` (có `người dẫn đường`), `khai=1` (có `khái niệm`), `y=1` (đủ `BÀI HỌC`, `BƯỚC NHỎ`, `SỰ THẬT`; `bước nhỏ` đúng 1 lần ở 30% cuối), `xoay=N` (≥ N điểm `xoay`), `giu=25` (tối đa 25 giây giữa hai "lý do xem tiếp").

---

## Thủ pháp học được (dùng được trong mọi khung)
Rút từ thư viện phân tích (`DOI-THU-SELFIMPROVE/phan-tich/`), chỉ học cách làm, không chép.
- **Ẩn dụ nhìn thấy được làm thước đo phụ:** một thứ trong cảnh đổi dần theo thói xấu (căn phòng tối dần, kệ đồ vơi dần, cửa sổ từ nắng sang mưa) song song với bộ đếm. Bộ dựng làm được: đổi `sky` cửa sổ, đèn bàn tắt / bật, `dim`, lịch tô dần. (Đổi cả cảnh sang màu xám: chưa hỗ trợ.)
- **Bộ đếm kèm tên việc:** `DAY 4 · RUN`, `DAY 10 · READ` biến phần làm lại thành danh sách người xem làm theo được.
- **Đếm ngược theo giờ trong 1 ngày** cho montage nghiện: 2:14 PM → 3:47 AM (cận đồng hồ / thanh trạng thái điện thoại).
- **Màn hình tắt phản chiếu mặt** ở bước ngoặt (`cận điện thoại, màn tắt`).
- **Đoạn giải thích giữa phim** làm móc lại (đổi nhịp, cho người xem 1 ý để chia sẻ): bộ dựng chưa có mẫu đồ thị → dùng `cận lịch` / bộ đếm / sổ tay vẽ chữ.
- **Gài – trả bằng người + vật:** người bạn + món đồ ở cảnh 2 quay lại ở cảnh cuối.

## Vật biểu tượng bộ dựng vẽ được
Cầm theo người: điện thoại, ô, sách, quả bóng (rổ), cặp, cốc. Trong bối cảnh: đồng hồ báo thức, lịch, đèn bàn, laptop, sổ tay (cận), gương (nứt được), bao cát, tạ, cửa phòng, cửa neon, ghế băng sân bóng, rổ bóng, cầu thang, đỉnh đồi, trạm xe buýt, cửa sổ (trăng / mưa / bình minh). Ảnh trong feed điện thoại: xem `kho-canh.md`.
Vật khác (đàn guitar, giá vẽ, diều, máy chơi game…): chọn vật gần nhất ở trên, hoặc ghi dòng `# cần vẽ thêm: <vật>` trong file 01 để người dựng biết.
