# Sổ tay viết cuốn và có nghĩa

Luật chữ ở `cau-truc.md` nói câu **được phép** dài bao nhiêu. File này nói vì sao một câu **hay**: nó cụ thể, có ngầm ý, có nhịp, và để lại cho người xem một việc làm được. Đọc trước khi viết bản nháp; dùng checklist cuối file cho lượt biên tập (SKILL.md mục 3, bước 7b).

Nguồn: phân tích cách viết 2 phim của một kênh nhỏ (Last Soul) cộng với kinh nghiệm của các khung truyện. Đây là **thủ pháp đáng thử**, không phải công thức thành công. Không chép câu chữ, tình huống, nhân vật, cảnh của kênh nào. Ví dụ dưới đây đều tự nghĩ.

Ký hiệu: ✗ = yếu, ✓ = mạnh hơn.

## a) Cụ thể thắng chung chung
Chung chung là lời kết luận. Cụ thể là bằng chứng để người xem tự kết luận. Thay tính từ ("lazy", "sad", "addicted") bằng thứ đo được: giờ, ngày, con số, tên, đồ vật.
- ✗ `> He was lazy.` → ✓ `> 11:40 AM. Alarm still off.`
- ✗ `> He wasted his time.` → ✓ `> 312 videos. Zero pages.`
- ✗ `> He felt alone.` → ✓ `> Birthday. Two texts. Both from apps.`
- **Luật:** mỗi cảnh có chữ chứa ít nhất 1 chi tiết cụ thể (số, giờ, thứ / ngày, tên người, tên vật). Không nhồi số vào mọi câu: câu đau nhất thường không có số.

## b) Hạ ngầm (subtext)
Nhân vật nói một điều, người xem hiểu điều khác. Đừng gọi tên cảm xúc; cho thấy hành vi.
- ✗ `" [mom] I'm worried about you.` → ✓ `" [mom] I made extra. In case.`
- ✗ `> He was ashamed of his grades.` → ✓ `> He flipped the paper face down.`
- ✗ `@me: i'm lonely` → ✓ `@me: haha yeah, busy week` (người xem biết là không bận)
- **Luật:** không dùng câu "He felt …", "He realized …" quá 1 lần trong phim.

## c) Đảo nghĩa và câu hỏi sắc
Ở điểm xoay, một câu hỏi ngắn đánh mạnh hơn một câu khẳng định, vì người xem phải tự trả lời.
- ✗ `> His plan was too big.` → ✓ `" [friend] could you do ten pushups?`
- ✗ `> He knew he had to change.` → ✓ `> Who was he saving the mornings for?`
- Đảo nghĩa: một câu quen thuộc lật lại ở cuối. `> Tomorrow, he'd start.` (đầu) → `> Tomorrow, he started again.` (cuối).
- **Luật:** đặt câu hỏi sắc ở nhịp Đáy / Người dẫn đường / Sự thật; tối đa 3 câu hỏi **sắc** (câu hỏi xoay chuyện) cả phim, không đặt ở 2 cảnh liền. Câu hỏi thường trong thoại ("then what?", "you okay?") không tính.

## d) Giọng người
Giọng người thật làm người xem nhận ra mình trong 3 giây đầu.
- **Ngôi thứ nhất được phép ở móc và kết** (khung `buoc-nho`, `giai-ma`; khung cũ chỉ ở móc kiểu `thu-nhan`): `> Every January, I bought a new planner.` / `> I still miss a day. I don't miss two.` Mỗi câu ≤ 9 từ.
- **Thoại là xương sống ở khung có thoại:** bong bóng `"` và tin nhắn `@` kể chuyện thay cho chữ kể chuyện `>`. Mỗi nhân vật phụ có **một chức năng**: kéo (rủ đi), hỏi (đặt câu hỏi sắc), thương (chăm sóc), đo (cho thấy cái giá: huấn luyện viên, sếp, bảng điểm).
- Viết như người nói thật: ngắn, có khi thiếu chủ ngữ, tin nhắn viết thường. ✗ `" [dad] You should go to bed earlier.` → ✓ `" [dad] lights. now.`

## e) Nhịp thở
- Dòng ngắn: nhiều câu 2–5 từ, mỗi cảnh tối đa 3 dòng chữ.
- **Khoảng lặng:** ít nhất 2 cảnh không chữ (hình tự nói: cận mặt, đồ vật, phòng trống). Đặt ngay sau câu đau nhất hoặc trước điểm xoay.
- **Danh sách có nhịp:** 3–4 nhịp đều rồi 1 câu chốt lệch nhịp.
  `> School till 3.` / `> Practice till 6.` / `> Homework till 10.` / `! Then, finally, mine.`
- Montage: cảnh 2–4 giây, câu 2–4 từ, cùng một cấu trúc lặp.

## f) Lý do bào chữa đời thường
Lý do hay nhất là lý do người xem từng dùng. Nó nghe hợp lý, nên mới đáng sợ (cùng tinh thần với giọng cám dỗ, nhưng là suy nghĩ của chính nhân vật).
- Leo thang theo ngày: thực tế → hợp lý hoá → đổ cho hoàn cảnh → bỏ hẳn.
  `Mon · Gym's packed on Mondays.` → `Wed · Need new headphones first.` → `Fri · Big test tomorrow.` → `Sun · Fresh start next month.`
- **Luật:** mỗi lý do gắn **một ngày** (dòng `!` có thứ / ngày) hoặc **một cảnh** (đồ vật minh hoạ). Không lặp cùng một lý do 2 lần, trừ lần quay lại ở nhịp trả.

## g) Người dẫn đường
Không giảng. Họ **thu nhỏ vấn đề** bằng 1 câu hỏi hoặc 1 đề nghị nhỏ, cụ thể, có thời lượng.
- ✗ `" [coach] Discipline is everything, kid.`
- ✓ `" [coach] can you show up for ten minutes?` / `" [mom] phone sleeps in the kitchen. deal?`
- Người dẫn đường có lý do để quan tâm (đã từng như vậy, có việc phải làm cùng), nói tối đa 2–3 câu, rồi để nhân vật tự làm.
- **Luật:** đánh dấu `# TRUYỆN: người dẫn đường` ở cảnh họ đưa đề nghị.

## h) Thẻ khái niệm
Đặt tên cho hiện tượng tạo khoảnh khắc "à ra thế" và dễ chia sẻ. **Chỉ dùng khái niệm có thật**, có người đặt tên / nghiên cứu, và định nghĩa đúng.
- Cú pháp (màn đen): `! Planning fallacy.` + `> We underestimate how long things take.` Ghi `# TRUYỆN: khái niệm <tên>`.
- Ghi nguồn ở dòng `SỰ THẬT:` đầu file (người đặt tên, năm, nơi công bố), không ghi lên hình.
- Ví dụ khái niệm có thật đã kiểm (chọn cái hợp đề tài, đừng dùng chỉ để trang trí): *planning fallacy* (Kahneman & Tversky, 1979), *implementation intentions* — kế hoạch "nếu… thì…" (Gollwitzer, 1999), *liking gap* — ta đánh giá thấp mức người khác quý mình sau một cuộc trò chuyện (Boothby và cộng sự, Psychological Science, 2018), *doomscrolling* (Merriam-Webster).
- **Tránh:** khái niệm đã thành câu cửa miệng mà không có nguồn ("dopamine detox" như một khái niệm khoa học), định nghĩa phóng đại ("proven to double your success").
- Không dùng lại khái niệm hoặc trích dẫn mà video tham khảo / đối thủ đã dùng làm điểm nhấn (xem `phan-tich/`).

## i) Thẻ trích dẫn
Một câu nói có thật của tác giả có thật, đặt **giữa phim** (35–70%) làm điểm dừng suy ngẫm; không đặt ở cuối để "dạy".
- Cú pháp (màn đen, tối đa 3 dòng):
  ```
  [B18] 9s | CẢNH: màn đen, trích dẫn | NỀN: màn đen | NHẠC: none
  # TRUYỆN: trích dẫn
  > "How we spend our days is,
  > of course, how we spend our lives."
  > — Annie Dillard
  ```
  Dòng bắt đầu bằng `— ` được bộ cinematic dựng thành chữ nhỏ in hoa (dòng nguồn). Câu dài thì cắt thành 2 dòng `>` ở chỗ ngắt tự nhiên.
- Giây của cảnh: `--dry-run` tính giờ đọc cả dòng nguồn như câu thường, nên thẻ 2 dòng + nguồn cần khoảng 8–9 giây và sẽ có `CANH BAO màn đen > 5s`. Giữ cảnh báo đó (ghi lý do "thẻ trích dẫn") thay vì cắt câu trích; câu trích ngắn (≤ 6 từ, 1 dòng) thì 5 giây là đủ.
- `SỰ THẬT:` đầu file ghi đủ: tác giả, tác phẩm, năm (vd `Annie Dillard, The Writing Life (1989)`).
- **Kiểm nguồn trước khi dùng** (có công cụ tìm kiếm thì tìm câu trong ngoặc kép + tên tác giả). Không kiểm được thì thêm dòng `# CẦN KIỂM NGUỒN` và **không đưa thẻ trích dẫn vào phim** (máy kiểm báo LỖI).
- **Tránh câu hay bị gán sai:** "We are what we repeatedly do" (của Will Durant, không phải Aristotle), "Be the change you wish to see" (không phải nguyên văn Gandhi), mọi câu chỉ thấy trên ảnh trích dẫn mạng xã hội.
- Tối đa 1–2 thẻ trích dẫn mỗi phim; thẻ trích dẫn tính là màn đen (tổng màn đen ≤ 4).

## j) Kết trung thực
Người xem tin cái kết khi nó **không hoàn hảo**.
- Tái phạm nhỏ: nhân vật lách luật một lần (`" [hoodie] just till 12:30.`), rồi quay lại. Thắng lặng lẽ: không cúp, không đám đông; một thói quen nhỏ còn sống sau 30 ngày.
- Bước nhỏ xuất hiện **đúng 1 lần ở cuối** bằng hình + chữ (trùng dòng `BƯỚC NHỎ:` đầu file).
- Câu cuối nói thẳng với người xem: ngắn, ấm, không doạ, không ra lệnh kiểu huấn luyện viên.
  ✗ `> Stop being weak. Start now.` → ✓ `> Ten minutes. Tonight. That's the whole plan.`

## k) Gài – trả đổi nghĩa
Một câu hoặc một vật ở đầu phim quay lại ở 40% cuối **với nghĩa mới**.
- Câu: lý do `Need new headphones first.` (gài, ngày 3) → cuối phim tai nghe hỏng thật, cậu vẫn đi (trả).
- Vật: cái đèn bàn tắt suốt nửa đầu → bật lúc 6 giờ sáng.
- Hay nhất khi cái trả là **chính lý do cũ bị đáp lại bằng bước nhỏ**.

## l) Những điều tránh
- Lời khuyên chung chung: "believe in yourself", "never give up", "stay consistent".
- Câu động lực sáo rỗng, giọng giảng: "Success is a journey, not a destination."
- Giải thích bài học giữa phim (20–80% thời lượng): `> He learned that small steps matter.` Hãy để cảnh làm việc đó; bài học chỉ nằm ở `BÀI HỌC:` đầu file và trong 02-PACKAGE.
- Kết hoàn hảo: từ con số 0 thành vô địch trong 30 ngày.
- Bịa số liệu ("90% of people…"), bịa nghiên cứu, bịa trích dẫn, gán sai tác giả.
- Đề tài nhạy cảm: luật ở SKILL.md mục 4 vẫn giữ nguyên (không minh hoạ cách tự hại; lust chỉ gợi ý kín đáo; kết hy vọng và nối với người thật).

---

## Checklist biên tập (12 câu — dùng cho lượt 2)
Đọc lại file 01 như biên tập viên, trả lời từng câu "có / chưa". Mỗi "chưa" là một chỗ cần viết lại.
1. **3 giây đầu** có một giọng người (lời thú nhận, câu nghịch lý, câu hỏi) mà người xem nhận ra chính mình không?
2. Mỗi cảnh có chữ có **ít nhất 1 chi tiết cụ thể** (giờ, ngày, số, tên, vật) không? Câu nào còn tính từ chung chung ("lazy", "sad", "hard")?
3. Có câu nào **gọi tên cảm xúc** thay vì cho thấy hành vi ("He felt…", "He realized…") không?
4. Ở điểm xoay có **câu hỏi sắc** thay cho câu khẳng định không?
5. Nhân vật phụ có **giọng riêng và chức năng riêng** (kéo / hỏi / thương / đo) không? Người dẫn đường có thu nhỏ vấn đề hay đang giảng?
6. Lý do bào chữa / giọng cám dỗ có **nghe hợp lý** và **leo thang** không?
7. Có **ít nhất 2 khoảng lặng** không chữ, và nhịp có câu ngắn xen câu chốt không?
8. Có **≥ 2 điểm xoay** và quãng nào quá 25 giây không có lý do xem tiếp không?
9. **Gài – trả** có đổi nghĩa thật không, hay chỉ lặp lại?
10. Có câu nào **giảng bài học giữa phim** hoặc sáo rỗng không?
11. **BƯỚC NHỎ** có làm được trong 1 phút / 1 giờ, xuất hiện đúng 1 lần ở cuối không? **BÀI HỌC** có kiểm chứng / bàn luận được không?
12. Mọi **trích dẫn, khái niệm, con số** đều có nguồn thật đã kiểm chưa? Kết có **trung thực** (không hoàn hảo) và câu cuối có ấm, ngắn không?
