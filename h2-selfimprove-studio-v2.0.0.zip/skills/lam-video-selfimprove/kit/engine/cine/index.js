// index.js — engine cinematic (2.5D Three.js) cho player.js: shot { kind: '3d', engine: 'cine', init(C, info) -> { stage }, draw(st, lt, info, C), overlay(g, lt, info, st) }
// stage = { scene, camera, cam (trang thai may tu camera.js), rig (lightRig), post: {...} }. render() goi hau ky va tra canvas WebGL.
import * as THREE from 'three';
import { E } from '../core.js';
import { Post } from './post.js';
import { applyCam } from './camera.js';
import { col } from './lighting.js';
export * from './timeline.js';
export * from './camera.js';
export * from './lighting.js';
export { THREE };

let R = null, P = null;
export function renderer(w, h) {
  if (!R) {
    const c = document.createElement('canvas');
    R = new THREE.WebGLRenderer({ canvas: c, antialias: false, preserveDrawingBuffer: true, alpha: false, powerPreference: 'high-performance' });
    R.toneMapping = THREE.NoToneMapping; R.outputColorSpace = THREE.SRGBColorSpace;
    R.shadowMap.enabled = true; R.shadowMap.type = THREE.PCFSoftShadowMap;
    P = new Post(R);
  }
  if (R.domElement.width !== w || R.domElement.height !== h) R.setSize(w, h, false);
  P.size(w, h);
  return R;
}

export function stage(o = {}) {
  const scene = new THREE.Scene(), camera = new THREE.PerspectiveCamera(34, E.W / E.H, 0.05, 200);
  return { scene, camera, cam: null, rig: null, post: {}, ...o };
}

// ve 1 khung: dat may theo st.cam (neu co), cap nhat anh sang theo t, hau ky
export function render(st, w, h) {
  const r = renderer(w, h);
  if (st.cam) applyCam(st.camera, st.cam, st.gt ?? 0);
  const rp = st.rig ? st.rig.post : {}, cp = st.cam || {};
  P.render(st.scene, st.camera, { exposure: st.rig ? st.rig.exposure : 1, ...rp, focus: cp.focus, aperture: cp.aperture ?? 0, frame: E.frame, quality: E.PX < 0.4 ? 'low' : 'high', ...st.post });
  return r.domElement;
}

export function dispose(st) {
  st.scene.traverse((o) => { o.geometry?.dispose?.(); if (o.material) [].concat(o.material).forEach((m) => { if (m.map && !m.map.userData?.shared) m.map.dispose(); m.dispose?.(); }); });
}

// ---------- vat lieu kieu 2.5D MINH HOA (nhu 2 phim tham khao): mau to phang theo bac, khong phan chieu / bong loang, khong vat lieu that.
// Phan "3D" chi la: may di chuyen, nhoe theo chieu sau, anh sang co huong + bong do.
// look: 'toon' (mac dinh: nhan vat, do vat — 2–3 bac sang toi ro rang) | 'soft' (tuong / san / tran: khuech tan Lambert, giu vung sang mem cua den)
//       | 'basic' (khong nhan anh sang: man hinh, troi, chu). bands: so bac (2–4), shadow: do sang bac toi nhat (0..1)
const _bands = new Map();
export function bands(n = 3, shadow = 0.42) {
  const k = n + ':' + shadow; if (_bands.has(k)) return _bands.get(k);
  const d = new Uint8Array(n); for (let i = 0; i < n; i++) d[i] = Math.round(255 * (shadow + (1 - shadow) * (n === 1 ? 1 : i / (n - 1))));
  const t = new THREE.DataTexture(d, n, 1, THREE.RedFormat); t.minFilter = t.magFilter = THREE.NearestFilter; t.generateMipmaps = false; t.needsUpdate = true; t.userData.shared = true;
  _bands.set(k, t); return t;
}
export function mat(c, o = {}) {
  // co map (texture da ve dung mau) thi mau goc = trang, tranh nhan mau 2 lan (toi gap doi)
  const look = o.look || 'toon', base = { color: o.map ? new THREE.Color(1, 1, 1) : col(c), side: o.side ?? THREE.FrontSide, map: o.map || null };
  if (look === 'basic') return new THREE.MeshBasicMaterial({ ...base, fog: o.fog ?? true });
  if (look === 'soft') return new THREE.MeshPhysicalMaterial({ ...base, roughness: 1, metalness: 0, specularIntensity: 0, emissive: o.emissive ? col(o.emissive) : 0x000000 });   // chi khuech tan (tat han phan chieu)
  return new THREE.MeshToonMaterial({ ...base, gradientMap: bands(o.bands ?? 3, o.shadow ?? 0.42), emissive: o.emissive ? col(o.emissive) : 0x000000 });
}
// net vien khoi (inverted hull): ban sao mat sau day ra theo phap tuyen `w` met -> duong vien deu quanh do vat, nhu net minh hoa.
// Dung cho do vat; nhan vat toi dung vien sang (rimMat) thay vi net toi.
const _olm = new Map();
export function outline(mesh, color = '#07080c', w = 0.008) {
  const k = color + w; let m = _olm.get(k);
  if (!m) {
    m = new THREE.MeshBasicMaterial({ color: col(color), side: THREE.BackSide });
    m.onBeforeCompile = (s) => { s.vertexShader = s.vertexShader.replace('#include <begin_vertex>', `vec3 transformed = vec3(position) + normalize(normal) * ${w.toFixed(4)};`); };
    m.customProgramCacheKey = () => 'ol' + w; _olm.set(k, m);
  }
  const h = new THREE.Mesh(mesh.geometry, m); h.name = 'outline'; h.castShadow = false; h.receiveShadow = false; mesh.add(h); return h;
}
