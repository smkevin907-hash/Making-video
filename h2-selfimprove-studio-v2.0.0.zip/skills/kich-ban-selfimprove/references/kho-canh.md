# Kho cảnh của bộ dựng (sinh tự động)

Sinh bằng `python tools/phim.py --kho` từ mã bộ dựng `packs/dem` (plugin 1.10.0). Đừng sửa tay: bộ dựng đổi thì chạy lại lệnh. `--dry-run` luôn kiểm theo đúng bản đang cài.

Cách ghi trong file 01: `[B07] 5s | CẢNH: <mô tả cho người đọc> | NỀN: … | AI: … | ĐỘNG TÁC: … | MÁY: … | HUD | NHẠC | SFX`. Cột trái là chữ ghi được (tiếng Việt hoặc mã), cột giữa là mã bộ dựng nhận.

## 1. NỀN — bối cảnh

| Ghi | Mã | Trông thế nào | Chi tiết ghi sau dấu phẩy |
|---|---|---|---|
| màn đen, nền đen | `black` | nền đen, chữ to giữa màn |  |
| khoảng tối có đèn rọi, khoảng tối, đèn rọi, khoảng trống | `void` | khoảng tối, đèn rọi từ trên xuống |  |
| phòng ngủ, giường | `bedroom` | giường, tủ đầu giường có đồng hồ LED, cửa sổ | đêm trăng / bình minh / mưa / ngày / tối om; đồng hồ 5:00 (kêu, nhấp nháy); lịch tháng oct tô 12; đèn bàn; laptop; bàn học; cửa phòng |
| thành phố, đường phố, đường chạy | `city` | nhà cao tầng, đường, đèn đường | hoàng hôn / đêm / bình minh / ngày; chim bay |
| phố mưa, trạm xe buýt, trạm xe, phố | `street` | phố mưa: đèn đường, trạm xe buýt có ghế | cửa neon; không mưa; không trạm xe |
| hành lang tủ đồ, tủ đồ, hành lang | `lockers` | hành lang tủ đồ trường học, bảng ghim giấy note |  |
| lớp học, lớp | `classroom` | bảng đen có chữ, cửa sổ, bàn học | bảng: <chữ> |
| sân bóng rổ, sân bóng | `court` | sân bóng rổ hoàng hôn: rổ, ghế băng, hàng rào |  |
| quán cà phê, cà phê, quán | `cafe` | quán cà phê: cửa kính thấy mưa và phố đêm, đèn treo, 1 bàn, chậu cây (không có ghế) |  |
| phòng tập | `gym` | bao cát đỏ (lõm khi trúng đấm), đèn rọi | tạ; không bao cát |
| cầu thang | `stairs` | cầu thang 9 bậc, ánh sáng trên đỉnh |  |
| đồi hoàng hôn, đỉnh đồi, đồi, núi | `hill` | đồi hoàng hôn, dãy núi mềm |  |
| gương phòng tắm, phòng tắm, gương | `mirror` | gương oval trên bệ | gương nứt |
| phòng khách | `sofa` | phòng khách tối có sofa | cửa sổ; đèn cây |
| bếp đêm, bếp | `kitchen` | bếp đêm: tủ lạnh, kệ bếp, cửa sổ | đèn bếp |
| cửa mở hắt sáng, khung cửa, cửa ra vào, cửa | `doorway` | khung cửa mở hắt sáng | cửa đóng / cửa hé |

## 2. NỀN — mẫu cận cảnh

| Ghi | Mã | Chi tiết |
|---|---|---|
| cận điện thoại, màn hình điện thoại, điện thoại | `phone` | cận điện thoại 2 tay cầm. Chi tiết: feed: mì, xe, burger… · video · chat (dòng @) · email · màn khoá (dòng @ = thông báo) · đếm ngày (số lấy từ HUD) · màn tắt · nền <bối cảnh> |
| cận đồng hồ, đồng hồ | `clock` | cận đồng hồ báo thức LED. Chi tiết: 11:59 -> 12:00, kêu, nhấp nháy |
| cận lịch, lịch | `calendar` | cận lịch to. Chi tiết: tháng nov, 0 tới 24, tô màu (mặc định gạch X), xoá về 0 |
| cận mặt | `face` | cận mặt từ ngực lên (ai, biểu cảm lấy từ AI). Chi tiết: nền <bối cảnh> |
| sổ tay | `note` | sổ tay, tay viết chữ (dòng chữ của cảnh) |
| đồ thị, biểu đồ | `graph` | đồ thị cảm xúc vẽ dần (kiểu DOPAMINE). Chi tiết: sụp đổ (mặc định) / nhiều đỉnh / đi lên chậm / phẳng; nhãn "<chữ>" |

Màn hình điện thoại (`screen`): `chat`, `counter`, `email`, `feed`, `lock`, `off`, `reel`. Ảnh bài đăng feed: mì (`ramen`), ramen (`ramen`), xe (`car`), ô tô (`car`), burger (`burger`), hamburger (`burger`), pizza (`pizza`), giày (`sneakers`), chó (`dog`), mèo (`cat`), biển (`beach`), núi (`mountain`), hoàng hôn (`sunset`), tạ (`gym`), gym (`gym`), đồng hồ đeo tay (`watch`), tiền (`money`), game (`game`), cà phê (`coffee`), thành phố (`city`), tiệc (`party`), selfie (`selfie`), cô gái (`girl`), gái (`girl`), donut (`donut`), bánh kem (`cake`).

## 3. AI — nhân vật

Mỗi người 1 cụm, cách nhau `;`: `preset[@x | @mốc] tư thế, biểu cảm, cầm đồ, chuyển động`. `x`: 0..1 theo bề ngang khung (0.5 = giữa). `cậu` / `nhân vật` = preset ghi ở dòng `NHÂN VẬT:` đầu file (mặc định `hero`). `bạn bè` = 2 người (`friend`, `friend2`).

| Ghi | Mã | Là ai |
|---|---|---|
| cậu trần | `hero` | cậu trai đầu tròn màu kem (trần) |
| cậu băng đô, băng đô | `band` | người hùng quấn băng đô màu nhấn (khi tập) |
| cậu hoodie | `hoodie` | người hùng mặc hoodie xám, mũ hạ sau cổ |
| cậu trùm mũ, trùm mũ | `hooded` | hoodie trùm mũ lên đầu (đêm, nghiện) |
| bạn mũ vàng, bạn 1, bạn | `friend` | bạn mũ lưỡi trai vàng |
| bạn mũ xanh, bạn 2 | `friend2` | bạn mũ xanh |
| bạn mũ đỏ, bạn 3 | `friend3` | bạn mũ đỏ |
| cô gái | `girl` | cô gái tóc bob khăn vàng |
| mẹ | `mom` | mẹ (búi tóc) |
| bố | `dad` | bố (đeo kính) |
| em nhỏ, em bé, đứa trẻ | `kid` | em nhỏ |
| bóng mờ, hồi tưởng | `ghost` | bóng mờ (hồi tưởng, bản thân cũ) |
| bóng đen, cám dỗ | `voice` | bóng đen cám dỗ (mắt đỏ, khói đỏ) |

**Mốc đặt người (`@`)** — chỉ dùng đúng bối cảnh:

| Ghi | Mã | Bối cảnh |
|---|---|---|
| mép giường | `bed.sit` | `bedroom` |
| đầu giường | `bed.head` | `bedroom` |
| ghế bàn, bàn học | `desk.seat` | `bedroom` |
| ghế xe buýt, trạm xe | `bus.seat` | `street` |
| cửa neon | `neon` | `street` |
| ghế băng, ghế sân | `bench` | `court` |
| bàn trái | `table.left` | `cafe` |
| bàn phải | `table.right` | `cafe` |
| đỉnh đồi | `top` | `hill` |
| gương | `mirror` | `mirror` |
| trong gương | `mirror.in` | `mirror` |
| ghế sofa, sofa | `sofa.seat` | `sofa` |
| sofa trái | `sofa.left` | `sofa` |
| sofa phải | `sofa.right` | `sofa` |
| cửa | `door` | `doorway` |
| bậc N | `step:N` (0–8; bóng đen từ bậc 3 trở lên nên ghi `cao 0.36` để không mất đầu) | `stairs` |

Ngồi chỉ đẹp ở mốc có ghế: mép giường, ghế bàn (phòng ngủ, tự bật bàn học), sofa, ghế xe buýt, ghế băng sân bóng. Quán cà phê chưa có ghế (ngồi sẽ lơ lửng): đứng @bàn trái / @bàn phải.

## 4. Tư thế tĩnh (đứng yên ở tư thế đó cả cảnh, chỉ thở / chớp mắt)

| Ghi | Mã |
|---|---|
| đứng | `stand` |
| đứng thả lỏng, thả lỏng | `relaxed` |
| cúi gục, đứng gục, gục | `slump` |
| cầm điện thoại, nhìn điện thoại, lướt điện thoại | `phone` |
| với tay, vươn tay | `reach` |
| chỉ tay, chỉ | `point` |
| vẫy tay, vẫy | `wave` |
| giơ hai tay, ăn mừng, reo | `cheer` |
| siết nắm đấm, nắm đấm | `fist` |
| ôm đầu | `headhold` |
| úp mặt, ôm mặt | `facepalm` |
| khoanh tay | `arms` |
| nhún vai | `shrug` |
| ôm | `hug` |
| thủ thế | `guard` |
| đấm | `punch` |
| nâng tạ | `lift` |
| ngồi | `sit` |
| ngồi cầm điện thoại, ngồi lướt điện thoại | `sitphone` |
| ngồi bàn, ngồi viết, ngồi học | `sitdesk` |
| ngồi gục, ngồi cúi đầu | `sitsad` |
| ngồi ôm gối, ngồi bó gối, ôm gối, bó gối | `knees` |
| quỳ | `kneel` |
| khom, ngồi xổm, cúi người | `crouch` |
| leo | `climb` |
| dang tay | `open` |
| cầm ô, che ô | `umbrella` |
| ôm đồ, bê đồ | `carry` |
| chống gối | `pant` |
| vung tay | `throw` |
| buông tay | `release` |
| chồm người, ngồi chồm | `sitfwd` |
| nằm sàn, nằm dưới sàn | `lie` |

Cầm đồ: cầm điện thoại (`phone`); cầm ô (`umbrella`); cầm sách, ôm sách (`book`); cầm bóng, ôm bóng (`ball`); đeo cặp, đeo balo, cầm cặp (`bag`); cầm cốc, cầm ly, cầm cà phê (`cup`).
Chi tiết thêm: mắt đỏ gân máu; mắt đỏ; gân máu; nước mắt; mồ hôi; ánh màn hình; phía sau; đứng sau; trong gương; nhìn trái; nhìn phải; quay trái; quay phải; giữ chỗ; mờ dần. Người nằm trong chăn (chỉ NỀN phòng ngủ): nằm trong chăn, ngủ trong chăn, nằm ngủ, nằm.

## 5. Biểu cảm

| Ghi | Mã |
|---|---|
| bình thường | `neutral` |
| mệt | `tired` |
| buồn ngủ | `sleepy` |
| ngủ | `sleep` |
| buồn | `sad` |
| khóc | `cry` |
| lo lắng, lo | `worried` |
| sợ | `scared` |
| sốc | `shock` |
| tức giận, giận | `angry` |
| quyết tâm | `determined` |
| gồng sức, gồng | `effort` |
| mỉm cười, cười | `smile` |
| cười đùa, vui | `happy` |
| cười nhếch | `smirk` |
| trống rỗng | `empty` |
| có lỗi, tội lỗi | `guilty` |
| thức trắng | `bloodshot` |
| ám ảnh | `haunted` |
| cười gian | `grin` |
| hy vọng | `hopeful` |
| nhẹ nhõm | `relieved` |
| tự hào | `proud` |
| xấu hổ, ngượng | `embarrassed` |
| ghê | `disgusted` |
| bực | `annoyed` |
| nghi ngờ | `skeptical` |
| kiệt sức | `exhausted` |
| ngáp | `yawn` |
| thẫn thờ | `dazed` |
| hoảng loạn, hoảng | `panic` |
| khóc nấc | `sob` |
| hét | `shout` |
| suy nghĩ | `thinking` |
| bị cám dỗ, thèm | `tempted` |
| nghiến răng | `grit` |
| cô đơn | `lonely` |

## 6. Động tác có chuyển động (bộ dựng diễn thật)

Ghi trong `ĐỘNG TÁC:` (`[ai] <động tác> <giây>s`, cách nhau `;`; không ghi ai = nhân vật chính) hoặc ngay trong cụm AI (chuyển động bắt đầu từ đầu cảnh).

| Ghi | Bộ dựng làm gì | Mã |
|---|---|---|
| đi tới 0.7 [từ 1s] [trong 3s] | đi bộ, chân bám đất, tự quay theo hướng đi, dừng hai chân khép | `walk` |
| chạy tới 0.85 | chạy: đổ người, vệt tốc độ, bụi chân | `run` |
| đi lùi tới 0.3 | đi lùi, mặt giữ hướng | `walk.back` |
| đi ngang / đi qua | đi băng ngang khung từ mép này sang mép kia | `walk` |
| chạy tại chỗ | chạy tại chỗ, đường và nhà trôi (hợp NỀN thành phố) | `run: 1.6` + `scroll` |
| đứng dậy | đang ngồi: chồm người rồi đứng dậy | `act standUp` |
| ngồi xuống | ngồi xuống | `act sitDown` |
| quỵ xuống | gục người → ôm đầu → quỵ gối (~1,5 giây) | `act collapse` |
| ngã | đổ sập xuống sàn, nảy nhẹ, nằm yên | `act fall` |
| ném điện thoại | vung tay ném, điện thoại bay vòng cung, rơi, tắt màn hình (đang ngồi thì tự đứng dậy trước) | `act throwPhone` |
| bỏ đi / chạy đi | quay lưng rồi đi / chạy ra khỏi khung | `act walkAway` |
| thở dốc | chống tay lên gối thở dốc rồi đứng thẳng | `act pant` |
| đấm liên tục / đấm 4 cú | thủ thế rồi đấm từng cú; bao cát lõm, chớp sáng; số đếm khi ≥ 3 cú | `poseAt guard↔punch` |
| quay trái / quay phải / quay lại | quay người trong 0,3 giây | `facingAt` |
| <tư thế> 2s (vd: ôm đầu 2s) | đổi sang tư thế đó, chuyển dần có lấy đà | `poseAt` |
| <biểu cảm> 2s (vd: khóc 2s) | đổi biểu cảm, chớp mắt đúng lúc đổi | `faceAt` |
| hiện 1s / biến mất 4s | xuất hiện / mờ đi | `at` / `out` |
| bóng đen vỡ 3s | nứt, vỡ thành mảnh, chữ cám dỗ vỡ từng chữ (SFX `vanish_burst` đúng giây) | `vanish burst` |
| bóng đen tan tro 3s | rã dần từ chân thành tro bay theo gió (SFX `vanish_ash`) | `vanish ash` |
| ngồi dậy 1.5s (người nằm giường) | thân nhổm dậy, chăn tuột, trượt ra mép giường | `bed.up` |
| với tay 1s (người nằm giường) | tay chui ra khỏi chăn với tắt đồng hồ | `bed.arm` |
| trở mình 2s / nằm ngửa 3s (người nằm giường) | nằm nghiêng co gối ↔ nằm ngửa | `bed.rollAt` |

Trong cụm AI, `A → B` đổi tư thế / biểu cảm giữa cảnh (vd `đứng → ôm đầu 2s`, `lo → khóc`).

## 7. Chưa hỗ trợ → cách thay

Bộ dựng chưa có chuyển động này. Ghi vào `ĐỘNG TÁC` / `AI` sẽ bị `--dry-run` báo LỖI; ghi trong `CẢNH` thì bị bỏ qua.

| Động tác | Thay bằng |
|---|---|
| đẩy cửa / mở cửa | cắt 2 cảnh: NỀN: cửa, cửa đóng → NỀN: cửa (mở sẵn, hắt sáng), người đứng @cửa; SFX door_open |
| đóng cửa / đóng sập | cắt sang cảnh NỀN: cửa, cửa đóng + SFX door_open / impact_heavy |
| nhảy | tư thế giơ hai tay (cheer) + MÁY: rung, hoặc cắt cảnh |
| hít đất / chống đẩy / gập bụng / plank | phòng tập: ĐỘNG TÁC đấm liên tục (có số đếm), hoặc tư thế khom + bộ đếm tăng |
| nâng tạ (liên tục / \d+ lần) / tập tạ / đẩy tạ | chưa vẽ thanh tạ trên tay khi nâng: dùng tư thế nâng tạ tĩnh + NỀN: phòng tập, tạ; cần số đếm thì đấm liên tục |
| leo cầu thang / bước lên cầu thang / đi lên cầu thang | cầu thang: cắt 3 cảnh @step:1 → @step:4 → @step:7, tư thế leo |
| ôm chầm / chạy tới ôm / lao vào ôm | 2 người đi tới gần nhau (đi tới x) rồi ĐỘNG TÁC: ôm <giây> |
| đánh nhau / xô đẩy / đẩy ngã | tư thế chỉ tay / khoanh tay + cắt cảnh; ngã: ĐỘNG TÁC ngã |
| ăn / uống / nhai | đứng / ngồi + cầm cốc; ăn uống vô độ: cận điện thoại feed ảnh đồ ăn |
| lái xe / đạp xe / xe máy | thành phố + chạy tại chỗ (đường cuộn), hoặc cận điện thoại ảnh xe |
| gõ phím / đánh máy | ngồi bàn + NỀN: phòng ngủ, laptop |
| viết | NỀN: sổ tay (tay viết chữ) hoặc ngồi bàn |
| lắc đầu / gật đầu | đổi biểu cảm theo giây (ĐỘNG TÁC: buồn 2s) hoặc quay người |
| đánh răng / đi tắm / đang tắm / tắm rửa / rửa mặt | NỀN: gương, đứng trước gương, đổi biểu cảm |
| gọi điện / nghe điện thoại / áp tai | tư thế cầm điện thoại + cắt sang cận điện thoại chat |
| cầm tay nhau / nắm tay | 2 người đứng sát (@x cách 0.08), tư thế đứng / ôm |
| vò giấy / xé giấy / vứt rác | ném điện thoại (throwPhone) hoặc cắt cảnh |
| ngủ gật | biểu cảm buồn ngủ → ngủ theo giây (ĐỘNG TÁC: ngủ 2s) |
| mở tủ lạnh | NỀN: bếp, đèn bếp, đứng |
| nhìn đồng hồ đeo tay | NỀN: cận đồng hồ |

## 8. MÁY

| Ghi | Làm gì |
|---|---|
| đẩy chậm | đẩy vào người chính (zoom 1 → 1,15) |
| đẩy chậm vào mặt | đẩy vào mặt người chính (→ 1,4; cận mặt → 1,2) |
| đẩy nhanh vào mặt | đẩy vào mặt trong ~1 giây |
| kéo ra | từ gần lùi ra toàn cảnh |
| lia trái / lia phải | lia ngang |
| bám theo | bám người chính đang đi / chạy |
| rung 2s / rung mạnh 2s | rung máy ở giây đó |
| cầm tay | rung tay rõ (hoảng loạn) |
| đứng yên / góc rộng | không đẩy |

Ghi `<cách> <giây>s` để bắt đầu ở giây đó (vd `đẩy chậm vào mặt 2s`). Nhiều cách cách nhau dấu phẩy.

**Chế độ cinematic (2.0)** — thêm cỡ khung / góc máy / chuyển động 3D cho góc chính của cảnh (không ghi: bộ dựng tự chia 1–3 góc và tự đổi cỡ khung giữa các cảnh):

| Ghi | Làm gì |
|---|---|
| toàn cảnh rộng / toàn thân / trung cảnh / cận trung / cận cảnh / đặc tả | cỡ khung |
| qua vai / góc thấp / góc cao / từ trên xuống / ngang mắt / pov | góc máy |
| dolly vào / dolly ra / trượt ngang / xoay quanh / nâng máy / nghiêng máy / đẩy vào cận | chuyển động máy |

## 8b. CHUYỂN (2.0)

`CHUYỂN: <kiểu> vì <lý do>` — kiểu chuyển vào cảnh này: `cắt sốc`, `cắt`, `match cut`, `khớp hình`, `iris`, `vòng tròn`, `lia nhanh`, `zoom vào đồ vật`, `zoom vào`, `qua màn đen`, `qua đen`, `mờ đen`, `chớp trắng`. Không ghi: chế độ cinematic tự chọn theo nội dung (vào điện thoại = zoom vào đồ vật, rời điện thoại = iris, sang màn đen = qua đen, trước cú sụp = cắt sốc, cùng bố cục = match cut), legacy = cắt.

## 9. NHẠC, SFX

NHẠC: `sad`, `dark`, `rise`, `resolve`, `hope`, `none` (`tension` … chỉ có khi cài đầy đủ).

SFX: `alarm_beep`, `alarm_long`, `boom_deep`, `breath_in`, `cash_register`, `clock_tick`, `crowd_cheer`, `ding_high`, `ding_soft`, `door_open`, `downer`, `flash_hit`, `footsteps`, `glass_shatter`, `glitch`, `heartbeat`, `impact_heavy`, `impact_light`, `impact_punch`, `msg_sent`, `notif_msg`, `page_flip`, `phone_ring`, `phone_vibrate`, `pop`, `pop_low`, `punch_bag`, `rain_loop`, `riser_2s`, `riser_4s`, `slowmo_ring`, `sting_low`, `tempt_swell`, `tempt_whisper`, `terminal_blip`, `terminal_typing`, `thud_soft`, `tick`, `ting_idea`, `type_key`, `typing_2s`, `ui_click`, `vanish_ash`, `vanish_burst`, `whoosh_fast`, `whoosh_long`, `whoosh_mid`, `whoosh_reverse`, `whoosh_tiny`. Ghi `tên@giây`.

## Đối chiếu

- Mã chỉ ghi được bằng tên mã (chưa có tên tiếng Việt): không có.
- Tên tiếng Việt trỏ tới mã bộ dựng KHÔNG còn: không có.
- Đối chiếu `lam-video-selfimprove/references/mau-canh.md`:
  - `pose`: khớp
  - `face`: khớp
  - `set`: khớp
  - `who`: khớp
  - `act`: khớp
