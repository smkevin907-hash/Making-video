// camera.js — may quay cinematic: rig { pos, target, fov, roll, focus, aperture, hand } + thu vien chuyen dong + bo giai co khung.
// Don vi: met, truc y huong len. Chu the (subject): { at: [x, y, z] (chan), h: cao (m, mac dinh 1.7), face: huong mat (rad, 0 = nhin ve +z), head: [x, y, z] (tuy chon) }
//   hoac do vat: { at: [x, y, z] (tam), h: cao, prop: true }.
// shotCam(lt, spec) -> trang thai may o giay lt cua shot. Moi bien deu di bang easing (mac dinh easeInOutCubic), khong chay thang deu.
import * as THREE from 'three';
import { E, clamp, lerp } from '../core.js';
import { easeOf, fbm1 } from './timeline.js';

// chieu cao nhin thay tai chu the (m) theo co khung + ong kinh mac dinh (do): canh cang can, ong cang dai
export const SIZES = {
  ews: { v: 16, fov: 42 }, ws: { v: 5.2, fov: 40 }, full: { v: 2.5, fov: 36 }, ms: { v: 1.3, fov: 34 },
  mcu: { v: 0.85, fov: 32 }, cu: { v: 0.52, fov: 30 }, ecu: { v: 0.26, fov: 26 },
};
const ALIAS = { wide: 'ws', extreme: 'ews', medium: 'ms', close: 'cu', closeup: 'cu', insert: 'ecu' };
export const sizeOf = (s) => SIZES[ALIAS[s] || s] ? (ALIAS[s] || s) : 'ms';
// goc nhin: do cao goc (rad, + = may tren cao nhin xuong)
const ELEV = { eye: 0.04, low: -0.3, high: 0.45, top: 1.3, dutch: 0.04 };
// do mo ong (do nhoe hau / tien canh) theo co khung: canh rong it nhoe, canh can nhoe nhieu
const APER = { ews: 0.25, ws: 0.45, full: 0.6, ms: 0.85, mcu: 1.05, cu: 1.25, ecu: 1.45 };

const V = (a) => new THREE.Vector3(a[0], a[1], a[2]);
const arr = (v) => [v.x, v.y, v.z];
const mixA = (a, b, k) => a.map((x, i) => lerp(x, b[i], k));

// diem nhin tren chu the theo co khung: rong -> giua nguoi, can -> mat
export function lookPoint(sub, size) {
  const h = sub.h ?? 1.7, at = sub.at || [0, 0, 0];
  if (sub.prop) return [at[0], at[1], at[2]];
  const head = sub.head || [at[0], at[1] + h * 0.9, at[2]];
  const k = { ews: 0.5, ws: 0.52, full: 0.55, ms: 0.74, mcu: 0.84, cu: 1, ecu: 1 }[size] ?? 0.7;
  return k >= 1 ? head.slice() : [lerp(at[0], head[0], k), at[1] + (head[1] - at[1]) * k, lerp(at[2], head[2], k)];
}

// dat may theo co khung + goc: tra { pos, target, fov }
export function frame(sub, o = {}) {
  const size = sizeOf(o.size || 'ms'), S = SIZES[size], fov = o.fov ?? S.fov;
  const target = o.target ? o.target.slice() : lookPoint(sub, size);
  if (o.dy) target[1] += o.dy;
  const d = (o.dist ?? S.v / 2 / Math.tan((fov * Math.PI / 180) / 2)) * (o.distK ?? 1);
  const elev = o.elev ?? ELEV[o.angle || 'eye'] ?? ELEV.eye;
  const yaw = (sub.face ?? 0) + (o.yaw ?? 0.42 * (o.side ?? 1));   // mac dinh lech 3/4 so voi huong mat
  const ch = Math.cos(elev) * d;
  let pos = [target[0] + Math.sin(yaw) * ch, target[1] + Math.sin(elev) * d, target[2] + Math.cos(yaw) * ch];
  pos[1] = Math.max(o.minY ?? 0.18, pos[1]);
  if (o.lateral) { const rx = Math.cos(yaw), rz = -Math.sin(yaw); pos = [pos[0] + rx * o.lateral, pos[1], pos[2] + rz * o.lateral]; }
  // trong phong (bounds): may khong duoc ra sau tuong -> lui may vao trong va mo rong ong kinh de giu co khung
  let f = fov;
  if (o.bounds) { const k = fitIn(target, pos, o.bounds); if (k < 1) { pos = mixA(target, pos, k); if (o.fov === undefined) f = Math.min(78, 2 * Math.atan(S.v / 2 / (d * k)) * 180 / Math.PI); } }
  return { pos, target, fov: f, size };
}
// ti le k (0..1) doan target -> pos con nam trong hop phong (le 0.18 m). bounds: { x0, x1, z0, z1, H }
function fitIn(a, b, B, m = 0.18) {
  let k = 1; const lo = [B.x0 + m, 0.12, B.z0 + m], hi = [B.x1 - m, (B.H ?? 3) - m, B.z1 - m];
  for (let i = 0; i < 3; i++) { const d = b[i] - a[i]; if (d > 1e-6 && b[i] > hi[i]) k = Math.min(k, (hi[i] - a[i]) / d); if (d < -1e-6 && b[i] < lo[i]) k = Math.min(k, (lo[i] - a[i]) / d); }
  return clamp(k, 0.05, 1);
}

// qua vai: may sau vai nguoi `over`, nhin ve mat `sub`. Vai / dau nguoi `over` nam o tien canh, tu mo
export function overShoulder(sub, over, o = {}) {
  const tgt = lookPoint(sub, 'mcu'), head = over.head || [over.at[0], over.at[1] + (over.h ?? 1.7) * 0.9, over.at[2]];
  const dir = V(tgt).sub(V(head)); dir.y = 0; dir.normalize();
  const side = new THREE.Vector3(dir.z, 0, -dir.x).multiplyScalar(o.side ?? 1);
  const p = V(head).addScaledVector(dir, -(o.back ?? 0.6)).addScaledVector(side, o.offset ?? 0.32); p.y += o.up ?? 0.06;
  // mix: diem nhin lech ve phia vai nguoi `over` -> vai / dau tien canh nam 1/3 mot ben, chu the nam 1/3 ben kia (khong che giua khung)
  const k = o.mix ?? 0; const aim = k ? mixA(tgt, head, k) : tgt;
  return { pos: arr(p), target: aim, fov: o.fov ?? 30, size: 'mcu' };
}
// POV: mat nguoi `who` nhin xuong tay (dien thoai, poster)
export function pov(sub, o = {}) {
  const head = sub.head || [sub.at[0], sub.at[1] + (sub.h ?? 1.7) * 0.9, sub.at[2]], f = sub.face ?? 0;
  const look = o.look || [head[0] + Math.sin(f) * 0.45, head[1] - 0.35, head[2] + Math.cos(f) * 0.45];
  return { pos: [head[0], head[1] + 0.02, head[2]], target: look, fov: o.fov ?? 44, size: 'cu' };
}

// ---------- thu vien chuyen dong: tu dat (A) -> diem den (B)
// amt: muc do (mac dinh 1). Tat ca deu tinh tu `base` = frame(...) cua shot
const MOVES = {
  hold: (b) => [b, b],
  dollyIn: (b, s, a) => [push(b, 1 + 0.16 * a), b],
  dollyOut: (b, s, a) => [b, push(b, 1 + 0.18 * a)],
  truck: (b, s, a) => [shift(b, -0.1 * a * dist(b)), shift(b, 0.1 * a * dist(b))],
  pan: (b, s, a) => [turn(b, -0.1 * a, 0), turn(b, 0.1 * a, 0)],
  tilt: (b, s, a) => [turn(b, 0, -0.08 * a), b],
  orbit: (b, s, a) => [orbitBy(b, -0.13 * a), orbitBy(b, 0.13 * a)],
  pushToCloseUp: (b, s, a, spec) => [frame(s, { ...spec, size: spec.from || 'ms' }), frame(s, { ...spec, size: spec.size === 'ms' ? 'cu' : spec.size })],
  pullBack: (b, s, a, spec) => [frame(s, { ...spec, size: spec.from || 'cu' }), b],
  lowAngleRise: (b, s, a, spec) => [frame(s, { ...spec, elev: -0.38, distK: 1.12 }), frame(s, { ...spec, elev: 0.02 })],
  overShoulder: (b, s, a) => [shift(b, -0.05 * a * dist(b)), shift(b, 0.03 * a * dist(b))],
  povHands: (b, s, a) => [shiftY(b, 0.03 * a), b],
};
export const MOVE_NAMES = Object.keys(MOVES);
const dist = (p) => V(p.pos).distanceTo(V(p.target));
function push(p, k) { const d = V(p.pos).sub(V(p.target)).multiplyScalar(k); return { ...p, pos: arr(V(p.target).add(d)) }; }
function shift(p, m) { const f = V(p.target).sub(V(p.pos)); f.y = 0; f.normalize(); const r = new THREE.Vector3(-f.z, 0, f.x).multiplyScalar(m); return { ...p, pos: arr(V(p.pos).add(r)), target: arr(V(p.target).add(r)) }; }
function shiftY(p, m) { return { ...p, pos: [p.pos[0], p.pos[1] + m, p.pos[2]], target: [p.target[0], p.target[1] + m, p.target[2]] }; }
function turn(p, yaw, pitch) {
  const d = V(p.target).sub(V(p.pos)); const r = d.length(); const sp = new THREE.Spherical().setFromVector3(d);
  sp.theta += yaw; sp.phi = clamp(sp.phi - pitch, 0.05, Math.PI - 0.05); sp.radius = r;
  return { ...p, target: arr(V(p.pos).add(new THREE.Vector3().setFromSpherical(sp))) };
}
function orbitBy(p, a) {
  const d = V(p.pos).sub(V(p.target)); d.applyAxisAngle(new THREE.Vector3(0, 1, 0), a);
  return { ...p, pos: arr(V(p.target).add(d)) };
}

// dang van toc: "settle" = chay o dau shot roi dung giu khung (kieu do duoc o 2 phim tham khao), "slow" = ca shot, "late" = giu roi moi chay
function moveK(lt, dur, spec) {
  const prof = spec.profile || (['pushToCloseUp', 'pullBack', 'lowAngleRise', 'truck', 'pan', 'tilt'].includes(spec.move) ? 'settle' : 'slow');
  const a0 = spec.at ?? 0, len = spec.len ?? (prof === 'settle' ? Math.min(dur * 0.62, Math.max(1.2, dur - 0.9)) : prof === 'late' ? dur * 0.55 : dur - a0);
  const start = prof === 'late' ? (spec.at ?? dur * 0.4) : a0;
  return easeOf(spec.ease || 'cubic')(clamp((lt - start) / Math.max(0.1, len)));
}

// trang thai may o giay lt. spec: { subject, size, angle, yaw, side, move, amt, from, profile, at, len, ease, over (qua vai), pov, hand, focusOn, aperture, roll, fov, keys }
// keys (tuy chon): [[giay, { pos, target, fov }], ...] -> bay theo moc (ghi de thu vien)
export function shotCam(lt, dur, spec) {
  const sub = spec.subject || { at: [0, 0, 0] };
  let A, B;
  if (spec.keys) {
    const ks = spec.keys; let i = 1; while (i < ks.length - 1 && lt > ks[i][0]) i++;
    const [t0, p0] = ks[i - 1], [t1, p1, e] = ks[Math.min(i, ks.length - 1)], k = easeOf(e || 'cubic')(clamp((lt - t0) / Math.max(1e-6, t1 - t0)));
    A = p0; B = p1; return finish(lt, spec, sub, { pos: mixA(A.pos, B.pos, k), target: mixA(A.target, B.target, k), fov: lerp(A.fov ?? 34, B.fov ?? A.fov ?? 34, k), size: B.size || A.size || 'ms' });
  }
  const base = spec.over ? overShoulder(sub, spec.over, spec) : spec.pov ? pov(sub, spec) : frame(sub, spec);
  const mv = MOVES[spec.move || 'hold'] || MOVES.hold;
  [A, B] = mv(base, sub, spec.amt ?? 1, spec);
  const k = moveK(lt, dur, spec);
  return finish(lt, spec, sub, { pos: mixA(A.pos, B.pos, k), target: mixA(A.target, B.target, k), fov: lerp(A.fov, B.fov, k), size: k < 0.5 ? A.size : B.size, k });
}
function finish(lt, spec, sub, p) {
  const size = sizeOf(p.size || 'ms');
  if (spec.bounds) { const B = spec.bounds, m = 0.12; p.pos = [clamp(p.pos[0], B.x0 + m, B.x1 - m), clamp(p.pos[1], 0.1, (B.H ?? 3) - m), clamp(p.pos[2], B.z0 + m, B.z1 - m)]; }
  const fp = spec.focusOn || lookPoint(sub, size === 'ws' || size === 'ews' ? 'full' : 'cu');
  const focus = spec.focus ?? V(p.pos).distanceTo(V(fp));
  return { ...p, size, roll: spec.roll ?? (spec.angle === 'dutch' ? 0.09 : 0), focus, aperture: spec.aperture ?? APER[size] ?? 0.8, hand: spec.hand ?? 0.35, seed: spec.seed ?? 1 };
}

// dat THREE.PerspectiveCamera theo trang thai; gt = giay toan phim (rung tay noi lien giua cac shot)
// hand: bien do % khung (0.2–0.6), tan so thap; 0 = may tinh (canh nang ne / tinh)
export function applyCam(cam, st, gt = 0) {
  cam.fov = st.fov; cam.aspect = E.W / E.H; cam.near = 0.05; cam.far = 200; cam.updateProjectionMatrix();
  cam.position.set(...st.pos); cam.up.set(0, 1, 0); cam.lookAt(...st.target);
  const amp = (st.hand || 0) / 100, fr = st.fov * Math.PI / 180, sd = st.seed || 1;
  if (amp > 0) { cam.rotateY(fbm1(gt * 0.42, sd) * amp * fr); cam.rotateX(fbm1(gt * 0.37, sd + 11) * amp * fr * 0.8); }
  const roll = (st.roll || 0) + (amp > 0 ? fbm1(gt * 0.25, sd + 23) * amp * 0.35 : 0);
  if (roll) cam.rotateZ(roll);
  cam.updateMatrixWorld(true);
  return cam;
}

// chieu diem 3D -> toa do logic (E.W x E.H) + do sau; vis = nam truoc may
const _v = new THREE.Vector3();
export function toScreen(p, cam) {
  _v.set(p[0], p[1], p[2]).project(cam);
  return { x: (_v.x * 0.5 + 0.5) * E.W, y: (-_v.y * 0.5 + 0.5) * E.H, z: _v.z, vis: _v.z > -1 && _v.z < 1 };
}
// hop bao 2D cua hop 3D (8 dinh) -> [x0, y0, x1, y1] logic
export function screenBox(min, max, cam) {
  let x0 = 1e9, y0 = 1e9, x1 = -1e9, y1 = -1e9;
  for (const x of [min[0], max[0]]) for (const y of [min[1], max[1]]) for (const z of [min[2], max[2]]) { const s = toScreen([x, y, z], cam); x0 = Math.min(x0, s.x); y0 = Math.min(y0, s.y); x1 = Math.max(x1, s.x); y1 = Math.max(y1, s.y); }
  return [x0, y0, x1, y1];
}
export function objBox(obj, cam) { const b = new THREE.Box3().setFromObject(obj); return screenBox(arr(b.min), arr(b.max), cam); }
