// pov.js — tay goc nhin thu nhat (POV): cang tay mac tay ao cua nhan vat chinh + ban tay toi vien sang.
// povPhone: tay trai cam dien thoai, ngon cai phai vuot dung nhip feed (chuan bi keo xuong -> vuot len -> nhac len).
// povMarker: tay cam but ve X len poster, di theo net dang ve.
import { THREE, mat, rimMat, fbm1 } from '/engine/cine/index.js';
import { clamp, lerp } from '/engine/core.js';
import { CAST3 } from './rig.js';
import { swipeAt } from './props.js';

const SKIN = '#15161c';
function hand(o = {}) {
  const skin = mat(SKIN, { shadow: 0.55 }), rim = rimMat(o.rim || '#a9c2ff', { strength: 0.5, power: 4 }), g = new THREE.Group();
  const add = (geo, x, y, z, rx = 0, rz = 0) => { const m = new THREE.Mesh(geo, skin); m.position.set(x, y, z); m.rotation.set(rx, 0, rz); m.castShadow = true; m.add(new THREE.Mesh(geo, rim)); g.add(m); return m; };
  const palm = add(new THREE.SphereGeometry(0.042, 16, 12), 0, 0, 0); palm.scale.set(1, 1.15, 0.55);
  const fingers = [-0.026, -0.009, 0.008, 0.025].map((x, i) => add(new THREE.CapsuleGeometry(0.011, 0.045 - Math.abs(i - 1.5) * 0.006, 4, 8), x, 0.06, 0.004));
  const thumb = add(new THREE.CapsuleGeometry(0.012, 0.04, 4, 8), 0.04, 0.012, 0.012, 0, -0.9);
  return { g, palm, fingers, thumb };
}
// cang tay: tu co tay `from` keo dai theo huong `dir` (ve phia may / mep duoi khung) -> ra ngoai khung, khong cat ngang hinh
function forearm(top, from, dir, len = 0.5, o = {}) {
  const geo = new THREE.CapsuleGeometry(0.036, len, 4, 12), m = new THREE.Mesh(geo, mat(top, { shadow: 0.5 })); m.castShadow = true;
  m.add(new THREE.Mesh(geo, rimMat(o.rim || '#a9c2ff', { strength: 0.18, power: 5.5 })));
  const d = new THREE.Vector3(...dir).normalize(); m.quaternion.setFromUnitVectors(new THREE.Vector3(0, 1, 0), d);
  m.position.set(from[0] + d.x * (len / 2 + 0.02), from[1] + d.y * (len / 2 + 0.02), from[2] + d.z * (len / 2 + 0.02)); return m;
}

// dien thoai cam tay o truoc may POV. ph = phoneMesh(...). Tra { group, update(lt) }
export function povPhone(ph, o = {}) {
  // outer: mau canh dat vi tri / huong; g (ben trong): tho + rung tay (chi lech nho quanh 0)
  const C = CAST3[o.who || 'hoodie'] || CAST3.hero, outer = new THREE.Group(), g = new THREE.Group(); outer.add(g);
  g.add(ph.group);
  // tay trai: om mep trai, ngon tay quap ra mat truoc
  const L = hand(o); L.g.position.set(-ph.w * 0.55, -ph.h * 0.12, -0.012); L.g.rotation.set(0, 0.5, -0.15); g.add(L.g);
  L.fingers.forEach((f, i) => { f.position.set(0.03 + i * 0.002, 0.03 - i * 0.022, 0.012); f.rotation.set(0, 0, -1.45); });
  // cang tay: tu co tay di xuong duoi va ve phia may (+z = phia mat nguoi xem) -> ra khoi khung o 2 goc duoi
  g.add(forearm(C.top || '#4a5878', [-ph.w * 0.62, -ph.h * 0.3, -0.03], [-0.35, -0.75, 0.55], 0.5, o));
  // tay phai: chi thay ngon cai + mot phan ban tay o mep phai duoi
  const Rh = hand(o); Rh.g.position.set(ph.w * 0.62, -ph.h * 0.42, -0.02); Rh.g.rotation.set(0.2, -0.5, 0.35); g.add(Rh.g);
  g.add(forearm(C.top || '#4a5878', [ph.w * 0.7, -ph.h * 0.55, -0.03], [0.35, -0.75, 0.55], 0.5, o));
  const thumbBase = Rh.thumb.position.clone();
  const update = (lt, gt) => {
    // ca 2 tay tho + rung rat nhe (cam tay that)
    g.position.y = Math.sin(lt * 2 * Math.PI / 3.8) * 0.002 + fbm1(gt * 0.6, 3) * 0.0015; g.rotation.z = fbm1(gt * 0.4, 5) * 0.012;
    if ((o.screen || 'feed') !== 'feed') return;
    const S = swipeAt(lt, o);
    // ngon cai: hold -> nghi tren man; prep -> cham va keo xuong; swipe -> vuot len; settle -> nhac ra
    let dy = 0, dz = 0.0, dx = 0;
    if (S.ph === 'hold') { dz = 0.012 * Math.min(1, S.k * 3); dy = -0.01; }
    else if (S.ph === 'prep') { dz = 0.012 * (1 - S.k); dy = -0.01 - 0.01 * S.k; }
    else if (S.ph === 'swipe') { dy = -0.02 + 0.07 * S.k; dx = -0.012 * S.k; }
    else { dy = 0.05 * (1 - S.k) - 0.01 * S.k; dz = 0.012 * S.k; dx = -0.012 * (1 - S.k); }
    Rh.thumb.position.set(thumbBase.x - 0.03 + dx, thumbBase.y + 0.03 + dy, thumbBase.z + 0.02 + dz); Rh.thumb.rotation.z = -0.5 - dy * 3;
  };
  return { group: outer, update };
}

// tay cam but ve len poster (poster = posterMesh). Tay di theo diem dang ve; luc khong ve thi ha xuong ngoai khung
export function povMarker(pm, o = {}) {
  const C = CAST3[o.who || 'hoodie'] || CAST3.hero, g = new THREE.Group();
  const H = hand(o); g.add(H.g); H.fingers.forEach((f) => { f.rotation.x = 1.2; f.position.z = 0.025; });
  const pen = new THREE.Mesh(new THREE.CylinderGeometry(0.008, 0.008, 0.14, 10), mat(o.penColor || '#d64545')); pen.position.set(0.0, 0.07, 0.03); pen.rotation.x = -0.5; H.g.add(pen);
  g.add(forearm(C.top || '#4a5878', [0.02, -0.05, 0.02], [0.45, -0.75, 0.5], 0.7, o));
  const update = (lt) => {
    const [u, v, n] = pm.tex.pen(lt), drawing = (o.at ?? 0.3) <= lt && lt <= (o.at ?? 0.3) + (o.dur ?? 3) + 0.15;
    const x = lerp(-pm.w / 2, pm.w / 2, u), y = lerp(pm.h / 2, -pm.h / 2, v), off = drawing ? 0 : 0.35;
    g.position.set(x + 0.03, y - 0.09 - off, 0.06 + (drawing ? 0 : 0.05)); g.rotation.set(0.15, -0.25, 0.25);
  };
  return { group: g, update };
}
