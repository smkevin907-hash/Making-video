// ui2d.js — chu tren hinh kieu phim tham khao (2 font):
// - thoai / giong trong dau (say, tempt, narr trong canh): Comic Neue dam, trang (nguoi hung) / mau nhan (giong cam do, tu bao chua),
//   phia sau la VET TOI MO (khong phai khung bong bong); hien dan + truot 10 px, cam do go tung chu. Dat tren dau nguoi noi, tu ne dau / than / HUD.
// - man den: serif Lora nghieng, nho, giua man; dong "— Ten" chu in nho gian cach. The ket: serif in hoa gian cach + dong phu nghieng.
// Moi hop chu ghi vao LAY (window.__lay) de --check do de chu / cat mep.
import { E, clamp, lerp, ease } from '/engine/core.js';
import { accent } from './puppet.js';

export const COMIC = '"Comic Neue"', SERIF = '"Lora"';
export const LAY = { actors: [], texts: [], objs: [] };
export function layReset() { LAY.actors = []; LAY.texts = []; LAY.objs = []; window.__lay = LAY; }
const ovl = (a, b) => Math.max(0, Math.min(a[2], b[2]) - Math.max(a[0], b[0])) * Math.max(0, Math.min(a[3], b[3]) - Math.max(a[1], b[1]));
function lines(g, s, maxW) { const out = []; for (const para of String(s).split('\n')) { let cur = ''; for (const w of para.split(' ')) { const tr = cur ? cur + ' ' + w : w; if (g.measureText(tr).width > maxW && cur) { out.push(cur); cur = w; } else cur = tr; } out.push(cur); } return out; }
const INK = { voice: null, friend: '#ffd27a', friend2: '#9fd0ff', friend3: '#ffab9a', girl: '#ffd9a0', mom: '#d9c2ff', dad: '#9fd0ff' };
const inkOf = (who) => (who === 'voice' ? accent() : INK[who] || '#f5f5f2');

// vet toi mo sau chu (nhu phim tham khao): hinh bo tron toi, mep nhoe, do mo <= 0.35 (chu tu doc duoc nho bong chu rieng)
// nen sang duoi chu (do that tren khung) -> vet toi dam hon de chu dat tuong phan >= 4.5:1
function bgLum(g, b) {
  try { const p = E.PX, x = Math.max(0, Math.round(b[0] * p)), y = Math.max(0, Math.round(b[1] * p)), w = Math.max(1, Math.min(g.canvas.width - x, Math.round((b[2] - b[0]) * p))), h = Math.max(1, Math.min(g.canvas.height - y, Math.round((b[3] - b[1]) * p)));
    const d = g.getImageData(x, y, w, h).data; let s = 0, n = 0; for (let i = 0; i < d.length; i += 4 * 9) { s += d[i] * 0.3 + d[i + 1] * 0.59 + d[i + 2] * 0.11; n++; } return n ? s / n : 0; } catch { return 0; }
}
function smudge(g, b, a) {
  if (b[2] - b[0] < 8) return;
  const L = bgLum(g, b), op = L > 150 ? 0.85 : L > 100 ? 0.6 : 0.35;
  const r = Math.max(5, (b[3] - b[1]) * 0.16), e = r * 0.5;   // mep nhoe hep hon + no ra ngoai hop -> loi duoi chu van dam (khong loang khi chu ngan)
  g.save(); g.filter = `blur(${r * E.PX}px)`; g.fillStyle = `rgba(8,8,10,${op * a})`;
  g.beginPath(); g.roundRect(b[0] - e, b[1] + 4 - e, b[2] - b[0] + 2 * e, b[3] - b[1] - 8 + 2 * e, (b[3] - b[1]) / 2 + e); g.fill(); g.restore();
}
// actors: [{ who, voice, head: [x, y, r], box: [x0, y0, x1, y1] }] (px logic) — tu puppet()
export function drawTexts(g, lt, list, ctx = {}) {
  const actors = ctx.actors || [];
  LAY.actors = actors.map((a) => ({ who: a.who, voice: a.voice, ok: true, head: a.head, box: a.box, fg: a.fg || a.crop }));
  const obst = actors.flatMap((a) => [[a.head[0] - a.head[2], a.head[1] - a.head[2], a.head[0] + a.head[2], a.head[1] + a.head[2]], ...(a.voice ? [] : [[a.box[0], a.box[1] + (a.box[3] - a.box[1]) * 0.4, a.box[2], a.box[3]]])]);
  const placed = ctx.hudRows ? [[40, 20, 420, 36 + 52 * ctx.hudRows]] : [];
  const free = (b) => b[0] > 24 && b[2] < E.W - 24 && b[1] > 18 && b[3] < E.H - 18 && !obst.some((h) => ovl(h, b) > 0) && !placed.some((p) => ovl(p, b) > 0);
  const spot = (w, h, cx, cy, kx = 1) => {
    if (free([cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2])) return [cx, cy];
    let best = null, bd = 1e18;
    for (let i = 0; i <= 10; i++) for (let j = 0; j <= 8; j++) { const x = lerp(w / 2 + 40, E.W - w / 2 - 40, i / 10), y = lerp(h / 2 + 30, E.H - h / 2 - 30, j / 8); if (!free([x - w / 2, y - h / 2, x + w / 2, y + h / 2])) continue; const d = ((x - cx) * kx) ** 2 + (y - cy) ** 2; if (d < bd) { bd = d; best = [x, y]; } }
    return best;
  };
  // ---- man den: serif giua man, cac dong xep doc
  const blk = (list || []).filter((x) => ctx.black && (x.kind === 'narr' || x.kind === 'big'));
  if (blk.length) {
    const sz = blk.map((x) => (x.t.startsWith('— ') ? 22 : x.kind === 'big' ? x.size ?? 46 : x.size ?? 40)), gap = 18, tot = sz.reduce((p, s) => p + s * 1.35, 0) + gap * (blk.length - 1);
    let y = E.H * (ctx.cy ?? 0.48) - tot / 2 + (ctx.drift || 0);   // chu troi len 8–16 px suot man (I5)
    blk.forEach((x, i) => {
      const s = sz[i], at = x.at ?? 0.3 + i * 0.9, k = clamp((lt - at) / 0.9), attr = x.t.startsWith('— ');
      y += s * 0.68;
      g.save(); g.textAlign = 'center'; g.textBaseline = 'middle';
      g.font = attr ? `400 ${s}px ${SERIF}` : `${x.kind === 'big' ? '' : 'italic '}400 ${s}px ${SERIF}`; if ('letterSpacing' in g) g.letterSpacing = attr ? '3px' : '0.5px';
      const txt = attr ? x.t.toUpperCase() : x.t, w = g.measureText(txt).width;
      if (k > 0) { g.globalAlpha = ease.inOut(k) * (attr ? 0.7 : 1); g.fillStyle = x.color || '#f2f1ec'; g.fillText(txt, E.W / 2, y); }
      g.restore(); LAY.texts.push({ t: x.t, box: [E.W / 2 - w / 2, y - s * 0.62, E.W / 2 + w / 2, y + s * 0.62] }); y += s * 0.67 + gap;
    });
  }
  // ---- thoai / giong noi trong canh
  for (const x of list || []) {
    if (blk.includes(x) || x.kind === 'sign') continue;
    const at = x.at ?? 0.3, dur = x.dur ?? 1e9, k = clamp((lt - at) / 0.35), out = clamp((lt - (at + dur)) / 0.3);
    if (lt < at || out >= 1) continue;
    const a = ease.inOut(k) * (1 - out), tempt = x.kind === 'tempt', narr = x.kind === 'narr' || x.kind === 'big';
    const who = tempt ? (actors.find((b) => b.voice) ? 'voice' : x.who || 'hero') : x.who || (narr ? 'hero' : actors[0]?.who || 'hero');
    const hb = narr ? null : actors.find((b) => b.who === who) || actors.find((b) => !b.voice) || null;
    const s = x.size ?? (x.kind === 'big' ? 46 : 36);
    g.save(); g.font = `700 ${s}px ${COMIC}`;
    const L = lines(g, x.t, Math.min(E.W * 0.42, 720)), w = Math.max(...L.map((l) => g.measureText(l).width)) + 56, h = L.length * s * 1.22 + 26;
    // vung rieng (I11): HUD goc trai tren; narration giua tren, ha xuong 0.15 khi co HUD; thoai tren dau nguoi noi
    let cx = hb ? hb.head[0] : E.W / 2, cy = hb ? hb.head[1] - hb.head[2] - 26 - h / 2 : narr && x.pos === 'bottom' ? E.H * 0.86 : E.H * (ctx.hudRows ? 0.15 : 0.11);
    cx = clamp(cx, w / 2 + 30, E.W - w / 2 - 30); cy = clamp(cy, h / 2 + 24, E.H - h / 2 - 24);
    const p = spot(w, h, cx, cy, narr ? 0.25 : 1); if (p) [cx, cy] = p;
    const b = [cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2], rec = { t: x.t, box: b }; placed.push(b); LAY.texts.push(rec);
    const lift = (1 - ease.out(k)) * 10;
    const shown = tempt && x.type !== false ? x.t.slice(0, Math.max(0, Math.floor((lt - at) * (x.cps ?? 16)))) : x.t;
    // nen theo PHAN CHU DANG HIEN (I6): do tung dong cua chuoi dang go, rong + 12 px; mep trai co dinh theo dong day du
    let left = shown.length; const parts = L.map((l) => { const part = l.slice(0, Math.max(0, left)); left -= l.length + 1; return part; });
    const vis = parts.map((pt, i) => ({ pt, x0: cx - g.measureText(L[i]).width / 2, w: g.measureText(pt).width })).filter((q) => q.pt.length);
    if (vis.length) { const x0 = Math.min(...vis.map((q) => q.x0)) - 12, x1 = Math.max(...vis.map((q) => q.x0 + q.w)) + 12, y0 = b[1] + lift, y1 = b[1] + lift + 26 + vis.length * s * 1.22; g.globalAlpha = Math.min(1, a * 1.8); smudge(g, [x0, y0, x1, y1], 1); rec.vis = [x0, y0, x1, y1]; rec.a = a; } else rec.vis = null;   // vet toi hien truoc chu -> chu luon tren nen du toi
    g.globalAlpha = a; g.fillStyle = x.color || inkOf(tempt ? 'voice' : narr ? 'hero' : who); g.textAlign = 'left'; g.textBaseline = 'middle';
    g.shadowColor = 'rgba(0,0,0,0.85)'; g.shadowBlur = 6; g.shadowOffsetY = 1;   // bong chu: giu tuong phan >= 4.5:1 ca tren tuong sang
    parts.forEach((pt, i) => { const lw = g.measureText(L[i]).width; g.fillText(pt, cx - lw / 2, b[1] + lift + 13 + s * 0.6 + i * s * 1.22); });
    g.restore();
  }
}

// bo dem goc trai tren (kin dao, serif in hoa nho) — so khac canh truoc thi loe mau nhan 0,8 giay
export function drawHud(g, lt, hud, prev) {
  if (!hud || !hud.rows) return;
  let y = 58;
  for (const r of hud.rows) {
    let n = r.n ?? r.to ?? 0; if (r.from !== undefined && r.to !== undefined) n = Math.round(lerp(r.from, r.to, clamp((lt - (r.at ?? 0.3)) / (r.dur ?? 3))));
    if (r.reset && lt >= r.reset.at) n = r.reset.to ?? 0;
    const pv = prev && prev.rows ? prev.rows.find((q) => q.label === r.label) : null, changed = pv && (pv.n ?? pv.to) !== (r.n ?? r.from ?? r.to) && hud.bump !== false && r.bump !== false;
    g.save(); g.textAlign = 'left'; g.textBaseline = 'middle'; g.font = `400 24px ${SERIF}`; if ('letterSpacing' in g) g.letterSpacing = '4px';
    const lab = String(r.label || 'DAY').toUpperCase() + '  '; g.fillStyle = 'rgba(240,240,236,0.72)'; g.fillText(lab, 60, y);
    const lw = g.measureText(lab).width; g.font = `600 32px ${SERIF}`; g.fillStyle = changed && lt < 0.8 ? accent() : '#f2f1ec';
    g.fillText(r.comma === false ? String(n) : Number(n).toLocaleString('en-US'), 60 + lw, y); g.restore();
    LAY.texts.push({ t: 'HUD', box: [52, y - 22, 60 + lw + 140, y + 22], hud: true }); y += 52;
  }
}

// the ket kieu phim tham khao: tu khoa serif in hoa gian cach, hien dan; dong phu nghieng nho; dong phu 2 mau nhan
export function drawCard(g, lt, a) {
  const word = a.word || '', k = ease.inOut(clamp((lt - 0.3) / 1.0));
  g.save(); g.textAlign = 'center'; g.textBaseline = 'middle'; g.font = `400 ${a.size ?? 84}px ${SERIF}`; if ('letterSpacing' in g) g.letterSpacing = '12px';
  g.globalAlpha = k; g.fillStyle = '#f2f1ec'; g.fillText(word.toUpperCase(), E.W / 2, E.H * 0.42); const W = g.measureText(word.toUpperCase()).width; g.restore();
  LAY.texts.push({ t: word, box: [E.W / 2 - W / 2, E.H * 0.42 - 50, E.W / 2 + W / 2, E.H * 0.42 + 50] });
  const sub = (s, y, at, c, it = true) => { if (!s) return; const kk = ease.inOut(clamp((lt - at) / 0.8)); g.save(); g.globalAlpha = kk; g.font = `${it ? 'italic ' : ''}400 34px ${SERIF}`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillStyle = c; g.fillText(s, E.W / 2, y); const w = g.measureText(s).width; g.restore(); LAY.texts.push({ t: s, box: [E.W / 2 - w / 2, y - 24, E.W / 2 + w / 2, y + 24] }); };
  sub(a.part, E.H * 0.3, 0.1, 'rgba(240,240,236,0.6)', false); sub(a.sub, E.H * 0.53, 1.3, '#e8e7e2'); sub(a.sub2, E.H * 0.6, a.sub2At ?? 2.3, accent());
}
