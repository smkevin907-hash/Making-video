"""doctor.py — kiem tra may co du cong cu de dung video. Them --install de tu cai phan con thieu."""
import importlib.util, json, os, platform, shutil, subprocess, sys
ROOT = os.path.dirname(os.path.dirname(os.path.abspath(__file__))); OS = platform.system()
fix_cmds, ok_all = [], True
def ok(name, cond, detail="", fix=None):
    global ok_all
    print(f"[{'OK' if cond else 'THIEU'}] {name}" + (f" — {detail}" if detail else ""))
    if not cond:
        ok_all = False
        if fix: fix_cmds.append(fix)
def ver(cmd):
    try: return subprocess.run(cmd, capture_output=True, text=True, timeout=30).stdout.strip().splitlines()[0]
    except Exception: return ""
ok("Python >= 3.9", sys.version_info >= (3, 9), sys.version.split()[0])
for m in ("numpy", "scipy", "soundfile"):
    ok(f"Python: {m}", importlib.util.find_spec(m) is not None, fix=f'"{sys.executable}" -m pip install numpy scipy soundfile' + (" --break-system-packages" if OS == "Linux" else ""))
ok("ffmpeg", shutil.which("ffmpeg") is not None, ver(["ffmpeg", "-version"])[:40], {"Windows": "winget install --id Gyan.FFmpeg -e", "Darwin": "brew install ffmpeg"}.get(OS, "sudo apt-get install -y ffmpeg"))
ok("ffprobe", shutil.which("ffprobe") is not None)
nv = ver(["node", "--version"]); ok("Node.js >= 18", nv.startswith("v") and int(nv[1:].split(".")[0]) >= 18, nv, {"Windows": "winget install OpenJS.NodeJS.LTS", "Darwin": "brew install node"}.get(OS, "cai Node 20 LTS"))
need = json.load(open(os.path.join(ROOT, "package.json"), encoding="utf-8")).get("dependencies", {})
miss = [k for k in need if not os.path.isdir(os.path.join(ROOT, "node_modules", *k.split("/")))]
ok("Goi Node (playwright, font, ban do, 3D)", not miss, ("thieu: " + ", ".join(miss)) if miss else f"{len(need)} goi", fix="npm install")
packs = sorted(d for d in os.listdir(os.path.join(ROOT, "packs"))) if os.path.isdir(os.path.join(ROOT, "packs")) else []
print(f"[--] Bo phong cach co san: {', '.join(packs) or 'khong co'} (+ nguoi que What If)")
# mo thu Chromium bang dung cach render.mjs tim (chrome-linux64, chrome-win64, headless shell...), chi OK khi mo duoc that
cr = ""
try: cr = (subprocess.run(["node", os.path.join("tools", "chromium.mjs"), "--check"], capture_output=True, text=True, cwd=ROOT, timeout=120).stdout.strip().splitlines() or [""])[-1]
except Exception as e: cr = "THIEU " + str(e)[:80]
ok("Chromium chay ngam", cr.startswith("OK "), cr[3:][-70:] if cr.startswith("OK ") else cr[6:][:90], "npx playwright install chromium")
sfx = os.path.join(ROOT, "audio", "sfx"); mus = os.path.join(ROOT, "audio", "music")
# kieu cai: gon (chi goi dem: Chromium rut gon, khong three / ban do, nhac sinh rieng tung phim) hoac day du (--full, moi goi H2)
opt = json.load(open(os.path.join(ROOT, "package.json"), encoding="utf-8")).get("optionalDependencies", {})
GON = bool(opt) and any(not os.path.isdir(os.path.join(ROOT, "node_modules", *k.split("/"))) for k in opt)
print(f"[--] Kieu cai: {'GON (goi dem; goi H2 khac can cai day du: xem cai-dat.md)' if GON else 'DAY DU'}")
if GON: ok("Thu vien SFX", os.path.isdir(sfx) and len(os.listdir(sfx)) >= 30, "nhac sinh rieng tung phim luc tron", f'"{sys.executable}" audio/build_audio.py --gon')
else: ok("Thu vien SFX + nhac", os.path.isdir(sfx) and len(os.listdir(sfx)) >= 30 and os.path.isdir(mus) and len(os.listdir(mus)) >= 6, fix=f'"{sys.executable}" audio/build_audio.py')
# pack co audio.py rieng (vd dem: nhac sad/dark/rise, SFX bao thuc, kinh vo...) phai da tao xong
for pk in packs:
    if not GON and os.path.exists(os.path.join(ROOT, "packs", pk, "audio.py")):
        have = os.path.isdir(mus) and any(f.startswith("bed_sad_") for f in os.listdir(mus)) if pk == "dem" else True
        ok(f"Nhac + SFX rieng cua pack {pk}", have, fix=f'"{sys.executable}" audio/build_audio.py')
if "--install" in sys.argv and fix_cmds:
    for c in dict.fromkeys(fix_cmds):
        print("\n>>>", c); subprocess.run(c, shell=True, cwd=ROOT)
elif fix_cmds:
    print("\nCach sua:"); [print("  " + c) for c in dict.fromkeys(fix_cmds)]
print("\nSAN SANG" if ok_all else "\nChua du — chay lai voi --install hoac lam theo cach sua o tren.")
