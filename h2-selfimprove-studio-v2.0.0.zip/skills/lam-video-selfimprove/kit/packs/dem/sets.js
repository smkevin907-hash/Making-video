// sets.js — boi canh nen toi net manh: set(g, ten, o) ve nen va tra ve "moc" (vi tri giuong, ghe, cua...) de dat nhan vat.
// Ten: bedroom city street lockers classroom court cafe gym stairs hill mirror kitchen void black doorway sofa
// o chung: t (giay), gy (mat san 0..1), dim (0..1 lam toi), seed
import { E, clamp, lerp, ease, rng, noise, alpha, shade, mix, text } from '/engine/core.js';
import { PAL, accent, obj, box, oval, ln, fillAll, vgrad, light, beam, FONT_UI, FONT_NARR, depth, seg7, classic } from './ink.js';
// lop chieu sau (parallax) cua tung boi canh: troi 0.2, nha xa 0.35-0.55, tuong sau 0.85-0.9, do vat + nhan vat 1
const D = { sky: 0.2, far: 0.35, mid: 0.55, wall: 0.88 };

const W = () => E.W, H = () => E.H;
const X = (k) => k * E.W, Y = (k) => k * E.H;
// khung doc: dat vat theo ti le cua chieu ngang 16:9 trung tam
const VX = (k) => (E.vertical ? E.W / 2 + (k - 0.5) * E.H * 0.5625 * 1.0 : k * E.W);

function wall(g, top = '#17171c', bot = '#1d1e24') { vgrad(g, [[0, top], [1, bot]]); }
function floor(g, gy, c = PAL.floor) { g.fillStyle = c; g.fillRect(-60, gy, E.W + 120, E.H - gy + 60); ln(g, [[-60, gy], [E.W + 60, gy]], { lw: 2, la: 0.45 }); }
export function rain(g, t, o = {}) {
  const r = rng(o.seed || 7), n = o.n || 160, sp = o.speed || 1400, len = o.len || 34;
  g.save(); g.strokeStyle = alpha(o.color || '#aab4c8', o.a ?? 0.35); g.lineWidth = o.lw || 1.6;
  for (let i = 0; i < n; i++) { const x0 = r() * (E.W + 200) - 100, y0 = r() * E.H, y = (y0 + t * sp * (0.8 + r() * 0.4)) % (E.H + 60) - 30, x = x0 - (y / E.H) * 60; g.beginPath(); g.moveTo(x, y); g.lineTo(x - 6, y + len); g.stroke(); }
  if (o.gy !== undefined) {   // giot mua bat len khi cham dat (chi tiet nho)
    const q = rng(41); g.lineWidth = 1.4; for (let i = 0; i < 26; i++) { const x = q() * E.W, ph = q(), u = (t * 2.2 + ph) % 1; if (u > 0.35) continue; const k = u / 0.35, yy = o.gy + 4 + q() * (E.H - o.gy) * 0.5; g.strokeStyle = alpha(o.color || '#aab4c8', 0.45 * (1 - k)); g.beginPath(); g.arc(x, yy, 3 + 9 * k, Math.PI * 1.1, Math.PI * 1.9); g.stroke(); }
  }
  g.restore();
}
// bui lo lung trong chum sang (chi tiet nho): chi ve trong hinh non cua chum
function beamDust(g, t, x0, y0, x1a, x1b, y1, n = 26, hand = true) {
  if (hand) t = Math.floor(t * 10) / 10;
  g.save(); g.beginPath(); g.moveTo(x0 - 6, y0); g.lineTo(x0 + 6, y0); g.lineTo(x1b, y1); g.lineTo(x1a, y1); g.closePath(); g.clip();
  const r = rng(53); for (let i = 0; i < n; i++) { const u = r(), v = r(), yy = lerp(y0, y1, (v + t * 0.02 * (0.5 + r())) % 1), xx = lerp(lerp(x0, x1a, (yy - y0) / (y1 - y0)), lerp(x0, x1b, (yy - y0) / (y1 - y0)), u) + Math.sin(t * 0.5 + i) * 6; g.fillStyle = `rgba(235,232,220,${0.25 + 0.35 * Math.abs(Math.sin(t * 0.7 + i * 1.3))})`; g.beginPath(); g.arc(xx, yy, 1 + r() * 1.8, 0, 7); g.fill(); }
  g.restore();
}
export function dust(g, t, o = {}) {
  if (o.hand) t = Math.floor(t * 10) / 10;   // nhip ve tay: bui nhay buoc 10 lan / giay (nhu phim mau)
  const r = rng(o.seed || 5); g.save();
  for (let i = 0; i < (o.n || 40); i++) { const x = (r() * E.W + Math.sin(t * 0.3 + i) * 30), y = (r() * E.H - t * 12 * (0.5 + r())) % E.H; g.fillStyle = alpha(o.color || '#e8e2d0', 0.15 + r() * 0.25); g.beginPath(); g.arc(x, y < 0 ? y + E.H : y, 1 + r() * 2, 0, 7); g.fill(); }
  g.restore();
}
function moon(g, x, y, r) { light(g, x, y, r * 4, '#cfd8ff', 0.25); g.beginPath(); g.arc(x, y, r, 0, 7); g.fillStyle = PAL.moon; g.fill(); }
function skyGrad(g, x, y, w, h, kind, t = 0) {
  const S = { moon: ['#151a2c', '#202842'], night: ['#11131f', '#1c2238'], dawn: ['#3b2b4f', '#c8705a'], dusk: ['#2c2140', '#d47a5e'], day: ['#6e9cc8', '#a9cce6'], rain: ['#151821', '#232a38'], dark: ['#0f1014', '#15161b'] }[kind] || ['#151a2c', '#202842'];
  const gr = g.createLinearGradient(0, y, 0, y + h); gr.addColorStop(0, S[0]); gr.addColorStop(1, S[1]); g.fillStyle = gr; g.fillRect(x, y, w, h);
  if (kind === 'moon' || kind === 'night') moon(g, x + w * 0.62, y + h * 0.3, Math.min(w, h) * 0.09);
  if (kind === 'rain') { g.save(); g.beginPath(); g.rect(x, y, w, h); g.clip(); g.strokeStyle = 'rgba(170,185,210,0.35)'; g.lineWidth = 1.2; const r = rng(3); for (let i = 0; i < 26; i++) { const xx = x + r() * w, yy = y + ((r() * h + t * 500) % h); g.beginPath(); g.moveTo(xx, yy); g.lineTo(xx - 3, yy + 16); g.stroke(); } g.restore(); }
  if (kind === 'day') { const r = rng(9); for (let i = 0; i < 4; i++) { g.beginPath(); g.ellipse(x + w * (0.15 + i * 0.25), y + h * (0.88 + r() * 0.05), w * 0.16, h * 0.2, 0, 0, 7); g.fillStyle = '#5c9a5a'; g.fill(); } }
}
export function windowBox(g, x, y, w, h, o = {}) {
  box(g, x - 8, y - 8, w + 16, h + 16, { fill: '#2a2c33', r: 6 });
  skyGrad(g, x, y, w, h, o.sky || 'moon', o.t);
  g.save(); g.strokeStyle = alpha(PAL.line, 0.8); g.lineWidth = 5; g.strokeRect(x, y, w, h); g.beginPath(); g.moveTo(x + w / 2, y); g.lineTo(x + w / 2, y + h); g.moveTo(x, y + h / 2); g.lineTo(x + w, y + h / 2); g.stroke(); g.restore();
}
// ---------- do vat
export function digitClock(g, x, y, s, o = {}) {
  const w = s * 1.6, h = s * 0.8, col = o.color || PAL.clock;
  box(g, x - w / 2, y - h, w, h, { fill: '#202127', r: s * 0.12 });
  const blink = o.blink ? (Math.floor((o.t || 0) * 2) % 2 === 0) : true;
  let str = String(o.time ?? '3:17'); if (!blink) str = str.replace(':', ' ');
  if (!classic()) seg7(g, String(o.time ?? '3:17'), x, y - h / 2, s * 0.4, col, { colon: blink });
  else { g.save(); g.shadowColor = col; g.shadowBlur = s * 0.25; text(g, str, x, y - h / 2 + s * 0.02, { size: s * 0.5, font: '"Be Vietnam Pro"', weight: 700, color: col, spacing: 2 }); g.restore(); }
  light(g, x, y - h / 2, s * 1.4, col, 0.12);
  if (o.ring) { const k = Math.sin((o.t || 0) * 26) > 0; if (k) for (const d of [-1, 1]) for (let i = 0; i < 2; i++) ln(g, [[x + d * (w / 2 + 10 + i * 12), y - h * 0.9 + i * 6], [x + d * (w / 2 + 22 + i * 12), y - h * 1.1 + i * 6]], { color: col, lw: 3, la: 0.9 }); }
}
export function calendar(g, x, y, w, o = {}) {
  const h = w * 1.1, col = o.headColor || '#c9463d';
  box(g, x, y, w, h, { fill: '#e9e6df', line: '#6d6f76', r: 4 });
  g.fillStyle = col; g.fillRect(x + 1, y + 1, w - 2, h * 0.2);
  text(g, o.month || 'OCT', x + w / 2, y + h * 0.105, { size: h * 0.12, font: '"Be Vietnam Pro"', weight: 700, color: '#fff' });
  const cw = (w - 12) / 7, ch = (h * 0.78 - 8) / 5, n = Math.round(o.fill ?? 0), mode = o.mode || 'x', mc = o.color || (mode === 'x' ? '#d23b33' : accent());
  for (let i = 0; i < 35; i++) {
    const cx = x + 6 + (i % 7) * cw, cy = y + h * 0.22 + 4 + Math.floor(i / 7) * ch;
    g.fillStyle = '#d6d2c9'; g.fillRect(cx + 1, cy + 1, cw - 2, ch - 2);
    if (i < n) { if (mode === 'x') { g.strokeStyle = mc; g.lineWidth = Math.max(1.5, cw * 0.12); g.beginPath(); g.moveTo(cx + 3, cy + 3); g.lineTo(cx + cw - 3, cy + ch - 3); g.moveTo(cx + cw - 3, cy + 3); g.lineTo(cx + 3, cy + ch - 3); g.stroke(); } else { g.fillStyle = mc; g.fillRect(cx + 1, cy + 1, cw - 2, ch - 2); } }
  }
}
export function deskLamp(g, x, y, s, on = true) {
  ln(g, [[x, y], [x + s * 0.25, y - s * 0.6], [x - s * 0.05, y - s * 0.95]], { lw: s * 0.05, color: '#6b6e77', la: 1 });
  obj(g, (c) => { c.moveTo(x - s * 0.05, y - s * 0.95); c.lineTo(x - s * 0.4, y - s * 0.7); c.lineTo(x - s * 0.15, y - s * 1.12); c.closePath(); }, { fill: '#5a5d66' });
  box(g, x - s * 0.2, y - s * 0.06, s * 0.4, s * 0.08, { fill: '#4a4d55', r: 3 });
  if (on) { beam(g, x - s * 0.3, y - s * 0.82, x - s * 1.2, x + s * 0.6, y + s * 0.05, PAL.lamp, 0.22); light(g, x - s * 0.3, y - s * 0.8, s * 1.6, PAL.lamp, 0.35); }
}
export function books(g, x, y, s) { const cs = ['#3f6ea8', '#c9463d', '#5f8f5a', '#e8b33c', '#7b6a8a']; for (let i = 0; i < 5; i++) box(g, x - s * 0.5 + (i % 2) * 6, y - (i + 1) * s * 0.13, s * (0.9 - i * 0.05), s * 0.12, { fill: cs[i], line: '#222', r: 2, la: 0.4 }); }
export function laptop(g, x, y, s, o = {}) {
  const c = o.color || '#9fb6ff';
  obj(g, (k) => { k.moveTo(x - s * 0.55, y - 2); k.lineTo(x + s * 0.55, y - 2); k.lineTo(x + s * 0.62, y + 4); k.lineTo(x - s * 0.62, y + 4); k.closePath(); }, { fill: '#3a3d45' });
  obj(g, (k) => { k.moveTo(x - s * 0.5, y - 4); k.lineTo(x - s * 0.42, y - s * 0.72); k.lineTo(x + s * 0.48, y - s * 0.72); k.lineTo(x + s * 0.5, y - 4); k.closePath(); }, { fill: o.on ? c : '#202127' });
  if (o.on) light(g, x, y - s * 0.4, s * 2.2, c, 0.28);
}
export function chair(g, x, gy, s, f = 1) {
  ln(g, [[x - f * s * 0.25, gy - s * 0.95], [x - f * s * 0.25, gy]], { lw: 5, color: '#5c5f68', la: 1 });
  ln(g, [[x - f * s * 0.25, gy - s * 0.5], [x + f * s * 0.25, gy - s * 0.5], [x + f * s * 0.25, gy]], { lw: 5, color: '#5c5f68', la: 1 });
  box(g, x - s * 0.3, gy - s * 0.54, s * 0.6, s * 0.07, { fill: '#3a3d45', r: 3 });
}
export function table(g, x, gy, w, h, o = {}) { box(g, x - w / 2, gy - h, w, h * 0.08, { fill: o.fill || '#3a3d45', r: 3 }); ln(g, [[x - w * 0.42, gy - h], [x - w * 0.42, gy]], { lw: 4, la: 0.7 }); ln(g, [[x + w * 0.42, gy - h], [x + w * 0.42, gy]], { lw: 4, la: 0.7 }); }
export function door(g, x, gy, w, h, o = {}) {
  box(g, x - w / 2, gy - h, w, h, { fill: o.open ? '#0d0d10' : '#2b2d34', r: 3 });
  if (o.open) { const k = o.open; g.save(); g.globalCompositeOperation = 'lighter'; g.fillStyle = alpha(o.lightColor || PAL.lamp, 0.55 * k); g.fillRect(x - w / 2 + 4, gy - h + 4, w * k - 8, h - 8); g.restore(); beam(g, x, gy - h * 0.5, x - w * 0.2, x + w * 1.6, gy + E.H * 0.2, o.lightColor || PAL.lamp, 0.18 * k); }
  else { oval(g, x + w * 0.35, gy - h * 0.48, 5, 5, { fill: '#9a9da6', line: null }); }
}
export function punchBag(g, x, y, s, o = {}) {
  let sw = Math.sin((o.t || 0) * 5) * (o.swing ?? 0.04);
  for (const h of o.hits || []) { const d = (o.t || 0) - h; if (d > 0 && d < 2.5) sw += Math.exp(-d * 2.5) * Math.sin(d * 7) * 0.13; }   // trung don: vang ra roi dung dan
  if (classic()) {
    g.save(); g.translate(x, y); g.rotate(sw); ln(g, [[0, 0], [0, s * 0.2]], { lw: 3, color: '#777' });
    box(g, -s * 0.18, s * 0.2, s * 0.36, s * 0.8, { fill: o.color || '#c4302b', line: '#5e1512', r: s * 0.12, la: 1 }); g.restore();
    light(g, x, y + s * 0.6, s * 0.7, o.color || '#c4302b', 0.12); return;
  }
  // dang moi: bao lom vao luc trung don roi nay lai, net soc ve tay tren bao, chop sang + tia o diem trung (phia nguoi dam)
  let dent = 0, flash = 0; const side = o.from ?? -1; for (const h of o.hits || []) { const d = (o.t || 0) - h; if (d > -0.02 && d < 0.35) { dent = Math.max(dent, Math.exp(-d * 14) * Math.max(0, Math.sin((d + 0.02) * 30)) * 0.5 + (d < 0.08 ? 0.5 : 0)); flash = Math.max(flash, d < 0.2 ? 1 - d / 0.2 : 0); } }
  const col = o.color || '#d6342b';
  g.save(); g.translate(x, y); g.rotate(sw); ln(g, [[0, 0], [0, s * 0.2]], { lw: 3, color: '#777' });
  g.save(); g.translate(0, s * 0.6); g.scale(1 - 0.12 * dent, 1 + 0.04 * dent); g.translate(-side * s * 0.03 * dent, -s * 0.6);
  box(g, -s * 0.18, s * 0.2, s * 0.36, s * 0.8, { fill: col, line: '#5e1512', r: s * 0.12, la: 1 });
  g.save(); g.beginPath(); g.roundRect(-s * 0.18, s * 0.2, s * 0.36, s * 0.8, s * 0.12); g.clip(); g.strokeStyle = 'rgba(120,20,18,0.55)'; g.lineWidth = Math.max(1.5, s * 0.006); g.lineCap = 'round'; const r = rng(31); for (let i = 0; i < 22; i++) { const xx = (r() - 0.5) * s * 0.3, yy = s * (0.26 + r() * 0.7), L = s * (0.03 + r() * 0.05); g.beginPath(); g.moveTo(xx, yy); g.lineTo(xx + L * 0.5, yy + L); g.stroke(); } g.restore();
  g.restore(); g.restore();
  light(g, x, y + s * 0.6, s * 0.7, col, 0.14);
  if (flash > 0) { const hx = x + side * s * 0.19, hy = clamp(o.hitY ?? y + s * 0.55, y + s * 0.28, y + s * 0.95) /* cao bang nam dam */; light(g, hx, hy, s * 0.42 * (0.6 + 0.4 * flash), '#ffd27a', 0.9 * flash); g.save(); g.strokeStyle = `rgba(255,226,150,${flash})`; g.lineWidth = Math.max(2, s * 0.008); g.lineCap = 'round'; for (let i = 0; i < 9; i++) { const a = Math.PI * (side < 0 ? 1 : 0) + (i / 8 - 0.5) * 2.2, r0 = s * 0.08, r1 = s * (0.16 + 0.06 * (i % 2)) * (1.3 - flash * 0.3); g.beginPath(); g.moveTo(hx + Math.cos(a) * r0, hy + Math.sin(a) * r0); g.lineTo(hx + Math.cos(a) * r1, hy + Math.sin(a) * r1); g.stroke(); } g.restore(); }
}
export function barbell(g, x, gy, s) { ln(g, [[x - s * 0.7, gy - s * 0.18], [x + s * 0.7, gy - s * 0.18]], { lw: 6, color: '#8a8d96', la: 1 }); for (const d of [-1, 1]) for (let i = 0; i < 2; i++) box(g, x + d * s * (0.5 + i * 0.09) - 9, gy - s * 0.18 - s * (0.18 - i * 0.04), 18, s * (0.36 - i * 0.08), { fill: '#202127', r: 4 }); }
export function plant(g, x, gy, s) { box(g, x - s * 0.18, gy - s * 0.3, s * 0.36, s * 0.3, { fill: '#7a5340', r: 3 }); const r = rng(4); for (let i = 0; i < 7; i++) { const a = -Math.PI / 2 + (r() - 0.5) * 1.6; obj(g, (c) => c.ellipse(x + Math.cos(a) * s * 0.3, gy - s * 0.3 + Math.sin(a) * s * 0.35, s * 0.07, s * 0.24, a + Math.PI / 2, 0, 7), { fill: '#4f7a4e', line: '#2c4a2c', la: 0.6 }); } }
export function bench(g, x, gy, w) { box(g, x - w / 2, gy - 52, w, 10, { fill: '#6b4e3a', r: 3 }); box(g, x - w / 2, gy - 82, w, 9, { fill: '#6b4e3a', r: 3 }); ln(g, [[x - w * 0.4, gy - 42], [x - w * 0.4, gy]], { lw: 4 }); ln(g, [[x + w * 0.4, gy - 42], [x + w * 0.4, gy]], { lw: 4 }); }
export function streetLamp(g, x, gy, h, on = true, t) {   // t (chi tiet nho): thinh thoang chap chon
  const fl = t === undefined ? 1 : Math.sin(t * 0.9 + x * 0.013) > 0.93 && Math.sin(t * 31 + x) > -0.2 ? 0.35 : 1;
  ln(g, [[x, gy], [x, gy - h], [x + h * 0.12, gy - h - 10]], { lw: 4, color: '#555861', la: 1 }); if (on) { light(g, x + h * 0.12, gy - h - 4, h * 0.35, PAL.lamp, 0.5 * fl); beam(g, x + h * 0.12, gy - h, x - h * 0.15, x + h * 0.4, gy, PAL.lamp, 0.08 * fl); } }

function skyline(g, gy, o = {}) {
  if (o.off) { const off = ((o.off % E.W) + E.W) % E.W; for (const k of [0, 1]) { g.save(); g.translate(-off + k * E.W, 0); skyline(g, gy, { ...o, off: 0 }); g.restore(); } return; }   // troi ngang, lap lien
  const r = rng(o.seed || 11), n = o.n || 14, col = o.color || '#1b1622', lit = o.lit ?? 0.25;
  for (let i = 0; i < n; i++) {
    const w = E.W / n * (0.8 + r() * 0.6), x = i * E.W / n - 20, h = E.H * (o.hmin ?? 0.18) + r() * E.H * (o.hvar ?? 0.28);
    obj(g, (c) => c.rect(x, gy - h, w, h + 4), { fill: col, line: o.line ?? null, la: 0.25 });
    if (lit) for (let k = 0; k < h / 34; k++) for (let j = 0; j < w / 30; j++) if (r() < lit) { g.fillStyle = alpha(PAL.lamp, 0.35 + r() * 0.4); g.fillRect(x + 10 + j * 30, gy - h + 14 + k * 34, 8, 12); }
  }
}

// ---------- boi canh
// moc tra ve: { gy, bed: {head:[x,y], sit:[x,y], lie:[x,y]}, clock:[x,y], desk:{seat:[x,y]}, door:[x,y], ... }
export function set(g, kind = 'bedroom', o = {}) {
  const t = o.t || 0, gy = Y(o.gy ?? (E.vertical ? 0.7 : 0.8)), M = { gy };
  switch (kind) {
    case 'black': fillAll(g, '#0b0b0d'); break;
    case 'void': {
      fillAll(g, '#0d0d10'); const sx = X(o.spot ?? 0.5); beam(g, sx, -20, sx - E.W * 0.16, sx + E.W * 0.16, gy + 40, '#e8e4dc', 0.13);
      g.save(); g.scale(1, 0.18); light(g, sx, gy / 0.18, E.W * 0.16, '#e8e4dc', 0.22); g.restore(); ln(g, [[-60, gy], [E.W + 60, gy]], { lw: 1.5, la: 0.18 }); dust(g, t, { n: 30, hand: o.hand }); break; }
    case 'bedroom': {
      const bx = VX(o.bedX ?? 0.27), bw = E.vertical ? E.W * 0.5 : X(o.bedW ?? 0.33), bh = E.H * 0.11;
      const wx = VX(o.windowX ?? 0.5), wy = Y(0.24), ww = E.vertical ? E.W * 0.26 : X(0.115), wh = Y(0.2);
      // tuong sau + cua so + lich (lop xa hon do dac)
      // ban moi toi gian nhu phim mau: chi giuong + tu dau giuong + cua so; lich / ban hoc chi hien khi ghi (calendar, desk, lamp, laptop)
      const cl = classic(), calOn = cl ? o.calendar !== false : !!o.calendar, deskOn = cl ? o.desk !== false : !!(o.desk || o.lamp || o.laptop);
      depth(g, D.wall, () => { wall(g); if (o.window !== false) windowBox(g, wx, wy, ww, wh, { sky: o.sky || 'moon', t }); if (calOn && !E.vertical) calendar(g, X(o.calX ?? 0.79), Y(0.26), X(0.055), o.calendar === true ? {} : o.calendar || {}); });
      floor(g, gy);
      // chum trang
      if (o.window !== false && ((o.sky || 'moon') === 'moon' || o.sky === 'dawn')) { beam(g, wx + ww / 2, wy + wh, bx + bw * 0.2, bx + bw * 0.9, gy + 30, o.sky === 'dawn' ? '#ffb48a' : '#c8d4ff', cl ? 0.07 : 0.1); if (o.details) beamDust(g, t, wx + ww / 2, wy + wh, bx + bw * 0.2, bx + bw * 0.9, gy + 30, 18); }
      if (deskOn && !E.vertical) {
        const dx = X(o.deskX ?? 0.84), dw = X(0.15), dh = E.H * 0.17; table(g, dx, gy, dw, dh); chair(g, dx - dw * 0.15, gy, E.H * 0.2, -1); books(g, dx + dw * 0.18, gy - dh, 60); deskLamp(g, dx - dw * 0.38, gy - dh, 90, o.lamp);
        if (o.laptop) laptop(g, dx - dw * 0.02, gy - dh, 70, { on: o.laptop !== 'off', t, color: o.laptopColor });
        M.desk = { seat: [dx - dw * 0.15, gy], top: [dx, gy - dh] };
      }
      if (o.door) door(g, X(o.doorX ?? 0.95), gy, X(0.07), E.H * 0.42, { open: o.doorOpen });
      // tu dau giuong + dong ho
      const nx = bx - E.W * (E.vertical ? 0.1 : 0.045);
      box(g, nx - 50, gy - 95, 100, 95, { fill: '#26272d', r: 6 }); ln(g, [[nx - 40, gy - 55], [nx + 40, gy - 55]], { lw: 1.5, la: 0.5 }); oval(g, nx, gy - 30, 4, 4, { fill: '#888', line: null });
      if (o.clock !== false) digitClock(g, nx, gy - 97, 62, { time: o.clock ?? '3:17', ring: o.ring, blink: o.blink, t });
      M.clock = [nx, gy - 130];
      // giuong
      ln(g, [[bx, gy], [bx, gy - E.H * 0.25]], { lw: 9, color: '#33353d', la: 1 }); ln(g, [[bx, gy - E.H * 0.25], [bx, gy - E.H * 0.13]], { lw: 3, la: 0.5 });
      box(g, bx, gy - bh, bw, bh * 0.55, { fill: '#2c2e35', r: 4 }); ln(g, [[bx + bw - 6, gy - bh * 0.5], [bx + bw - 6, gy]], { lw: 6, color: '#33353d', la: 1 });
      M.bed = { head: [bx + bw * 0.1, gy - bh - 22], sit: [bx + bw * 0.62, gy], lie: [bx + bw * 0.4, gy - bh], x0: bx, x1: bx + bw, top: gy - bh };
      M.pillow = () => oval(g, bx + bw * 0.1, gy - bh - 6, bw * 0.09, 16, { fill: PAL.pillow });
      M.blanket = (occupied) => obj(g, (c) => { c.moveTo(bx + bw * (occupied ? 0.17 : 0.24), gy - bh + 4); if (occupied) { c.quadraticCurveTo(bx + bw * 0.19, gy - bh - 34, bx + bw * 0.35, gy - bh - 28); c.quadraticCurveTo(bx + bw * 0.6, gy - bh - 36, bx + bw * 0.8, gy - bh - 18); } else c.quadraticCurveTo(bx + bw * 0.6, gy - bh - 14, bx + bw * 0.95, gy - bh - 4); c.lineTo(bx + bw * 0.98, gy - bh + bh * 0.5); c.lineTo(bx + bw * 0.16, gy - bh + bh * 0.5); c.closePath(); }, { fill: PAL.blanket, line: '#8c95b5', la: 0.5 });
      if (!o.occupied) { M.pillow(); M.blanket(false); }
      break; }
    case 'city': {
      const tm = o.time || 'dusk', S = { dusk: classic() ? ['#251c35', '#6a3f5c', '#d0745a'] : ['#1d1824', '#563a4e', '#c06a54'], night: ['#0c0f1c', '#182038', '#25304e'], dawn: ['#2a2a4a', '#8a5a78', '#f0a070'], day: ['#5c8fc4', '#8fb8de', '#cfe2f0'] }[tm] || ['#251c35', '#6a3f5c', '#d0745a'];
      // troi (rat xa) -> nha xa -> nha gan -> duong + den (lop nhan vat). scroll: duong troi (px/giay / 60), nha troi cham hon theo do xa
      const sc = (o.scroll || 0) * 60 * t;
      depth(g, D.sky, () => { vgrad(g, [[0, S[0]], [0.55, S[1]], [1, S[2]]], 0, gy); if (tm !== 'night') light(g, X(0.5), gy, E.W * 0.45, tm === 'day' ? '#ffffff' : '#ffb070', 0.35); else moon(g, X(0.8), Y(0.25), 22); });
      if (o.birds) depth(g, 0.3, () => { g.save(); g.strokeStyle = '#2a2030'; g.lineWidth = 2.5; for (let i = 0; i < 3; i++) { const bx = X(0.7) + i * 34 + t * 20, by = Y(0.25) + i * 10 + Math.sin(t * 3 + i) * 4; g.beginPath(); g.moveTo(bx - 8, by); g.quadraticCurveTo(bx - 3, by - 6, bx, by); g.quadraticCurveTo(bx + 3, by - 6, bx + 8, by); g.stroke(); } g.restore(); });
      // ban moi: nha toi hon, it cua sang, vien nha mo (nhu phim mau)
      const cl = classic(), lk = cl ? 1 : 0.35;
      depth(g, D.far, () => skyline(g, gy, { color: tm === 'day' ? '#7d8fa6' : cl ? '#2a2033' : '#1e1a24', seed: 3, hmin: 0.22, hvar: 0.3, lit: tm === 'day' ? 0 : 0.18 * lk, off: sc * 0.2, line: cl ? null : '#4a4452' }));
      depth(g, D.mid, () => skyline(g, gy, { color: tm === 'day' ? '#5d6e86' : cl ? '#17131d' : '#121015', seed: 8, n: 9, hmin: 0.1, hvar: 0.22, lit: tm === 'day' ? 0 : 0.3 * lk, off: sc * 0.45, line: cl ? null : '#55505e' }));
      g.fillStyle = '#1a1a20'; g.fillRect(-60, gy, E.W + 120, E.H); ln(g, [[-60, gy], [E.W + 60, gy]], { lw: 2, la: 0.35 });
      for (let i = 0; i < 12; i++) { const x = ((i * 220 - sc) % (E.W + 220) + E.W + 220) % (E.W + 220) - 110; g.fillStyle = 'rgba(200,200,210,0.25)'; g.fillRect(x, gy + (E.H - gy) * 0.55, 90, 5); }
      for (const k of o.lamps || [0.12, 0.88]) streetLamp(g, ((X(k) + 150 - sc) % (E.W + 300) + E.W + 300) % (E.W + 300) - 150, gy, E.H * 0.3, true, o.details ? t : undefined);
      break; }
    case 'street': {
      depth(g, D.mid, () => { wall(g, '#15171d', '#1d212a'); skyline(g, gy - E.H * 0.05, { color: '#1b1f27', seed: 21, n: 10, hmin: 0.3, hvar: 0.25, lit: 0.12, off: (o.scroll || 0) * 60 * t * 0.45 }); });
      g.fillStyle = '#16181d'; g.fillRect(-60, gy, E.W + 120, E.H); ln(g, [[-60, gy], [E.W + 60, gy]], { lw: 2, la: 0.4 });
      if (o.neonDoor !== undefined && o.neonDoor !== false) { const dx = X(o.neonDoor === true ? 0.32 : o.neonDoor), dh = E.H * 0.34; box(g, dx - 60, gy - dh, 120, dh, { fill: '#0b0b0f', line: accent(), la: 0.9, lw: 3 }); g.save(); g.globalCompositeOperation = 'lighter'; const gr = g.createLinearGradient(0, gy - dh, 0, gy); gr.addColorStop(0, alpha(accent(), 0.05)); gr.addColorStop(1, alpha(accent(), 0.45)); g.fillStyle = gr; g.fillRect(dx - 56, gy - dh + 4, 112, dh - 4); g.restore(); light(g, dx, gy - dh * 0.5, dh * 0.8, accent(), 0.2); M.neon = [dx, gy]; }
      if (o.busstop !== false) { const sx = X(o.busX ?? 0.72), sw = X(0.2); box(g, sx - sw / 2, gy - E.H * 0.36, sw, 10, { fill: '#30333b' }); ln(g, [[sx - sw / 2 + 6, gy - E.H * 0.36], [sx - sw / 2 + 6, gy]], { lw: 5 }); ln(g, [[sx + sw / 2 - 6, gy - E.H * 0.36], [sx + sw / 2 - 6, gy]], { lw: 5 }); g.fillStyle = 'rgba(160,180,210,0.07)'; g.fillRect(sx - sw / 2 + 8, gy - E.H * 0.35, sw - 16, E.H * 0.3); bench(g, sx, gy, sw * 0.7); light(g, sx, gy - E.H * 0.34, sw * 0.6, '#d8e4ff', 0.25); box(g, sx + sw / 2 + 20, gy - E.H * 0.42, 34, 26, { fill: '#2f6fd0', r: 3 }); M.bus = { seat: [sx, gy], x: sx }; }
      streetLamp(g, X(o.lampX ?? 0.55), gy, E.H * 0.42, true, o.details ? t : undefined);
      if (o.rain !== false) { rain(g, t, { n: 180, gy: o.details ? gy : undefined }); g.save(); g.globalAlpha = 0.12; g.fillStyle = '#9fb0d0'; for (let i = 0; i < 10; i++) g.fillRect(X(0.05 + i * 0.1), gy + 12 + (i % 3) * 18, 70, 3); g.restore(); }
      break; }
    case 'lockers': {
      depth(g, D.wall, () => wall(g, '#1c1d22', '#23252c')); floor(g, gy, '#1e1f24'); const n = 16, lw = E.W / n, top = gy - E.H * 0.5, cs = ['#3d5277', '#3d5277', '#6b3f3f', '#3d5277', '#3d5277', '#3d5277', '#6b3f3f'];
      for (let i = 0; i < n; i++) { const x = i * lw; box(g, x + 2, top, lw - 4, E.H * 0.5, { fill: cs[(i * 3) % cs.length], line: '#151619', la: 0.8, r: 3 }); ln(g, [[x + lw * 0.3, top + E.H * 0.12], [x + lw * 0.3, top + E.H * 0.18]], { lw: 3, la: 0.6 }); for (let k = 0; k < 3; k++) ln(g, [[x + lw * 0.55, top + 20 + k * 10], [x + lw * 0.8, top + 20 + k * 10]], { lw: 2, la: 0.3 }); }
      if (o.board !== false) { const bx = X(o.boardX ?? 0.68); box(g, bx - 110, top - E.H * 0.17, 220, 130, { fill: '#8a6a45', r: 8 }); const nc = ['#f4e48b', '#bcdaf5', '#f4e48b', '#f2f0ea']; for (let i = 0; i < 4; i++) box(g, bx - 90 + i * 46, top - E.H * 0.15 + (i % 2) * 22, 38, 42, { fill: nc[i], line: null, r: 2 }); }
      break; }
    case 'classroom': {
      depth(g, D.wall, () => { wall(g, '#1e2027', '#24262e'); windowBox(g, X(0.08), Y(0.18), X(0.16), Y(0.28), { sky: o.sky || 'day', t });
        box(g, X(0.62), Y(0.17), X(0.3), Y(0.3), { fill: '#2b3a33', line: '#8c7a68', r: 4 }); text(g, o.board || 'x + 4 = 10', X(0.77), Y(0.27), { size: 46, font: FONT_NARR, weight: 700, color: '#d8ddd5' }); text(g, 'x = ?', X(0.72), Y(0.37), { size: 46, font: FONT_NARR, weight: 700, color: '#d8ddd5' });
        oval(g, X(0.47), Y(0.18), 26, 26, { fill: '#e9e6df', line: '#555' }); { const am = o.details ? t * 0.105 : 0, ah = o.details ? t * 0.009 + 1.57 : 1.57; ln(g, [[X(0.47), Y(0.18)], [X(0.47) + Math.sin(am) * 16, Y(0.18) - Math.cos(am) * 16]], { color: '#222', lw: 3, la: 1 }); ln(g, [[X(0.47), Y(0.18)], [X(0.47) + Math.sin(ah) * 12, Y(0.18) - Math.cos(ah) * 12]], { color: '#222', lw: 3, la: 1 }); } });
      floor(g, gy, '#1d1e23');
      for (const k of o.desks || [0.2, 0.45, 0.7]) table(g, X(k) + 60, gy, 150, E.H * 0.16, { fill: '#5a4a3c' });
      break; }
    case 'court': {
      depth(g, D.sky, () => vgrad(g, [[0, '#2a2038'], [1, '#7a4a5c']], 0, gy - E.H * 0.1)); depth(g, D.mid, () => skyline(g, gy - E.H * 0.1, { color: '#2a2234', seed: 5, n: 12, hmin: 0.12, hvar: 0.18, lit: 0.25 }));
      g.fillStyle = '#b77a45'; g.fillRect(-60, gy - E.H * 0.1, E.W + 120, E.H); ln(g, [[-60, gy + E.H * 0.06], [E.W + 60, gy + E.H * 0.06]], { lw: 3, color: '#f0d6b0', la: 0.5 });
      g.save(); g.strokeStyle = 'rgba(200,200,210,0.25)'; g.lineWidth = 1.5; const ft = gy - E.H * 0.42, fb = gy - E.H * 0.1; for (let x = -200; x < E.W + 200; x += 26) { g.beginPath(); g.moveTo(x, fb); g.lineTo(x + (fb - ft), ft); g.moveTo(x, ft); g.lineTo(x + (fb - ft), fb); g.stroke(); } g.restore(); ln(g, [[-60, gy - E.H * 0.42], [E.W + 60, gy - E.H * 0.42]], { lw: 3, la: 0.5 });
      const hx = X(o.hoopX ?? 0.84); ln(g, [[hx, gy], [hx, gy - E.H * 0.5]], { lw: 7, color: '#3d4048', la: 1 }); box(g, hx - 70, gy - E.H * 0.56, 90, 60, { fill: '#e9e6df', line: '#444', r: 2 }); oval(g, hx - 80, gy - E.H * 0.47, 26, 6, { fill: null, line: '#e2562b', lw: 4, la: 1 });
      streetLamp(g, X(0.55), gy - E.H * 0.1, E.H * 0.35); bench(g, X(o.benchX ?? 0.3), gy - E.H * 0.06, 220); M.bench = [X(o.benchX ?? 0.3), gy - E.H * 0.06];
      break; }
    case 'cafe': {
      wall(g, '#2a2019', '#33271f'); floor(g, gy, '#241b15');
      const wx = X(0.22), ww = X(0.56); box(g, wx, Y(0.16), ww, Y(0.42), { fill: '#141821', line: '#6b5644', r: 4 }); g.save(); g.beginPath(); g.rect(wx, Y(0.16), ww, Y(0.42)); g.clip(); skyline(g, Y(0.58), { color: '#1d2230', seed: 13, n: 9, hmin: 0.12, hvar: 0.2, lit: 0.35 }); rain(g, t, { n: 70, a: 0.3 }); g.restore();
      ln(g, [[wx + ww / 2, Y(0.16)], [wx + ww / 2, Y(0.58)]], { lw: 4, color: '#6b5644', la: 1 });
      const lx = X(o.lampX ?? 0.5); ln(g, [[lx, -10], [lx, Y(0.2)]], { lw: 2, color: '#666' }); obj(g, (c) => { c.moveTo(lx - 40, Y(0.26)); c.lineTo(lx + 40, Y(0.26)); c.lineTo(lx + 12, Y(0.2)); c.lineTo(lx - 12, Y(0.2)); c.closePath(); }, { fill: '#c99a3a', line: null }); light(g, lx, Y(0.27), E.H * 0.55, PAL.lamp, 0.45);
      table(g, lx, gy, 260, E.H * 0.2, { fill: '#5a3f2c' }); M.table = { left: [lx - 190, gy], right: [lx + 190, gy], top: gy - E.H * 0.2 };
      plant(g, X(0.9), gy, 160);
      break; }
    case 'gym': {
      wall(g, '#141417', '#1a1a1e'); floor(g, gy, '#111114'); for (let i = 0; i < 8; i++) ln(g, [[X(i / 7), gy], [X(i / 7) + (i - 3.5) * 40, E.H]], { lw: 1, la: 0.12 });
      beam(g, X(o.spot ?? 0.5), -20, X(o.spot ?? 0.5) - 380, X(o.spot ?? 0.5) + 380, gy + 60, '#ffe2b0', 0.1); if (o.details) beamDust(g, t, X(o.spot ?? 0.5), -20, X(o.spot ?? 0.5) - 380, X(o.spot ?? 0.5) + 380, gy + 60, 30);
      if (o.bag !== false) punchBag(g, X(o.bagX ?? 0.62), Y(0.1), E.H * 0.42, { t, swing: o.swing, hits: o.hits, from: o.hitFrom, hitY: o.hitY });
      if (o.barbell) barbell(g, X(o.barbellX ?? 0.3), gy, 220);
      break; }
    case 'stairs': {
      fillAll(g, '#0f0f12'); const n = 9, sx = X(0.1), sy = gy, dx = (E.W * 0.85) / n, dy = (E.H * 0.62) / n;
      if (classic()) obj(g, (c) => { c.moveTo(sx, sy + 200); for (let i = 0; i < n; i++) { c.lineTo(sx + i * dx, sy - i * dy); c.lineTo(sx + (i + 1) * dx, sy - i * dy); } c.lineTo(E.W + 60, sy - n * dy); c.lineTo(E.W + 60, E.H + 60); c.lineTo(sx, E.H + 60); c.closePath(); }, { fill: '#25262c', line: PAL.line, la: 0.5 });
      else {   // bac bo tron mem (ve tay), mat bac sang hon thanh dung
        const P = [[sx - 40, sy + 200], [sx - 40, sy]]; for (let i = 0; i < n; i++) P.push([sx + i * dx, sy - i * dy], [sx + (i + 1) * dx, sy - i * dy]); P.push([E.W + 60, sy - n * dy]);
        const r = Math.min(dx, dy) * 0.32, path = (c) => { c.moveTo(P[0][0], P[0][1]); for (let i = 1; i < P.length - 1; i++) c.arcTo(P[i][0], P[i][1], P[i + 1][0], P[i + 1][1], r); c.lineTo(P[P.length - 1][0], P[P.length - 1][1]); };
        obj(g, (c) => { path(c); c.lineTo(E.W + 60, E.H + 60); c.lineTo(sx - 40, E.H + 60); c.closePath(); }, { fill: '#202126', line: null });
        g.save(); g.beginPath(); path(g); g.strokeStyle = alpha('#c9ccd4', 0.42); g.lineWidth = 2.2; g.lineJoin = 'round'; g.stroke(); g.restore();
      }
      if (o.top !== false) light(g, E.W * 0.98, sy - n * dy, E.H * 0.5, o.topColor || '#ffd9a0', 0.35);
      M.step = (k) => [sx + (k + 0.5) * dx, sy - k * dy]; M.steps = n;
      break; }
    case 'hill': {
      const cl = classic();
      depth(g, D.sky, () => { vgrad(g, cl ? [[0, '#2a1c2e'], [0.45, '#6b3446'], [0.8, '#c4604a'], [1, '#e8915a']] : [[0, '#160f12'], [0.45, '#3e2422'], [0.82, '#a85a36'], [1, '#e08a4c']], 0, gy); light(g, X(0.55), gy - E.H * 0.06, E.W * 0.4, '#ffb070', cl ? 0.45 : 0.5); });
      // day nui: ban cu gap khuc; ban moi luon mem, mau nau am
      for (const [c, a, s, dd] of cl ? [['#4a2a3a', 0.18, 2, D.far], ['#3a2030', 0.12, 5, D.mid]] : [['#3a2422', 0.2, 2, D.far], ['#24171a', 0.13, 5, D.mid]]) depth(g, dd, () => {
        g.fillStyle = c; g.beginPath(); g.moveTo(-160, gy + 4); const r = rng(s), pts = []; for (let i = 0; i <= 10; i++) pts.push([-60 + i * (E.W + 120) / 10, gy - E.H * a * (0.4 + r())]);
        if (cl) pts.forEach((p) => g.lineTo(p[0], p[1])); else { g.lineTo(pts[0][0], pts[0][1]); for (let i = 1; i < pts.length; i++) { const m = [(pts[i - 1][0] + pts[i][0]) / 2, (pts[i - 1][1] + pts[i][1]) / 2]; g.quadraticCurveTo(pts[i - 1][0], pts[i - 1][1], m[0], m[1]); } g.lineTo(pts[10][0], pts[10][1]); }
        g.lineTo(E.W + 160, gy + 4); g.closePath(); g.fill(); });
      g.fillStyle = '#c87a50'; g.fillRect(-60, gy, E.W + 120, E.H * 0.04); g.fillStyle = cl ? '#18121a' : '#110c0e'; g.beginPath(); g.moveTo(X(0.18), E.H + 20); g.quadraticCurveTo(X(0.45), gy - E.H * 0.33, X(0.72), E.H + 20); g.closePath(); g.fill();
      if (cl) ln(g, [[X(0.25), E.H * 0.97], [X(0.45), gy - E.H * 0.16]], { color: '#e8915a', lw: 2, la: 0.4 });
      else { g.save(); g.beginPath(); g.moveTo(X(0.18), E.H + 20); g.quadraticCurveTo(X(0.45), gy - E.H * 0.33, X(0.72), E.H + 20); g.strokeStyle = alpha('#e8915a', 0.45); g.lineWidth = 2; g.stroke(); g.restore(); }   // vien sang hat tu mat troi len suon doi
      M.top = [X(0.45), 0.5 * (E.H + 20) + 0.5 * (gy - E.H * 0.33)];   // dinh doi that (dinh duong cong), het lo lung
      break; }
    case 'mirror': if (!classic()) {   // guong oval tren be (nhu phim mau), nen toi trong; crack / crackAt: vet nut lan tu tam
      depth(g, D.wall, () => wall(g, '#111115', '#16171c')); ln(g, [[-60, gy], [E.W + 60, gy]], { lw: 1.6, la: 0.3 });
      const mx = X(o.mirrorX ?? 0.55), ry = E.H * 0.2, rx = ry * 0.66, bt = gy - E.H * 0.075, cy = bt - ry - E.H * 0.01;
      obj(g, (c) => c.roundRect(mx - rx * 1.05, gy - E.H * 0.042, rx * 2.1, E.H * 0.042, E.H * 0.016), { fill: '#2a2b31', line: '#5b5d66', lw: 2, la: 0.7 });
      obj(g, (c) => c.roundRect(mx - rx * 1.25, bt, rx * 2.5, E.H * 0.035, E.H * 0.016), { fill: '#33343b', line: '#6b6d76', lw: 2, la: 0.7 });
      M.mirrorClip = (c) => { c.beginPath(); c.ellipse(mx, cy, rx, ry, 0, 0, Math.PI * 2); c.clip(); };
      g.save(); M.mirrorClip(g); g.fillStyle = '#121318'; g.fillRect(mx - rx, cy - ry, rx * 2, ry * 2); g.strokeStyle = 'rgba(220,225,235,0.05)'; g.lineWidth = rx * 0.18; g.beginPath(); g.moveTo(mx - rx * 0.6, cy + ry * 0.2); g.lineTo(mx + rx * 0.1, cy - ry * 0.8); g.stroke(); g.restore();
      M.mirrorFrame = () => {
        const k = o.crackAt !== undefined ? clamp((t - o.crackAt) / 0.35) : o.crack ? 1 : 0;
        if (k > 0) { const r = rng(o.seed || 17); g.save(); M.mirrorClip(g); g.strokeStyle = 'rgba(225,228,238,0.8)'; g.lineWidth = 1.6; g.lineJoin = 'round'; for (let i = 0; i < 9; i++) { let a = (i / 9) * Math.PI * 2 + r() * 0.5, x = mx + (r() - 0.5) * rx * 0.2, y = cy - ry * 0.1 + (r() - 0.5) * ry * 0.2; g.beginPath(); g.moveTo(x, y); const L = (0.7 + r() * 0.6) * ry * k; for (let s = 0; s < 4; s++) { a += (r() - 0.5) * 0.7; x += Math.cos(a) * L / 4; y += Math.sin(a) * L / 4; g.lineTo(x, y); } g.stroke(); } g.restore(); }
        obj(g, (c) => c.ellipse(mx, cy, rx, ry, 0, 0, Math.PI * 2), { fill: null, line: '#8e919b', lw: 7, la: 0.9 }); obj(g, (c) => c.ellipse(mx, cy, rx - 6, ry - 6, 0, 0, Math.PI * 2), { fill: null, line: '#3b3d45', lw: 3, la: 1 });
      };
      M.mirror = { x: mx, y: cy - ry, w: rx * 2, h: ry * 2, cy, rx, ry, in: [mx, cy + ry * 0.92] };   // moc "mirror.in": dung TRONG guong (kem inMirror: true, behind: true)
      break; } else {
      depth(g, D.wall, () => { wall(g, '#1b1d22', '#202228'); g.save(); g.strokeStyle = 'rgba(200,205,215,0.09)'; g.lineWidth = 2; for (let x = -70; x < E.W + 70; x += 70) { g.beginPath(); g.moveTo(x, -60); g.lineTo(x, E.H + 60); g.stroke(); } for (let y = -70; y < E.H + 70; y += 70) { g.beginPath(); g.moveTo(-60, y); g.lineTo(E.W + 60, y); g.stroke(); } g.restore(); });
      const mx = X(o.mirrorX ?? 0.55), mw = X(0.18), mh = Y(0.36); box(g, mx - mw / 2, Y(0.24), mw, mh, { fill: '#2b3038', line: PAL.line, r: 10 }); box(g, mx - mw * 0.35, Y(0.2), mw * 0.7, 10, { fill: '#e8ecf5', line: null, r: 5 }); light(g, mx, Y(0.2), mw * 0.8, '#e8ecf5', 0.35);
      box(g, mx - mw * 0.6, gy - E.H * 0.2, mw * 1.2, E.H * 0.06, { fill: '#c9ccd4', line: '#666', r: 6 });
      M.mirror = { x: mx, y: Y(0.24), w: mw, h: mh };
      break; }
    case 'sofa': {   // phong khach toi: sofa giua phong (moc sofa.seat, sofa.left, sofa.right — dung pose sit / sitphone), cua so (window: true), den cay (lamp: true)
      depth(g, D.wall, () => { wall(g, '#111115', '#16171c'); if (o.window) windowBox(g, VX(o.windowX ?? 0.78), Y(0.22), X(0.1), Y(0.2), { sky: o.sky || 'moon', t }); }); ln(g, [[-60, gy], [E.W + 60, gy]], { lw: 1.6, la: 0.3 });
      const sx = VX(o.sofaX ?? 0.45), sw = E.vertical ? E.W * 0.72 : X(o.sofaW ?? 0.3), seat = E.H * 0.065, back = E.H * 0.17, arm = E.H * 0.1, aw = sw * 0.08, col = o.sofaColor || '#2c2a33', ed = '#6d6878';
      obj(g, (c) => c.roundRect(sx - sw / 2 + aw * 0.5, gy - back, sw - aw, back - seat * 0.6, E.H * 0.025), { fill: shade(col, -0.08), line: ed, lw: 2, la: 0.6 });   // lung tua
      obj(g, (c) => c.roundRect(sx - sw / 2 + aw * 0.6, gy - seat - E.H * 0.012, sw - aw * 1.2, seat * 0.75, E.H * 0.014), { fill: col, line: ed, lw: 2, la: 0.6 });   // dem ngoi
      for (const d of [-1, 1]) obj(g, (c) => c.roundRect(sx + d * (sw / 2 - aw / 2) - aw / 2, gy - arm, aw, arm - E.H * 0.012, E.H * 0.02), { fill: shade(col, 0.04), line: ed, lw: 2, la: 0.6 });   // tay vin
      obj(g, (c) => c.rect(sx - sw / 2 + aw * 0.3, gy - E.H * 0.018, sw - aw * 0.6, E.H * 0.012), { fill: shade(col, -0.2), line: null }); for (const d of [-1, 1]) ln(g, [[sx + d * (sw / 2 - aw), gy - E.H * 0.008], [sx + d * (sw / 2 - aw * 1.1), gy]], { lw: 3, color: '#45434c', la: 1 });
      if (o.lamp) { const lx = X(o.lampX ?? 0.18); ln(g, [[lx, gy], [lx, gy - E.H * 0.42]], { lw: 3, color: '#55575f', la: 1 }); obj(g, (c) => { c.moveTo(lx - 40, gy - E.H * 0.42); c.lineTo(lx + 40, gy - E.H * 0.42); c.lineTo(lx + 24, gy - E.H * 0.48); c.lineTo(lx - 24, gy - E.H * 0.48); c.closePath(); }, { fill: '#c99a3a', line: null }); light(g, lx, gy - E.H * 0.42, E.H * 0.45, PAL.lamp, 0.35); }
      M.sofa = { seat: [sx - sw * 0.15, gy], left: [sx - sw * 0.28, gy], right: [sx + sw * 0.22, gy], x: sx };
      break; }
    case 'kitchen': {
      depth(g, D.wall, () => { wall(g, '#1c1e24', '#22242b'); windowBox(g, X(0.45), Y(0.2), X(0.12), Y(0.2), { sky: o.sky || 'moon', t }); }); floor(g, gy);
      box(g, X(0.08), gy - E.H * 0.5, X(0.11), E.H * 0.5, { fill: '#3a3d45', r: 6 }); ln(g, [[X(0.08), gy - E.H * 0.3], [X(0.19), gy - E.H * 0.3]], { lw: 2, la: 0.5 });
      box(g, X(0.25), gy - E.H * 0.2, X(0.6), E.H * 0.2, { fill: '#2c2e35', r: 3 }); box(g, X(0.25), gy - E.H * 0.22, X(0.6), 14, { fill: '#4a4d55', r: 3 }); box(g, X(0.62), Y(0.17), X(0.22), E.H * 0.16, { fill: '#2c2e35', r: 3 });
      if (o.lamp) light(g, X(0.5), gy - E.H * 0.24, E.H * 0.4, PAL.lamp, 0.3);
      break; }
    case 'doorway': {
      depth(g, D.wall, () => wall(g, '#121216', '#18181d')); floor(g, gy); door(g, X(o.doorX ?? 0.62), gy, X(0.1), E.H * 0.45, { open: o.doorOpen ?? 1 }); M.door = [X(o.doorX ?? 0.62), gy];
      break; }
    default: wall(g); floor(g, gy);
  }
  if (o.dim) { g.save(); g.fillStyle = `rgba(0,0,0,${o.dim})`; g.fillRect(-60, -60, E.W + 120, E.H + 120); g.restore(); }
  M.avoid = avoidOf(kind, o, gy);
  return M;
}
// vung cam cho chu (chu tu dat khong de len; --check bao loi neu de): [ten, x0, y0, x1, y1] toa do the gioi
function avoidOf(kind, o, gy) {
  const A = [];
  if (kind === 'bedroom') {
    const bx = VX(o.bedX ?? 0.27), nx = bx - E.W * (E.vertical ? 0.1 : 0.045);
    if (o.window !== false) { const wx = VX(o.windowX ?? 0.5), wy = Y(0.24), ww = E.vertical ? E.W * 0.26 : X(0.115); A.push(['cửa sổ', wx - 10, wy - 10, wx + ww + 10, wy + Y(0.2) + 10]); }
    const cl = classic(), calOn = cl ? o.calendar !== false : !!o.calendar, deskOn = cl ? o.desk !== false : !!(o.desk || o.lamp || o.laptop);
    if (calOn && !E.vertical) { const cx = X(o.calX ?? 0.79), w = X(0.055); A.push(['lịch', cx - 6, Y(0.26) - 6, cx + w + 6, Y(0.26) + w * 1.1 + 6]); }
    if (o.clock !== false) A.push(['đồng hồ', nx - 62, gy - 160, nx + 62, gy - 90]);
    if (deskOn && !E.vertical) { const dx = X(o.deskX ?? 0.84), dw = X(0.15), dh = E.H * 0.17, lx = dx - dw * 0.38; A.push(['đèn bàn', lx - 70, gy - dh - 115, lx + 45, gy - dh + 5]); }
  } else if (kind === 'mirror') { const mx = X(o.mirrorX ?? 0.55), mw = X(0.18), ry = E.H * 0.2, rx = ry * 0.66, cy = gy - E.H * 0.085 - ry; if (classic()) A.push(['gương', mx - mw * 0.6, Y(0.2) - 14, mx + mw * 0.6, gy - E.H * 0.14]); else A.push(['gương', mx - rx - 10, cy - ry - 10, mx + rx + 10, gy - E.H * 0.075]); }
  else if (kind === 'street') {
    if (o.neonDoor !== undefined && o.neonDoor !== false) { const dx = X(o.neonDoor === true ? 0.32 : o.neonDoor), dh = E.H * 0.34; A.push(['cửa neon', dx - 64, gy - dh - 6, dx + 64, gy]); }
    if (o.busstop !== false) { const sx = X(o.busX ?? 0.72), sw = X(0.2); A.push(['biển xe buýt', sx + sw / 2 + 14, gy - E.H * 0.42 - 6, sx + sw / 2 + 60, gy - E.H * 0.42 + 32]); }
  }
  else if (kind === 'classroom') A.push(['bảng', X(0.62), Y(0.17), X(0.92), Y(0.47)], ['đồng hồ', X(0.47) - 32, Y(0.18) - 32, X(0.47) + 32, Y(0.18) + 32], ['cửa sổ', X(0.08) - 8, Y(0.18) - 8, X(0.24) + 8, Y(0.46) + 8]);
  else if (kind === 'sofa' && o.window) A.push(['cửa sổ', VX(o.windowX ?? 0.78) - 10, Y(0.22) - 10, VX(o.windowX ?? 0.78) + X(0.1) + 10, Y(0.42) + 10]);
  else if (kind === 'kitchen') A.push(['cửa sổ', X(0.45) - 8, Y(0.2) - 8, X(0.57) + 8, Y(0.4) + 8]);
  else if (kind === 'gym' && o.bag !== false) { const b = X(o.bagX ?? 0.62); A.push(['bao cát', b - E.H * 0.09, Y(0.1), b + E.H * 0.09, Y(0.1) + E.H * 0.42]); }
  else if (kind === 'court') { const hx = X(o.hoopX ?? 0.84); A.push(['rổ bóng', hx - 75, gy - E.H * 0.57, hx + 25, gy - E.H * 0.44]); }
  else if (kind === 'lockers' && o.board !== false) { const b = X(o.boardX ?? 0.68), top = gy - E.H * 0.5; A.push(['bảng ghim', b - 112, top - E.H * 0.17 - 2, b + 112, top - E.H * 0.17 + 132]); }
  else if (kind === 'doorway') { const d = X(o.doorX ?? 0.62), w = X(0.05); A.push(['cửa', d - w, gy - E.H * 0.45, d + w, gy]); }
  else if (kind === 'cafe') { const lx = X(o.lampX ?? 0.5); A.push(['đèn', lx - 42, Y(0.2), lx + 42, Y(0.27)]); }
  return A;
}
export const SETS = ['bedroom', 'city', 'street', 'lockers', 'classroom', 'court', 'cafe', 'gym', 'stairs', 'hill', 'mirror', 'kitchen', 'void', 'black', 'doorway'];
