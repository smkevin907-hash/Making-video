"""new_project.py — tao thu muc du an video moi.
  python tools/new_project.py --name never-forget --title "What If You Never Forgot Anything?" [--aspect 16:9|9:16] [--resolution 1080p] [--style dusk] [--captions] [--pack doodle --lang vi]
  python tools/new_project.py --name five-min --title "FIVE MINUTES" --pack dem [--mode cinematic|legacy]   (2.0: ngach self-improvement mac dinh cinematic)
"""
import argparse, os, sys
sys.path.insert(0, os.path.dirname(os.path.abspath(__file__)))
from common import write_json
ap = argparse.ArgumentParser()
ap.add_argument("--name", required=True); ap.add_argument("--title", default="")
ap.add_argument("--aspect", default="16:9"); ap.add_argument("--resolution", default="1080p")
ap.add_argument("--style", default="dusk"); ap.add_argument("--captions", action="store_true")
ap.add_argument("--pack", default="", help="bo phong cach ngach (vd doodle); de trong = nguoi que What If")
ap.add_argument("--lang", default="en")
ap.add_argument("--mode", default="", help="cinematic (phim 2D vector kieu dien anh, 30 fps, bo phim) | legacy (san khau 2D cu). De trong: cinematic neu --pack dem/phim/cine, con lai legacy")
ap.add_argument("--render", default="2d", help="che do cinematic: 2d (mac dinh, bo phim) | 3d (Three.js 2.5D, bo cine, tuy chon)")
a = ap.parse_args()
# 2.0: ngach self-improvement mac dinh dung che do cinematic; --mode legacy giu y ban 2D cu
mode = a.mode or ("cinematic" if a.pack in ("dem", "cine", "phim") else "legacy")
if mode == "cinematic":
    if a.pack in ("", "dem", "cine", "phim"): a.pack = "cine" if a.render == "3d" else "phim"
    a.style = "flat"
    if a.aspect == "9:16": print("Luu y: che do cinematic chua ho tro 9:16 -> dung legacy (--mode legacy) cho Shorts"); mode = "legacy"; a.pack = "dem"
root = os.path.join(os.path.dirname(os.path.dirname(os.path.abspath(__file__))), "projects", a.name)
for d in ["input", "anh", "timeline", "story", "scenes/sets", "scenes/shots", "build", "out"]: os.makedirs(os.path.join(root, d), exist_ok=True)
cfg = os.path.join(root, "config.json")
if not os.path.exists(cfg):
    c = {"title": a.title or a.name, "aspect": a.aspect, "resolution": a.resolution, "fps": 30 if mode == "cinematic" else 24, "style": a.style,
         "captions": bool(a.captions or a.aspect == "9:16"), "bars": None, "fadeIn": 0.4, "fadeOut": 0.8,
         "pack": a.pack, "lang": a.lang, "music": {"enabled": True, "gainDb": -15}, "sfx": {"enabled": True, "gainDb": -4}, "loudness": -14}
    if mode == "cinematic":
        c["mode"] = "cinematic"; c["captions"] = False
        if a.render == "3d": c["render"] = "3d"
    write_json(cfg, c)
print("Du an:", root)
