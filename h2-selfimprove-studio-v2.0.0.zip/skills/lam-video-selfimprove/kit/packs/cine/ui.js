// ui.js — chu tren hinh cua che do cinematic (ve 2D sau khi dung 3D, don vi logic 1920x1080). Toi da 2 font: Be Vietnam Pro + Caveat.
// - say / tempt: thoai gan vao dau nhan vat (chieu 3D -> 2D moi khung), can giua tren dau, nen mo nhe, moi nguoi 1 mau chu;
//   hien bang mo dan + truot 12 px (say) hoac go tung chu (tempt). Tu ne dau / nguoi khac va mep khung.
// - narr: chu ke chuyen giua tren (dai toi mem phia sau, tu xuong duoi neu de dau). big: dong nhan giua khung (man den).
// - hud: bo dem goc trai tren, nay + loe mau nhan khi doi so. card: the ket.
// Moi hop chu ghi vao LAY (window.__lay) de --check do de chu / cat mep.
import { E, clamp, lerp, ease } from '/engine/core.js';
import { toScreen } from '/engine/cine/index.js';
import { accent, CAST3 } from './rig.js';

export const SANS = '"Be Vietnam Pro"', HAND = '"Caveat"';
export const LAY = { actors: [], texts: [], objs: [] };
export function layReset() { LAY.actors = []; LAY.texts = []; LAY.objs = []; window.__lay = LAY; }
const ovl = (a, b) => Math.max(0, Math.min(a[2], b[2]) - Math.max(a[0], b[0])) * Math.max(0, Math.min(a[3], b[3]) - Math.max(a[1], b[1]));
function rr(g, x, y, w, h, r) { g.beginPath(); g.roundRect(x, y, w, h, r); }
const inkOf = (who) => (who === 'voice' ? accent() : (CAST3[who] || CAST3.hero).ink || '#f4f6fb');
function lines(g, s, maxW) { const out = []; for (const para of String(s).split('\n')) { let cur = ''; for (const w of para.split(' ')) { const tr = cur ? cur + ' ' + w : w; if (g.measureText(tr).width > maxW && cur) { out.push(cur); cur = w; } else cur = tr; } out.push(cur); } return out; }

// hop dau cua dien vien tren man hinh (de ne chu + de --check do)
export function actorBoxes(actors, cam) {
  const out = [];
  for (const a of actors) {
    if (!a.rg.root.visible) continue;
    const c = toScreen(a.headPos(), cam), top = toScreen(a.headTop(), cam), r = Math.max(8, Math.abs(c.y - top.y) * 0.85);
    if (!c.vis) continue;
    out.push({ who: a.who, voice: a.voice, head: [c.x, c.y, r], top: [top.x, top.y], box: [c.x - r, c.y - r, c.x + r, c.y + r * 4], ok: true });
  }
  LAY.actors = out.map((b) => ({ who: b.who, voice: b.voice, ok: true, head: b.head, box: b.box }));
  return out;
}

// texts: danh sach chu cua canh (kind narr | big | tempt | say | sign). ctx: { boxes (actorBoxes), black: true (man den) }
export function drawTexts(g, lt, list, ctx = {}) {
  // vat can: dau moi nhan vat + than nguoi (tru bong den: chu cam do duoc phep nam canh than no)
  const placed = ctx.hudRows ? [[40, 20, 440, 40 + 58 * ctx.hudRows]] : [], heads = (ctx.boxes || []).flatMap((b) => [[b.head[0] - b.head[2], b.head[1] - b.head[2], b.head[0] + b.head[2], b.head[1] + b.head[2]], ...(b.voice ? [] : [[b.box[0], b.box[1] + (b.box[3] - b.box[1]) * 0.45, b.box[2], b.box[3]]])]);
  const free = (b) => b[0] > 24 && b[2] < E.W - 24 && b[1] > 20 && b[3] < E.H - 20 && !heads.some((h) => ovl(h, b) > 0) && !placed.some((p) => ovl(p, b) > 0);
  // cho trong gan (cx, cy) nhat cho hop w x h (tam): thu luoi 9 x 7 vi tri, uu tien gan diem mong muon, phat nhe khi lech ngang
  const spot = (w, h, cx, cy, kx = 1) => {
    if (free([cx - w / 2, cy - h / 2, cx + w / 2, cy + h / 2])) return [cx, cy];
    let best = null, bd = 1e18;
    for (let i = 0; i <= 8; i++) for (let j = 0; j <= 6; j++) {
      const x = lerp(w / 2 + 40, E.W - w / 2 - 40, i / 8), y = lerp(h / 2 + 40, E.H - h / 2 - 40, j / 6), b = [x - w / 2, y - h / 2, x + w / 2, y + h / 2];
      if (!free(b)) continue; const d = ((x - cx) * kx) ** 2 + (y - cy) ** 2; if (d < bd) { bd = d; best = [x, y]; }
    }
    return best;
  };
  // man den: cac dong narr / big xep doc quanh giua
  const blk = (list || []).filter((x) => ctx.black && (x.kind === 'narr' || x.kind === 'big'));
  if (blk.length) {
    const sizes = blk.map((x) => (x.kind === 'big' ? x.size ?? 74 : x.size ?? 56)), gap = 26, tot = sizes.reduce((p, s) => p + s * 1.25, 0) + gap * (blk.length - 1);
    let y = E.H * (ctx.cy ?? 0.48) - tot / 2;
    blk.forEach((x, i) => {
      const s = sizes[i], at = x.at ?? 0.3 + i * 0.9, k = clamp((lt - at) / 0.8); y += s * 0.62;
      if (k > 0) { g.save(); g.globalAlpha = ease.inOut(k) * (x.a ?? 1); g.font = `${x.kind === 'big' ? 700 : 600} ${s}px ${SANS}`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillStyle = x.color || '#f2f3f6'; g.fillText(x.t, E.W / 2, y + (1 - ease.out(k)) * 12); g.restore(); }
      const mw = (() => { g.save(); g.font = `${x.kind === 'big' ? 700 : 600} ${s}px ${SANS}`; const m = g.measureText(x.t).width; g.restore(); return m; })();
      LAY.texts.push({ t: x.t, box: [E.W / 2 - mw / 2, y - s * 0.6, E.W / 2 + mw / 2, y + s * 0.6] }); y += s * 0.63 + gap;
    });
  }
  for (const x of list || []) {
    if (blk.includes(x)) continue;
    const at = x.at ?? 0.3, dur = x.dur ?? 1e9, k = clamp((lt - at) / 0.35), out = clamp((lt - (at + dur)) / 0.3);
    if (lt < at || out >= 1) continue;
    const a = ease.inOut(k) * (1 - out);
    if (x.kind === 'narr' || x.kind === 'big') {
      const s = x.kind === 'big' ? 64 : x.size ?? 46; g.save(); g.font = `${x.kind === 'big' ? 700 : 600} ${s}px ${SANS}`;
      const want = x.pos === 'bottom' ? E.H * 0.86 : x.pos === 'center' ? E.H / 2 : E.H * 0.12;
      // giua tren (hoac duoi) neu trong; can mat chiem giua -> chuyen sang cot 1/3 trai / phai (cot hep hon, xuong dong)
      let L = lines(g, x.t, E.W * 0.7), w = Math.max(...L.map((l) => g.measureText(l).width)), h = L.length * s * 1.25, cx = E.W / 2, cy = want;
      const fits = (ww, hh, xx, yy) => free([xx - ww / 2 - 20, yy - hh / 2 - 10, xx + ww / 2 + 20, yy + hh / 2 + 10]);
      if (!fits(w, h, cx, cy)) {
        const alt = [E.H * 0.12, E.H * 0.86, E.H * 0.2, E.H * 0.78].find((yy) => fits(w, h, cx, yy));
        if (alt !== undefined) cy = alt;
        else { L = lines(g, x.t, E.W * 0.28); w = Math.max(...L.map((l) => g.measureText(l).width)); h = L.length * s * 1.25; const p = spot(w + 40, h + 20, E.W / 2, want, 0.3); if (p) [cx, cy] = p; }
      }
      const b = [cx - w / 2 - 20, cy - h / 2 - 10, cx + w / 2 + 20, cy + h / 2 + 10]; placed.push(b); LAY.texts.push({ t: x.t, box: b });
      // dai toi mem sau chu (dam bao do tuong phan >= 4.5:1 tren nen sang)
      const gr = g.createLinearGradient(0, b[1] - 30, 0, b[3] + 30); gr.addColorStop(0, 'rgba(6,7,10,0)'); gr.addColorStop(0.5, `rgba(6,7,10,${0.5 * a})`); gr.addColorStop(1, 'rgba(6,7,10,0)');
      g.fillStyle = gr; g.fillRect(b[0] - 160, b[1] - 30, b[2] - b[0] + 320, b[3] - b[1] + 60);
      g.globalAlpha = a; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillStyle = x.color || '#f4f5f8';
      L.forEach((l, i) => g.fillText(l, cx, cy - h / 2 + s * 0.62 + i * s * 1.25 + (1 - ease.out(k)) * 12)); g.restore(); continue;
    }
    if (x.kind === 'say' || x.kind === 'tempt') {
      const who = x.kind === 'tempt' ? (ctx.boxes || []).find((b) => b.voice) ? 'voice' : (x.who || 'hero') : x.who || (ctx.boxes || [])[0]?.who || 'hero';
      const hb = (ctx.boxes || []).find((b) => b.who === who) || (ctx.boxes || []).find((b) => !b.voice) || null;
      const s = x.size ?? 38; g.save(); g.font = `${x.kind === 'tempt' ? 700 : 600} ${s}px ${SANS}`;
      const full = x.t, shown = x.kind === 'tempt' && x.type !== false ? full.slice(0, Math.max(0, Math.floor((lt - at) * (x.cps ?? 16)))) : full;
      const L = lines(g, full, Math.min(E.W * 0.42, 720)), w = Math.max(...L.map((l) => g.measureText(l).width)) + 44, h = L.length * s * 1.25 + 26;
      let cx = hb ? hb.top[0] : E.W / 2, by = hb ? hb.top[1] - 26 : E.H * 0.2;
      const box = (xx, yy) => [xx - w / 2, yy - h, xx + w / 2, yy];
      cx = clamp(cx, w / 2 + 30, E.W - w / 2 - 30); by = clamp(by, h + 30, E.H - 30);
      if (!free(box(cx, by))) { const p = spot(w, h, cx, by - h / 2); if (p) { cx = p[0]; by = p[1] + h / 2; } }   // gan dau nhat ma khong de dau / chu khac
      const b = box(cx, by); placed.push(b); LAY.texts.push({ t: full, box: b });
      const lift = (1 - ease.out(k)) * 12;
      g.globalAlpha = a; g.fillStyle = 'rgba(8,10,16,0.62)'; rr(g, b[0], b[1] + lift, w, h, Math.min(h / 2, 30)); g.fill();
      g.fillStyle = x.color || inkOf(x.kind === 'tempt' ? 'voice' : who); g.textAlign = 'left'; g.textBaseline = 'middle';
      let left = shown.length; L.forEach((l, i) => { const part = l.slice(0, Math.max(0, left)); left -= l.length + 1; const lw = g.measureText(l).width; g.fillText(part, cx - lw / 2, b[1] + lift + 13 + s * 0.62 + i * s * 1.25); });
      g.restore(); continue;
    }
    if (x.kind === 'sign') { g.save(); g.globalAlpha = a; g.font = `700 ${x.size ?? 52}px ${HAND}`; g.textAlign = 'center'; g.fillStyle = x.color || '#f4f5f8'; g.fillText(x.t, (x.x ?? 0.5) * E.W, (x.y ?? 0.2) * E.H); g.restore(); }
  }
}

// bo dem goc trai tren: { rows: [{ label, n, from, to, at, dur, reset }] }. bump: so khac canh truoc -> nay + loe mau nhan 0,8 giay
export function drawHud(g, lt, hud, prev) {
  if (!hud || !hud.rows) return;
  let y = 64;
  for (const r of hud.rows) {
    let n = r.n ?? r.to ?? 0; if (r.from !== undefined && r.to !== undefined) n = Math.round(lerp(r.from, r.to, clamp((lt - (r.at ?? 0.3)) / (r.dur ?? 3))));
    if (r.reset && lt >= r.reset.at) n = r.reset.to ?? 0;
    const pv = prev && prev.rows ? prev.rows.find((q) => q.label === r.label) : null, changed = pv && (pv.n ?? pv.to) !== (r.n ?? r.from ?? r.to) && hud.bump !== false && r.bump !== false;
    const bk = changed ? clamp(lt / 0.8) : 1, sc = changed ? 1 + Math.sin(Math.PI * clamp(lt / 0.35)) * 0.18 : 1;
    g.save(); g.textBaseline = 'middle'; g.textAlign = 'left';
    g.font = `600 26px ${SANS}`; if ('letterSpacing' in g) g.letterSpacing = '4px'; g.fillStyle = 'rgba(236,238,244,0.82)'; g.fillText(String(r.label || 'DAY').toUpperCase(), 64, y);
    const lw = g.measureText(String(r.label || 'DAY').toUpperCase()).width + 18;
    g.translate(64 + lw, y); g.scale(sc, sc); if ('letterSpacing' in g) g.letterSpacing = '1px'; g.font = `700 40px ${SANS}`; g.fillStyle = changed && bk < 1 ? accent() : '#f4f5f8'; g.fillText(r.comma === false ? String(n) : Number(n).toLocaleString('en-US'), 0, 0);
    g.restore(); LAY.texts.push({ t: 'HUD', box: [56, y - 26, 64 + lw + 140, y + 26], hud: true }); y += 58;
  }
}

// the ket: tu khoa to (go tung chu), gach chan mau nhan ve dan, dong phu trang, dong phu 2 mau nhan
export function drawCard(g, lt, a) {
  const word = a.word || '', n = a.type === false ? word.length : Math.floor(clamp((lt - 0.3) / (a.typeDur ?? 1.2)) * word.length);
  g.save(); g.textAlign = 'center'; g.textBaseline = 'middle'; g.font = `700 ${a.size ?? 120}px ${SANS}`; if ('letterSpacing' in g) g.letterSpacing = '10px'; g.fillStyle = '#f4f5f8';
  const W = g.measureText(word).width; g.textAlign = 'left'; g.fillText(word.slice(0, n), E.W / 2 - W / 2, E.H * 0.42); g.restore();
  const k = ease.inOut(clamp((lt - 0.3 - (a.typeDur ?? 1.2)) / 0.6)); g.fillStyle = accent(); g.fillRect(E.W / 2 - W / 2, E.H * 0.42 + 78, W * k, 6);
  LAY.texts.push({ t: word, box: [E.W / 2 - W / 2, E.H * 0.42 - 70, E.W / 2 + W / 2, E.H * 0.42 + 84] });
  const sub = (s, y, at, c) => { if (!s) return; const kk = ease.inOut(clamp((lt - at) / 0.7)); if (kk <= 0) return; g.save(); g.globalAlpha = kk; g.font = `600 44px ${SANS}`; g.textAlign = 'center'; g.textBaseline = 'middle'; g.fillStyle = c; g.fillText(s, E.W / 2, y + (1 - kk) * 10); const w = g.measureText(s).width; g.restore(); LAY.texts.push({ t: s, box: [E.W / 2 - w / 2, y - 28, E.W / 2 + w / 2, y + 28] }); };
  sub(a.part, E.H * 0.25, 0.1, 'rgba(236,238,244,0.7)'); sub(a.sub, E.H * 0.6, (a.typeDur ?? 1.2) + 0.9, '#e9ebf0'); sub(a.sub2, E.H * 0.67, a.sub2At ?? (a.typeDur ?? 1.2) + 2.0, accent());
}
