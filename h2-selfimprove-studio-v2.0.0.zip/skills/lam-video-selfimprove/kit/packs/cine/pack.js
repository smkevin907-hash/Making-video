// pack.js — bo phong cach "cine": phim ngan kieu dien anh 2.5D minh hoa (Three.js) cho ngach self-improvement.
// config.json: "mode": "cinematic" (player tu chon pack nay). Dung lai ngu phap shots.json cua packs/dem (cung ten mau canh, cung args).
// Chu tren hinh: 2 font Be Vietnam Pro (sans) + Caveat (viet tay). Font cua bo 2D chi nap de ve cac canh tu lui ve 2D.
import './templates.js';
import { planFilm } from './director.js';
export * from './sets.js';
export * from './rig.js';
export * from './props.js';
export * from './ui.js';
export { coverage, plan, planFilm } from './director.js';
export { thumb } from '/packs/dem/thumb.js';

function css(href) { return new Promise((r) => { const l = document.createElement('link'); l.rel = 'stylesheet'; l.href = href; l.onload = r; l.onerror = r; document.head.appendChild(l); }); }
export async function init(E) {
  await Promise.all(['be-vietnam-pro/600.css', 'be-vietnam-pro/700.css', 'caveat/700.css', 'comic-neue/700.css', 'comic-neue/400.css', 'luckiest-guy/400.css'].map((f) => css('/node_modules/@fontsource/' + f)));
  await Promise.all([document.fonts.load('700 40px "Be Vietnam Pro"', 'Day after day.'), document.fonts.load('600 40px "Be Vietnam Pro"', 'Day after day.'), document.fonts.load('700 40px "Caveat"', 'just one more'), document.fonts.load('700 40px "Comic Neue"', 'x')]);
  E.cfg.style = 'flat';            // mau / vignette / grain do hau ky 3D lam (engine/cine/post.js), player khong chinh mau them
  if (E.cfg.bars === null || E.cfg.bars === undefined) E.cfg.bars = 'none';
  E.cfg.captionStyle = 'none';
  // dao dien ca phim: goc may tung canh + luat giua cac canh + chuyen canh co ly do (tat dinh, chi doc shots.json)
  if (E.cfg.mode === 'cinematic') planFilm(E.shots, E.story || {});
}
// phim khong loi doc: khong co phu de tu dong
export function captions() {}
