// vanish.js — bong den cam do tan bien. actor voice: "vanish": { at, style, from, pieces, flash, words, wind, dur, seed } (hoac "vanish": <giay>)
//   burst (mac dinh): lay da (vet nut sang lan tu diem bi danh, phong nhe) -> chop co tam + tia sang + vong song -> hinh bong den vo thanh
//          manh meo khong deu (cat tu chinh hinh luc do), bay ra co luc can, xoay, hoi bay LEN, vien nguoi dan, tan thanh tan lua; chu cam do vo tung chu cai.
//   ash: ra dan tu chan len thanh tro, tro bay theo gio, khong chop. classic: manh tam giac cu (fx shards, style: "classic").
// fx { kind: "shards" } trong canh co bong den -> tu dung burst (giu "style": "classic" de quay ve cach cu).
import { E, clamp, lerp, ease, rng, noise, alpha, mix, text, measure } from '/engine/core.js';
import { accent, light, temptFont } from './ink.js';

const sstep = (x) => { x = clamp(x); return x * x * (3 - 2 * x); };
export const BURST_PRE = 0.35;                 // giay lay da truoc cu vo
const LIFE = { burst: 3.2, ash: 4.2 };

export function vanishSpec(a, args) {
  let v = a.vanish;
  if (v === undefined && a.who === 'voice') { const s = (args.fx || []).find((f) => f.kind === 'shards' && f.style !== 'classic'); if (s) v = { at: s.at ?? 0, style: s.style || 'burst', from: s.from, seed: s.seed }; }
  if (v === undefined || v === false || v === null) return null;
  if (typeof v === 'number') v = { at: v };
  const style = v.style === 'ash' ? 'ash' : 'burst', t0 = v.at ?? a.out ?? 0;
  return { t0, style, from: v.from ?? 'hero', pieces: v.pieces, flash: v.flash !== false && style === 'burst', words: v.words !== false, wind: v.wind,
    dur: v.dur ?? 1.8, seed: v.seed ?? Math.floor((typeof a.x === 'number' ? a.x : 0.37) * 9973 + t0 * 131 + 17), end: t0 + (style === 'ash' ? (v.dur ?? 1.8) : 0) + LIFE[style] };
}

// chup hinh bong den o khoanh khac vo vao canvas rieng (toa do the gioi), cat thanh manh theo luoi meo; manh nao trung hinh moi giu
const _snap = new Map();
export function vanishSnap(spec, x, y, h, draw, heroX) {
  const key = `${spec.seed}|${spec.style}|${E.PX}|${E.W}|${Math.round(x)}|${Math.round(y)}`; let S = _snap.get(key);
  if (S) return S;
  const x0 = x - 0.8 * h, y0 = y - 1.2 * h, w = 1.6 * h, hh = 1.35 * h, k = Math.min(E.PX, 1400 / w);
  const cv = document.createElement('canvas'); cv.width = Math.ceil(w * k); cv.height = Math.ceil(hh * k); const c = cv.getContext('2d');
  c.setTransform(k, 0, 0, k, -x0 * k, -y0 * k); const r = draw(c) || null;
  const data = c.getImageData(0, 0, cv.width, cv.height).data, A = (wx, wy) => { const i = Math.floor((wy - y0) * k), j = Math.floor((wx - x0) * k); return i < 0 || j < 0 || i >= cv.height || j >= cv.width ? 0 : data[(i * cv.width + j) * 4 + 3]; };
  // khung chat quanh hinh (bo vien phat sang mo)
  let bx0 = x0 + w, bx1 = x0, by0 = y0 + hh, by1 = y0; const thr = spec.style === 'ash' ? 14 : 140;   // ash: luoi phu ca quang sang de quang cung ra thanh tro
  for (let i = 0; i < cv.height; i += 3) for (let j = 0; j < cv.width; j += 3) if (data[(i * cv.width + j) * 4 + 3] > thr) { const wx = x0 + j / k, wy = y0 + i / k; bx0 = Math.min(bx0, wx); bx1 = Math.max(bx1, wx); by0 = Math.min(by0, wy); by1 = Math.max(by1, wy); }
  if (bx1 <= bx0) { bx0 = x0; bx1 = x0 + w; by0 = y0; by1 = y0 + hh; }
  const pad = 0.03 * h; bx0 -= pad; bx1 += pad; by0 -= pad; by1 += pad;
  const R = rng(spec.seed), C = spec.style === 'ash' ? 13 : Math.round((spec.pieces ?? 44) ** 0.5 * 0.85), Rw = spec.style === 'ash' ? 22 : Math.round((spec.pieces ?? 44) / C * 1.35);
  const cw = (bx1 - bx0) / C, ch = (by1 - by0) / Rw, V = [];
  for (let i = 0; i <= C; i++) { V.push([]); for (let j = 0; j <= Rw; j++) { const ed = i === 0 || i === C || j === 0 || j === Rw; V[i].push([bx0 + i * cw + (ed ? 0 : (R() - 0.5) * 0.85 * cw), by0 + j * ch + (ed ? 0 : (R() - 0.5) * 0.85 * ch)]); } }
  const cell = [], P = [];
  for (let i = 0; i < C; i++) for (let j = 0; j < Rw; j++) {
    const q = [V[i][j], V[i + 1][j], V[i + 1][j + 1], V[i][j + 1]]; let hit = 0;
    for (let u = 0; u < 4; u++) for (let v = 0; v < 4; v++) { const s = (u + 0.5) / 4, t = (v + 0.5) / 4, px = lerp(lerp(q[0][0], q[1][0], s), lerp(q[3][0], q[2][0], s), t), py = lerp(lerp(q[0][1], q[1][1], s), lerp(q[3][1], q[2][1], s), t); if (A(px, py) > (spec.style === 'ash' ? 14 : 60)) hit++; }
    cell.push(hit / 16 > 0.06);
    if (hit / 16 <= 0.06) continue;
    const polys = spec.style === 'burst' && R() < 0.6 ? (R() < 0.5 ? [[q[0], q[1], q[2]], [q[0], q[2], q[3]]] : [[q[0], q[1], q[3]], [q[1], q[2], q[3]]]) : [q];
    for (const poly of polys) { const cx = poly.reduce((s, p) => s + p[0], 0) / poly.length, cy = poly.reduce((s, p) => s + p[1], 0) / poly.length; P.push({ poly, c: [cx, cy], r: [R(), R(), R(), R(), R(), R(), R()] }); }
  }
  // diem bi danh: phia nguoi hung (ngang nguc), hoac toa do from, hoac giua than
  const mid = [(bx0 + bx1) / 2, by0 + (by1 - by0) * 0.38], f = spec.from;
  const hit = Array.isArray(f) ? [f[0] <= 1.5 ? f[0] * E.W : f[0], f[1] <= 1.5 ? f[1] * E.H : f[1]] : f === 'hero' && heroX !== undefined ? [mid[0] + Math.sign(heroX - mid[0] || 1) * (bx1 - bx0) * 0.28, mid[1]] : mid;
  // vet nut: chi nhung canh chung (giua 2 o trung hinh) chay XUYEN TAM tu diem bi danh, bo bot ngau nhien, be gap khuc -> nut toa ra, khong thanh luoi
  const cracks = [], radial = (a, b) => { const mx = (a[0] + b[0]) / 2 - hit[0], my = (a[1] + b[1]) / 2 - hit[1], ex = b[0] - a[0], ey = b[1] - a[1]; return Math.abs(mx * ex + my * ey) / ((Math.hypot(mx, my) || 1) * (Math.hypot(ex, ey) || 1)); };
  const addCrack = (a, b) => { if (radial(a, b) < 0.72 || R() < 0.3) return; const n = 3, pts = [a]; for (let s = 1; s < n; s++) { const u = s / n, nx = -(b[1] - a[1]), ny = b[0] - a[0], L = Math.hypot(nx, ny) || 1, o = (R() - 0.5) * 0.35 * L; pts.push([lerp(a[0], b[0], u) + nx / L * o, lerp(a[1], b[1], u) + ny / L * o]); } pts.push(b); cracks.push(pts); };
  for (let i = 0; i < C; i++) for (let j = 0; j < Rw; j++) {
    if (!cell[i * Rw + j]) continue;
    if (i + 1 < C && cell[(i + 1) * Rw + j]) addCrack(V[i + 1][j], V[i + 1][j + 1]);
    if (j + 1 < Rw && cell[i * Rw + j + 1]) addCrack(V[i][j + 1], V[i + 1][j + 1]);
  }
  S = { cv, x0, y0, w, hh, h, U: h / 100, pieces: P, cracks, hit, box: [bx0, by0, bx1, by1], r, wind: spec.wind ?? (heroX !== undefined ? Math.sign(mid[0] - heroX || 1) : 1) };
  _snap.set(key, S); if (_snap.size > 12) _snap.delete(_snap.keys().next().value);
  return S;
}

function piecePath(g, poly) { g.beginPath(); g.moveTo(poly[0][0], poly[0][1]); for (let i = 1; i < poly.length; i++) g.lineTo(poly[i][0], poly[i][1]); g.closePath(); }

// vi tri / xoay / co / do trong cua 1 manh sau t giay tu luc roi
function burstState(S, p, t) {
  const [r1, r2, r3, r4, r5] = p.r, h = S.h, dx = p.c[0] - S.hit[0], dy = p.c[1] - S.hit[1], dist = Math.hypot(dx, dy) || 1;
  const near = 1 - clamp(dist / (h * 0.9)), V = h * (0.45 + 1.3 * near) * (0.7 + 0.6 * r1), k = 3.0, ang = Math.atan2(dy, dx) + (r2 - 0.5) * 0.6;
  const d = V * (1 - Math.exp(-k * t)) / k, life = 0.9 + 0.9 * r5;
  return { x: p.c[0] + Math.cos(ang) * d + noise(t * 1.3 + r3 * 50, 7) * h * 0.03 * t, y: p.c[1] + Math.sin(ang) * d - h * 0.1 * t * t,
    rot: (r3 - 0.5) * 10 * (1 - Math.exp(-k * t)) / k + (r4 - 0.5) * 0.6 * t, s: 1 - 0.55 * sstep(t / life), a: 1 - sstep((t - 0.35 * life) / (0.65 * life)), heat: Math.exp(-t * 4.5), life };
}
function ashState(S, p, t) {
  const [r1, r2, r3, r4] = p.r, h = S.h, k = 1.5;
  return { x: p.c[0] + S.wind * h * 0.35 * (0.5 + r1) * (1 - Math.exp(-k * t)) / k + noise(t * 0.9 + r2 * 40, 3) * h * 0.05 * t, y: p.c[1] - h * (0.2 + 0.1 * r3) * t - h * 0.05 * t * t,
    rot: (r4 - 0.5) * 2 * t, s: 1 - 0.85 * sstep(t / 1.6), a: 1 - sstep((t - 0.3) / 1.3), heat: 0, gray: sstep(t / 0.8), life: 1.6 };
}
const releaseAt = (S, spec, p) => spec.style === 'ash' ? spec.dur * clamp((S.box[3] - p.c[1]) / (S.box[3] - S.box[1])) + p.r[5] * 0.12 : 0;

function drawPiece(g, S, p, st, hot) {
  g.save(); g.globalAlpha *= st.a; g.translate(st.x, st.y); g.rotate(st.rot); g.scale(st.s, st.s); g.translate(-p.c[0], -p.c[1]);
  piecePath(g, p.poly); g.save(); g.clip(); g.drawImage(S.cv, S.x0, S.y0, S.w, S.hh);
  if (st.gray) { g.globalCompositeOperation = 'source-atop'; g.fillStyle = alpha('#77737a', 0.85 * st.gray); g.fillRect(S.x0, S.y0, S.w, S.hh); }
  if (st.heat > 0.02) { g.globalCompositeOperation = 'lighter'; g.fillStyle = alpha(hot, 0.16 * st.heat); g.fillRect(S.x0, S.y0, S.w, S.hh); }
  if (st.edge) { g.globalCompositeOperation = 'lighter'; g.fillStyle = alpha(mix(hot, '#ffd9a8', 0.35 * st.edge), 0.55 * st.edge); g.fillRect(S.x0, S.y0, S.w, S.hh); }   // mep dang chay (ash): sang mem, khong ke vien o
  g.restore();
  if (st.heat > 0.02) { const e = st.edge ?? st.heat; g.lineJoin = 'round'; g.lineWidth = (0.6 + 1.6 * e) * S.U; g.strokeStyle = alpha(mix('#fff4e0', hot, clamp(1.2 - e)), 0.15 + 0.75 * e); g.shadowColor = hot; g.shadowBlur = 7 * S.U * e; piecePath(g, p.poly); g.stroke(); }
  g.restore();
}

// ve phan than bong den (the gioi, trong may quay) o giay lt. Truoc t0: vet nut (burst) / vien chay (ash) ve DE len than dang ve binh thuong.
export function vanishDraw(g, lt, spec, S) {
  const t = lt - spec.t0, hot = accent(), h = S.h;
  if (t < 0) {   // lay da: vet nut sang lan ra tu diem bi danh
    if (spec.style !== 'burst') return; const q = clamp((t + BURST_PRE) / BURST_PRE);
    light(g, S.hit[0], S.hit[1], h * 0.45 * q, hot, 0.4 * q);
    g.save(); g.globalCompositeOperation = 'lighter'; g.lineCap = 'round';
    for (const cp of S.cracks) {
      const d0 = Math.hypot(cp[0][0] - S.hit[0], cp[0][1] - S.hit[1]), d1 = Math.hypot(cp[cp.length - 1][0] - S.hit[0], cp[cp.length - 1][1] - S.hit[1]), pts = d0 <= d1 ? cp : cp.slice().reverse();
      const rv = clamp(q * 1.7 - Math.min(d0, d1) / (h * 0.75)); if (rv <= 0) continue;
      const n = (pts.length - 1) * rv, path = () => { g.beginPath(); g.moveTo(pts[0][0], pts[0][1]); for (let s = 1; s <= Math.ceil(n); s++) { const u = Math.min(1, n - (s - 1)); g.lineTo(lerp(pts[s - 1][0], pts[s][0], u), lerp(pts[s - 1][1], pts[s][1], u)); } };
      path(); g.strokeStyle = alpha(hot, 0.8); g.lineWidth = 1.8 * S.U; g.shadowColor = hot; g.shadowBlur = 9 * S.U; g.stroke();
      path(); g.strokeStyle = alpha('#fff6e8', 0.8 * q); g.lineWidth = 0.6 * S.U; g.shadowBlur = 0; g.stroke();
    }
    g.restore(); return;
  }
  // manh vo / tro
  for (const p of S.pieces) {
    const tr = t - releaseAt(S, spec, p);
    if (spec.style === 'ash' && tr < 0) { drawPiece(g, S, p, { x: p.c[0], y: p.c[1], rot: 0, s: 1, a: 1, heat: 0, edge: tr > -0.25 ? sstep(1 + tr / 0.25) : 0 }, hot); continue; }   // chua roi: dung yen, mep sap roi chay sang dan
    const st = spec.style === 'ash' ? ashState(S, p, tr) : burstState(S, p, tr);
    if (st.a > 0.005) drawPiece(g, S, p, st, hot);
  }
  // tan lua bay len (moi manh 3 hat), lac theo gio
  g.save(); g.globalCompositeOperation = 'lighter';
  for (const p of S.pieces) for (let j = 0; j < 3; j++) {
    const rr = rng(Math.floor(p.r[6] * 1e6) + j), tr = t - releaseAt(S, spec, p), base = spec.style === 'ash' ? 0.1 : 0.25, life0 = spec.style === 'ash' ? 1.6 : 0.9 + 0.9 * p.r[4];
    const tau = life0 * (base + 0.22 * j) * (0.8 + 0.4 * rr()), e = tr - tau, el = 1.3 + 1.1 * rr(); if (e <= 0 || e > el) continue;
    const bs = spec.style === 'ash' ? ashState(S, p, tau) : burstState(S, p, tau), vx = (rr() - 0.5) * h * 0.25 + (spec.style === 'ash' ? S.wind * h * 0.12 : 0);
    const x = bs.x + vx * (1 - Math.exp(-1.6 * e)) / 1.6 + noise(e * 1.4 + j * 9 + p.r[0] * 30, 11) * h * 0.04, y = bs.y - h * (0.06 + 0.06 * rr()) * e * (1 + e);
    const life = e / el, rad = S.U * (0.6 + 1.1 * rr()) * (1 - 0.6 * life), a = Math.sin(Math.PI * Math.min(1, life * 1.1 + 0.05)) ** 0.7;
    const ashy = spec.style === 'ash' && rr() < 0.75, col = ashy ? '#9a959c' : e < 0.25 ? mix('#fff2dc', hot, e / 0.25) : hot;
    if (ashy) { g.globalCompositeOperation = 'source-over'; g.fillStyle = alpha(col, 0.55 * a); } else { g.globalCompositeOperation = 'lighter'; g.fillStyle = alpha(col, 0.9 * a); }
    g.beginPath(); g.arc(x, y, Math.max(0.3, rad), 0, 7); g.fill();
  }
  g.restore();
  // khoi mong noi len
  if (t < 3) for (let i = 0; i < 4; i++) { const r = rng(spec.seed + i * 13), cx = lerp(S.box[0], S.box[2], 0.25 + 0.5 * r()), cy = lerp(S.box[1], S.box[3], 0.2 + 0.5 * r()) - h * (0.15 + 0.1 * r()) * t; light(g, cx + noise(t * 0.5 + i, 5) * h * 0.08, cy, h * (0.18 + 0.22 * t), mix(hot, '#30303a', 0.55), 0.09 * (1 - t / 3) * (spec.style === 'ash' ? 1.4 : 1)); }
  // chop co tam + tia sang + vong song (trong khung canh)
  if (spec.flash && t < 0.75) {
    const P = S.hit, k = t / 0.7, rr = rng(spec.seed + 99);
    light(g, P[0], P[1], h * (0.5 + 1.6 * ease.out(Math.min(1, t / 0.25))), '#fff3e2', clamp((1 - ease.out(clamp(k))) * 1.3));
    light(g, P[0], P[1], h * 0.6, hot, 0.5 * (1 - clamp(k)));
    g.save(); g.globalCompositeOperation = 'lighter';
    if (t < 0.6) for (let i = 0; i < 22; i++) { const an = rr() * Math.PI * 2, L = h * (0.5 + 1.2 * rr()) * ease.out(Math.min(1, t / 0.3)), wd = S.U * (1.5 + 3 * rr()) * (1 - t / 0.6); g.fillStyle = alpha('#fff6e6', 0.75 * (1 - t / 0.6) ** 1.5); g.beginPath(); g.moveTo(P[0] + Math.cos(an + 1.57) * wd, P[1] + Math.sin(an + 1.57) * wd); g.lineTo(P[0] + Math.cos(an) * L, P[1] + Math.sin(an) * L); g.lineTo(P[0] - Math.cos(an + 1.57) * wd, P[1] - Math.sin(an + 1.57) * wd); g.closePath(); g.fill(); }
    if (t < 0.55) { const q = t / 0.55; g.strokeStyle = alpha(mix('#ffffff', hot, q), 0.6 * (1 - q)); g.lineWidth = S.U * 4 * (1 - q); g.beginPath(); g.arc(P[0], P[1], h * (0.15 + 1.1 * ease.out(q)), 0, 7); g.stroke(); }
    g.restore();
  }
}

// chop trang ca man (ngoai may quay), ngan: loa 1-2 khung roi tan
export function vanishScreen(g, lt, spec) {
  if (!spec.flash) return; const t = lt - spec.t0; if (t < 0 || t > 0.45) return;
  const a = t < 0.05 ? 0.88 : 0.88 * (1 - ease.out((t - 0.05) / 0.4));
  g.save(); g.setTransform(E.PX, 0, 0, E.PX, 0, 0); g.fillStyle = alpha('#fff6ea', a); g.fillRect(0, 0, E.W, E.H); g.restore();
}

// chu cam do vo tung chu cai (toa do man hinh). P = diem bi danh tren man hinh. Tra ve false neu chua toi luc vo.
export function vanishLetters(g, lt, spec, str, x, y, size, col, a0, P) {
  const t = lt - spec.t0; if (t < 0) return false;
  const lines = String(str).split('\n'), R = rng(spec.seed + 7);
  g.save();
  lines.forEach((l, i) => {
    const lw = measure(g, l, size, temptFont(), 700), yy = y + i * size * 1.05;
    for (let j = 0; j < l.length; j++) {
      const ch = l[j], r = [R(), R(), R(), R(), R()]; if (ch === ' ') continue;
      const cx = x - lw / 2 + measure(g, l.slice(0, j), size, temptFont(), 700) + measure(g, ch, size, temptFont(), 700) / 2;
      let px, py, rot, sc, al, c = col;
      if (spec.style === 'ash') {
        const d0 = j / Math.max(1, l.length) * 0.6 + r[0] * 0.2, tt = Math.max(0, t - d0);
        px = cx + (spec.wind ?? 1) * 70 * tt * (0.6 + r[1]) + noise(tt + j, 4) * 6; py = yy - 35 * tt * (0.6 + r[2]); rot = (r[3] - 0.5) * 0.8 * tt; sc = 1 - 0.3 * sstep(tt / 1.5);
        al = a0 * (1 - sstep((tt - 0.15) / 1.3)); c = mix(col, '#8d8890', sstep(tt / 0.9));
      } else {
        const dx = cx - P[0], dy = yy - P[1], dist = Math.hypot(dx, dy) || 1, near = 1 - clamp(dist / 900), d0 = 0.03 + r[0] * 0.2, tt = Math.max(0, t - d0), V = (220 + 420 * near) * (0.7 + 0.6 * r[1]), k = 2.4;
        const dd = V * (1 - Math.exp(-k * tt)) / k; px = cx + dx / dist * dd; py = yy + dy / dist * dd - 40 * tt * tt; rot = (r[2] - 0.5) * 5 * (1 - Math.exp(-k * tt)) / k;
        sc = 1 + 0.35 * tt; al = a0 * (1 - sstep((t - d0 - 0.15 - r[3] * 0.45) / (1.0 + 0.6 * r[4]))); c = mix('#ffffff', col, clamp(tt / 0.25));
        if (tt > 0 && tt < 0.22) { const dg = V * (1 - Math.exp(-k * Math.max(0, tt - 0.04))) / k; text(g, ch, cx + dx / dist * dg, yy + dy / dist * dg, { size, font: temptFont(), weight: 700, color: c, a: al * 0.3, rot }); }   // vet nhoe theo huong bay
      }
      if (al > 0.01) { g.save(); g.translate(px, py); g.rotate(rot); g.scale(sc, sc); text(g, ch, 0, 0, { size, font: temptFont(), weight: 700, color: c, a: al, glowColor: alpha(col, 0.55) }); g.restore(); }
    }
  });
  g.restore(); return true;
}
