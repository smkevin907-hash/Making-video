// post.js — hau ky cinematic: canh -> target HDR co depth -> DOF (nhoe theo |z - tieu diem|, tien canh lan ra ngoai) -> bloom nhe co nguong
// -> phoi sang + ACES -> sRGB -> nang vung toi (giu chi tiet) -> vignette -> grain co seed (theo so khung). Shader tu viet, khong can EffectComposer.
// Tham so (P): { focus (m), aperture (0 = tat DOF), bloom, threshold, vignette, grain, exposure, lift: [r,g,b], frame, maxCoc (px o 1080p) }
import * as THREE from 'three';

const VS = 'varying vec2 vUv; void main(){ vUv = uv; gl_Position = vec4(position.xy, 0.0, 1.0); }';
const COC = `
#include <packing>
uniform sampler2D tDepth; uniform float cNear, cFar, focus, aperture, K, maxCoc;
float viewZ(vec2 uv){ return -perspectiveDepthToViewZ(texture2D(tDepth, uv).x, cNear, cFar); }
// vong nhoe (px o do phan giai that): aperture * K * |z - f| / z  (z -> vo cuc: aperture * K)
float cocOf(float z){ return min(aperture * K * abs(z - focus) / max(z, 1e-3), maxCoc); }
`;
// gather 1 lan (golden angle), lam o nua do phan giai. a = muc nhoe can tron (gom ca tien canh mo lan sang vung net)
const DOF_FS = `
varying vec2 vUv; uniform sampler2D tColor; uniform vec2 texel; uniform float radStep;
${COC}
void main(){
  float z0 = viewZ(vUv), s0 = cocOf(z0);
  vec3 c = texture2D(tColor, vUv).rgb, acc = c; float tot = 1.0, fg = 0.0, r = radStep, ang = 0.0;
  for (int i = 0; i < 200; i++) {
    if (r >= maxCoc) break;
    vec2 tc = vUv + vec2(cos(ang), sin(ang)) * texel * r;
    vec3 sc = texture2D(tColor, tc).rgb; float zs = viewZ(tc), ss = cocOf(zs);
    if (zs > z0) ss = clamp(ss, 0.0, s0 * 2.0);
    float m = smoothstep(r - 0.5, r + 0.5, ss);
    acc += mix(acc / tot, sc, m); tot += 1.0;
    if (zs < z0 && zs < focus) fg = max(fg, m * ss);
    r += radStep / r; ang += 2.39996323;
  }
  gl_FragColor = vec4(acc / tot, max(s0, fg));
}`;
const BRIGHT_FS = `varying vec2 vUv; uniform sampler2D tColor; uniform float threshold;
void main(){ vec3 c = texture2D(tColor, vUv).rgb; float l = dot(c, vec3(0.2126, 0.7152, 0.0722)); gl_FragColor = vec4(min(c * smoothstep(threshold, threshold * 1.6 + 0.05, l), vec3(4.0)), 1.0); }`;
const BLUR_FS = `varying vec2 vUv; uniform sampler2D tColor; uniform vec2 dir;
void main(){ vec3 s = texture2D(tColor, vUv).rgb * 0.2270;
  s += (texture2D(tColor, vUv + dir * 1.3846).rgb + texture2D(tColor, vUv - dir * 1.3846).rgb) * 0.3162;
  s += (texture2D(tColor, vUv + dir * 3.2308).rgb + texture2D(tColor, vUv - dir * 3.2308).rgb) * 0.0703;
  gl_FragColor = vec4(s, 1.0); }`;
const FINAL_FS = `varying vec2 vUv; uniform sampler2D tColor, tDof, tB1, tB2; uniform vec2 res;
uniform float bloom, exposure, vignette, grain, frame, dofOn, sat, dim; uniform vec3 lift;
${COC}
vec3 aces(vec3 x){ return clamp((x * (2.51 * x + 0.03)) / (x * (2.43 * x + 0.59) + 0.14), 0.0, 1.0); }
vec3 toSRGB(vec3 c){ return mix(c * 12.92, 1.055 * pow(c, vec3(1.0 / 2.4)) - 0.055, step(0.0031308, c)); }
// hash12 (Hoskins): khong tao soc doc / ngang tren luoi diem anh nhu ban fract(p * hang so)
float hash(vec2 p){ vec3 p3 = fract(vec3(p.xyx) * 0.1031); p3 += dot(p3, p3.yzx + 33.33); return fract((p3.x + p3.y) * p3.z); }
void main(){
  vec3 c = texture2D(tColor, vUv).rgb;
  if (dofOn > 0.5) { vec4 d = texture2D(tDof, vUv); float k = smoothstep(0.8, 2.6, max(cocOf(viewZ(vUv)), d.a)); c = mix(c, d.rgb, k); }
  c += (texture2D(tB1, vUv).rgb * 0.6 + texture2D(tB2, vUv).rgb * 0.4) * bloom;
  c = toSRGB(aces(c * exposure));
  c = mix(vec3(dot(c, vec3(0.2126, 0.7152, 0.0722))), c, sat) * (1.0 - dim);   // mau ke chuyen (grade): the gioi mat mau / toi dan theo nhip
  vec2 q = (vUv - 0.5) * vec2(res.x / res.y, 1.0);
  c *= 1.0 - vignette * smoothstep(0.35, 1.05, length(q));
  c = lift + c * (1.0 - lift);   // nang vung toi SAU vignette: goc khung toi nhung khong den dac (van thay hat / chi tiet)
  float n = hash(vUv * res + vec2(frame * 17.0, frame * 31.0)) - 0.5;
  c += n * grain * (1.0 - 0.6 * dot(c, vec3(0.333)));
  gl_FragColor = vec4(clamp(c, 0.0, 1.0), 1.0);
}`;

const rt = (w, h, o = {}) => new THREE.WebGLRenderTarget(Math.max(1, w), Math.max(1, h), { type: THREE.HalfFloatType, minFilter: THREE.LinearFilter, magFilter: THREE.LinearFilter, depthBuffer: !!o.depth, ...o });

export class Post {
  constructor(renderer) {
    this.r = renderer; this.w = 0; this.h = 0;
    this.cam = new THREE.OrthographicCamera(-1, 1, 1, -1, 0, 1); this.quad = new THREE.Mesh(new THREE.PlaneGeometry(2, 2)); this.scene = new THREE.Scene(); this.scene.add(this.quad); this.quad.frustumCulled = false;
    const U = () => ({ tDepth: { value: null }, cNear: { value: 0.05 }, cFar: { value: 200 }, focus: { value: 3 }, aperture: { value: 0 }, K: { value: 14 }, maxCoc: { value: 24 } });
    const sm = (fs, u) => new THREE.ShaderMaterial({ vertexShader: VS, fragmentShader: fs, uniforms: u, depthTest: false, depthWrite: false });
    this.mDof = sm(DOF_FS, { ...U(), tColor: { value: null }, texel: { value: new THREE.Vector2() }, radStep: { value: 1.6 } });
    this.mBright = sm(BRIGHT_FS, { tColor: { value: null }, threshold: { value: 1.0 } });
    this.mBlur = sm(BLUR_FS, { tColor: { value: null }, dir: { value: new THREE.Vector2() } });
    this.mFinal = sm(FINAL_FS, { ...U(), tColor: { value: null }, tDof: { value: null }, tB1: { value: null }, tB2: { value: null }, res: { value: new THREE.Vector2() }, bloom: { value: 0.2 }, exposure: { value: 1 }, vignette: { value: 0.4 }, grain: { value: 0.03 }, frame: { value: 0 }, dofOn: { value: 1 }, sat: { value: 1 }, dim: { value: 0 }, lift: { value: new THREE.Vector3() } });
  }
  size(w, h) {
    if (w === this.w && h === this.h) return; this.w = w; this.h = h;
    [this.main, this.dof, this.q1, this.q2, this.e1, this.e2].forEach((t) => t && t.dispose());
    this.main = rt(w, h, { depth: true, samples: 4 }); this.main.depthTexture = new THREE.DepthTexture(w, h); this.main.depthTexture.type = THREE.UnsignedIntType;
    this.dof = rt(Math.ceil(w / 2), Math.ceil(h / 2));
    this.q1 = rt(Math.ceil(w / 4), Math.ceil(h / 4)); this.q2 = rt(Math.ceil(w / 4), Math.ceil(h / 4));
    this.e1 = rt(Math.ceil(w / 8), Math.ceil(h / 8)); this.e2 = rt(Math.ceil(w / 8), Math.ceil(h / 8));
  }
  pass(mat, target) { this.quad.material = mat; this.r.setRenderTarget(target); this.r.render(this.scene, this.cam); }
  blur(src, tmp, w, h) { const b = this.mBlur; b.uniforms.tColor.value = src.texture; b.uniforms.dir.value.set(1 / w, 0); this.pass(b, tmp); b.uniforms.tColor.value = tmp.texture; b.uniforms.dir.value.set(0, 1 / h); this.pass(b, src); }
  render(scene, camera, P = {}) {
    const { w, h } = this, sc = h / 1080, r = this.r;
    r.setRenderTarget(this.main); r.render(scene, camera);
    const set = (m) => { const u = m.uniforms; u.tDepth.value = this.main.depthTexture; u.cNear.value = camera.near; u.cFar.value = camera.far; u.focus.value = P.focus ?? 3; u.aperture.value = P.aperture ?? 0; u.K.value = 14 * sc; u.maxCoc.value = (P.maxCoc ?? 24) * sc; };
    const dofOn = (P.aperture ?? 0) > 0.01;
    if (dofOn) { set(this.mDof); const u = this.mDof.uniforms; u.tColor.value = this.main.texture; u.texel.value.set(1 / w, 1 / h); u.radStep.value = P.quality === 'low' ? 3 : 1.6 * Math.max(1, sc); this.pass(this.mDof, this.dof); }
    // bloom 2 tang (1/4, 1/8)
    this.mBright.uniforms.tColor.value = this.main.texture; this.mBright.uniforms.threshold.value = P.threshold ?? 0.9; this.pass(this.mBright, this.q1);
    this.blur(this.q1, this.q2, this.q1.width, this.q1.height);
    this.mBlur.uniforms.tColor.value = this.q1.texture; this.mBlur.uniforms.dir.value.set(0, 0); this.pass(this.mBlur, this.e1);
    this.blur(this.e1, this.e2, this.e1.width, this.e1.height);
    const f = this.mFinal, u = f.uniforms; set(f);
    u.tColor.value = this.main.texture; u.tDof.value = this.dof.texture; u.tB1.value = this.q1.texture; u.tB2.value = this.e1.texture; u.res.value.set(w, h);
    u.bloom.value = Math.min(P.bloom ?? 0.2, 0.45); u.exposure.value = P.exposure ?? 1; u.vignette.value = P.vignette ?? 0.4; u.grain.value = P.grain ?? 0.03; u.frame.value = P.frame ?? 0; u.dofOn.value = dofOn ? 1 : 0; u.sat.value = P.sat ?? 1; u.dim.value = P.dim ?? 0;
    u.lift.value.set(...(P.lift || [0.02, 0.02, 0.03]));
    this.pass(f, null);
  }
}
