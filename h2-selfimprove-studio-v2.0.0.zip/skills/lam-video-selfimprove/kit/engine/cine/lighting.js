// lighting.js — kieu 2.5D minh hoa: bloom / grain rat nhe (hinh sach nhu phim tham khao). Moi canh mot lightRig: toi thieu 1 nguon chinh + 1 nguon bo tro (+ vignette o post). Nhiet do mau theo cam xuc:
// met / toi = xanh lanh, dong luc = am, hy vong = xanh troi + hoang hon. Bang mau <= 6 mau + 1 mau nhan co nghia.
// lightRig(scene, name, o) -> { palette, accent, exposure, post, update(t) }. o: { key: [x,y,z] (vi tri nguon chinh, vd cua so), keyTarget, practical: [x,y,z] (den ban), phone: [x,y,z], accent }
import * as THREE from 'three';
import { hex } from '../core.js';
import { rng, fbm1 } from './timeline.js';

export const col = (c) => new THREE.Color(...hex(c).map((v) => v / 255)).convertSRGBToLinear();

const RIGS = {
  // phong dem: anh trang xanh lanh qua cua so + den ban am nho + troi toi giu chi tiet
  nightRoom: { bg: '#0c1222', fog: ['#0e1528', 0.035], hemi: ['#3a4f86', '#0b0d16', 0.75], key: { c: '#9db8ff', i: 2.4, kind: 'spot', angle: 0.55, pen: 0.95 }, fill: { c: '#ffb36b', i: 9, d: 6 }, rim: { c: '#6f8fe0', i: 0.6 }, exposure: 1.15, palette: ['#0c1222', '#1c2747', '#3a4f86', '#9db8ff', '#ffb36b'], post: { bloom: 0.12, vignette: 0.42, grain: 0.022, lift: [0.035, 0.04, 0.06] } },
  // anh dien thoai: xanh trang hat len mat tu duoi, phong gan nhu toi
  phoneNight: { bg: '#080b16', fog: ['#0a0f1e', 0.05], hemi: ['#26345c', '#06070c', 0.32], key: { c: '#bcd4ff', i: 1.1, kind: 'spot', angle: 0.45, pen: 0.7 }, fill: { c: '#ffae66', i: 2.2, d: 4 }, rim: { c: '#5a78c8', i: 0.45 }, exposure: 1.2, palette: ['#080b16', '#151d36', '#26345c', '#bcd4ff', '#ffae66'], post: { bloom: 0.15, vignette: 0.5, grain: 0.025, lift: [0.03, 0.035, 0.055] } },
  // ban ngay xam (thieu dong luc): troi u, anh dau, it bao hoa
  dayGrey: { bg: '#b9c0c8', fog: ['#aab2bc', 0.02], hemi: ['#dfe5ee', '#5d6168', 1.5], key: { c: '#fff3e2', i: 2.6, kind: 'dir' }, fill: { c: '#c9d6ea', i: 1.2, d: 9 }, rim: { c: '#ffffff', i: 0.5 }, exposure: 1.0, palette: ['#e4e7eb', '#b9c0c8', '#7d848d', '#3b3f45', '#c94b4b'], post: { bloom: 0.07, vignette: 0.32, grain: 0.018, lift: [0.02, 0.02, 0.025] } },
  // phong tap / noi nong: vang am tu den tran + cua
  gymWarm: { bg: '#2a1c12', fog: ['#3a2818', 0.02], hemi: ['#ffd9a6', '#3a2416', 1.1], key: { c: '#ffcf8a', i: 3.2, kind: 'spot', angle: 0.7, pen: 0.5 }, fill: { c: '#ff9f5a', i: 4, d: 10 }, rim: { c: '#fff0d0', i: 0.7 }, exposure: 1.05, palette: ['#2a1c12', '#6b4326', '#c9874a', '#ffcf8a', '#8a1f2a'], post: { bloom: 0.12, vignette: 0.38, grain: 0.022, lift: [0.04, 0.03, 0.02] } },
  // pho dem: den duong cam + troi xanh dam
  streetNight: { bg: '#0d1530', fog: ['#16203f', 0.03], hemi: ['#2c3e74', '#0a0b12', 0.5], key: { c: '#ffb15c', i: 9, kind: 'spot', angle: 0.6, pen: 0.55 }, fill: { c: '#6d86c8', i: 1.2, d: 30 }, rim: { c: '#ffc985', i: 0.5 }, exposure: 1.1, palette: ['#0d1530', '#1f2c55', '#2c3e74', '#ffb15c', '#ffe2b0'], post: { bloom: 0.18, vignette: 0.45, grain: 0.025, lift: [0.03, 0.035, 0.06] } },
  // hy vong: troi xanh + nang hoang hon / binh minh am
  dawnHope: { bg: '#8fc3ec', fog: ['#c9dff0', 0.012], hemi: ['#bfe0ff', '#5c7a4a', 1.4], key: { c: '#ffd29a', i: 3.4, kind: 'dir' }, fill: { c: '#9cc8ff', i: 1.4, d: 30 }, rim: { c: '#ffe7c4', i: 0.9 }, exposure: 1.0, palette: ['#8fc3ec', '#bfe0ff', '#ffd29a', '#6f9a4f', '#2f3b2a'], post: { bloom: 0.1, vignette: 0.28, grain: 0.016, lift: [0.02, 0.02, 0.02] } },
  // khoang trong toi (man den co bui, the ket)
  void: { bg: '#050507', fog: ['#050507', 0.08], hemi: ['#2a2c36', '#050507', 0.3], key: { c: '#d8dcff', i: 1.2, kind: 'spot', angle: 0.5, pen: 0.8 }, fill: { c: '#ffb36b', i: 0.6, d: 4 }, rim: { c: '#9aa4d8', i: 0.3 }, exposure: 1.0, palette: ['#050507', '#16171d', '#d8dcff'], post: { bloom: 0.1, vignette: 0.55, grain: 0.02, lift: [0.012, 0.012, 0.016] } },
};
export const RIG_NAMES = Object.keys(RIGS);

export function lightRig(scene, name = 'nightRoom', o = {}) {
  const R = RIGS[name] || RIGS.nightRoom, g = new THREE.Group(); g.name = 'lightRig:' + name;
  scene.background = col(o.bg || R.bg);
  scene.fog = new THREE.FogExp2(col(R.fog[0]), o.fog ?? R.fog[1]);
  const hemi = new THREE.HemisphereLight(col(R.hemi[0]), col(R.hemi[1]), (o.ambient ?? 1) * R.hemi[2]); g.add(hemi);
  // nguon chinh: co bong do (shadow map mem)
  const kp = o.key || [-2.5, 3.2, 2.5], kt = o.keyTarget || [0, 0.6, 0];
  let key;
  if (R.key.kind === 'dir') { key = new THREE.DirectionalLight(col(R.key.c), R.key.i * (o.keyK ?? 1)); const sc = key.shadow.camera; sc.left = sc.bottom = -8; sc.right = sc.top = 8; sc.near = 0.5; sc.far = 40; }
  else { key = new THREE.SpotLight(col(R.key.c), R.key.i * 10 * (o.keyK ?? 1), 0, R.key.angle, R.key.pen, 1.2); key.shadow.camera.near = 0.3; key.shadow.camera.far = 30; }
  key.position.set(...kp); key.target.position.set(...kt); key.castShadow = o.shadows !== false;
  key.shadow.mapSize.set(o.shadowSize || 1024, o.shadowSize || 1024); key.shadow.bias = -0.0006; key.shadow.normalBias = 0.02; key.shadow.radius = 4;
  g.add(key, key.target);
  // bo tro: den thuc trong canh (den ban, den tran...) — am
  const fp = o.practical || [1.6, 1.1, -0.6];
  const fill = new THREE.PointLight(col(o.fillColor || R.fill.c), R.fill.i * (o.fillK ?? 1), R.fill.d, 2); fill.position.set(...fp); g.add(fill);
  // vien sang tu sau (tach chu the khoi nen)
  const rim = new THREE.DirectionalLight(col(R.rim.c), R.rim.i * (o.rimK ?? 1)); rim.position.set(...(o.rimPos || [1.5, 2.5, -4])); g.add(rim);
  // anh dien thoai (tuy chon): diem sang lanh rat gan, tat nhanh theo khoang cach
  let phone = null;
  const PH = 0.45;   // do sang anh dien thoai: du hat len mat / ao, khong lam dau toi thanh sang
  if (o.phone) { phone = new THREE.PointLight(col('#c4dcff'), (o.phoneK ?? 1) * PH, 1.4, 2); phone.position.set(...o.phone); g.add(phone); }
  scene.add(g);
  const rig = { name, group: g, key, fill, rim, phone, palette: R.palette.slice(), accent: o.accent || null, exposure: o.exposure ?? R.exposure, post: { ...R.post, ...(o.post || {}) }, fx: [] };
  // nhap nhay rat nhe cua den thuc (tat dinh): khong co doan nao tinh hoan toan
  rig.update = (t) => {
    fill.intensity = R.fill.i * (o.fillK ?? 1) * (1 + fbm1(t * 1.3, 4) * (o.flicker ?? 0.03));
    if (phone) phone.intensity = (o.phoneK ?? 1) * PH * (1 + fbm1(t * 2.1, 9) * 0.08);
    rig.fx.forEach((f) => f(t));
  };
  return rig;
}

// vien sang manh (rim light) cho nhan vat toi: lop phu cong sang theo goc nhin (fresnel), chi sang o mep — mat / dau khong bao gio chay trang.
// Dung: mesh.add(new THREE.Mesh(mesh.geometry, rimMat('#9db8ff'))). strength <= 0.9 (gioi han glow tren mat)
export function rimMat(c, o = {}) {
  return new THREE.ShaderMaterial({
    uniforms: { rc: { value: col(c) }, pw: { value: o.power ?? 3.2 }, st: { value: Math.min(0.9, o.strength ?? 0.65) } },
    vertexShader: 'varying vec3 vN; varying vec3 vV; void main(){ vec4 mv = modelViewMatrix * vec4(position, 1.0); vN = normalize(normalMatrix * normal); vV = normalize(-mv.xyz); gl_Position = projectionMatrix * mv; }',
    fragmentShader: 'uniform vec3 rc; uniform float pw, st; varying vec3 vN; varying vec3 vV; void main(){ float f = pow(1.0 - clamp(dot(normalize(vN), normalize(vV)), 0.0, 1.0), pw); gl_FragColor = vec4(rc * f * st, 1.0); }',
    transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, depthFunc: THREE.LessEqualDepth, fog: false,
  });
}

// mat phong tu phat sang mem (o cua so, den, man hinh) — dung cho "practical" nhin thay duoc
let _glowTex = null;
export function glowTex() {
  if (_glowTex) return _glowTex;
  const c = document.createElement('canvas'); c.width = c.height = 128; const x = c.getContext('2d');
  const gr = x.createRadialGradient(64, 64, 0, 64, 64, 64); gr.addColorStop(0, 'rgba(255,255,255,1)'); gr.addColorStop(0.3, 'rgba(255,255,255,.35)'); gr.addColorStop(1, 'rgba(255,255,255,0)');
  x.fillStyle = gr; x.fillRect(0, 0, 128, 128); _glowTex = new THREE.CanvasTexture(c); return _glowTex;
}
export function glowSprite(c, size, a = 0.6) {
  const s = new THREE.Sprite(new THREE.SpriteMaterial({ map: glowTex(), color: col(c), transparent: true, opacity: a, blending: THREE.AdditiveBlending, depthWrite: false, fog: false }));
  s.scale.set(size, size, 1); return s;
}

// chum sang (hinh non mo, cong sang) tu cua so / den: chi la khoi khong khi sang, khong chieu sang vat
// Mem: mo dan o mep (theo goc nhin) va mo dan ve cuoi chum -> khong thanh "tam kinh" canh sac
export function beam(from, to, r0, r1, c, a = 0.07) {
  const len = new THREE.Vector3(...to).sub(new THREE.Vector3(...from)).length();
  const geo = new THREE.CylinderGeometry(r0, r1, len, 32, 1, true); geo.translate(0, -len / 2, 0);
  const sm = new THREE.ShaderMaterial({
    uniforms: { bc: { value: col(c) }, a: { value: a } },
    vertexShader: 'varying vec3 vN; varying vec3 vV; varying float vY; void main(){ vec4 mv = modelViewMatrix * vec4(position, 1.0); vN = normalize(normalMatrix * normal); vV = normalize(-mv.xyz); vY = uv.y; gl_Position = projectionMatrix * mv; }',
    fragmentShader: 'uniform vec3 bc; uniform float a; varying vec3 vN; varying vec3 vV; varying float vY; void main(){ float e = pow(abs(dot(normalize(vN), normalize(vV))), 2.2); float l = smoothstep(0.0, 0.25, vY) * (0.35 + 0.65 * vY); gl_FragColor = vec4(bc * a * e * l, 1.0); }',
    transparent: true, blending: THREE.AdditiveBlending, depthWrite: false, side: THREE.DoubleSide, fog: false,
  });
  const m = new THREE.Mesh(geo, sm);
  m.position.set(...from); m.lookAt(...to); m.rotateX(-Math.PI / 2); return m;
}

// hat bui trong chum sang: vi tri = ham thuan cua t (troi cham, quay vong trong hop), seed co dinh
export function dust(rig, box, o = {}) {
  const n = o.n ?? 160, r = rng(o.seed ?? 7), base = [], vel = [];
  const [x0, y0, z0, x1, y1, z1] = box, W = [x1 - x0, y1 - y0, z1 - z0];
  for (let i = 0; i < n; i++) { base.push(r(), r(), r()); vel.push((r() - 0.5) * 0.02, 0.004 + r() * 0.012, (r() - 0.5) * 0.02); }
  const pos = new Float32Array(n * 3), geo = new THREE.BufferGeometry(); geo.setAttribute('position', new THREE.BufferAttribute(pos, 3));
  const pts = new THREE.Points(geo, new THREE.PointsMaterial({ map: glowTex(), color: col(o.color || '#dfe6ff'), size: o.size ?? 0.03, transparent: true, opacity: o.a ?? 0.55, blending: THREE.AdditiveBlending, depthWrite: false, sizeAttenuation: true }));
  const fr = (v) => v - Math.floor(v);
  const upd = (t) => {
    for (let i = 0; i < n; i++) for (let k = 0; k < 3; k++) { const j = i * 3 + k; pos[j] = [x0, y0, z0][k] + W[k] * fr(base[j] + vel[j] * t / Math.max(0.2, W[k]) + (k === 0 ? fbm1(t * 0.2 + i, 3) * 0.01 : 0)); }
    geo.attributes.position.needsUpdate = true;
  };
  upd(0); rig.fx.push(upd); rig.group.add(pts); return pts;
}
