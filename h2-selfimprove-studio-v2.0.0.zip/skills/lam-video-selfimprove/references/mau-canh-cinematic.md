# Mẫu cảnh ở chế độ cinematic (bộ `phim`, 2D)

Cùng `story/shots.json`, cùng tên mẫu cảnh, cùng `args` như legacy (`mau-canh.md`). Dưới đây chỉ ghi chỗ **khác** hoặc **thêm**.
- `x` số 0..1 = vị trí ngang trong phòng (trái → phải).
- Mốc: `bed.sit`, `bed.head`, `desk.seat`, `window`, `poster`, `center`.
- Toạ độ trong phòng (m): `"x": [x, độ cao chỗ ngồi, z]`, với x −2,2..2,2 và z 1,4 (gần máy)..6 (tường sau).

## Thêm cho mọi mẫu
| Khoá | Ý nghĩa |
|---|---|
| `shot` | `{ "size", "angle", "move" }` cho góc chính (góc đầu) của cảnh. Cỡ `ws full ms mcu cu ecu`; chuyển động `hold dollyIn pullBack truck pan tilt pushToCloseUp`. `phim.py` tự ghi từ `MÁY:` |
| `coverage` | ghi đè cả danh sách góc: `[{ "at": 0, "role": "wide", "move": "hold" }, { "at": 2.6, "role": "push" }]`. Vai: `wide push ots face top pov otsPoster insertPoster insertClock void` |
| `tone` | ép tông phòng: `night` \| `day` \| `hope` (mặc định: theo `setArgs.sky` + nhạc) |
| `grade` | như legacy (bão hoà / tối theo nhịp) |
| `cam` | MÁY kiểu cũ tự đổi sang chuyển động tương đương |
| `look: "2d"` | ép riêng cảnh này vẽ kiểu legacy |

Chuyển cảnh: `"in": { "type", "why" }`. Kiểu: `cut matchCut iris whipPan zoomIntoProp fadeThroughBlack smashCut` (+ `dip fade flash whip zoom`). Không ghi `why` thì director tự chọn.

## `scene`
- `set`: `bedroom`; nội thất `cafe kitchen classroom gym sofa mirror doorway lockers court stairs`; ngoài trời `street city hill`; sân khấu tối `void` (`none`, `black` cùng nghĩa). Tên khác → phòng ngủ.
- Mốc nội thất: `center`, `table.left`, `table.right`, `bench`, `sofa.seat`, `sofa.left`, `sofa.right`, `mirror`, `mirror.in`, `door`, `top`. Ngoài trời: `center`, `top`, `bench`, `bus.seat`, `neon`. Sân khấu: `center`, `left`, `right`.
- `setArgs`: `clock` (đồng hồ 7 đoạn trên tủ đầu giường), `lamp`, `laptop` (`"off"`), `sky` (`day` / `dawn` → ban ngày).
- `actors`: như legacy. Thêm:
  - `yaw` (góc nhìn thân), `front`, `back`;
  - `hold: "phone"` (điện thoại sáng trong tay);
  - `outfit` (ghi đè phụ kiện).
  - Bóng đen tự đứng sau / cạnh người hùng, phía giữa phòng; không muốn thì `"keepX": true`.
- `bed`: người nằm (đầu trên gối, chăn là thân). `bed.up`: cắt sang góc mới đúng `up.at`, người ngồi mép giường.

## `phone`
Điện thoại nằm trên mặt tủ, tay đen POV.

| `screen` | Ghi chú |
|---|---|
| `feed` | `posts` (≥ 3 ảnh), `hold`, `times: ["10:04 PM", …]` (giờ nhảy mỗi lần vuốt) hoặc `clockAt`. Ngón tay vuốt đúng nhịp: chuẩn bị → vuốt → dừng nhẹ |
| `alarm` (mới) | `time` / `clockAt`, `date`, `label`, `button` (mặc định SNOOZE), `button2` (STOP), `pressAt` (giây ngón tay ấn nút) |
| `chat`, `lock`, `email`, `counter`, `reel`, `off` | args như legacy |

## `calendar`
- `title`, `month`, `from`, `to`, `mode` (`x` | `fill`), `at`, `dur`, `reset`, `color`.
- Cảnh ≥ 4,5 s: lưng người hùng trước poster (`who`, mặc định `hoodie`), rồi poster đầy khung với cánh tay đen gạch X đúng nhịp `at` / `dur`.

## `clock`
`time`, `timeAt` [[giây, "12:00"]], `color`. Cận trên mặt tủ, ghost segment.

## `face`
`who`, `face`, `faceAt`, `look`, `blink`. Cận ngực trở lên, phòng phía sau nhoè mạnh, đẩy rất chậm.

## `black` / `card`
- `black`: `texts` (narr = Lora nghiêng, big = Lora thẳng, dòng bắt đầu `"— "` = tên tác giả in hoa nhỏ). Tối đa 12 từ mỗi màn.
- `card`: `word` (in hoa giãn cách), `part`, `sub`, `sub2` (màu nhấn).

## `graph` / `cta`
- `graph`: args như legacy; đồ thị sáng trộn lên phòng mờ phía sau, máy đẩy chậm.
- `cta`: `line`; nhân vật vẫy tay, 2 nút LIKE / SUBSCRIBE trên phòng mờ.

## Vẽ kiểu legacy (tự lùi)
Chỉ mẫu `note` (và cảnh có `look: "2d"`).
