// sets.js — boi canh minh hoa phang kieu phim hoat hinh vector dien anh: phoi canh 1 diem tu VE TAY (engine/flat/persp.js), moi mat 1 mau,
// chuyen sac chi o vang sang (den, cua so), net mep rat nhe, texture gan nhu khong co. Bang mau do tu phim tham khao:
// ngay "chua co dong luc" = xam lanh khong bao hoa; dem = xanh than / chi + cam den; hy vong = kem am + xanh la + troi xanh.
// bedroom(o) -> { V (phoi canh), layers: [far, mid, light], anchors (vi tri nguoi theo m), place(a) -> { x, y, h, anchor } (px), rim, rimC }
import { E, clamp, lerp } from '/engine/core.js';
import { view, box, wallRect, sideRect, quad, poly, shade, floorGlow, floorLines } from '/engine/flat/persp.js';
import { glow, vgrad, rgba } from '/engine/flat/stage.js';
import { rng } from '/engine/cine/timeline.js';

export const PAL = {
  night: { wall: '#353c48', side: '#2a303a', floor: '#1d2027', ceil: '#16191f', line: 'rgba(0,0,0,0.22)', wood: '#3b3f47', woodTop: '#4a4f58', sheet: '#5a636e', blanket: '#36405a', sky: ['#121a2c', '#24304a'], city: '#0d1220', lamp: '#ffc27a', moon: '#dfe6f0', winLight: '#7d93c4', rimC: '#7f8da6', poster: '#8a8f96' },
  day:   { wall: '#c3c9ce', side: '#adb4ba', floor: '#8d9499', ceil: '#d7dde1', line: 'rgba(0,0,0,0.10)', wood: '#757c80', woodTop: '#8d9499', sheet: '#dae0e4', blanket: '#7f8b9e', sky: ['#c9d3da', '#e6ebee'], city: '#9ea7ae', lamp: '#fff1d6', moon: null, winLight: '#ffffff', rimC: '#e6e9ec', poster: '#dfe3e6' },
  hope:  { wall: '#d9cdb9', side: '#c7b9a3', floor: '#a8927a', ceil: '#e8dcc8', line: 'rgba(60,40,20,0.12)', wood: '#8a6e58', woodTop: '#a3866d', sheet: '#ece2cf', blanket: '#7d9a58', sky: ['#8fb5d7', '#cfe2ee'], city: '#94b55b', lamp: '#fff1d6', moon: null, winLight: '#fff3d8', rimC: '#fff2dc', poster: '#ece2cf' },
};
const RW = { x0: -2.2, x1: 2.2, H: 2.6, zb: 6.0 };

// dong ho so 7 doan co "ghost segment" (doan tat van mo), glow do co gioi han
const SEG = { 0: 'abcdef', 1: 'bc', 2: 'abged', 3: 'abgcd', 4: 'fgbc', 5: 'afgcd', 6: 'afgedc', 7: 'abc', 8: 'abcdefg', 9: 'abfgcd' };
export function seg7(g, str, cx, cy, h, on, off = 'rgba(255,60,48,0.08)') {
  const w = h * 0.55, th = h * 0.13, gap = h * 0.22, s = String(str), cw = (ch) => (ch === ':' ? h * 0.25 : w);
  let x = cx - [...s].reduce((p, ch) => p + cw(ch) + gap, -gap) / 2;
  for (const ch of s) {
    if (ch === ':') { g.fillStyle = on; g.beginPath(); g.arc(x + h * 0.12, cy - h * 0.2, th * 0.55, 0, 7); g.arc(x + h * 0.12, cy + h * 0.2, th * 0.55, 0, 7); g.fill(); x += cw(ch) + gap; continue; }
    const y = cy - h / 2, P = { a: [x + th, y, w - 2 * th, th], d: [x + th, y + h - th, w - 2 * th, th], g: [x + th, y + h / 2 - th / 2, w - 2 * th, th], f: [x, y + th * 0.6, th, h / 2 - th * 1.1], b: [x + w - th, y + th * 0.6, th, h / 2 - th * 1.1], e: [x, y + h / 2 + th * 0.5, th, h / 2 - th * 1.1], c: [x + w - th, y + h / 2 + th * 0.5, th, h / 2 - th * 1.1] };
    for (const k of 'abcdefg') { const lit = (SEG[ch] || '').includes(k); g.fillStyle = lit ? on : off; const [px, py, pw, ph] = P[k]; g.beginPath(); g.roundRect(px, py, pw, ph, th * 0.45); g.fill(); }
    x += cw(ch) + gap;
  }
}

// vet nang / trang xien tu cua so tren san: chieu 4 goc cua so theo huong sang L xuong san -> hinh binh hanh, mo dan, co bong khung cua
export function windowPatch(g, V, win, zb, color, a, L = [0.28, -0.62, -0.75]) {
  const hit = (x, y) => { const t = y / -L[1]; return [x + L[0] * t, 0, zb + L[2] * t]; };
  const c = [hit(win.x0, win.y0), hit(win.x1, win.y0), hit(win.x1, win.y1), hit(win.x0, win.y1)].map((q) => V.p(...q));
  const [ax, ay] = c[0], [bx, by] = c[2], gr = g.createLinearGradient(ax, ay, bx, by); gr.addColorStop(0, rgba(color, a)); gr.addColorStop(1, rgba(color, a * 0.25));
  g.save(); g.filter = `blur(${Math.max(2, V.k(zb) * 0.03) * E.PX}px)`; poly(g, c, gr);
  const m = (p, q) => [(p[0] + q[0]) / 2, (p[1] + q[1]) / 2]; g.strokeStyle = rgba('#000000', 0.12); g.lineWidth = Math.max(2, V.k(zb) * 0.05); g.beginPath(); g.moveTo(...m(c[0], c[1])); g.lineTo(...m(c[3], c[2])); g.moveTo(...m(c[0], c[3])); g.lineTo(...m(c[1], c[2])); g.stroke(); g.restore();
}
// bong tiep dat mem duoi do dac (x0..x1, z0..z1 tren san)
export function contactShadow(g, V, x0, x1, z0, z1, a = 0.35) { g.save(); g.filter = `blur(${Math.max(3, V.k((z0 + z1) / 2) * 0.06) * E.PX}px)`; quad(g, V, [[x0 - 0.05, 0, z0 - 0.05], [x1 + 0.05, 0, z0 - 0.05], [x1 + 0.05, 0, z1 + 0.05], [x0 - 0.05, 0, z1 + 0.05]], `rgba(0,0,0,${a})`); g.restore(); }
// goc may: high (nhin xuong) | eye | low (nhin len) -> do cao mat + duong chan troi
export const ANGLE = { high: { eye: 1.75, hz: 0.34 }, eye: { eye: 1.2, hz: 0.42 }, low: { eye: 0.62, hz: 0.6 } };

export function bedroom(o = {}) {
  const tone = o.tone || (o.time === 'day' ? 'day' : 'night'), P = PAL[tone], night = tone === 'night', ang = ANGLE[o.angle] || ANGLE.eye, key = `${o.key || 'room'}:${tone}:${o.angle || 'eye'}`;
  o = { eye: ang.eye, hz: E.H * ang.hz, ...o };
  // may gan hon (tieu cu dai) -> nhan vat chiem ~45–60% chieu cao khung o toan canh, nhu phim tham khao
  const V = view({ eye: o.eye ?? 1.2, hz: o.hz ?? E.H * 0.42, f: o.f ?? E.H * 1.35, x0: o.camX ?? 0.1 });
  const { x0, x1, H, zb } = RW, zf = 1.4;
  const win = { x0: -1.35, x1: -0.15, y0: 0.95, y1: 2.05 };
  // ---- lop xa: tuong, san, tran, cua so, poster, ke
  const far = (g) => {
    g.fillStyle = P.wall; g.fillRect(-400, -400, E.W + 800, E.H + 800);
    quad(g, V, [[x0, 0, zf], [x1, 0, zf], [x1, 0, zb], [x0, 0, zb]], P.floor);                    // san
    quad(g, V, [[x0, H, zf], [x1, H, zf], [x1, H, zb], [x0, H, zb]], P.ceil);                     // tran
    sideRect(g, V, x0, zf, zb, 0, H, P.side); sideRect(g, V, x1, zf, zb, 0, H, shade(P.side, -0.05));   // 2 tuong ben
    wallRect(g, V, x0, x1, 0, H, zb, P.wall);                                                       // tuong sau
    floorLines(g, V, x0, x1, zf, zb, { dx: 0.24, color: P.line, lw: 1.3 });                         // van go hoi tu
    wallRect(g, V, x0, x1, 0, 0.09, zb - 0.001, shade(P.wall, -0.15)); sideRect(g, V, x0 + 0.001, zf, zb, 0, 0.09, shade(P.side, -0.15)); sideRect(g, V, x1 - 0.001, zf, zb, 0, 0.09, shade(P.side, -0.2));   // len chan tuong
    // cua so: troi gradient + thanh pho / doi xa + trang (dem) | sang (ngay)
    const [ax, ay] = V.p(win.x0, win.y1, zb), [bx, by] = V.p(win.x1, win.y0, zb);
    g.fillStyle = vgrad(g, 0, ay, 0, by, [[0, P.sky[0]], [1, P.sky[1]]]); g.fillRect(ax, ay, bx - ax, by - ay);
    g.save(); g.beginPath(); g.rect(ax, ay, bx - ax, by - ay); g.clip();
    const r = rng(9); g.fillStyle = P.city; let cx = ax; while (cx < bx) { const w = (bx - ax) * (0.08 + r() * 0.12), hh = (by - ay) * (0.15 + r() * 0.35); g.fillRect(cx, by - hh, w - 2, hh); if (night) { g.fillStyle = rgba(P.lamp, 0.55); for (let k = 0; k < 3; k++) if (r() < 0.5) g.fillRect(cx + 4 + r() * (w - 12), by - hh + 6 + r() * (hh - 14), 4, 5); g.fillStyle = P.city; } cx += w; }
    if (P.moon) glow(g, ax + (bx - ax) * 0.72, ay + (by - ay) * 0.25, (bx - ax) * 0.22, P.moon, 0.35);
    g.restore();
    const fw = Math.max(3, V.k(zb) * 0.045); g.strokeStyle = shade(P.wall, night ? 0.15 : -0.25); g.lineWidth = fw; g.strokeRect(ax, ay, bx - ax, by - ay);
    g.beginPath(); g.moveTo((ax + bx) / 2, ay); g.lineTo((ax + bx) / 2, by); g.moveTo(ax, (ay + by) / 2); g.lineTo(bx, (ay + by) / 2); g.lineWidth = fw * 0.7; g.stroke();
    wallRect(g, V, win.x0 - 0.06, win.x1 + 0.06, win.y0 - 0.06, win.y0, zb - 0.01, shade(P.wall, night ? 0.1 : -0.12));   // bau cua so
    // rem 2 ben (khoi phang)
    wallRect(g, V, win.x0 - 0.32, win.x0 - 0.04, 0.7, 2.25, zb - 0.02, shade(P.blanket, night ? -0.1 : 0.1)); wallRect(g, V, win.x1 + 0.04, win.x1 + 0.3, 0.7, 2.25, zb - 0.02, shade(P.blanket, night ? -0.1 : 0.1));
    // poster / lich (chi tiet o lo 2D-b) + ke sach
    if (o.poster !== false) { wallRect(g, V, 0.55, 1.1, 1.25, 1.95, zb - 0.005, P.poster); const [px, py] = V.p(0.6, 1.88, zb), [qx, qy] = V.p(1.05, 1.3, zb); g.fillStyle = rgba('#000', 0.18); for (let i = 0; i < 4; i++) g.fillRect(px + (qx - px) * 0.1, py + (qy - py) * (0.3 + i * 0.16), (qx - px) * 0.8, (qy - py) * 0.07); }
    box(g, V, 1.3, 2.05, 1.58, 1.62, zb - 0.22, zb, P.woodTop);
    const bc = night ? ['#4a3f3a', '#3d4656', '#4f4a3a', '#3a3f4a'] : ['#8a7e74', '#7a8696', '#9a907a', '#808894']; let bxp = 1.35; const rb = rng(4);
    for (let i = 0; i < 7; i++) { const w = 0.05 + rb() * 0.03, hb = 0.16 + rb() * 0.08; box(g, V, bxp, bxp + w, 1.62, 1.62 + hb, zb - 0.18, zb - 0.02, bc[i % bc.length]); bxp += w + 0.01; }
    if (!night) { g.save(); g.globalCompositeOperation = 'multiply'; g.fillStyle = 'rgba(138,160,200,0.14)'; g.fillRect(-400, -400, E.W + 800, E.H + 800); g.restore(); }   // bo tro lanh (#8aa0c8) phia bong
  };
  // ---- lop giua: do dac (giuong, tu dau giuong + dong ho, ban + den + laptop, ghe, tham)
  const mid = (g) => {
    const rug = night ? '#2c2f3a' : '#9aa2a8'; { const [cx, cy] = V.p(0.1, 0, 4.4), rx = V.k(4.4) * 1.0, ry = Math.abs(V.p(0, 0, 3.7)[1] - V.p(0, 0, 5.1)[1]) / 2; g.fillStyle = rug; g.beginPath(); g.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2); g.fill(); }
    // bong tiep dat mem duoi giuong / tu / ban / ghe (do dac "dung" tren san, khong troi)
    contactShadow(g, V, x0 + 0.02, -1.0, 3.6, 5.95, 0.4); contactShadow(g, V, -0.92, -0.5, 5.45, 5.95); contactShadow(g, V, 1.35, x1 - 0.02, 3.7, 5.0, 0.25); contactShadow(g, V, 0.95, 1.35, 4.0, 4.4, 0.3);
    // ve tu XA toi GAN (nhu hoa si): dau giuong + tu dau giuong (sat tuong sau) truoc, roi giuong
    box(g, V, x0 + 0.02, -1.0, 0, 0.95, 5.92, 6.0, P.wood, { top: P.woodTop });                              // dau giuong
    box(g, V, -0.92, -0.5, 0, 0.5, 5.45, 5.95, P.wood, { top: P.woodTop });                                  // tu dau giuong
    box(g, V, -0.84, -0.6, 0.5, 0.6, 5.55, 5.7, '#141518', { top: '#1c1d21' });                              // dong ho so
    { const [cx, cy] = V.p(-0.72, 0.55, 5.55), hh = V.k(5.55) * 0.055; if (night) glow(g, cx, cy, hh * 4, '#ff3b30', 0.25); seg7(g, o.clock || '2:14', cx, cy, hh, '#ff4a3d'); }
    box(g, V, x0 + 0.02, -1.0, 0, 0.28, 3.6, 5.92, P.wood, { top: P.woodTop });                              // khung giuong
    box(g, V, x0 + 0.04, -1.04, 0.28, 0.45, 3.65, 5.9, P.sheet, { top: shade(P.sheet, 0.08), side: shade(P.sheet, -0.15) });
    box(g, V, x0 + 0.15, -1.2, 0.45, 0.58, 5.35, 5.85, shade(P.sheet, 0.05), { top: shade(P.sheet, 0.15) });   // goi
    box(g, V, x0 + 0.06, -1.06, 0.45, 0.52, 3.6, 5.0, P.blanket, { top: shade(P.blanket, 0.1), side: shade(P.blanket, -0.15) });   // chan
    // ban hoc + den + laptop (tuong phai) + ghe
    box(g, V, 1.35, x1 - 0.02, 0.72, 0.77, 3.7, 5.0, P.woodTop, { top: shade(P.woodTop, 0.1) });
    for (const [lx, lz] of [[1.4, 3.75], [2.1, 3.75], [1.4, 4.95], [2.1, 4.95]]) box(g, V, lx, lx + 0.05, 0, 0.72, lz, lz + 0.05, P.wood);
    box(g, V, 1.55, 1.95, 0.77, 0.79, 4.05, 4.35, '#3a3d44', { top: '#45484f' }); quad(g, V, [[1.55, 0.79, 4.35], [1.95, 0.79, 4.35], [1.97, 1.04, 4.42], [1.57, 1.04, 4.42]], o.laptop === 'off' || !night ? '#2a2d33' : '#6f86b8');
    box(g, V, 1.9, 1.98, 0.77, 1.12, 4.65, 4.72, '#26282d'); box(g, V, 1.78, 2.02, 1.1, 1.2, 4.58, 4.78, '#34363c', { top: '#3c3e44' });
    box(g, V, 0.95, 1.35, 0.45, 0.5, 4.0, 4.4, '#2e3138', { top: '#3a3d45' }); box(g, V, 0.95, 1.0, 0.5, 0.95, 4.0, 4.4, '#2a2d33');
    for (const [lx, lz] of [[0.97, 4.02], [1.3, 4.02], [0.97, 4.35], [1.3, 4.35]]) box(g, V, lx, lx + 0.03, 0, 0.45, lz, lz + 0.03, '#202227');
  };
  // ---- lop anh sang (cong 'screen'): vung sang cua so tren san + den ban am + quang man laptop
  const light = (g) => {
    const lampOn = o.lamp !== false && night;
    // nguon chinh = cua so: vet sang xien tren san (dem: trang lanh; ngay: nang am #ffd9a0) + quang quanh cua so
    if (night) { windowPatch(g, V, win, zb, P.winLight, 0.28); const [wx, wy] = V.p((win.x0 + win.x1) / 2, (win.y0 + win.y1) / 2, zb); glow(g, wx, wy, V.k(zb) * 1.3, P.winLight, 0.18); }
    else { windowPatch(g, V, win, zb, '#ffd9a0', 0.5); const [wx, wy] = V.p((win.x0 + win.x1) / 2, (win.y0 + win.y1) / 2, zb); glow(g, wx, wy, V.k(zb) * 1.8, '#fff1d6', 0.3); }
    if (lampOn) { const [lx, ly] = V.p(1.86, 1.12, 4.66); glow(g, lx, ly, V.k(4.66) * 1.6, P.lamp, 0.42); glow(g, lx, ly, V.k(4.66) * 0.35, '#fff3dc', 0.6); floorGlow(g, V, 1.75, 4.4, 0.9, 0.7, P.lamp, 0.2); }
    if (night && o.laptop !== 'off') { const [lx, ly] = V.p(1.76, 0.95, 4.4); glow(g, lx, ly, V.k(4.4) * 0.6, '#8fa6d8', 0.2); }
  };
  // vi tri nguoi: moc -> m -> px. h = chieu cao 1,55 m o do sau z
  const A = {
    'bed.sit': { x: -1.05, z: 4.55, seat: 0.47, f: 1 }, 'bed.head': { x: -1.6, z: 5.5, seat: 0.55, f: 1 }, 'desk.seat': { x: 1.17, z: 4.2, seat: 0.5, f: 1 },
    window: { x: -0.75, z: 5.15, f: -1 }, poster: { x: 0.82, z: 5.3, f: 1 }, center: { x: 0.1, z: 3.6, f: 1 },
  };
  const place = (a) => {
    let q;
    if (Array.isArray(a.x)) q = { x: a.x[0], z: a.x[2] ?? 3.6, seat: a.x[1] || 0 };
    else if (typeof a.x === 'string' && A[a.x]) q = A[a.x];
    else { const k = typeof a.x === 'number' ? (a.x > 1.5 ? a.x / 1920 : a.x) : 0.5; q = { x: lerp(-1.5, 1.6, k), z: a.z ?? 4.4 }; }   // dung giua phong (nguoi ~ 1/2 chieu cao khung, thay ca phong)
    const sit = q.seat && String(a.pose || '').startsWith('sit');
    const [sx, sy] = V.p(q.x, sit ? q.seat : 0, q.z), h = V.k(q.z) * 1.55 * (a.who === 'voice' ? 1.12 : 1) * (a.scale ?? 1);
    return { x: sx, y: sy, h, anchor: sit ? 'hip' : 'feet', z: q.z };
  };
  place.rim = -1; place.rimC = P.rimC;   // cua so ben trai -> vien sang ben trai nhan vat
  return { V, P, night, layers: [{ key: key + ':far', p: 0.85, draw: far }, { key: key + ':mid', p: 1, draw: mid }, { key: key + ':light', p: 0.95, draw: light, add: 'screen', order: 1.5 }], place, anchors: A };
}
