# Cài đặt studio (một lần cho mỗi máy / thư mục làm việc)

Bộ dựng là một bộ công cụ nhỏ Node + Python nằm trong thư mục `kit/` của skill `lam-video-selfimprove`. Phải chép ra một thư mục làm việc có quyền ghi, vì thư mục plugin có thể chỉ đọc và studio cần `node_modules`, dự án và file xuất bên cạnh.

## 1. Tìm kit
- `kit/` nằm trong thư mục gốc của skill này.
- Nếu không rõ đường dẫn: `find / -path "*lam-video-selfimprove/kit/render.mjs" 2>/dev/null | head -1` (Linux/macOS/máy ảo Cowork) hoặc PowerShell: `Get-ChildItem -Recurse -Filter render.mjs -Path $HOME\.claude | Select-Object -First 1`.

## 2. Chọn nơi làm việc và chép
- Dùng thư mục người dùng đã kết nối nếu có (ví dụ `D:\whatif`), không thì thư mục làm việc hiện tại. Tạo `h2-2d-studio/` ở đó.
- Đã có `h2-2d-studio/render.mjs` (cài từ gói ngách khác): chép đè `engine/ packs/ tools/ audio/*.py render.mjs player.html package.json` từ kit mới, chép thêm `projects/selfimprove-mau` và `projects/selfimprove-phim`, rồi chạy lại bước 3 (`npm install` để thêm font mới, `audio/build_audio.py` để tạo nhạc riêng). **Không bao giờ ghi đè `projects/` khác của người dùng.**
- Chép toàn bộ `kit/` vào: `cp -r "<kit>/." h2-2d-studio/` (bash) hoặc `Copy-Item -Recurse "<kit>\*" h2-2d-studio\` (PowerShell).
- Nếu phiên làm việc chạy trên máy cloud (không có shell trên máy người dùng): cài và dựng ở máy cloud, chỉ chép video thành phẩm về thư mục của người dùng.

## 3. Cài phụ thuộc

**Kiểu cài gọn (mặc định cho ngách này, khoảng 290 MB):** chỉ những gì gói `cine` + `dem` cần (từ 2.0 gồm cả Three.js cho chế độ cinematic).
```bash
npm install --omit=optional
npx playwright install --only-shell chromium
python audio/build_audio.py --gon
```
- `--omit=optional`: bỏ bản đồ của gói H2 khác (`three` từ 2.0 là gói bắt buộc, vẫn được cài). `--only-shell`: chỉ Chromium bản rút gọn để dựng hình chạy ngầm (bỏ bản đầy đủ 344 MB). `--gon`: chỉ tạo SFX; nhạc tự sinh riêng cho từng phim ở lần trộn đầu.
- **Kiểu cài đầy đủ** (thư mục `h2-2d-studio/` dùng chung với gói H2 khác, khoảng 860 MB): `npm install`, `npx playwright install chromium`, `python audio/build_audio.py`. Đang cài gọn muốn lên đầy đủ: chạy 3 lệnh này, không cần xoá gì.
- `doctor.py` in dòng `Kieu cai: GON | DAY DU`.

Danh sách cũ (kiểu đầy đủ):
Báo người dùng một danh sách ngắn: ffmpeg (ghép hình/tiếng), Node.js + gói (bộ vẽ, font chữ kể chuyện Comic Neue, chữ viết tay Caveat, chữ thumbnail Luckiest Guy, dữ liệu bản đồ, Three.js), Chromium chạy ngầm (vẽ từng khung), numpy/scipy/soundfile (tạo tiếng và nhạc).

| Cần | Windows | macOS | Linux |
|---|---|---|---|
| ffmpeg + ffprobe | `winget install --id Gyan.FFmpeg -e` (mở terminal mới) | `brew install ffmpeg` | `sudo apt-get install -y ffmpeg` |
| Node.js ≥ 18 | `winget install OpenJS.NodeJS.LTS` | `brew install node` | gói của distro / nodesource |
| Python ≥ 3.9 | python.org | `brew install python` | gói của distro |
| Gói JS | `npm install` (trong h2-2d-studio) | như trên | như trên |
| Chromium | `npx playwright install chromium` | như trên | như trên (`npx playwright install-deps chromium` nếu thiếu thư viện) |
| Gói Python | `python -m pip install numpy scipy soundfile` | như trên | thêm `--break-system-packages` nếu Python bị quản lý |
| Tiếng + nhạc | `python audio/build_audio.py` (tạo khoảng 47 SFX và 11 nền nhạc, kể cả nhạc riêng của ngách; khoảng 1 phút) | như trên | như trên |

Hoặc chạy `python tools/doctor.py --install` để tự cài phần còn thiếu.

## 4. Kiểm tra và tự thử
1. `python tools/doctor.py` (dùng `python3` nếu `python` không phải Python 3, `py -3` trên một số máy Windows). Lặp lại đến khi mọi dòng là OK. Dòng Chromium chỉ OK khi **mở được Chromium thật** (doctor mở thử rồi đóng, in đường dẫn file đã dùng).
2. Tự thử: `node render.mjs --project projects/selfimprove-mau --sheet --scale 0.4 --at 0.8`. Phải ghi ra `projects/selfimprove-mau/build/sheets/sheet_01.jpg`, `sheet_02.jpg` đủ các mẫu: phòng ngủ có bóng đen phát sáng, bộ đếm DAY, phố mưa, điện thoại chat / feed / email, đồng hồ, lịch, cận mặt, sổ tay, thẻ kết, màn xin đăng ký. Mở ảnh xem chữ đúng font (chữ kể chuyện tròn, chữ cám dỗ viết tay), rồi xoá thư mục `build/` của dự án mẫu.
3. Tự thử cinematic: `node render.mjs --project projects/selfimprove-phim --check --scale 0.25` phải in `Khong co loi`; rồi `--sheet --scale 0.4 --at 0.3` xem các bối cảnh cùng một kiểu vẽ (sân khấu tối, phòng ngủ, phố, đồi, nội thất, điện thoại, đồng hồ, lịch, cận mặt, thẻ kết). Xoá `build/` sau khi xem.
4. Ngách này **không cần voice, không cần Whisper**.

## Ghi chú
- **Chromium:** `render.mjs` tự tìm Chromium đã tải ở mọi kiểu thư mục (`chrome-linux`, `chrome-linux64`, `chrome-win`, `chrome-win64`, bản mac, bản headless shell), trong `PLAYWRIGHT_BROWSERS_PATH` và thư mục mặc định của Playwright, bản mới hơn thử trước. Máy có Chromium ở chỗ khác: đặt biến `H2_CHROMIUM` là đường dẫn file chrome (vd `export H2_CHROMIUM=/opt/pw-browsers/chromium-1200/chrome-linux64/chrome`). Kiểm nhanh: `node tools/chromium.mjs --check` → `OK <file>` hoặc `THIEU <lý do>`.
- Máy không GPU (máy chủ Linux, máy ảo Cowork): bộ `dem` (legacy) vẽ bằng CPU, không cần GPU, xuất khoảng 20 khung/giây ở 1080p.
- **Bản cinematic 3D tuỳ chọn (`"render": "3d"`, WebGL; bản 2D mặc định vẽ bằng CPU, không cần mục này):**
  - Chromium chạy ngầm mặc định vẽ WebGL bằng phần mềm (SwiftShader). Đo trên máy Windows có Intel UHD: SwiftShader 3,6 khung/giây ở 960x540; GPU thật ~32 khung/giây.
  - `render.mjs` tự dùng GPU thật ở chế độ cinematic: Windows (Direct3D 11), macOS (Metal).
  - Chọn tay: `--gl gpu | auto | swiftshader`.
  - Linux không GPU dùng SwiftShader: chậm, nên dựng 720p.
  - Kiểm GPU: dòng `[trinh duyet]` báo lỗi WebGL, hoặc dựng thử `--stills 1` xem có ảnh không.
  - GPU gây lỗi (ảnh đen / nhiễu): thêm `--gl swiftshader`.
- Dung lượng: cài gọn khoảng 260 MB (gói Node 18 MB + Chromium rút gọn 206 MB + SFX 32 MB); đầy đủ khoảng 860 MB. Mỗi phim thêm nhạc riêng (~60–100 MB trong `build/music`, xoá được sau khi xuất) và file xuất (phim 3 phút 1080p khoảng 20–40 MB).
- Cập nhật plugin hoặc dùng chung với gói ngách khác: chép `engine/ packs/ tools/ render.mjs player.html package.json` mới đè lên bản cài cũ rồi `npm install`, giữ nguyên `projects/`. Mọi gói ngách H2 dùng chung một thư mục `h2-2d-studio/`. `render.mjs` mới cần `tools/chromium.mjs`: luôn chép cả `tools/` cùng `render.mjs`.
