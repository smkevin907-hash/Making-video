// bean.js — nhan vat dau tron mau kem (nguoi hung, ban be, co gai) va "giong noi" (bong den phat sang).
//   bean(g, x, yChan, chieuCao, o)
// o: who (preset trong CAST) | pose | face | facing (1 nhin phai, -1 nhin trai) | look (-1..1 lech mat) | t (giay, cho chop mat / tho)
//    walk / run (toc do chu ky, 0 = dung) | rot (nghieng ca nguoi, rad) | hold: 'phone' | 'umbrella' | 'book' | 'ball' | 'bag'
//    headband | hood | cap (mau) | hair: 'bob' | scarf (mau) | shirt (mau than) | tears | sweat | bags (quang tham) | glowFace (mau anh man hinh hat len mat)
//    shadow: true -> ve thanh bong den "giong noi" (dung preset 'voice')
import { E, clamp, lerp, ease, noise, rng, alpha, shade, mix, radGrad } from '/engine/core.js';
import { PAL, accent, light, classic } from './ink.js';
// dang ve: "classic" = dau tron tach than (ban 1.4.0); mac dinh = hat dau (dau nho hon, dinh lien than, tay chan thon, vien manh)
const isCl = (o) => classic() || o.look === 'classic';
const ANX = ['scared', 'worried', 'panic', 'cry', 'sob', 'shock', 'embarrassed'];   // bieu cam van tho nhanh + run khi dung yen
export const headK = (o = {}) => (isCl(o) ? 18.5 : 15.5);   // ban kinh dau / chieu cao (x100)

export const CAST = {
  hero:    { skin: PAL.hero },
  band:    { skin: PAL.hero, headband: true },                         // nguoi hung khi tap luyen (bang do mau nhan)
  hoodie:  { skin: PAL.hero, hood: true },                             // nguoi hung mac hoodie (mu ha xuong sau co, dau tron tron nhu doi thu)
  hooded:  { skin: PAL.hero, hood: 'up' },                             // hoodie trum mu len dau (canh dem, nghien)
  friend:  { skin: PAL.friend1, cap: PAL.capY },
  friend2: { skin: PAL.friend2, cap: PAL.capB },
  friend3: { skin: PAL.friend1, cap: PAL.capR },
  girl:    { skin: PAL.girlSkin, hair: 'bob', scarf: PAL.scarf, shirt: PAL.coat },
  mom:     { skin: PAL.friend1, hair: 'bun', shirt: '#7b6a8a' },
  dad:     { skin: PAL.friend2, glasses: true, shirt: '#4d5a6e' },
  kid:     { skin: PAL.hero, kid: true },
  ghost:   { skin: PAL.hero, ghost: true },                            // ban cu mo nhat (hoi tuong)
  voice:   { shadow: true },                                           // "giong noi" — cam do
};

// tu the: goc tuyet doi (rad) cua [canh tay, cang tay] / [dui, cang chan]; 0 = thang xuong, + = ve phia mat nhin.
// F = tay/chan gan (phia truoc), B = phia sau. lean = nghieng than, drop = ha hong (ngoi), head = [dx, dy] dau lech
export const POSES = {
  stand:    { aF: [0.1, 0.05], aB: [-0.1, -0.05], lF: [0.02, 0], lB: [-0.02, 0] },
  relaxed:  { aF: [0.18, 0.3], aB: [-0.15, -0.05], lF: [0.08, 0], lB: [-0.06, 0] },
  slump:    { aF: [0.25, 0.2], aB: [0.15, 0.1], lF: [0.04, 0], lB: [-0.02, 0], lean: 0.14, head: [3, 4] },
  phone:    { aF: [0.55, 2.5], aB: [0.35, 2.2], lF: [0.03, 0], lB: [-0.03, 0], head: [1, 2], lean: 0.05, hand: 'front' },
  reach:    { aF: [1.35, 1.45], aB: [-0.1, -0.05], lF: [0.05, 0], lB: [-0.05, 0], lean: 0.1 },
  point:    { aF: [1.45, 1.5], aB: [-0.1, -0.05], lF: [0.02, 0], lB: [-0.02, 0] },
  wave:     { aF: [2.4, 2.9], aB: [-0.1, -0.05], lF: [0.02, 0], lB: [-0.02, 0] },
  cheer:    { aF: [2.7, 2.95], aB: [-2.7, -2.95], lF: [0.1, 0], lB: [-0.1, 0] },
  fist:     { aF: [0.35, 2.6], aB: [-0.1, -0.05], lF: [0.05, 0], lB: [-0.05, 0] },
  headhold: { aF: [2.1, -2.6], aB: [-2.1, 2.6], lF: [0.03, 0], lB: [-0.03, 0], head: [0, 3] },
  facepalm: { aF: [0.9, 2.9], aB: [-0.1, -0.05], lF: [0.02, 0], lB: [-0.02, 0], head: [2, 4], lean: 0.08 },
  arms:     { aF: [0.6, -1.3], aB: [-0.6, 1.3], lF: [0.04, 0], lB: [-0.04, 0] },          // khoanh tay
  shrug:    { aF: [0.7, 2.0], aB: [-0.7, -2.0], lF: [0.04, 0], lB: [-0.04, 0] },
  hug:      { aF: [0.5, 1.9], aB: [0.4, 1.7], lF: [0.04, 0], lB: [-0.04, 0], lean: 0.06 },  // om nguoi / om gang tay
  guard:    { aF: [0.6, 2.7], aB: [0.4, 2.5], lF: [0.35, -0.1], lB: [-0.35, 0.05], lean: 0.08, drop: 4 },   // the dam boc
  punch:    { aF: [1.55, 1.55], aB: [0.4, 2.5], lF: [0.35, -0.1], lB: [-0.35, 0.05], lean: 0.18, drop: 4 },
  lift:     { aF: [2.95, 3.1], aB: [-2.95, -3.1], lF: [0.25, 0], lB: [-0.25, 0], drop: 3 },                // nang ta qua dau
  sit:      { aF: [0.35, 1.3], aB: [0.2, 1.2], lF: [1.5, 0.05], lB: [1.45, 0.0], drop: 15, lean: -0.05 },  // ngoi ghe / mep giuong
  sitphone: { aF: [0.6, 2.5], aB: [0.4, 2.3], lF: [1.5, 0.05], lB: [1.45, 0], drop: 15, lean: 0.12, head: [2, 3] },
  sitdesk:  { aF: [1.0, 1.55], aB: [0.9, 1.5], lF: [1.5, 0.05], lB: [1.45, 0], drop: 15, lean: 0.22 },     // cui viet / doc
  sitsad:   { aF: [0.5, 1.5], aB: [0.4, 1.4], lF: [1.5, 0.05], lB: [1.45, 0], drop: 15, lean: 0.3, head: [3, 6] },
  knees:    { aF: [0.9, 1.8], aB: [0.8, 1.7], lF: [2.3, -0.15], lB: [2.2, -0.2], drop: 26, lean: 0.25, head: [3, 4] },   // ngoi bo goi duoi dat
  kneel:    { aF: [0.3, 0.2], aB: [0.1, 0.1], lF: [1.4, -0.1], lB: [0.0, -1.5], drop: 13, lean: 0.15, head: [2, 4] },
  crouch:   { aF: [0.9, 1.6], aB: [0.7, 1.5], lF: [1.6, -0.3], lB: [1.2, -0.6], drop: 12, lean: 0.35 },
  climb:    { aF: [0.6, 1.4], aB: [-0.5, -0.2], lF: [1.0, 0.1], lB: [-0.3, 0.0], lean: 0.2, drop: 3 },
  open:     { aF: [1.3, 1.25], aB: [-0.1, -0.05], lF: [0.25, 0], lB: [-0.2, 0], lean: 0.12 },     // day cua
  umbrella: { aF: [0.55, 2.55], aB: [-0.1, -0.05], lF: [0.02, 0], lB: [-0.02, 0], hand: 'front' },
  carry:    { aF: [0.5, 1.6], aB: [0.4, 1.5], lF: [0.03, 0], lB: [-0.03, 0] },             // om do vat truoc nguc
  // dong tac ke chuyen (act)
  pant:     { aF: [0.75, 0.55], aB: [0.6, 0.45], lF: [0.35, -0.25], lB: [0.15, -0.35], lean: 0.62, drop: 4, head: [3, -1] },   // chong tay len goi, tho doc
  throw:    { aF: [-1.05, -1.55], aB: [0.6, 1.2], lF: [0.3, 0], lB: [-0.35, 0], lean: -0.12, head: [-1, 0] },  // lay da nem: tay vung ra sau ngang vai (khong che mat)
  release:  { aF: [1.75, 1.6], aB: [-0.4, -0.2], lF: [0.35, 0], lB: [-0.4, 0], lean: 0.2 },                  // vua nem: tay vuot ra truoc
  sitfwd:   { aF: [0.7, 1.1], aB: [0.6, 1.0], lF: [1.4, 0.05], lB: [1.35, 0], drop: 15, lean: 0.42, head: [2, 1] },  // ngoi chom ra truoc truoc khi dung len
  lie:      { aF: [0.15, 0.1], aB: [-0.1, -0.05], lF: [0.02, 0], lB: [-0.02, 0] },                            // nam thang (giuong, guc xuong san)
};

const lerpPose = (a, b, k) => {
  const L = (x, y) => (Array.isArray(x) ? x.map((v, i) => lerp(v, y[i], k)) : lerp(x ?? 0, y ?? 0, k));
  const o = {}; for (const key of new Set([...Object.keys(a), ...Object.keys(b)])) { if (key === 'hand') { o.hand = k < 0.5 ? a.hand : b.hand; continue; } o[key] = L(a[key] ?? (Array.isArray(b[key]) ? b[key].map(() => 0) : 0), b[key] ?? (Array.isArray(a[key]) ? a[key].map(() => 0) : 0)); }
  return o;
};
export function poseOf(name, from, k) { const P = classic() ? POSES : POSES2(); const p = P[name] || (typeof name === 'object' ? name : P.stand); return from ? lerpPose(P[from] || from, p, k) : p; }
// chuyen tu the dan: lay da nhe (lui 6%) -> toi dich -> vuot qua ~10% -> doi ve. k 0..1
export const easePose = (k) => (k <= 0 ? 0 : k >= 1 ? 1 : k < 0.16 ? -0.06 * Math.sin(Math.PI * k / 0.16) : ease.outBack((k - 0.16) / 0.84));
// thoi gian chuyen mac dinh theo do lon thay doi: 0,3 giay (nho) -> 0,75 giay (dung -> quy)
export function poseDur(a, b) {
  const A = poseOf(a), B = poseOf(b); let m = 0;
  for (const k of ['aF', 'aB', 'lF', 'lB']) for (let i = 0; i < 2; i++) m = Math.max(m, Math.abs((A[k]?.[i] ?? 0) - (B[k]?.[i] ?? 0)));
  m = Math.max(m, Math.abs((A.lean || 0) - (B.lean || 0)) * 3, Math.abs((A.drop || 0) - (B.drop || 0)) / 10);
  return clamp(0.26 + m * 0.14, 0.3, 0.75);
}

// ---------- di / chay: nhip buoc tinh theo QUANG DUONG da di nen chan tru dung yen tren san (khong truot).
// s = { d: quang duong da di (am = di lui), S: do dai 1 buoc (ca hai don vi U = chieu cao / 100), w: 0..1 (tron voi tu the dung luc vao / ra) }
// Khong co s (di / chay tai cho, walk: 0.9 | run: 1.6): quang duong ao = t * speed * 2 * S, ban chan lui deu nhu tren may chay.
const L1 = 15, L2 = 15.5, GND = 0.5;          // dui, cang chan, mat san (giong tu the dung)
export const GAIT = { walk: { st: 0.6, lift: 4, hmax: 29.4, lean: 0.05, arm: 0.42, elbow: 0.3, S: 24 }, run: { st: 0.36, lift: 9, hmax: 28.6, lean: 0.2, arm: 0.75, elbow: 1.45, S: 34 } };
// dang moi: chay do nguoi ~19 do, goi nang cao, tay co danh manh (nhu phim mau)
const GAIT2 = { walk: GAIT.walk, run: { st: 0.34, lift: 14, hmax: 28.2, lean: 0.34, arm: 1.05, elbow: 1.8, S: 34 } };
function ik(dx, dy) {                          // hong -> ban chan (dx ve phia truoc, dy xuong) => [goc dui, goc cang chan], goi gap ve phia truoc
  const D = clamp(Math.hypot(dx, dy), Math.abs(L1 - L2) + 0.01, L1 + L2 - 0.01), phi = Math.atan2(dx, dy);
  return [phi + Math.acos(clamp((L1 * L1 + D * D - L2 * L2) / (2 * L1 * D), -1, 1)), phi - Math.acos(clamp((L2 * L2 + D * D - L1 * L1) / (2 * L2 * D), -1, 1))];
}
// ban chan so voi hong o pha c: dang tru -> lui dung bang quang duong than di; dang buoc -> nhac len, dat xuong truoc (van toc dau / cuoi = 0 so voi dat)
function footRel(c, G, S) {
  if (c < G.st) return { x: G.st * S - (c / G.st) * 2 * G.st * S, up: 0, stance: true };
  const u = (c - G.st) / (1 - G.st);
  return { x: -G.st * S + 2 * S * u * u * (3 - 2 * u) - 2 * (1 - G.st) * S * u, up: Math.sin(Math.PI * u), stance: false };
}
const wrap1 = (c) => ((c % 1) + 1) % 1;
function hipAt(cF, G, S, run) {                // do cao hong: thap khi 2 chan cham dat, cao khi chan buoc luot qua (chan tru luon voi toi dat)
  let hip = run ? G.hmax - 2.2 * (0.5 + 0.5 * Math.cos(4 * Math.PI * (cF - G.st / 2))) + 1 : G.hmax;
  for (const c of [cF, wrap1(cF + 0.5)]) { const f = footRel(c, G, S); if (f.stance) hip = Math.min(hip, Math.sqrt(Math.max(0, 900 - f.x * f.x)) - GND); }
  return hip;
}
const fwd = (c, st) => Math.cos(2 * Math.PI * (c < st ? 0.5 * c / st : 0.5 + 0.5 * (c - st) / (1 - st)));   // 1 = chan dang o truoc nhat
// tu the rieng dang moi: the dam chan rong, goi chung (ban chan tinh bang ik de cham dung san); dam: xoay vai (twist), do nguoi
let _P2 = null;
function POSES2() {
  if (_P2) return _P2;
  const h = (drop) => 30 - drop + GND, L = (x, drop) => ik(x, h(drop));
  _P2 = { ...POSES,
    guard: { aF: [0.75, 2.75], aB: [0.55, 2.6], lF: L(10, 7), lB: L(-11, 7), lean: 0.12, drop: 7, head: [1, 1] },
    punch: { aF: [1.57, 1.55], aB: [0.45, 2.65], lF: L(12, 8), lB: L(-13, 8), lean: 0.27, drop: 8, twist: 4.5, head: [3, 1] } };
  return _P2;
}
function gait(p, t, speed, run, s) {
  const G = (classic() ? GAIT : GAIT2)[run ? 'run' : 'walk'], S = s?.S || G.S, d = s ? s.d : t * speed * 2 * S, lift = (s ? clamp(Math.abs(d) / (0.12 * S)) : 1) * G.lift;
  const cyc = d / (2 * S) + G.st / 2, cF = wrap1(cyc), cB = wrap1(cyc + 0.5);   // d = 0: chan truoc giua nhip tru, chan sau giua nhip buoc (2 chan khep)
  const hip = hipAt(cF, G, S, run), hipLag = hipAt(wrap1(cyc - 0.07), G, S, run);
  const fF = footRel(cF, G, S), fB = footRel(cB, G, S);
  if (s && Math.abs(d) < 0.35 * S) { const k = Math.abs(d) / (0.35 * S); fB.x = lerp(-d, fB.x, k * k * (3 - 2 * k)); }   // buoc dau: chan sau nhac len roi moi dua di (khong lê tren san)
  const out = { ...p, lF: ik(fF.x, hip + GND - fF.up * lift), lB: ik(fB.x, hip + GND - fB.up * lift), lean: (p.lean || 0) + G.lean, bounce: hip - 30, mv: run ? 1 : 0.55,
    head: [(p.head?.[0] || 0), (p.head?.[1] || 0) - (hipLag - hip) * 0.7] };   // dau nay tre nhip so voi hong
  if (!p.hand) {                               // tay vung nguoc chan cung ben, tre nhip; tay dang cam do (dien thoai, o) giu nguyen
    const sw = (c) => -fwd(wrap1(c - 0.05), G.st) * G.arm, a1 = sw(cF), a2 = sw(cB);
    out.aF = [a1, a1 + G.elbow + 0.3 * Math.max(0, a1)]; out.aB = [a2, a2 + G.elbow + 0.3 * Math.max(0, a2)];
  }
  return out;
}

const seg2 = (x, y, a1, l1, a2, l2, f) => { const ex = x + Math.sin(a1) * l1 * f, ey = y + Math.cos(a1) * l1; return [[x, y], [ex, ey], [ex + Math.sin(a2) * l2 * f, ey + Math.cos(a2) * l2]]; };
function limb(g, pts, w, fill, edge, lw) {
  g.lineCap = 'round'; g.lineJoin = 'round';
  const path = () => { g.beginPath(); g.moveTo(pts[0][0], pts[0][1]); g.quadraticCurveTo(pts[1][0], pts[1][1], (pts[1][0] + pts[2][0]) / 2, (pts[1][1] + pts[2][1]) / 2); g.lineTo(pts[2][0], pts[2][1]); };
  if (edge) { path(); g.lineWidth = w + lw * 2; g.strokeStyle = edge; g.stroke(); }
  path(); g.lineWidth = w; g.strokeStyle = fill; g.stroke();
}
// tay chan thon dan (dang moi): doan tren w0, doan duoi w1, dau tron re; vien ve chung 1 lan (khong lo vet noi o khop)
function limbT(g, pts, w0, w1, re, fill, edge, lw) {
  g.lineCap = 'round'; g.lineJoin = 'round';
  const m = [(pts[1][0] + pts[2][0]) / 2, (pts[1][1] + pts[2][1]) / 2], end = pts[2];
  const A = () => { g.beginPath(); g.moveTo(pts[0][0], pts[0][1]); g.quadraticCurveTo(pts[1][0], pts[1][1], m[0], m[1]); }, B = () => { g.beginPath(); g.moveTo(m[0], m[1]); g.lineTo(end[0], end[1]); };
  const pass = (col, add) => { A(); g.lineWidth = w0 + add; g.strokeStyle = col; g.stroke(); B(); g.lineWidth = w1 + add; g.stroke(); if (re) { g.beginPath(); g.arc(end[0], end[1], re + add / 2, 0, Math.PI * 2); g.fillStyle = col; g.fill(); } };
  if (edge) pass(edge, lw * 2); pass(fill, 0);
}
function dot(g, x, y, r, fill, edge, lw) { g.beginPath(); g.arc(x, y, r, 0, Math.PI * 2); g.fillStyle = fill; g.fill(); if (edge) { g.lineWidth = lw; g.strokeStyle = edge; g.stroke(); } }

export function bean(g, x, y, h, o = {}) {
  const pre = CAST[o.who] || {}; o = { ...pre, ...o };
  const U = h / 100, f = o.facing ?? 1, t = o.t || 0, sh = !!o.shadow, cl = isCl(o);
  const skin = sh ? '#050507' : (o.skin || PAL.hero), edge = sh ? alpha(o.glow || accent(), 0.85) : (o.edge || (cl ? PAL.heroLine : '#4f4a43')), lw = sh ? Math.max(1.2, 0.9 * U) : cl ? Math.max(1.6, 2.2 * U / 2.4) : Math.max(1.3, 0.62 * U) * (1 + 0.16 * (o.boil || 0));   // boil: vien day / mong chut it moi 0,1 giay (net ve tay)
  const glowC = o.glow || (sh ? accent() : null);
  let p = poseOf(o.pose || 'stand', o.fromPose, o.poseK ?? 1);
  if (o.stride) { // dang di theo walk/run { to }; luc vao / ra tron voi tu the dung, ban chan khong duoc lun xuong san
    const gp = gait(p, t, 0, !!o.stride.run, o.stride);
    if ((o.stride.w ?? 1) < 1) {
      p = lerpPose(p, gp, o.stride.w); const hy = 30 - (p.drop || 0) + (p.bounce || 0);
      for (const k of ['lF', 'lB']) { const a = p[k] || [0, 0], fx = Math.sin(a[0]) * L1 + Math.sin(a[1] ?? a[0]) * L2, fy = Math.cos(a[0]) * L1 + Math.cos(a[1] ?? a[0]) * L2; if (fy > hy + GND) p[k] = ik(fx, hy + GND); }
    } else p = gp;
  }
  else if (typeof (o.run || o.walk) === 'number') p = gait(p, t, o.run || o.walk, !!o.run);
  if (p.squat) { // nhun (lay da, giua vong quay): ha hong nhung giu ban chan tai cho -> gap goi
    const fk = (a) => [Math.sin(a[0]) * L1 + Math.sin(a[1] ?? a[0]) * L2, Math.cos(a[0]) * L1 + Math.cos(a[1] ?? a[0]) * L2], A = fk(p.lF || [0, 0]), B = fk(p.lB || [0, 0]);
    p = { ...p, drop: (p.drop || 0) + p.squat, lF: ik(A[0], A[1] - p.squat), lB: ik(B[0], B[1] - p.squat) };
  }
  // chuyen dong phu: tho khong deu; dung yen thi don trong tam rat nhe (idle: false de tat)
  const sd = o.seed || 0, idle = o.idle !== false && !sh;
  const hv = o.heavy || 0;   // tho doc (act pant): nhanh va manh hon
  // nhip ve tay (R21): dung yen thi gan nhu giu nguyen (chi tho rat nhe); ngoai le: so / lo / hoang / khoc -> tho nhanh + run; chay / tho doc giu nhu cu
  const handA = !cl && o.anim === 'hand', anx = handA && ANX.includes(o.face) ? 1 : 0, calm = handA && !anx && !hv && !(p.mv > 0.2);
  const breathe = (Math.sin(t * 2.1 * (1 + 1.6 * hv + 0.9 * anx) + sd) + (idle && !calm ? 0.35 * Math.sin(t * 0.77 + sd * 2.3) : 0)) * 0.6 * U * (1 + 2.2 * hv + 0.5 * anx) * (calm ? 0.35 : 1);
  if (sh && !cl && o.menace !== false) {   // bong den (dang moi): cui ve phia nguoi, dau nghieng lac cham, tay vuon ra thu vao rat cham
    const s1 = Math.sin(t * 0.8 + sd), s2 = Math.sin(t * 0.55 + sd * 1.7);
    p = { ...p, lean: (p.lean || 0) + 0.07 + 0.035 * s1, head: [(p.head?.[0] || 0) + 1.5 + 2 * s2, (p.head?.[1] || 0) + 1.2 + 0.8 * s1] };
    if (p.aF) p.aF = [p.aF[0] + 0.07 * Math.sin(t * 1.05 + sd), p.aF[1] + 0.09 * Math.sin(t * 1.3 + sd)];
  }
  if (idle && !(p.mv > 0.2) && !calm) p = { ...p, lean: (p.lean || 0) + noise(t * 0.32, sd + 3) * 0.014, head: [(p.head?.[0] || 0) + noise(t * 0.45, sd + 7) * 0.5, p.head?.[1] || 0] };
  if (o.age === 'old' && !sh && !cl) p = { ...p, lean: (p.lean || 0) + 0.07, head: [(p.head?.[0] || 0) + 1.2, (p.head?.[1] || 0) + 1.8] };   // 1.10 tuoi gia: hoi khom, dau cui
  const drop = (p.drop || 0) * U - (p.bounce || 0) * U * -1 * 0, bounce = (p.bounce || 0) * U;
  g.save(); g.translate(x, y);
  if (anx) g.translate(noise(t * 21, sd + 11) * 0.45 * U, noise(t * 17, sd + 13) * 0.3 * U);   // run nguoi khi so
  if (o.lift) g.translate(0, -o.lift);   // nam / gục xuong san: nang than len de khong lun xuong dat
  if (o.rot) g.rotate(o.rot);
  if (o.scale) g.scale(o.scale, o.scale);
  if (sh && glowC && cl) { // vong sang duoi chan + vien phat sang (dang moi: bo vong do duoi chan nhu phim mau)
    g.save(); g.globalCompositeOperation = 'lighter'; g.fillStyle = radGrad(g, 0, 0, 0, 30 * U, [[0, alpha(glowC, 0.25)], [1, alpha(glowC, 0)]]); g.scale(1, 0.22); g.beginPath(); g.arc(0, 0, 30 * U, 0, Math.PI * 2); g.fill(); g.restore();
    g.save(); g.strokeStyle = glowC; g.lineWidth = 1.6 * U; g.shadowColor = glowC; g.shadowBlur = 8 * U; g.beginPath(); g.ellipse(0, 0, 20 * U, 4.2 * U, 0, 0, Math.PI * 2); g.stroke(); g.restore();
  }
  const hipY = -30 * U + drop - bounce, lean = p.lean || 0;
  // dang moi: than dai hon 4U, dau nho hon va ha thap -> dinh lien than (chieu cao tong gan nhu cu)
  const TL = cl ? 32 : 36, HD = cl ? 15 : 13;
  const neck = [Math.sin(lean) * TL * U * f, hipY - Math.cos(lean) * TL * U];
  const sx = (k) => neck[0] + (k * 9 * U) * Math.cos(lean) + (p.twist || 0) * U * f, shY = neck[1] + 3 * U + breathe * 0.4;
  const hx = neck[0] + ((p.head?.[0] || 0) + Math.sin(lean) * (HD - 1)) * U * f, hy = neck[1] - HD * U + (p.head?.[1] || 0) * U + breathe * 0.5;
  const R = (o.kid ? (cl ? 16.5 : 14) : (cl ? 18.5 : 15.5)) * U;
  const legW = 8 * U, armW = 6.4 * U;
  const hipF = [2.5 * U * f, hipY], hipB = [-2.5 * U * f, hipY];
  // chan: [goc dui, goc cang chan] tuyet doi
  const leg = (side, ang) => seg2(side[0], side[1], ang[0], 15 * U, ang[1] ?? ang[0], 15.5 * U, f);
  const arm = (k, ang) => seg2(sx(k), shY, ang[0], 12.5 * U, ang[1], 12 * U, f);
  const pal = { skin, edge, lw };
  const glowSil = (fn) => { if (sh && glowC) { g.save(); g.shadowColor = glowC; g.shadowBlur = 26 * U * (o.glowK ?? 1); fn(); g.restore(); } fn(); };
  const drawArm = (pts, front) => { const hd = pts[2]; if (cl) { limb(g, pts, armW, skin, edge, lw); dot(g, hd[0], hd[1], 4.2 * U, skin, edge, lw); } else limbT(g, pts, armW, armW * 0.84, armW * 0.56, skin, edge, lw); if (front && o.hold && o.hold !== 'none') holdItem(g, hd[0], hd[1], U, f, o.hold, t, o); };
  // dang quay chinh dien (|f| < 1): vai tach ra hai ben thay vi dồn vao giua (tay khong luot qua bung); ffrom = huong truoc khi quay
  const fe = Math.abs(f) >= 0.999 ? f : f + (o.ffrom || Math.sign(f) || 1) * (1 - Math.abs(f));
  // 1.10 nham tay: bong den vuon tay (reach / point) toi diem o.aim (vai nguoi hung, toa do the gioi): IK 2 doan, khuyu tay chui xuong, khong vuot qua diem
  if (o.aim && sh && !cl && p.aF && p.aF[0] > 0.9) {
    const sc = o.scale || 1, tx = (o.aim[0] - x) / sc, ty = (o.aim[1] - y) / sc, dx = (tx - sx(fe)) * Math.sign(f || 1), dy = ty - shY;
    if (dx > 4 * U) {
      const L1a = 12.5, L2a = 12, d = clamp(Math.hypot(dx, dy) / U, 6, L1a + L2a - 0.4), phi = Math.atan2(dx, dy);
      const A = Math.acos(clamp((L1a * L1a + d * d - L2a * L2a) / (2 * L1a * d), -1, 1)), B = Math.acos(clamp((L1a * L1a + L2a * L2a - d * d) / (2 * L1a * L2a), -1, 1));
      const a1 = phi - A, a2 = a1 + (Math.PI - B), w = clamp(o.aimK ?? 1);
      p = { ...p, aF: [lerp(p.aF[0], a1, w), lerp(p.aF[1], a2, w)] };
    }
  }
  const aB = arm(-1 * fe, p.aB || [0, 0]), aF = arm(1 * fe, p.aF || [0, 0]); let feet = null;
  glowSil(() => {
    // tay sau, chan
    drawArm(aB, false);
    const lb = leg(hipB, p.lB || [0, 0]), lf = leg(hipF, p.lF || [0, 0]); feet = [lf[2], lb[2]];
    if (cl) { limb(g, lb, legW, sh ? skin : shade(skin, -0.05), edge, lw); limb(g, lf, legW, skin, edge, lw); }
    else { limbT(g, lb, legW * 1.04, legW * 0.86, legW * 0.47, sh ? skin : shade(skin, -0.07), edge, lw); limbT(g, lf, legW * 1.04, legW * 0.86, legW * 0.47, skin, edge, lw); }
    if (o.shoes) for (const L of [lb, lf]) { g.beginPath(); g.ellipse(L[2][0] + 2 * U * f, L[2][1] - 1 * U, 5 * U, 2.6 * U, 0, 0, Math.PI * 2); g.fillStyle = o.shoes; g.fill(); }
    // than (bao tron)
    const tw = (cl ? 12.5 : 11.5) * U, bw = (cl ? 14 : 14.5) * U, k = TL / 32, bodyEdge = o.hood || o.shirt ? shade(o.hood ? PAL.hood : o.shirt, -0.35) : edge;
    const torso = cl ? () => { g.beginPath(); g.moveTo(-tw, 2 * U); g.bezierCurveTo(-tw - 1 * U, 14 * U * k, -bw - 1 * U, 26 * U * k, -bw + 2 * U, 31 * U * k); g.quadraticCurveTo(0, 34 * U * k, bw - 2 * U, 31 * U * k); g.bezierCurveTo(bw + 1 * U, 26 * U * k, tw + 1 * U, 14 * U * k, tw, 2 * U); g.quadraticCurveTo(0, -3 * U, -tw, 2 * U); g.closePath(); }
      : () => {   // hat dau: eo thon duoi dau, phinh dan, day tron (khong goc vuong)
        g.beginPath(); g.moveTo(-10 * U, 0); g.bezierCurveTo(-12 * U, 10 * U * k, -14.5 * U, 19 * U * k, -14 * U, 27 * U * k); g.bezierCurveTo(-13.5 * U, 36 * U * k, 13.5 * U, 36 * U * k, 14 * U, 27 * U * k);
        g.bezierCurveTo(14.5 * U, 19 * U * k, 12 * U, 10 * U * k, 10 * U, 0); g.quadraticCurveTo(0, -4 * U, -10 * U, 0); g.closePath(); };
    if (!cl && edge) {   // dang moi: vien chung cua than + dau (ve vien truoc, to sau) -> dau dinh lien than nhu hat dau
      g.save(); g.translate(neck[0], neck[1]); g.rotate(lean * f); torso(); g.lineWidth = lw * 2; g.strokeStyle = bodyEdge; g.lineJoin = 'round'; g.stroke(); g.restore();
      g.beginPath(); g.arc(hx, hy, R, 0, Math.PI * 2); g.lineWidth = lw * 2; g.strokeStyle = edge; g.stroke();
    }
    g.save(); g.translate(neck[0], neck[1]); g.rotate(lean * f);
    torso();
    g.fillStyle = sh ? skin : (o.hood ? PAL.hood : o.shirt || skin); g.fill(); if (edge && cl) { g.lineWidth = lw; g.strokeStyle = bodyEdge; g.stroke(); }
    if (!sh && !o.hood && !o.shirt) { g.save(); g.clip(); g.fillStyle = alpha(PAL.heroShade, 0.55); g.fillRect(-bw * f * 1.0 - (f > 0 ? 0 : 0), -5 * U, bw * 0.7 * -f, 40 * U); g.restore(); }
    if (o.hood) { g.beginPath(); g.moveTo(-3 * U, 6 * U); g.lineTo(-3 * U, 12 * U); g.moveTo(3 * U, 6 * U); g.lineTo(3 * U, 12 * U); g.lineWidth = 0.9 * U; g.strokeStyle = '#2e3036'; g.stroke(); g.beginPath(); g.roundRect(-8 * U, 20 * U, 16 * U, 7 * U, 2 * U); g.strokeStyle = '#44474e'; g.stroke(); }
    if (o.hood && o.hood !== 'up') { g.beginPath(); g.ellipse(-1.5 * U * f, 1.5 * U, tw * 0.95, 5.2 * U, 0, 0, Math.PI * 2); g.fillStyle = PAL.hoodDark; g.fill(); g.lineWidth = lw; g.strokeStyle = '#2e3036'; g.stroke(); }
    if (o.scarf) { g.beginPath(); g.roundRect(-tw - 1 * U, -1 * U, tw * 2 + 2 * U, 6 * U, 3 * U); g.fillStyle = o.scarf; g.fill(); g.beginPath(); g.roundRect(3 * U * f, 3 * U, 5 * U, 12 * U, 2 * U); g.fill(); }
    g.restore();
    // dau
    head(g, hx, hy, R, { ...o, U, f, t, pal, mv: p.mv || 0, noEdge: !cl });
    // tay truoc
    drawArm(aF, true);
  });
  // anh sang man hinh hat len mat
  if (o.glowFace) light(g, hx + 10 * U * f, hy + 6 * U, R * 2.4, o.glowFace, 0.32);
  else if (!cl && o.details && o.hold === 'phone' && !sh && !o.hideHold) light(g, hx + 8 * U * f, hy + 5 * U, R * 2.3, o.screen || PAL.screen, 0.26);   // tu hat anh man hinh len mat
  g.restore();
  return { head: [x + hx, y + hy], R, hand: [x + aF[2][0], y + aF[2][1]], handB: [x + aB[2][0], y + aB[2][1]], feet: feet && !o.rot && !o.scale ? feet.map((q) => [x + q[0], y + q[1]]) : null };
}

// ---------- dau + mat
export const FACES = ['neutral', 'tired', 'sleepy', 'sleep', 'sad', 'cry', 'worried', 'scared', 'shock', 'angry', 'determined', 'effort', 'smile', 'happy', 'smirk', 'empty', 'guilty', 'bloodshot', 'haunted', 'grin',
  'hopeful', 'relieved', 'proud', 'embarrassed', 'disgusted', 'annoyed', 'skeptical', 'exhausted', 'yawn', 'dazed', 'panic', 'sob', 'shout', 'thinking', 'tempted', 'grit', 'lonely'];   // dong 2: chi co o dang moi (classic -> ra neutral)
export function head(g, x, y, R, o = {}) {
  const U = o.U || R / 17, f = o.f ?? o.facing ?? 1, t = o.t || 0, sh = !!o.shadow, pal = o.pal || (isCl(o) ? { skin: o.skin || PAL.hero, edge: PAL.heroLine, lw: 2 } : { skin: o.skin || PAL.hero, edge: '#4f4a43', lw: Math.max(1.3, 0.62 * U) });
  const look = (o.look ?? 0.25) * f;
  // mu trum (sau dau)
  if (o.hood === 'up') { g.beginPath(); g.ellipse(x - 1.5 * U * f, y + 1 * U, R * 1.28, R * 1.22, 0, 0, Math.PI * 2); g.fillStyle = PAL.hood; g.fill(); g.lineWidth = pal.lw; g.strokeStyle = PAL.hoodDark; g.stroke(); }
  if (o.hair === 'bob' && !sh) { g.beginPath(); g.ellipse(x, y + 1 * U, R * 1.12, R * 1.08, 0, Math.PI * 0.92, Math.PI * 2.08); g.lineTo(x + R * 1.12, y + R * 0.75); g.lineTo(x - R * 1.12, y + R * 0.75); g.closePath(); g.fillStyle = PAL.hair; g.fill(); }
  if (o.hair === 'bun' && !sh) { dot(g, x - 2 * U * f, y - R * 1.05, R * 0.38, '#5a4a40'); }
  g.beginPath(); g.arc(x, y, R, 0, Math.PI * 2); g.fillStyle = pal.skin; g.fill();
  if (pal.edge && !o.noEdge) { g.lineWidth = pal.lw; g.strokeStyle = pal.edge; g.stroke(); }
  if (!sh) { // bong mem nua sau
    g.save(); g.beginPath(); g.arc(x, y, R - pal.lw / 2, 0, Math.PI * 2); g.clip(); g.fillStyle = alpha(PAL.heroShade, 0.38); g.beginPath(); g.arc(x + R * 0.28 * f, y - R * 0.05, R * 1.02, 0, Math.PI * 2); g.rect(x - R * 2, y - R * 2, R * 4, R * 4); g.fill('evenodd'); g.restore();
  }
  if (o.hood === 'up') { g.beginPath(); g.arc(x - 1.5 * U * f, y + 1 * U, R * 1.16, Math.PI * (f > 0 ? 0.55 : 0.45) - 0.0, Math.PI * (f > 0 ? 0.55 : 0.45) + 0.001); g.save(); g.beginPath(); g.ellipse(x - 1.5 * U * f, y + 1 * U, R * 1.28, R * 1.22, 0, 0, Math.PI * 2); g.ellipse(x + 0.5 * U * f, y + 0.5 * U, R * 1.0, R * 1.02, 0, 0, Math.PI * 2); g.fillStyle = PAL.hood; g.fill('evenodd'); g.restore(); }
  if (o.hood === 'up' && !sh) { g.save(); g.beginPath(); g.arc(x, y, R - pal.lw / 2, 0, Math.PI * 2); g.clip(); g.beginPath(); g.ellipse(x - 2 * U * f, y - R * 1.05, R * 1.25, R * 0.55, 0, 0, Math.PI * 2); g.fillStyle = PAL.hood; g.fill(); g.lineWidth = 1.4 * U; g.strokeStyle = PAL.hoodDark; g.stroke(); g.restore(); }
  if (o.hair === 'bob' && !sh) { g.beginPath(); g.ellipse(x, y - R * 0.18, R * 1.02, R * 0.78, 0, Math.PI, Math.PI * 2); g.lineTo(x + R * 1.0, y - R * 0.12); g.quadraticCurveTo(x, y - R * 0.32, x - R * 1.0, y - R * 0.12); g.closePath(); g.fillStyle = PAL.hair; g.fill(); }
  if (o.cap && !sh) { g.beginPath(); g.ellipse(x, y - R * 0.3, R * 1.02, R * 0.85, 0, Math.PI, Math.PI * 2); g.closePath(); g.fillStyle = o.cap; g.fill(); g.beginPath(); g.ellipse(x + R * 0.75 * f, y - R * 0.32, R * 0.62, R * 0.14, 0, 0, Math.PI * 2); g.fill(); g.lineWidth = 1.2 * U; g.strokeStyle = shade(o.cap, -0.35); g.stroke(); }
  if (o.headband && !sh) { // duoi bang do: dung yen bay nhe, di / chay bay manh va keo dai ra sau
    const c = o.bandColor || accent(), mv = o.mv || 0, fr = 2.4 + 9 * mv, am = (1.2 + 2.4 * mv) * U, st = 1 + 0.25 * mv;
    g.save(); g.beginPath(); g.arc(x, y, R - pal.lw / 2, 0, Math.PI * 2); g.clip(); g.fillStyle = c; g.fillRect(x - R, y - R * 0.62, R * 2, R * 0.28); g.restore(); g.fillStyle = c; g.beginPath(); g.moveTo(x - R * 0.95 * f, y - R * 0.5); g.quadraticCurveTo(x - R * 1.45 * st * f, y - R * 0.6 + Math.sin(t * fr) * am, x - R * 1.7 * st * f, y - R * 0.25 + Math.sin(t * fr + 1) * am - mv * 2 * U); g.lineTo(x - R * 1.62 * st * f, y - R * 0.12 - mv * 2 * U); g.quadraticCurveTo(x - R * 1.35 * f, y - R * 0.35, x - R * 0.95 * f, y - R * 0.33); g.closePath(); g.fill(); }
  if (o.glasses && !sh) { g.lineWidth = 1.4 * U; g.strokeStyle = '#2a2a2e'; for (const k of [-1, 1]) { g.beginPath(); g.arc(x + (k * 0.42 + look * 0.3) * R, y - R * 0.02, R * 0.22, 0, Math.PI * 2); g.stroke(); } }
  (isCl(o) ? face : face2)(g, x, y, R, o.face || 'neutral', { ...o, look, U, f, t, sh });
  if (o.age === 'old' && !sh && !isCl(o)) {   // 1.10 tuoi gia (age: "old"): 2 nep nhan tran + vai soi toc bac tren dinh dau (khong ve chom 2 ben: trong nhu chup tai)
    g.save(); g.lineCap = 'round'; g.lineWidth = 1.1 * U; g.strokeStyle = 'rgba(79,74,67,0.5)';
    for (const k of [0, 1]) { const yy = y - R * (0.66 - k * 0.14), cx = x + look * R * 0.18; g.beginPath(); g.moveTo(cx - R * (0.3 - k * 0.04), yy); g.quadraticCurveTo(cx, yy - R * 0.06, cx + R * (0.3 - k * 0.04), yy); g.stroke(); }
    // toc bac thua: 1 vet cong nam sat dinh dau, phia sau gay (khong dung len: trong nhu rau con trung)
    const a0 = -Math.PI / 2 - f * 0.25; g.strokeStyle = 'rgba(214,214,220,0.95)'; g.lineWidth = R * 0.11;
    g.beginPath(); g.arc(x, y, R * 0.97, a0 - f * 0.15, a0 - f * 1.25, f > 0); g.stroke();
    g.lineWidth = 0.9 * U; g.strokeStyle = 'rgba(150,150,158,0.8)';
    for (const k of [0.35, 0.7, 1.0]) { const an = a0 - f * k, r0 = R * 0.9, r1 = R * 1.04; g.beginPath(); g.moveTo(x + Math.cos(an) * r0, y + Math.sin(an) * r0); g.lineTo(x + Math.cos(an - f * 0.08) * r1, y + Math.sin(an - f * 0.08) * r1); g.stroke(); }
    g.restore();
  }
}

// thong so tung bieu cam. Doi bieu cam (faceAt) thi tron dan: fromFace -> face theo faceK (0..1)
const FACE_DEF = {
  neutral: { lid: 0.12, brow: 0 }, tired: { lid: 0.5, brow: -0.05, bags: 1 }, sleepy: { lid: 0.75, brow: 0 }, sleep: { lid: 1, brow: 0, mouth: 'flat' },
  sad: { lid: 0.35, brow: -0.35, mouth: 'frown' }, cry: { lid: 0.3, brow: -0.45, mouth: 'wobble', tears: 1 }, worried: { lid: 0.1, brow: -0.3, mouth: 'flat', sweat: 1 },
  scared: { lid: 0, brow: -0.45, mouth: 'wobble', sweat: 1, small: 1 }, shock: { lid: 0, brow: -0.2, mouth: 'o', small: 1 }, angry: { lid: 0.3, brow: 0.5, mouth: 'frown' },
  determined: { lid: 0.32, brow: 0.42, mouth: 'flat' }, effort: { lid: 0.4, brow: 0.55, mouth: 'teeth', sweat: 1 }, smile: { lid: 0.15, brow: -0.05, mouth: 'smile' },
  happy: { lid: 0, brow: -0.1, mouth: 'open', eyes: 'arc' }, smirk: { lid: 0.35, brow: 0.2, mouth: 'smirk' }, empty: { lid: 0.45, brow: 0, mouth: 'flat', bags: 1, dead: 1 },
  guilty: { lid: 0.4, brow: -0.35, mouth: 'flat', look: -0.6 }, bloodshot: { lid: 0.05, brow: -0.25, mouth: 'frown', blood: 1, small: 1 }, haunted: { lid: 0.3, brow: -0.2, mouth: 'flat', blood: 1 }, grin: { mouth: 'grin', eyes: 'slit' },
};
// mieng net (uon dan duoc): [trai x, y, diem uon x, y, phai x, y, do run] theo be ngang mieng
const MOUTH = { flat: [-0.8, 0, 0, 0, 0.8, 0, 0], frown: [-1, 0.35, 0, -0.45, 1, 0.35, 0], smile: [-1, -0.15, 0, 0.65, 1, -0.15, 0], smirk: [-0.8, 0.1, 0.3, 0.25, 1, -0.35, 0], wobble: [-1, 0.2, 0, 0.2, 1, 0.2, 0.18] };
function mouthLine(g, mx, my, mw, P) {
  g.beginPath(); g.moveTo(mx + P[0] * mw, my + P[1] * mw);
  if (!P[6]) g.quadraticCurveTo(mx + P[2] * mw, my + P[3] * mw, mx + P[4] * mw, my + P[5] * mw);
  else { const v = (n) => (n === 0 ? 0 : n % 2 ? -1 : 1); for (let j = 1; j <= 24; j++) { const u = j / 24, s = u * 6, i = Math.floor(s), off = lerp(v(i), v(Math.min(6, i + 1)), s - i) * P[6]; g.lineTo(mx + ((1 - u) * (1 - u) * P[0] + 2 * (1 - u) * u * P[2] + u * u * P[4]) * mw, my + ((1 - u) * (1 - u) * P[1] + 2 * (1 - u) * u * P[3] + u * u * P[5] + off) * mw); } }
  g.stroke();
}
// chop mat: ngau nhien 2,2-6 giay / lan, doi khi chop doi; nham nhanh, mo cham, co khung nham do. 0 = mo, 1 = nham kin
export const blinkShape = (d) => (d < 0 ? 0 : d < 0.05 ? ease.in(d / 0.05) : d < 0.09 ? 1 : d < 0.21 ? 1 - ease.sine((d - 0.09) / 0.12) : 0);
export function blinkAt(t, seed = 0, slow = 1) {   // slow > 1: chop cham (met, buon ngu)
  const r = rng(Math.floor(Math.abs(seed) * 977) + 7); let tb = 0.4 + r() * 2.6, v = 0;
  while (tb <= t) { v = Math.max(v, blinkShape((t - tb) / slow)); if (r() < 0.22) v = Math.max(v, blinkShape((t - tb) / slow - 0.27)); tb += 2.2 + r() * 3.8; }
  return v;
}

function face(g, x, y, R, name, o) {
  const { U, t, sh } = o, look = o.look;
  const ex = (k) => x + (k * 0.38 + look * 0.32) * R, ey = y - R * 0.02, er = R * 0.2;
  const ink = sh ? null : '#2a2826', line = sh ? (o.glow || accent()) : '#4a463f';
  const F = FACE_DEF[name] || { lid: 0.12 };
  if (sh || name === 'grin') { // bong den: mat la vet sang cong, mieng cuoi rong
    g.save(); g.strokeStyle = line; g.shadowColor = line; g.shadowBlur = 10 * U; g.lineWidth = 2.6 * U; g.lineCap = 'round';
    for (const k of [-1, 1]) { g.beginPath(); g.moveTo(ex(k) - er * 1.0, ey - er * 0.1 + k * 0); g.quadraticCurveTo(ex(k), ey - er * (sh && name === 'angry' ? -0.6 : 0.9), ex(k) + er * 1.0, ey + er * 0.1); g.stroke(); }
    if (name !== 'sad') { g.beginPath(); g.moveTo(x - R * 0.42 + look * R * 0.25, y + R * 0.36); g.quadraticCurveTo(x + look * R * 0.25, y + R * 0.78, x + R * 0.42 + look * R * 0.25, y + R * 0.36); g.stroke(); }
    else { g.beginPath(); g.moveTo(x - R * 0.3, y + R * 0.55); g.quadraticCurveTo(x, y + R * 0.38, x + R * 0.3, y + R * 0.55); g.stroke(); }
    g.restore(); return;
  }
  // doi bieu cam: tron dan mi, may, con nguoi, mieng; nuoc mat / mo hoi / quang tham hien dan
  const F0 = o.fromFace && o.fromFace !== 'grin' && (o.faceK ?? 1) < 1 ? (FACE_DEF[o.fromFace] || { lid: 0.12 }) : null, q = F0 ? clamp(o.faceK) : 1;
  const mixv = (fn) => (F0 ? lerp(fn(F0), fn(F), q) : fn(F));
  const open = (f) => !f.eyes && (f.lid || 0) < 0.98;
  let blink = o.blink === false ? 0 : blinkAt(t, o.blinkSeed ?? o.seed ?? 0);
  if (F0 && open(F0) && open(F) && o.faceSince !== undefined) blink = Math.max(blink, blinkShape(o.faceSince));   // chop mat dung luc doi bieu cam
  const lid = Math.max(mixv((f) => f.lid || 0), blink), lk = mixv((f) => f.look ?? 0) * R * 0.08;
  const bagsA = mixv((f) => (f.bags ? 1 : 0)), bloodA = o.bloodshot ? 1 : mixv((f) => (f.blood ? 1 : 0)), deadA = mixv((f) => (f.dead ? 1 : 0)), arcA = mixv((f) => (f.eyes === 'arc' ? 1 : 0));
  const browA = mixv((f) => (open(f) ? 1 : 0)), brow = mixv((f) => f.brow || 0), small = mixv((f) => (f.small ? 1 : 0));
  const fade = (a, fn) => { if (a <= 0) return; g.save(); g.globalAlpha *= Math.min(1, a); fn(); g.restore(); };
  for (const k of [-1, 1]) {
    const cx = ex(k), cy = ey;
    fade(bagsA, () => { g.beginPath(); g.ellipse(cx, cy + er * 0.55, er * 1.1, er * 0.75, 0, 0, Math.PI); g.fillStyle = 'rgba(110,80,110,0.35)'; g.fill(); });
    fade(arcA, () => { g.beginPath(); g.arc(cx, cy + er * 0.3, er * 0.75, Math.PI * 1.1, Math.PI * 1.9); g.lineWidth = 2 * U; g.strokeStyle = ink; g.stroke(); });
    fade(1 - arcA, () => {
      if (lid >= 0.98) { g.beginPath(); g.moveTo(cx - er * 0.9, cy + er * 0.2); g.quadraticCurveTo(cx, cy + er * 0.7, cx + er * 0.9, cy + er * 0.2); g.lineWidth = 1.8 * U; g.strokeStyle = ink; g.stroke(); return; }
      const blood = bloodA >= 0.5;
      fade(bloodA * (1 - bagsA), () => { g.beginPath(); g.ellipse(cx, cy + er * 0.55, er * 1.15, er * 0.8, 0, 0, Math.PI); g.fillStyle = 'rgba(70,40,55,0.45)'; g.fill(); });
      g.beginPath(); g.ellipse(cx, cy, er, er * 1.05, 0, 0, Math.PI * 2); g.fillStyle = bloodA <= 0 ? '#ffffff' : bloodA >= 1 ? '#f6d4d4' : mix('#ffffff', '#f6d4d4', bloodA); g.fill(); g.lineWidth = 1.2 * U; g.strokeStyle = '#6d685e'; g.stroke();
      fade(Math.max(bagsA, deadA, bloodA), () => { g.beginPath(); g.ellipse(cx, cy, er, er * 1.05, 0, 0, Math.PI * 2); g.clip(); g.strokeStyle = blood ? 'rgba(200,55,65,0.75)' : 'rgba(220,90,90,0.5)'; g.lineWidth = (blood ? 0.55 : 0.8) * U; for (const sd of blood ? [-1, 1] : [-1]) for (let i = 0; i < (blood ? 4 : 3); i++) { const yy = cy + (i - 1.5) * er * 0.38; g.beginPath(); g.moveTo(cx + sd * er, yy); g.quadraticCurveTo(cx + sd * er * 0.72, yy + er * 0.12 * (i % 2 ? 1 : -1), cx + sd * er * 0.5, yy + er * 0.05); g.stroke(); } });
      const pr = er * lerp(0.48, 0.32, small);
      dot(g, cx + look * er * 0.45 + lk, cy + er * 0.12, pr, '#1e1c1b');
      fade(1 - deadA, () => dot(g, cx + look * er * 0.45 + lk + pr * 0.35, cy + er * 0.12 - pr * 0.35, pr * 0.3, '#ffffff'));
      if (lid > 0.02) { g.save(); g.beginPath(); g.ellipse(cx, cy, er + 0.6, er * 1.05 + 0.6, 0, 0, Math.PI * 2); g.clip(); g.fillStyle = o.pal?.skin || PAL.hero; g.fillRect(cx - er - 2, cy - er * 1.1 - 1, er * 2 + 4, er * 2.1 * lid + 1); g.beginPath(); g.moveTo(cx - er, cy - er * 1.05 + er * 2.1 * lid); g.lineTo(cx + er, cy - er * 1.05 + er * 2.1 * lid); g.lineWidth = 1.5 * U; g.strokeStyle = '#6d685e'; g.stroke(); g.restore(); }
    });
    // long may: b > 0 = cau (dau trong cup xuong), b < 0 = buon (dau trong nhuong len). Van ve khi dang chop mat
    fade(browA, () => {
      const b = brow, by = cy - er * 1.55, inner = cx - k * er * 0.85, outer = cx + k * er * 0.9;
      g.beginPath(); g.moveTo(outer, by - b * er * 0.45); g.lineTo(inner, by + b * er * 0.9);
      g.lineWidth = 1.7 * U; g.strokeStyle = '#3d3a35'; g.lineCap = 'round'; g.stroke();
    });
  }
  // mieng: hai mieng net -> uon dan; co mieng ha (o, open, teeth) -> mo dan / khep dan
  const mx = x + look * R * 0.28, my = y + R * 0.47, mw = R * 0.22;
  const drawMouth = (m, a, sc) => fade(a, () => {
    g.save(); g.translate(mx, my); g.scale(sc, sc); g.translate(-mx, -my);
    g.lineWidth = 1.9 * U; g.strokeStyle = '#3d3a35'; g.lineCap = 'round';
    if (m === 'flat') { g.beginPath(); g.moveTo(mx - mw * 0.8, my); g.lineTo(mx + mw * 0.8, my); g.stroke(); }
    if (m === 'frown') { g.beginPath(); g.moveTo(mx - mw, my + mw * 0.35); g.quadraticCurveTo(mx, my - mw * 0.45, mx + mw, my + mw * 0.35); g.stroke(); }
    if (m === 'smile') { g.beginPath(); g.moveTo(mx - mw, my - mw * 0.15); g.quadraticCurveTo(mx, my + mw * 0.65, mx + mw, my - mw * 0.15); g.stroke(); }
    if (m === 'smirk') { g.beginPath(); g.moveTo(mx - mw * 0.8, my + mw * 0.1); g.quadraticCurveTo(mx + mw * 0.3, my + mw * 0.25, mx + mw, my - mw * 0.35); g.stroke(); }
    if (m === 'o') { g.beginPath(); g.ellipse(mx, my + mw * 0.2, mw * 0.45, mw * 0.6, 0, 0, Math.PI * 2); g.fillStyle = '#4a2f2c'; g.fill(); }
    if (m === 'open') { g.beginPath(); g.moveTo(mx - mw, my - mw * 0.1); g.quadraticCurveTo(mx, my + mw * 1.2, mx + mw, my - mw * 0.1); g.closePath(); g.fillStyle = '#5a3430'; g.fill(); }
    if (m === 'teeth') { g.beginPath(); g.roundRect(mx - mw * 1.1, my - mw * 0.35, mw * 2.2, mw * 0.8, mw * 0.25); g.fillStyle = '#ffffff'; g.fill(); g.stroke(); g.beginPath(); g.moveTo(mx - mw * 1.1, my + mw * 0.05); g.lineTo(mx + mw * 1.1, my + mw * 0.05); g.lineWidth = 1 * U; g.stroke(); }
    if (m === 'wobble') { g.beginPath(); g.moveTo(mx - mw, my + mw * 0.2); for (let i = 1; i <= 6; i++) g.lineTo(mx - mw + (i / 6) * mw * 2, my + mw * 0.2 + (i % 2 ? -1 : 1) * mw * 0.18); g.stroke(); }
    g.restore();
  });
  const m = F.mouth || 'flat', m0 = F0 ? F0.mouth || 'flat' : m;
  if (!F0 || m0 === m) drawMouth(m, 1, 1);
  else if (MOUTH[m0] && MOUTH[m]) { g.lineWidth = 1.9 * U; g.strokeStyle = '#3d3a35'; g.lineCap = 'round'; mouthLine(g, mx, my, mw, MOUTH[m0].map((v, i) => lerp(v, MOUTH[m][i], q))); }
  else { drawMouth(m0, 1 - q, lerp(1, 0.6, q)); drawMouth(m, q, lerp(0.6, 1, q)); }
  fade(o.tears ? 1 : mixv((f) => (f.tears ? 1 : 0)), () => { for (const k of [-1, 1]) { const tx = ex(k) + k * er * 0.2, ty = ey + er * 1.2 + ((t * 0.9 + k * 0.3) % 1) * R * 0.5; g.beginPath(); g.moveTo(tx, ty - R * 0.12); g.quadraticCurveTo(tx + R * 0.07, ty, tx, ty + R * 0.06); g.quadraticCurveTo(tx - R * 0.07, ty, tx, ty - R * 0.12); g.fillStyle = 'rgba(140,200,255,0.9)'; g.fill(); } });
  fade(o.sweat ? 1 : mixv((f) => (f.sweat ? 1 : 0)), () => { const sx = x + R * 0.82 * (o.f > 0 ? -1 : 1), sy = y - R * 0.45 + Math.sin(t * 3) * 1.5; g.beginPath(); g.moveTo(sx, sy - R * 0.16); g.quadraticCurveTo(sx + R * 0.1, sy + R * 0.02, sx, sy + R * 0.08); g.quadraticCurveTo(sx - R * 0.1, sy + R * 0.02, sx, sy - R * 0.16); g.fillStyle = 'rgba(150,205,255,0.95)'; g.fill(); });
}

// ---------- mat dang moi (kieu phim mau): mat cham den nho + mi nang, long may dam cong, nhieu kieu mieng, cu dong nho theo cam xuc.
// Truong: lid (0 mo .. 1 nham) | brow (+ cau, - buon) | browA (lech: + = may ben trai nhuong) | lidTilt (+ mi xien vao trong = gian, - = buon)
// mouth | small (con nguoi nho) | wide (mat trang tron: so, bat ngo) | blush | tilt (nghieng dau, rad) | lookX / lookY (nhin ngang / len -, xuong +)
// dart (liec qua lai) | slow (chop cham) | tremble (moi / may run) | twitch (may giat) | tears (1 chay, 2 khoc nac) | sweat | bags | blood | dead | shine | mark ('!')
const FACE2 = {
  neutral: { lid: 0.22 }, tired: { lid: 0.55, brow: -0.1, bags: 1, slow: 1, tilt: 0.04 }, sleepy: { lid: 0.78, slow: 1.5, tilt: 0.06 }, sleep: { lid: 1, mouth: 'flat' },
  sad: { lid: 0.42, brow: -0.55, lidTilt: -0.4, mouth: 'frown', tilt: 0.08, lookY: 0.6, tremble: 0.25 }, cry: { lid: 0.38, brow: -0.65, lidTilt: -0.4, mouth: 'wobble', tears: 1, tilt: 0.08, tremble: 1 },
  worried: { lid: 0.12, brow: -0.5, mouth: 'tight', sweat: 1, dart: 1 }, scared: { lid: 0, brow: -0.65, mouth: 'wobble', sweat: 1, wide: 1, small: 1, dart: 1, tremble: 1 },
  shock: { lid: 0, brow: -0.35, mouth: 'o', wide: 1, small: 1, mark: 1 }, angry: { lid: 0.36, brow: 0.62, lidTilt: 0.35, mouth: 'frown', twitch: 1 },
  determined: { lid: 0.4, brow: 0.52, lidTilt: 0.25, mouth: 'flat' }, effort: { lid: 0.44, brow: 0.68, lidTilt: 0.3, mouth: 'teeth', sweat: 1 },
  smile: { lid: 0.2, brow: -0.08, mouth: 'smile' }, happy: { lid: 0, brow: -0.15, mouth: 'open', eyes: 'arc', blush: 0.5 }, smirk: { lid: 0.42, brow: 0.12, browA: 0.35, mouth: 'smirk' },
  empty: { lid: 0.5, mouth: 'flat', bags: 1, dead: 1, slow: 1.4 }, guilty: { lid: 0.46, brow: -0.42, mouth: 'tight', lookX: -0.7, lookY: 0.8, tilt: 0.1 },
  bloodshot: { lid: 0.06, brow: -0.3, mouth: 'frown', blood: 1, small: 1, wide: 1 }, haunted: { lid: 0.36, brow: -0.25, mouth: 'flat', blood: 1, bags: 1, slow: 1.2 }, grin: { lid: 0.55, brow: 0.25, mouth: 'grinw' },
  // bieu cam moi
  hopeful: { lid: 0.04, brow: -0.32, mouth: 'halfsmile', lookY: -0.7, tilt: -0.04, shine: 1 }, relieved: { lid: 0.62, brow: -0.28, mouth: 'smile', tilt: 0.05, slow: 1.3 },
  proud: { lid: 0.46, brow: 0.08, mouth: 'smile', tilt: -0.08, lookY: -0.2 }, embarrassed: { lid: 0.3, brow: -0.38, mouth: 'wobble', blush: 1, lookX: -0.7, lookY: 0.6, tilt: 0.07, sweat: 1 },
  disgusted: { lid: 0.5, brow: 0.38, browA: -0.35, mouth: 'disgust', tilt: -0.06 }, annoyed: { lid: 0.58, brow: 0.42, browA: 0.28, mouth: 'tight', twitch: 1 },
  skeptical: { lid: 0.42, brow: 0.12, browA: 0.65, mouth: 'smirk', tilt: -0.05 }, exhausted: { lid: 0.62, brow: -0.38, mouth: 'tongue', sweat: 1, bags: 1, slow: 1.5, tilt: 0.08 },
  yawn: { lid: 0.92, brow: -0.22, mouth: 'yawn', tilt: -0.1 }, dazed: { lid: 0.46, mouth: 'o', small: 1, slow: 1.6, tilt: 0.06, lookY: 0.25 },
  panic: { lid: 0, brow: -0.7, mouth: 'shout', wide: 1, small: 1, sweat: 1, dart: 1.6, tremble: 1, mark: 1 }, sob: { lid: 0.92, brow: -0.75, lidTilt: -0.3, mouth: 'shout', tears: 2, tremble: 1.3, tilt: 0.06 },
  shout: { lid: 0.14, brow: 0.62, lidTilt: 0.35, mouth: 'shout', twitch: 0.5 }, thinking: { lid: 0.3, brow: 0.05, browA: 0.45, mouth: 'pout', lookX: 0.6, lookY: -0.9, tilt: -0.08 },
  tempted: { lid: 0.52, brow: -0.1, mouth: 'halfsmile', slow: 1.3, shine: 1, lookY: 0.3 }, grit: { lid: 0.42, brow: 0.7, lidTilt: 0.35, mouth: 'grit', sweat: 0.6 },
  lonely: { lid: 0.46, brow: -0.42, lidTilt: -0.2, mouth: 'tight', lookY: 0.55, tilt: 0.07, slow: 1.3 },
};
// mieng net (uon dan duoc): [trai x, y, diem uon x, y, phai x, y, do run]
const MOUTH2 = { ...MOUTH, tight: [-0.45, 0, 0, 0, 0.45, 0, 0], halfsmile: [-0.75, 0.05, 0.25, 0.32, 0.9, -0.28, 0], disgust: [-0.9, 0.12, 0, -0.25, 0.9, -0.18, 0.12], pout: [-0.35, 0.12, 0, -0.3, 0.35, 0.12, 0] };
const hash1 = (n) => { const v = Math.sin(n * 127.1 + 311.7) * 43758.5453; return (v - Math.floor(v)) * 2 - 1; };
function dartAt(t, s) { const T = 0.62, z = (t + s * 0.37) / T, i = Math.floor(z), k = clamp((z - i) / 0.12); return lerp(hash1(i - 1 + s * 13), hash1(i + s * 13), k * k * (3 - 2 * k)); }   // liec: doi huong nhanh moi ~0,6 giay
function face2(g, x, y, R, name, o) {
  const { U, t, sh } = o, f = o.f ?? 1, look = o.look, sd = o.blinkSeed ?? o.seed ?? 0, skin = o.pal?.skin || PAL.hero, ink = '#1f1d1b', line = '#33302c';
  if (sh) {   // bong den: 2 mat do xech phat sang, khong mieng (buon: mat xech nguoc)
    const c = o.glow || accent(), s = name === 'sad' ? -1 : 1;
    g.save(); g.strokeStyle = c; g.shadowColor = c; g.shadowBlur = 12 * U; g.lineWidth = 3.4 * U; g.lineCap = 'round';
    for (const k of [-1, 1]) { const ex = x + (k * 0.36 + look * 0.3) * R, ey = y - R * 0.04; g.beginPath(); g.moveTo(ex + k * R * 0.17, ey - s * R * 0.08); g.lineTo(ex - k * R * 0.12, ey + s * R * 0.07); g.stroke(); }
    g.restore(); return;
  }
  const F = FACE2[name] || FACE2.neutral, F0 = o.fromFace && (o.faceK ?? 1) < 1 ? (FACE2[o.fromFace] || FACE2.neutral) : null, q = F0 ? clamp(o.faceK) : 1;
  const mv = (key) => { const v = (X) => +(X[key] ?? 0); return F0 ? lerp(v(F0), v(F), q) : v(F); };
  const mf = (fn) => (F0 ? lerp(fn(F0) ? 1 : 0, fn(F) ? 1 : 0, q) : fn(F) ? 1 : 0);
  const fade = (a, fn) => { if (a <= 0.001) return; g.save(); g.globalAlpha *= Math.min(1, a); fn(); g.restore(); };
  // cu dong nho: liec, run, giat may, mo to mat truoc khi hoang (lay da)
  const dart = mv('dart'), trem = mv('tremble'), twitch = mv('twitch') * Math.pow(Math.max(0, Math.sin(t * 1.3 + sd * 2.1)), 40) * 0.35;
  const wideA = mv('wide'), since = o.faceSince ?? 9, boost = F.wide && F0 && !F0.wide ? Math.sin(Math.PI * clamp(since / 0.3)) * 0.28 : 0;
  const tilt = mv('tilt') * f + noise(t * 9, sd + 4) * 0.012 * trem;
  g.save(); g.translate(x, y); g.rotate(tilt); g.translate(-x, -y);
  const lx = (mv('lookX') * f * 0.07 + dart * dartAt(t, sd) * 0.075) * R, ly = mv('lookY') * R * 0.06;
  const ex = (k) => x + (k * 0.34 + look * 0.3) * R + lx, ey = y + R * 0.03 + ly;
  const slow = 1 + 1.2 * Math.max(0, mv('slow') - (mv('slow') > 1 ? 0 : 0));
  let blink = o.blink === false ? 0 : blinkAt(t, sd, slow);
  const opn = (X) => !X.eyes && (X.lid || 0) < 0.97;
  if (F0 && opn(F0) && opn(F) && o.faceSince !== undefined) blink = Math.max(blink, blinkShape(o.faceSince));
  const lid = Math.max(mv('lid'), blink), lt = mv('lidTilt'), arcA = mf((X) => X.eyes === 'arc'), ps = lerp(1, 0.68, mv('small')) * (1 + boost);
  const bagsA = mv('bags'), bloodA = o.bloodshot ? 1 : mv('blood'), deadA = mv('dead'), shine = mv('shine'), blushA = Math.max(mv('blush'), o.blush ? 1 : 0);
  for (const k of [-1, 1]) {
    const cx = ex(k), cy = ey, rx = R * 0.09 * ps, ry = R * 0.13 * ps;
    fade(bagsA, () => { g.beginPath(); g.ellipse(cx, cy + R * 0.16, R * 0.15, R * 0.07, 0, 0, Math.PI); g.fillStyle = 'rgba(110,80,110,0.35)'; g.fill(); });
    fade(blushA, () => { g.beginPath(); g.ellipse(cx + k * R * 0.08, cy + R * 0.24, R * 0.14, R * 0.065, 0, 0, Math.PI * 2); g.fillStyle = 'rgba(236,120,120,0.42)'; g.fill(); });
    fade(arcA, () => { g.beginPath(); g.arc(cx, cy + R * 0.06, R * 0.12, Math.PI * 1.12, Math.PI * 1.88); g.lineWidth = 2.2 * U; g.strokeStyle = ink; g.lineCap = 'round'; g.stroke(); });
    fade(1 - arcA, () => {
      if (lid >= 0.97) { g.beginPath(); g.moveTo(cx - R * 0.13, cy); g.quadraticCurveTo(cx, cy + R * 0.09, cx + R * 0.13, cy); g.lineWidth = 2.1 * U; g.strokeStyle = ink; g.lineCap = 'round'; g.stroke(); return; }
      // mat trang tron (so / bat ngo) <-> mat cham den
      fade(wideA, () => { const sr = R * 0.15 * (1 + boost); g.beginPath(); g.ellipse(cx, cy, sr, sr * 1.12, 0, 0, Math.PI * 2); g.fillStyle = bloodA > 0.5 ? '#f6d8d6' : '#fbfaf6'; g.fill(); g.lineWidth = 0.9 * U; g.strokeStyle = '#8a857b'; g.stroke();
        if (bloodA > 0) { g.save(); g.clip(); g.strokeStyle = 'rgba(200,55,65,0.7)'; g.lineWidth = 0.55 * U; for (const s of [-1, 1]) for (let i = 0; i < 3; i++) { const yy = cy + (i - 1) * sr * 0.4; g.beginPath(); g.moveTo(cx + s * sr, yy); g.quadraticCurveTo(cx + s * sr * 0.7, yy + sr * 0.1, cx + s * sr * 0.45, yy); g.stroke(); } g.restore(); }
        g.beginPath(); g.arc(cx + look * sr * 0.3, cy + sr * 0.1, sr * 0.36 * ps, 0, Math.PI * 2); g.fillStyle = ink; g.fill(); });
      fade(1 - wideA, () => { g.beginPath(); g.ellipse(cx, cy, rx, ry, 0, 0, Math.PI * 2); g.fillStyle = deadA > 0.5 ? '#4a4642' : ink; g.fill(); });
      fade(shine * (1 - deadA), () => { g.beginPath(); g.arc(cx + rx * 0.35, cy - ry * 0.35, rx * 0.38, 0, Math.PI * 2); g.fillStyle = name === 'tempted' ? 'rgba(160,190,255,0.95)' : 'rgba(255,255,255,0.92)'; g.fill(); });
      // mi tren: to da phia tren duong mi + net mi xien (lidTilt: dau trong ha = gian, nang = buon)
      if (lid > 0.04) {
        const hh = Math.max(ry, wideA * R * 0.19), yl = cy - hh * 1.12 + lid * hh * 2.15, w = Math.max(rx * 1.45, wideA * R * 0.17 * 1.05), dIn = lt * hh * 0.7, yIn = yl + dIn, yOut = yl - dIn * 0.6;
        const xi = cx - k * w, xo = cx + k * w;
        g.save(); g.beginPath(); g.ellipse(cx, cy, w * 1.12, hh * 1.4, 0, 0, Math.PI * 2); g.clip(); g.beginPath(); g.moveTo(xi, yIn); g.lineTo(xo, yOut); g.lineTo(xo, cy - hh * 3); g.lineTo(xi, cy - hh * 3); g.closePath(); g.fillStyle = skin; g.fill(); g.restore();
        fade(clamp((lid - 0.04) / 0.12), () => { g.beginPath(); g.moveTo(xi + k * w * 0.12, yIn); g.quadraticCurveTo(cx, (yIn + yOut) / 2 - hh * 0.12, xo - k * w * 0.05, yOut); g.lineWidth = 1.7 * U; g.strokeStyle = ink; g.lineCap = 'round'; g.stroke(); });
      }
    });
    // long may: cong, dam; b > 0 cau (dau trong cup xuong), b < 0 buon (dau trong nhuong len); browA lam lech mot ben
    const b = mv('brow') + twitch + noise(t * 13 + k, sd) * 0.05 * trem, asym = mv('browA'), by = ey - R * 0.38 - (k < 0 ? asym * R * 0.1 : -asym * R * 0.02) - wideA * R * 0.05;
    const inX = cx - k * R * 0.11, outX = cx + k * R * 0.15, inY = by + b * R * 0.12, outY = by - b * R * 0.06;
    g.beginPath(); g.moveTo(outX, outY); g.quadraticCurveTo((inX + outX) / 2, Math.min(inY, outY) - R * 0.045 * (1 - Math.abs(b) * 0.6), inX, inY); g.lineWidth = (o.age === 'old' ? 2.6 : 2.1) * U; g.strokeStyle = o.age === 'old' && !o.sh ? '#c9c9cf' : line; g.lineCap = 'round'; g.stroke();   // 1.10 tuoi gia: long may bac, day hon
  }
  // mieng
  const mx = x + look * R * 0.26 + lx * 0.4, my = y + R * 0.45, mw = R * 0.19;
  const drawM = (m, a, sc) => fade(a, () => {
    g.save(); g.translate(mx, my); g.scale(sc, sc); g.translate(-mx, -my); g.lineWidth = 1.6 * U; g.strokeStyle = line; g.lineCap = 'round'; g.lineJoin = 'round';
    if (MOUTH2[m]) { const P = MOUTH2[m].slice(); if (m === 'wobble') P[6] = 0.14 + 0.06 * trem; mouthLine2(g, mx, my, mw, P, t, trem); }
    else if (m === 'o') { g.beginPath(); g.ellipse(mx, my + mw * 0.15, mw * 0.32, mw * 0.42, 0, 0, Math.PI * 2); g.fillStyle = '#3d2624'; g.fill(); }
    else if (m === 'open') { g.beginPath(); g.moveTo(mx - mw, my - mw * 0.1); g.quadraticCurveTo(mx, my + mw * 1.2, mx + mw, my - mw * 0.1); g.closePath(); g.fillStyle = '#4d2c29'; g.fill(); g.beginPath(); g.ellipse(mx, my + mw * 0.38, mw * 0.4, mw * 0.16, 0, 0, Math.PI * 2); g.fillStyle = '#d8706a'; g.fill(); }
    else if (m === 'teeth' || m === 'grit') { const w = mw * (m === 'grit' ? 1.25 : 1.05), h = mw * (m === 'grit' ? 0.62 : 0.72), n = m === 'grit' ? 4 : 3; g.beginPath(); g.roundRect(mx - w, my - h / 2, w * 2, h, h * 0.35); g.fillStyle = '#fbf9f3'; g.fill(); g.lineWidth = 0.9 * U; g.stroke(); g.lineWidth = 0.55 * U; g.beginPath(); g.moveTo(mx - w, my); g.lineTo(mx + w, my); for (let i = 1; i <= n; i++) { const xx = mx - w + (2 * w * i) / (n + 1); g.moveTo(xx, my - h / 2); g.lineTo(xx, my + h / 2); } g.stroke(); }
    else if (m === 'shout') { const j = noise(t * 18, sd) * 0.05 * trem; g.beginPath(); g.ellipse(mx, my + mw * 0.35, mw * (1.15 + j), mw * (0.95 - j), 0, 0, Math.PI * 2); g.fillStyle = '#3a2220'; g.fill(); g.save(); g.clip(); g.fillStyle = '#f7f4ee'; g.fillRect(mx - mw * 1.3, my + mw * 0.35 - mw, mw * 2.6, mw * 0.3); g.beginPath(); g.ellipse(mx, my + mw * 1.1, mw * 0.65, mw * 0.38, 0, 0, Math.PI * 2); g.fillStyle = '#d0665f'; g.fill(); g.restore(); }
    else if (m === 'yawn') { g.beginPath(); g.ellipse(mx, my + mw * 0.3, mw * 0.5, mw * 0.85, 0, 0, Math.PI * 2); g.fillStyle = '#3a2220'; g.fill(); g.save(); g.clip(); g.beginPath(); g.ellipse(mx, my + mw * 1.0, mw * 0.36, mw * 0.3, 0, 0, Math.PI * 2); g.fillStyle = '#c9605a'; g.fill(); g.restore(); }
    else if (m === 'tongue') { g.beginPath(); g.moveTo(mx - mw * 0.8, my); g.quadraticCurveTo(mx, my + mw * 0.95, mx + mw * 0.8, my); g.closePath(); g.fillStyle = '#3d2624'; g.fill(); const d = 0.5 + 0.5 * Math.sin(t * 7); g.beginPath(); g.ellipse(mx + mw * 0.15, my + mw * (0.55 + 0.1 * d), mw * 0.3, mw * 0.36, 0.15, 0, Math.PI * 2); g.fillStyle = '#d8706a'; g.fill(); g.lineWidth = 1 * U; g.stroke(); }
    else if (m === 'grinw') { g.beginPath(); g.moveTo(mx - mw * 1.3, my - mw * 0.2); g.quadraticCurveTo(mx, my + mw * 0.9, mx + mw * 1.3, my - mw * 0.2); g.stroke(); }
    g.restore();
  });
  const m = F.mouth || 'flat', m0 = F0 ? F0.mouth || 'flat' : m;
  if (!F0 || m0 === m) drawM(m, 1, 1);
  else if (MOUTH2[m0] && MOUTH2[m]) { g.lineWidth = 1.6 * U; g.strokeStyle = line; g.lineCap = 'round'; mouthLine2(g, mx, my, mw, MOUTH2[m0].map((v, i) => lerp(v, MOUTH2[m][i], q)), t, trem); }
  else { drawM(m0, 1 - q, lerp(1, 0.6, q)); drawM(m, q, lerp(0.6, 1, q)); }
  // nuoc mat chay thanh dong (2 = khoc nac), mo hoi truot xuong, dau "!" luc giat minh
  const tears = Math.max(mv('tears'), o.tears ? 1 : 0);
  fade(Math.min(1, tears), () => { for (const k of [-1, 1]) { const tx = ex(k) + k * R * 0.04, ty = ey + R * 0.13; g.save(); g.strokeStyle = 'rgba(150,205,255,0.75)'; g.lineWidth = (1.4 + tears) * U; g.lineCap = 'round'; g.beginPath(); g.moveTo(tx, ty); g.quadraticCurveTo(tx + k * R * 0.05, ty + R * 0.3, tx + k * R * 0.02, ty + R * 0.55); g.stroke(); g.restore();
    const u = ((t * (0.8 + 0.4 * tears) + (k + 1) * 0.37) % 1), dy = ty + u * R * 0.75; g.beginPath(); g.moveTo(tx + k * R * 0.03, dy - R * 0.09); g.quadraticCurveTo(tx + k * R * 0.03 + R * 0.06, dy, tx + k * R * 0.03, dy + R * 0.05); g.quadraticCurveTo(tx + k * R * 0.03 - R * 0.06, dy, tx + k * R * 0.03, dy - R * 0.09); g.fillStyle = `rgba(150,205,255,${0.9 * (1 - u)})`; g.fill(); } });
  fade(Math.max(mv('sweat'), o.sweat ? 1 : 0), () => { const u = (t * 0.45 + sd * 0.13) % 1, sx = x + R * 0.8 * (f > 0 ? -1 : 1), sy = y - R * 0.5 + ease.in(u) * R * 0.55; g.globalAlpha *= Math.min(1, (1 - u) * 3); g.beginPath(); g.moveTo(sx, sy - R * 0.15); g.quadraticCurveTo(sx + R * 0.09, sy + R * 0.02, sx, sy + R * 0.08); g.quadraticCurveTo(sx - R * 0.09, sy + R * 0.02, sx, sy - R * 0.15); g.fillStyle = 'rgba(160,210,255,0.95)'; g.fill(); });
  if (F.mark && since < 0.9) fade(Math.sin(Math.PI * clamp(since / 0.9)), () => { const bx = x + R * 1.15 * (f > 0 ? 1 : -1), by = y - R * 1.05 - ease.outBack(clamp(since / 0.25)) * R * 0.15; g.lineCap = 'round'; g.strokeStyle = '#f2efe8'; g.lineWidth = 3 * U; g.beginPath(); g.moveTo(bx, by - R * 0.3); g.lineTo(bx, by + R * 0.05); g.stroke(); g.beginPath(); g.arc(bx, by + R * 0.2, 1.8 * U, 0, Math.PI * 2); g.fillStyle = '#f2efe8'; g.fill(); });
  g.restore();
}
function mouthLine2(g, mx, my, mw, P, t, trem) {   // nhu mouthLine, them run theo thoi gian (tremble)
  g.beginPath(); const v = (n) => (n === 0 ? 0 : n % 2 ? -1 : 1);
  for (let j = 0; j <= 24; j++) { const u = j / 24, s = u * 6, i = Math.floor(s), off = (P[6] ? lerp(v(i), v(Math.min(6, i + 1)), s - i) * P[6] : 0) + (trem ? noise(t * 22 + j * 0.6, 3) * 0.05 * trem : 0);
    const xx = mx + ((1 - u) * (1 - u) * P[0] + 2 * (1 - u) * u * P[2] + u * u * P[4]) * mw, yy = my + ((1 - u) * (1 - u) * P[1] + 2 * (1 - u) * u * P[3] + u * u * P[5] + off) * mw; j ? g.lineTo(xx, yy) : g.moveTo(xx, yy); }
  g.stroke();
}

// do vat cam tay
function holdItem(g, x, y, U, f, what, t, o) {
  if (what === 'phone') {
    g.save(); g.translate(x + 1 * U * f, y - 4 * U); g.rotate(-0.15 * f);
    g.beginPath(); g.roundRect(-3.2 * U, -6.5 * U, 6.4 * U, 12 * U, 1.2 * U); g.fillStyle = '#1b1c20'; g.fill(); g.lineWidth = 0.8 * U; g.strokeStyle = '#8b8e96'; g.stroke();
    const sc = o.screen || PAL.screen; g.fillStyle = sc; g.fillRect(-2.5 * U, -5.6 * U, 5 * U, 10.2 * U); g.restore();
    light(g, x + 3 * U * f, y - 6 * U, 26 * U, o.screen || PAL.screen, 0.38);
  } else if (what === 'umbrella') {
    const top = y - 36 * U; g.save(); g.strokeStyle = '#3a3a3a'; g.lineWidth = 1.2 * U; g.beginPath(); g.moveTo(x, y + 4 * U); g.lineTo(x, top); g.stroke();
    g.beginPath(); g.moveTo(x - 30 * U, top + 6 * U); g.quadraticCurveTo(x, top - 22 * U, x + 30 * U, top + 6 * U); for (let i = 3; i >= -3; i--) g.quadraticCurveTo(x + (i + 0.5) * 10 * U - 5 * U, top + 1 * U, x + i * 10 * U - 0 * U, top + 6 * U); g.closePath(); g.fillStyle = o.umbrellaColor || '#f2c230'; g.fill(); g.lineWidth = 1 * U; g.strokeStyle = '#a07c15'; g.stroke(); g.restore();
  } else if (what === 'book') { g.save(); g.translate(x, y - 2 * U); g.fillStyle = '#e8b33c'; g.fillRect(-6 * U, -8 * U, 9 * U, 11 * U); g.fillStyle = '#4e6b52'; g.fillRect(-6 * U, -8 * U, 2 * U, 11 * U); g.restore(); }
  else if (what === 'ball') { dot(g, x + 3 * U * f, y + 2 * U, 5.5 * U, '#e07b2f', '#6a3510', 0.8 * U); }
  else if (what === 'bag') { g.save(); g.fillStyle = '#24262c'; g.beginPath(); g.roundRect(x - 4 * U, y, 12 * U, 14 * U, 2 * U); g.fill(); g.restore(); }
  else if (what === 'cup') { g.save(); g.fillStyle = '#f2efe9'; g.beginPath(); g.roundRect(x - 3 * U, y - 6 * U, 6 * U, 7 * U, 1.2 * U); g.fill(); g.restore(); }
}

// dau nam tren goi (nguoi trong chan): goc nghieng rot
export function lyingHead(g, x, y, R, o = {}) { g.save(); g.translate(x, y); g.rotate(o.rot ?? -0.35); head(g, 0, 0, R, { ...CAST[o.who || 'hero'], ...o, U: R / (isCl(o) ? 17 : 15.5), f: o.facing ?? 1 }); g.restore(); }
// ban tay to (can canh cam dien thoai, viet so...)
export function bigHand(g, x, y, s, o = {}) {
  g.save(); g.translate(x, y); g.rotate(o.rot || 0); const skin = o.skin || PAL.hero, ed = PAL.heroLine;
  // canh tay (tay ao xam neu co)
  g.fillStyle = o.sleeve || skin; g.beginPath(); g.roundRect(-s * 0.32, 0, s * 0.64, s * 3, s * 0.3); g.fill(); g.lineWidth = s * 0.03; g.strokeStyle = o.sleeve ? shade(o.sleeve, -0.3) : ed; g.stroke();
  g.fillStyle = skin; g.beginPath(); g.ellipse(0, 0, s * 0.42, s * 0.5, 0, 0, Math.PI * 2); g.fill(); g.strokeStyle = ed; g.stroke();
  if (o.thumb !== false) { g.beginPath(); g.ellipse(s * 0.15, -s * 0.55, s * 0.16, s * 0.42, 0.25, 0, Math.PI * 2); g.fill(); g.stroke(); }
  g.restore();
}
