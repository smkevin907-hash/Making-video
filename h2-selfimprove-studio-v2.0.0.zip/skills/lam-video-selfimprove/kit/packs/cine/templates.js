// templates.js — mau canh cinematic, CUNG TEN va CUNG args voi bo 2D (packs/dem) de shots.json tu phim.py dung duoc ngay:
//   scene | phone | calendar | clock | face | black | card  -> dung 3D (engine/cine) + coverage tu director.js
//   note | cta | graph, va scene co boi canh chua co ban 3D -> tu lui ve mau 2D cua packs/dem (use2d), --check bao CANH BAO.
import '/packs/dem/templates.js';
import { E, getTemplate, registerTemplate, clamp, lerp, ease } from '/engine/core.js';
import { buildSet, SETS3 } from './sets.js';
import { actor } from './rig.js';
import { phoneMesh, swipeAt } from './props.js';
import { povPhone, povMarker } from './pov.js';
import { coverage, subShot } from './director.js';
import { layReset, actorBoxes, drawTexts, drawHud, drawCard, LAY } from './ui.js';

const LEG = {}; for (const n of ['scene', 'phone', 'clock', 'calendar', 'face', 'black', 'card']) LEG[n] = getTemplate(n);
const isDay = (sa = {}) => ['day', 'dawn'].includes(sa.sky) || sa.time === 'day';
const gv = (v, lt, g) => (Array.isArray(v) ? lerp(v[0], v[1], ease.inOut(clamp((lt - (g.at ?? 0)) / (g.dur ?? 1.5)))) : v);
function prevHud(info) { const i = E.shots.indexOf(info.shot); for (let k = i - 1; k >= 0; k--) { const h = E.shots[k].args && E.shots[k].args.hud; if (h) return h; } return null; }

// dung 1 canh 3D: boi canh + anh sang + dien vien. kind: loai mau canh
function build(C, info, kind) {
  const a = info.args || {}, sa = a.setArgs || {}, st = { stage: C.stage(), actors: [], kind };
  const setName = kind === 'black' || kind === 'card' ? 'void' : a.set || a.bg || 'bedroom';
  const day = isDay(sa);
  st.set = buildSet(C, st.stage.scene, SETS3.includes(setName) ? setName : 'bedroom', { time: day ? 'day' : 'night', lamp: sa.lamp !== false && !day, laptop: sa.laptop, clock: sa.clock ?? a.time, clockAt: a.timeAt, blink: sa.blink, calendar: kind === 'calendar' ? a : sa.calendar });
  const A = st.set.anchors, R = A.room;
  // anh sang theo cam xuc: dem = xanh lanh (+ den am nho); ngay luc sa nga = xam dau; ngay luc hy vong / dung len (nhac hope / rise / resolve) = nang am
  const mus = ((E.story && E.story.music) || []).find((m) => info.start >= m.start - 0.01 && info.start < m.end), hope = mus && ['hope', 'rise', 'resolve'].includes(mus.bed);
  const rigName = a.light || (kind === 'black' || kind === 'card' ? 'void' : kind === 'phone' ? 'phoneNight' : day ? (hope ? 'dawnHope' : 'dayGrey') : 'nightRoom');
  st.rig = C.lightRig(st.stage.scene, rigName, { key: [R.x0 - 1.4, 2.6, (A.window || [0, 0, -0.4])[2] - 0.3], keyTarget: [0, 0.4, -0.2], practical: A.lamp || [1.5, 1.1, -1.5], rimPos: [2, 2.4, -3], phoneK: kind === 'phone' ? 0.35 : 1, phone: kind === 'phone' || (a.actors || []).some((x) => x.hold === 'phone') ? [0, 1, 0] : null });
  st.stage.rig = st.rig;
  if (kind !== 'phone' && kind !== 'clock') C.dust(st.rig, st.set.beamBox, { n: kind === 'black' || kind === 'card' ? 220 : 160, seed: 5, color: day ? '#fff3dd' : '#cfdcff', a: kind === 'black' || kind === 'card' ? 0.35 : 0.5 });
  // dien vien (scene / face); bong den (voice) dung sau-canh nguoi hung va quay mat ve phia nguoi hung
  const list = kind === 'face' ? [{ who: a.who || 'hoodie', x: a.x ?? 'bed.sit', pose: a.pose || (a.x ? 'stand' : 'sit'), poseAt: a.poseAt, face: a.face, faceAt: a.faceAt, hold: a.hold, blink: a.blink, look: a.look }, ...(a.actors || [])] : kind === 'calendar' && !(a.actors || []).length ? [{ who: a.who || 'hoodie', x: [A.poster[0] + 0.62, 0, A.poster[2] + 0.95], face3: Math.PI + 0.55, pose: 'stand', face: a.face || 'tired' }] : a.actors || [];   // dung lech phai poster, nhin cheo vao poster -> goc qua vai thay ro poster
  for (const ac of list) { const x = actor(ac, A); st.stage.scene.add(x.rg.root); st.actors.push(x); }
  st.main = st.actors.find((x) => !x.voice) || null; st.voice = st.actors.find((x) => x.voice) || null;
  if (st.voice && st.main) {   // bong den: phia sau, lech canh, nhin nguoi hung
    const m = st.main.rg.base, v = st.voice.rg.base; if (st.voice.a.keepX !== true) { st.voice.rg.base = [lerp(v[0], m[0], 0.35), 0, m[2] - 0.75]; }
    const b = st.voice.rg.base; st.voice.a.face3 = Math.atan2(m[0] - b[0], m[2] - b[2]);
  }
  // nguoi nam trong chan: chi hien dau tren goi (chan la than nguoi). Bong den (neu co) dung canh giuong, cui ve phia goi
  if (a.bed && st.set.anchors.bedLie && st.voice && !st.main && st.voice.a.keepX !== true) {
    const L = st.set.anchors.bedLie; st.voice.rg.base = [L[0] + 0.95, 0, L[2] - 0.35]; st.voice.a.face3 = Math.atan2(L[0] - 0.25 - (L[0] + 0.95), L[2] - 0.7 - (L[2] - 0.35));
  }
  if (a.bed && st.set.anchors.bedLie) {
    const s = actor({ who: a.bed.who || 'hoodie', x: [0, 0, 0], face: a.bed.face || 'sleep', faceAt: a.bed.faceAt, idle: false }, A); st.stage.scene.add(s.rg.root); st.sleeper = s;
    const L = st.set.anchors.bedLie; s.lie = () => { const r = s.rg.root; r.rotation.set(-Math.PI / 2, 0, 0); r.position.set(L[0] - 0.25, L[1] + 0.13, L[2] - 0.72 + 1.5); s.rg.spine.children.forEach((c) => { if (c !== s.rg.neck) c.visible = false; }); s.rg.L.r.hp.visible = s.rg.L.l.hp.visible = false; s.rg.neck.rotation.set(0, 0.5, 0); };
    st.sleeperSub = () => ({ at: [L[0] - 0.25, L[1], L[2] - 0.7], h: 0.4, face: 0.6, head: s.headPos() });
    // ngoi day (bed.up): cat dung dong tac — goc may moi bat dau o up.at, nguoi da ngoi mep giuong (director: goc 'push')
    if (a.bed.up) {
      const u = a.bed.up; s.upAt = u.at ?? info.dur * 0.5;
      const sit = actor({ who: a.bed.who || 'hoodie', x: 'bed.sit', pose: u.pose || 'sit', face: u.face || a.bed.face || 'tired', faceAt: a.bed.faceAt, at: s.upAt, facing: 1 }, A);
      st.stage.scene.add(sit.rg.root); st.actors.push(sit); st.sitter = sit;
    }
  }
  // can canh dien thoai: POV 2 tay, man hinh canvas; may o mat nguoi ngoi mep giuong nhin xuong
  if (kind === 'phone') {
    const eye = [A.bedSit[0], A.bedSit[1] + 0.8, A.bedSit[2]], P = [eye[0] + 0.3, eye[1] - 0.2, eye[2] + 0.02];
    const pm = phoneMesh({ ...a }), pv = povPhone(pm, { ...a, who: a.who || 'hoodie' });
    pv.group.position.set(...P); pv.group.lookAt(...eye); st.stage.scene.add(pv.group); st.pov = pv; st.phone = pm;
    st.povCam = { pos: eye, target: [P[0], P[1] - 0.005, P[2]], fov: a.fov ?? 40, size: 'ecu' }; st.povFocus = Math.hypot(P[0] - eye[0], P[1] - eye[1], P[2] - eye[2]);
    // anh man hinh: dat truoc mat man hinh (phia nguoi xem), yeu -> hat len tay vua du, khong lam tay ao chay trang
    if (st.rig.phone) { st.rig.phone.position.set(lerp(P[0], eye[0], 0.3), lerp(P[1], eye[1], 0.3), lerp(P[2], eye[2], 0.3)); }  }
  if (kind === 'calendar') {
    const pm = st.set.poster; st.posterSub = { at: A.poster.slice(), h: pm.h, prop: true, face: 0 }; st.posterDist = (pm.h * 1.28) / 2 / Math.tan((30 * Math.PI) / 360);
    if (a.pov !== false) { const mk = povMarker(pm, { at: a.at, dur: a.dur, who: a.who || 'hoodie' }); pm.group.add(mk.group); st.marker = mk; }
  }
  if (kind === 'clock') st.clockSub = { at: A.clock.slice(), h: 0.1, prop: true, face: 0.35 };
  st.cov = coverage(kind, info, st);
  return st;
}

function draw(st, lt, info, C) {
  const gt = info.globalT, a = info.args || {};
  layReset();
  st.set.update(lt); st.rig.update(gt);
  for (const x of st.actors) x.update(lt, gt);
  if (st.sleeper) { st.sleeper.update(lt, gt); st.sleeper.lie(); if (st.sleeper.upAt !== undefined && lt >= st.sleeper.upAt) st.sleeper.rg.root.visible = false; }
  if (st.pov) { st.pov.update(lt, gt); st.phone.screen.draw(lt); }
  if (st.marker) st.marker.update(lt);
  if (st.rig.phone && !st.pov) { const ph = st.actors.map((x) => x.phonePos()).find(Boolean); if (ph) st.rig.phone.position.set(ph[0], ph[1] + 0.05, ph[2]); }
  const S = subShot(st.cov, lt, info.dur), spec = { bounds: st.set.anchors.room, ...S.spec() };
  st.stage.cam = C.shotCam(lt - S.at, S.dur, spec);
  st.sub = S.i;
  // can poster (goc cuoi cua calendar) la goc POV: an nguoi dung truoc poster, chi hien tay cam but
  if (st.kind === 'calendar') { const ins = S.i === st.cov.length - 1; if (st.main) st.main.rg.root.visible = st.main.rg.root.visible && !ins; if (st.marker) st.marker.group.visible = ins; }
  const g = a.grade || {}; st.stage.post = { sat: gv(g.sat ?? 1, lt, g), dim: gv(g.dim ?? 0, lt, g) };
}
function overlay(g, lt, info, st) {
  const a = info.args || {};
  const boxes = actorBoxes([...st.actors, ...(st.sleeper ? [st.sleeper] : [])], st.stage.camera);
  if (st.kind === 'card') drawCard(g, lt, a);
  const blk = st.kind === 'black' || st.kind === 'card';
  drawTexts(g, lt, a.texts, { boxes, black: blk, cy: a.cy, hudRows: !blk && a.hud && a.hud.rows ? a.hud.rows.length : 0 });
  if (st.kind !== 'black' && st.kind !== 'card') drawHud(g, lt, a.hud, prevHud(info));
  LAY.cam = { sub: st.sub, n: st.cov.length };}

for (const kind of ['scene', 'phone', 'calendar', 'clock', 'face', 'black', 'card']) {
  registerTemplate(kind, {
    kind: '3d', engine: 'cine', cine: true,
    // che do legacy, hoac boi canh chua co ban 3D -> ve 2D bang mau cu
    use2d: (info) => E.cfg.mode !== 'cinematic' || (kind === 'scene' && !SETS3.includes((info.args || {}).set || 'bedroom')) || (info.args || {}).look === '2d',
    init: (C, info) => build(C, info, kind),
    draw(x, lt, info, C) { if (!C) return LEG[kind].draw(x, lt, info); return draw(x, lt, info, C); },
    overlay,
  });
}
export { swipeAt };
