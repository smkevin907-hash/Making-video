# Kênh, chuỗi và tự chấm

Ba công cụ trong `tools/` (Python 3.8+, không cài thêm gói): `kenh.py` (dấu ấn kênh), `series.py` (hồ sơ chuỗi), `cham_diem.py` (tự chấm). `<D>` = thư mục người dùng.

## 1. Dấu ấn kênh — `<D>/KENH.md`
Lần đầu dùng skill (chưa có `KENH.md`): `python tools/kenh.py mau --thu-muc <D>` tạo file mẫu, rồi **hỏi người dùng 1 lần** (mỗi mục đưa 2–3 gợi ý để chọn):

| Mục | Gợi ý cách chọn |
|---|---|
| Tên kênh | Không giống tên kênh đối thủ (`kenh.txt`). |
| Hậu tố tiêu đề | Có **từ khoá ngách** để được tìm thấy (`Animated Short`, `Short Film`) + **tên kênh** để có dấu ấn: vd `Second Wind Animated Short`. Không dùng nguyên `An Animated Short Film` của đối thủ. |
| Câu ký tên | 1 câu cố định ≤ 9 từ, tiếng Anh, giọng kênh (vd `Every night has a second wind.`). Đặt ở **màn KÊU GỌI dòng 1** (mặc định) hoặc **thẻ kết dòng 2**. |
| Màu nhấn chủ đạo | 1 màu cho cả kênh (`red`, `pink`, `amber`, `teal`); ngoại lệ ghi ở "Màu nhấn riêng" (vd `lust = pink`). Chuỗi đã có màu thì giữ màu chuỗi. |
| Chuỗi đang sở hữu | Tên chuỗi + đề tài (kênh nên sở hữu 1–2 đề tài, đào sâu bằng chuỗi). |

Màn KÊU GỌI trong file 01: dòng chữ 1 = câu ký tên, dòng 2 = lời mời (hiện màu nhấn dưới nút):
```
[B42] 6s | KÊU GỌI
> Every night has a second wind.
> If this hit, like and subscribe.
```

### Công thức 10 tiêu đề (cân bằng tìm thấy / dấu ấn)
- 4 tiêu đề **từ khoá + hậu tố kênh**: `RESPAWN. | Second Wind Animated Short`, `RESPAWN PART 2 | Second Wind Animated Short`.
- 3 tiêu đề **câu đâm thẳng có từ khoá ngách**: `Gaming Stole My Mornings.`, `You Didn't Lose. You Logged Off Too Late.`
- 2 tiêu đề **dấu ấn chuỗi / kênh**: `Respawn, Part 2: The Off-Season`, `Second Wind · Respawn`.
- Tối đa 1 tiêu đề theo mẫu đối thủ `WORD | An Animated Short Film` (để so sánh).
- Đúng 1 tiêu đề đánh dấu `← nên dùng` (nên là tiêu đề có dấu ấn kênh). ≤ 60 ký tự. Không trùng tiêu đề đối thủ.

Trong 02-PACKAGE, mục `## Tiêu đề` ghi dạng danh sách số `1. …` đến `10. …`.

**Máy kiểm:** `python tools/kenh.py kiem --thu-muc <D> --phim <01> --goi <02>` → câu ký tên đúng chỗ, màu nhấn (cảnh báo nếu khác màu chủ đạo mà không phải màu riêng của đề tài / chuỗi), 10 tiêu đề: ≥ 4 có dấu ấn kênh, ≥ 8 có từ khoá ngách, ≤ 3 theo mẫu đối thủ, đúng 1 "nên dùng", không trùng tiêu đề đối thủ.

## 2. Hồ sơ chuỗi — `<D>/series/<chuỗi>/SERIES.md`
- **Sau khi giao mỗi phim** (kể cả tập 1): `python tools/series.py ghi --thu-muc <D> --phim <01>` → thêm / cập nhật tập đó: nhân vật (preset chính + phụ), người thật theo tên trong tin nhắn, màu nhấn, bộ đếm (nhãn + mốc cuối), ước mơ từng tập, vật biểu tượng + các trạng thái, khung / câu móc / kết đã dùng, thẻ kết, **mọi câu cám dỗ đã dùng**, gợi ý tập sau.
- Chuỗi và tập lấy từ đầu file 01: `CHUỖI: RESPAWN`, `TẬP: 2` (không ghi thì lấy từ `TITLE` và `PART N` ở thẻ kết).
- **Viết PART 2 / tập sau:** đọc `SERIES.md` trước khi đưa 3 hướng kể. Giữ nhân vật, màu nhấn, nhãn bộ đếm, vật biểu tượng (đi tiếp từ trạng thái cuối); nâng ước mơ lên chặng mới; **không lặp câu cám dỗ** — cám dỗ đổi giọng (khôn hơn, khó nhận ra hơn); nên đổi khung và câu móc (gợi ý: tập 1 Vực dậy → tập 2 Vòng lặp → tập 3 Thư gửi bản thân).
- Chưa có `SERIES.md` mà người dùng muốn làm PART 2 của phim cũ: chạy `series.py ghi` với file 01 cũ trước.
- **Máy kiểm:** `python tools/series.py kiem --thu-muc <D> --phim <01 tập mới>` → LỖI nếu đổi nhân vật chính, đổi màu, bỏ nhãn bộ đếm của chuỗi, lặp câu cám dỗ cũ (giống ≥ 85%); cảnh báo nếu đổi vật, cùng khung / câu móc với tập trước, ước mơ y hệt, thẻ kết thiếu `PART N`.

## 3. Tự chấm trước khi giao — `cham_diem.py`
`python tools/cham_diem.py --thu-muc <D> --phim <01> --ghi <02-PACKAGE>`. Mỗi tiêu chí bắt đầu 5 điểm, máy trừ theo bằng chứng trong file 01 (dòng `# TRUYỆN`, HUD, NHẠC, SFX, chữ) và thư viện đối thủ:

| Tiêu chí | Máy trừ điểm khi |
|---|---|
| Câu móc | thiếu / trùng kiểu MÓC B (−2); chữ đầu đến sau 3 giây (trừ câu móc bằng hình / bộ đếm); câu móc > 9 từ; cảnh mở > 7 giây; cấu trúc không khớp kiểu; ≥ 50% video đối thủ đã phân tích mở bằng cùng kiểu (mỗi lỗi −1) |
| Độ rõ của ước mơ | chưa gài (1 điểm); gài > 15% (−2) hoặc 10–15% (−1); `ƯỚC MƠ` < 4 từ; vật biểu tượng không xuất hiện cùng lúc; giải thích bằng chữ; 40% cuối không quay lại ước mơ / vật |
| Cú sụp | không có (1 điểm); không có bộ đếm đổi / câu đau ngắn (−2); nhạc không đổi; không SFX nhấn; ngoài nhịp sụp của khung |
| Khoảnh khắc người thật | không có (1 điểm); không có người thật trong cảnh (−2); ngoài nhịp của khung; sau đó nhân vật không có hành động mới |
| Độ mới so với đối thủ | trùng 4/4 → 1, 3/4 → 3, 2/4 → 4, ≤ 1/4 → 5; −1 nếu đối thủ cùng đề tài đã dùng khung này, −1 nếu từ khoá tiêu đề trùng video đối thủ; thư viện trống → 3 |
| Độ đọc được khi không có tiếng | chữ không đủ giờ đọc (−2); câu kể chuyện > 9 từ; < 30% cảnh có chữ; nhịp không có câu kể chuyện / tin nhắn |

Máy ghi bảng vào mục `## Tự chấm` của 02-PACKAGE (cột Máy, Cuối, Vì sao). Claude đọc lại kịch bản, được chỉnh cột Cuối **±1 kèm lý do** (không cao hơn Máy + 1). **Tiêu chí nào dưới 4 thì sửa kịch bản rồi chấm lại**, chỉ giao khi mọi tiêu chí ≥ 4.
