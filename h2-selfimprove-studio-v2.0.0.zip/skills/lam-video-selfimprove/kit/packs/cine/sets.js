// sets.js — boi canh 3D co phoi canh that (san / tuong / tran, duong song song hoi tu). Don vi met, y len, cua so tuong trai.
// buildSet(C, scene, name, o) -> { group, anchors, lightAt, update(t) }. anchors: diem dat nhan vat / may (bedSit, bedHead, deskSeat, window, lamp, clock, poster...)
// Lo 3a: "bedroom" (dem / ngay; dong ho, lich, den ban, laptop, rem, tham). Cac boi canh khac: lo 3b / lo 2.
import { THREE, mat, outline, col, rng, fbm1, glowSprite, beam, dust } from '/engine/cine/index.js';
import { RoundedBoxGeometry } from '/node_modules/three/examples/jsm/geometries/RoundedBoxGeometry.js';
import { clockMesh, posterMesh } from './props.js';

const TEX = new Map();
// texture canvas co seed (khong Math.random): van go san, tuong co hat mo de vung toi van co chi tiet
function canvasTex(key, w, h, draw, rep = [1, 1]) {
  if (TEX.has(key)) return TEX.get(key);
  const c = document.createElement('canvas'); c.width = w; c.height = h; draw(c.getContext('2d'), w, h);
  const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.wrapS = t.wrapT = THREE.RepeatWrapping; t.repeat.set(...rep); t.anisotropy = 4; t.userData.shared = true;
  TEX.set(key, t); return t;
}
function planks(base, line, seed = 3) {
  return canvasTex('planks' + base + line, 512, 512, (g, w, h) => {
    const r = rng(seed); g.fillStyle = base; g.fillRect(0, 0, w, h);
    for (let i = 0; i < 8; i++) {
      const y = i * h / 8; g.fillStyle = `rgba(255,255,255,${0.02 + r() * 0.04})`; g.fillRect(0, y, w, h / 8);
      g.fillStyle = line; g.fillRect(0, y, w, 2); const cut = r() * w; g.fillRect(cut, y, 2, h / 8);
      for (let k = 0; k < 6; k++) { g.strokeStyle = `rgba(0,0,0,${0.05 + r() * 0.05})`; g.lineWidth = 1; g.beginPath(); const yy = y + r() * h / 8; g.moveTo(0, yy); g.bezierCurveTo(w * 0.3, yy + (r() - 0.5) * 6, w * 0.6, yy + (r() - 0.5) * 6, w, yy); g.stroke(); }
    }
  }, [2.2, 2.2]);
}
function grainTex(base, seed = 5, amt = 10) {
  return canvasTex('grain' + base + amt, 256, 256, (g, w, h) => {
    g.fillStyle = base; g.fillRect(0, 0, w, h); const id = g.getImageData(0, 0, w, h), r = rng(seed);
    for (let i = 0; i < id.data.length; i += 4) { const v = (r() - 0.5) * amt; id.data[i] += v; id.data[i + 1] += v; id.data[i + 2] += v; }
    g.putImageData(id, 0, 0);
  }, [3, 3]);
}
// khoi do vat: to phang theo bac (toon) + net vien toi manh (kieu minh hoa). INK = mau net cua boi canh dang dung
let INK = '#07080c';
const rbox = (w, h, d, c, o = {}) => {
  const m = new THREE.Mesh(o.round === 0 ? new THREE.BoxGeometry(w, h, d) : new RoundedBoxGeometry(w, h, d, 3, o.round ?? Math.min(w, h, d) * 0.12), o.mat || mat(c, o)); m.castShadow = o.cast !== false; m.receiveShadow = true;
  if (o.line !== false && o.round !== 0) outline(m, INK, o.lw ?? 0.007);
  return m;
};
const at = (m, x, y, z) => { m.position.set(x, y, z); return m; };

// dem: tuong / san sang vua du de doc duoc khong gian (nhu phong dem trong phim tham khao), toi la do anh sang chu khong do mau vat
const NIGHT = { wall: '#46506e', floor: '#3a3d4a', line: '#1a1c24', ceil: '#2c3247', bed: '#3a4260', sheet: '#5b6687', blanket: '#3c4f86', wood: '#3a2f2a', sky: ['#0b1430', '#1d2c5a'], moon: true, ink: '#06070b' };
const DAY = { wall: '#c9ccd2', floor: '#8d8378', line: '#5f574f', ceil: '#dadde2', bed: '#6c7385', sheet: '#e3e6ec', blanket: '#7d8db8', wood: '#8a6e58', sky: ['#9fb6cf', '#d9e3ec'], moon: false, ink: '#3a3632' };

// boi canh da co ban cinematic (lo 1). Cac boi canh khac: mau canh tu lui ve ve 2D (legacy) va --check bao CANH BAO
export const SETS3 = ['bedroom', 'void', 'black'];
export function buildSet(C, scene, name = 'bedroom', o = {}) {
  if (name === 'void' || name === 'black') return voidSet(scene, o);
  if (name !== 'bedroom') throw new Error(`boi canh "${name}" chua co ban cinematic`);
  return bedroom(scene, o);
}
// khoang toi (man chu den, the ket): san mo rat toi + bui troi -> van co chieu sau, khong den dac
function voidSet(scene, o) {
  const G = new THREE.Group(); G.name = 'set:void'; scene.add(G); INK = '#000';
  const fl = new THREE.Mesh(new THREE.PlaneGeometry(30, 30), mat('#0d0e12', { look: 'soft' })); fl.rotation.x = -Math.PI / 2; fl.receiveShadow = true; G.add(fl);
  return { group: G, anchors: { center: [0, 0, 0], room: { x0: -15, x1: 15, z0: -15, z1: 15, H: 12 }, stageZ: 0 }, beamBox: [-2.5, 0.2, -3, 2.5, 2.6, 1.5], update: () => {}, P: {} };
}

function bedroom(scene, o) {
  const P = o.time === 'day' ? DAY : NIGHT, G = new THREE.Group(); G.name = 'set:bedroom'; scene.add(G); INK = P.ink;
  const W = 4.4, D = 4.8, H = 2.65, x0 = -W / 2, x1 = W / 2, z0 = -D / 2, z1 = D / 2;
  // san, tran, 4 tuong (cua so o tuong trai): khuech tan mem (giu vung sang cua den / cua so), khong bac
  const floor = new THREE.Mesh(new THREE.PlaneGeometry(W, D), mat(P.floor, { look: 'soft', map: planks(P.floor, P.line) })); floor.rotation.x = -Math.PI / 2; floor.receiveShadow = true; G.add(floor);
  const ceil = new THREE.Mesh(new THREE.PlaneGeometry(W, D), mat(P.ceil, { look: 'soft' })); ceil.rotation.x = Math.PI / 2; ceil.position.y = H; G.add(ceil);
  const wallM = mat(P.wall, { look: 'soft', map: grainTex(P.wall, 5, 6) });
  const wall = (w, rotY, x, z) => { const m = new THREE.Mesh(new THREE.PlaneGeometry(w, H), wallM); m.rotation.y = rotY; m.position.set(x, H / 2, z); m.receiveShadow = true; G.add(m); return m; };
  wall(W, 0, 0, z0); wall(W, Math.PI, 0, z1); wall(D, -Math.PI / 2, x1, 0);
  // tuong trai co lo cua so: 4 mang quanh lo
  const wz = -0.4, ww = 1.5, wy0 = 0.95, wy1 = 2.15;
  const leftPart = (w, h, y, z) => { const m = new THREE.Mesh(new THREE.PlaneGeometry(w, h), wallM); m.rotation.y = Math.PI / 2; m.position.set(x0, y, z); m.receiveShadow = true; G.add(m); };
  leftPart(D, wy0, wy0 / 2, 0); leftPart(D, H - wy1, (H + wy1) / 2, 0);
  leftPart((wz - ww / 2) - z0, wy1 - wy0, (wy0 + wy1) / 2, (z0 + wz - ww / 2) / 2); leftPart(z1 - (wz + ww / 2), wy1 - wy0, (wy0 + wy1) / 2, (z1 + wz + ww / 2) / 2);
  // len chan tuong (duong ngang giup thay phoi canh)
  for (const [w, ry, x, z] of [[W, 0, 0, z0 + 0.01], [D, -Math.PI / 2, x1 - 0.01, 0]]) { const s = rbox(w, 0.09, 0.02, P.line, { round: 0, cast: false }); s.rotation.y = ry; at(s, x, 0.045, z); G.add(s); }
  // cua so: troi phat sang (khong nhan anh sang) + khung + kinh chia o + trang
  const sky = new THREE.Mesh(new THREE.PlaneGeometry(ww * 1.6, (wy1 - wy0) * 1.6), new THREE.ShaderMaterial({ uniforms: { a: { value: col(P.sky[0]) }, b: { value: col(P.sky[1]) } }, vertexShader: 'varying vec2 v; void main(){ v = uv; gl_Position = projectionMatrix * modelViewMatrix * vec4(position, 1.0); }', fragmentShader: 'uniform vec3 a, b; varying vec2 v; void main(){ gl_FragColor = vec4(mix(b, a, v.y) * 1.6, 1.0); }', fog: false }));
  sky.rotation.y = Math.PI / 2; sky.position.set(x0 - 0.9, (wy0 + wy1) / 2, wz); G.add(sky);
  if (P.moon) { const m = glowSprite('#e6ecff', 0.5, 0.9); m.position.set(x0 - 0.85, wy1 - 0.25, wz - 0.35); G.add(m); }
  const frameM = mat(P.wood);
  for (const [w, h, y, z] of [[0.07, wy1 - wy0 + 0.14, (wy0 + wy1) / 2, wz - ww / 2], [0.07, wy1 - wy0 + 0.14, (wy0 + wy1) / 2, wz + ww / 2], [ww, 0.07, wy0, wz], [ww, 0.07, wy1, wz], [ww, 0.04, (wy0 + wy1) / 2, wz]]) { const f = rbox(0.09, h, w, P.wood, { mat: frameM, round: 0.01 }); at(f, x0 + 0.02, y, z); G.add(f); }
  const mullion = rbox(0.06, wy1 - wy0, 0.04, P.wood, { mat: frameM, round: 0.01 }); at(mullion, x0 + 0.02, (wy0 + wy1) / 2, wz); G.add(mullion);
  const sill = rbox(0.24, 0.05, ww + 0.25, P.wood, { mat: frameM }); at(sill, x0 + 0.1, wy0 - 0.03, wz); G.add(sill);
  // rem 2 ben: bay rat nhe (ham thuan cua t) -> canh khong bao gio dung hinh hoan toan
  const curtains = [];
  for (const s of [-1, 1]) {
    const geo = new THREE.PlaneGeometry(0.55, H - 0.25, 8, 12), cm = mat(o.time === 'day' ? '#b8c2d6' : '#2d3a63', { side: THREE.DoubleSide }); const c = new THREE.Mesh(geo, cm);
    c.rotation.y = Math.PI / 2; c.position.set(x0 + 0.1, (H - 0.25) / 2 + 0.05, wz + s * (ww / 2 + 0.3)); c.castShadow = true; G.add(c);
    const base = geo.attributes.position.array.slice(); curtains.push({ geo, base, s });
  }
  // giuong (dau giuong sat tuong sau, ben trai phong)
  const bx = -0.7, bz = -1.15, bw = 1.25, bl = 2.0;
  const bedG = new THREE.Group(); at(bedG, bx, 0, bz); G.add(bedG);
  // mat nem cao 0.45 m: nguoi ngoi mep giuong chan cham san
  bedG.add(at(rbox(bw, 0.24, bl, P.wood, { round: 0.03 }), 0, 0.15, 0));
  bedG.add(at(rbox(bw - 0.06, 0.18, bl - 0.08, P.sheet, { round: 0.07 }), 0, 0.36, 0.02));
  bedG.add(at(rbox(bw + 0.04, 0.85, 0.08, P.wood, { round: 0.03 }), 0, 0.45, -bl / 2));           // dau giuong
  bedG.add(at(rbox(0.6, 0.12, 0.34, P.sheet, { round: 0.06 }), -0.25, 0.5, -bl / 2 + 0.28));      // goi
  const blanket = rbox(bw + 0.02, 0.1, bl * 0.62, P.blanket, { round: 0.05 }); at(blanket, 0, 0.48, bl * 0.18); bedG.add(blanket);
  // ban hoc + den ban + laptop (tuong phai)
  const dx = 1.55, dz = -1.3;
  const desk = new THREE.Group(); at(desk, dx, 0, dz); G.add(desk);
  desk.add(at(rbox(0.7, 0.05, 1.3, P.wood, { round: 0.015 }), 0, 0.74, 0));
  for (const [x, z] of [[-0.3, -0.6], [0.3, -0.6], [-0.3, 0.6], [0.3, 0.6]]) desk.add(at(rbox(0.05, 0.72, 0.05, P.wood, { round: 0.01 }), x, 0.36, z));
  const lampBase = at(rbox(0.14, 0.03, 0.14, '#2a2a30', { round: 0.01 }), 0.15, 0.78, -0.45); desk.add(lampBase);
  desk.add(at(rbox(0.025, 0.42, 0.025, '#2a2a30', { round: 0.01 }), 0.15, 0.99, -0.45));
  const shade = new THREE.Mesh(new THREE.ConeGeometry(0.13, 0.16, 20, 1, true), mat('#3a3a44', { side: THREE.DoubleSide })); at(shade, 0.12, 1.2, -0.4); shade.rotation.z = 0.5; shade.castShadow = true; desk.add(shade);
  const lampOn = o.lamp !== false;
  const bulb = new THREE.Mesh(new THREE.SphereGeometry(0.035, 12, 8), new THREE.MeshBasicMaterial({ color: col(lampOn ? '#ffd9a0' : '#444'), fog: false })); at(bulb, 0.1, 1.15, -0.4); desk.add(bulb);
  if (lampOn) { const gl = glowSprite('#ffb36b', 0.7, 0.55); at(gl, 0.1, 1.12, -0.4); desk.add(gl); }
  const lap = new THREE.Group(); at(lap, -0.05, 0.765, 0.05); lap.rotation.y = -Math.PI / 2; desk.add(lap);
  lap.add(at(rbox(0.36, 0.02, 0.25, '#55585f', { round: 0.006 }), 0, 0.01, 0));
  const scr = rbox(0.36, 0.24, 0.015, '#2a2c33', { round: 0.006 }); at(scr, 0, 0.13, -0.12); scr.rotation.x = -0.25; lap.add(scr);
  const scrGlow = new THREE.Mesh(new THREE.PlaneGeometry(0.32, 0.2), new THREE.MeshBasicMaterial({ color: col(o.laptop === 'off' ? '#101114' : '#7fa2e8'), fog: false })); at(scrGlow, 0, 0.13, -0.11); scrGlow.rotation.x = -0.25; lap.add(scrGlow);
  // ghe ban hoc (vat tien canh tot cho goc qua ghe)
  const chair = new THREE.Group(); at(chair, dx - 0.55, 0, dz + 0.15); chair.rotation.y = Math.PI / 2 + 0.25; G.add(chair);
  chair.add(at(rbox(0.45, 0.05, 0.45, '#2c2f3a', { round: 0.02 }), 0, 0.47, 0)); chair.add(at(rbox(0.45, 0.5, 0.05, '#2c2f3a', { round: 0.02 }), 0, 0.75, -0.2));
  for (const [x, z] of [[-0.19, -0.19], [0.19, -0.19], [-0.19, 0.19], [0.19, 0.19]]) chair.add(at(rbox(0.035, 0.46, 0.035, '#1c1e25', { round: 0.01 }), x, 0.23, z));
  // tu dau giuong + dong ho so 7 doan (ghost segment, gio theo setArgs.clock / clockAt)
  const ns = at(rbox(0.42, 0.48, 0.38, P.wood, { round: 0.02 }), bx + bw / 2 + 0.32, 0.24, bz - bl / 2 + 0.25); G.add(ns);
  const clk = clockMesh({ time: o.clock || '2:14', timeAt: o.clockAt, blink: o.blink }); at(clk.group, bx + bw / 2 + 0.32, 0.53, bz - bl / 2 + 0.25); clk.group.rotation.y = 0.35; G.add(clk.group);
  // ke + sach + lich tren tuong sau
  const shelf = at(rbox(0.9, 0.03, 0.22, P.wood, { round: 0.01 }), 1.25, 1.62, z0 + 0.12); G.add(shelf);
  const r = rng(11); for (let i = 0; i < 7; i++) { const h = 0.16 + r() * 0.08; G.add(at(rbox(0.04 + r() * 0.02, h, 0.16, ['#7a4b3a', '#3e5a7a', '#5f7a4a', '#8a7a3a', '#4a3a5a'][i % 5], { round: 0.005 }), 0.88 + i * 0.075, 1.635 + h / 2, z0 + 0.12)); }
  // poster / lich tren tuong sau (setArgs.calendar: { title, month, from, to, mode, at, dur }; khong co thi poster tron cung tong)
  const pm = posterMesh({ title: 'EVERY DAY', to: 0, ...(typeof o.calendar === 'object' ? o.calendar : {}) }, 0.62); at(pm.group, 0.35, 1.45, z0 + 0.004); G.add(pm.group);
  // tham giua phong
  const rug = new THREE.Mesh(new THREE.CircleGeometry(0.85, 40), mat(o.time === 'day' ? '#7d6a5c' : '#2c2a3c', { look: 'soft' })); rug.rotation.x = -Math.PI / 2; rug.scale.set(1.4, 1, 1); at(rug, 0.35, 0.004, 0.35); rug.receiveShadow = true; G.add(rug);
  // chum sang + bui tu cua so (dem: anh trang; ngay: nang)
  const beamFrom = [x0 - 0.3, wy1 + 0.1, wz], beamTo = [0.2, 0.0, wz + 0.25];
  G.add(beam(beamFrom, beamTo, 0.25, 0.85, o.time === 'day' ? '#fff1d8' : '#9db8ff', o.time === 'day' ? 0.05 : 0.06));
  const anchors = {
    bedSit: [bx + bw / 2 - 0.05, 0.45, bz + 0.25], bedHead: [bx - 0.25, 0.58, bz - bl / 2 + 0.3], bedLie: [bx, 0.47, bz + 0.1], deskSeat: [dx - 0.55, 0.47, dz + 0.15],
    window: [x0, (wy0 + wy1) / 2, wz], lamp: [dx + 0.1, 1.15, dz - 0.4], clock: [bx + bw / 2 + 0.32, 0.53, bz - bl / 2 + 0.25], poster: [0.35, 1.45, z0 + 0.02], chair: [dx - 0.55, 0.75, dz + 0.15],
    center: [0.3, 0, 0.4], room: { x0, x1, z0, z1, H }, stageZ: 0.35,
  };
  const update = (t) => {
    clk.face.draw(t); pm.tex.draw(t);
    for (const c of curtains) { const p = c.geo.attributes.position.array; for (let i = 0; i < p.length; i += 3) { const yy = c.base[i + 1], k = (H / 2 - yy) / H; p[i + 2] = c.base[i + 2] + fbm1(t * 0.35 + yy * 0.8 + c.s * 3, 2) * 0.04 * k; } c.geo.attributes.position.needsUpdate = true; c.geo.computeVertexNormals(); }
  };
  return { group: G, anchors, beamBox: [x0 + 0.05, 0.1, wz - 1.0, 0.6, wy1, wz + 1.2], update, P, clock: clk, poster: pm, blanket };
}
export { dust };
