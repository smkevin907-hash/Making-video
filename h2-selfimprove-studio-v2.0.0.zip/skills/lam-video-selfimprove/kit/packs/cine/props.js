// props.js — do vat can canh cua phim: man hinh dien thoai (canvas rieng), dong ho so 7 doan co "ghost segment", poster / lich (ghim, bong, vet gap, X ve tay dan).
// Moi texture ve lai theo t (ham thuan), chi ve lai khi noi dung doi.
import { THREE, mat } from '/engine/cine/index.js';
import { accent } from './rig.js';
import { swipeAt, clockNow, drawPhoneScreen, poster } from '/packs/phim/screens.js';

const canvas = (w, h) => { const c = document.createElement('canvas'); c.width = w; c.height = h; return c; };
const tex = (c) => { const t = new THREE.CanvasTexture(c); t.colorSpace = THREE.SRGBColorSpace; t.anisotropy = 4; return t; };
function rr(g, x, y, w, h, r) { g.beginPath(); g.roundRect(x, y, w, h, r); }

// ---------- lich vuot feed, gio theo bang, ve man hinh / poster: dung chung voi bo 2D (packs/phim/screens.js)
export { swipeAt, clockNow } from '/packs/phim/screens.js';

// ---------- man hinh dien thoai: canvas 540 x 1170 lam texture, chi ve lai khi noi dung doi
export function phoneScreen(o = {}) {
  const W = 540, H = 1170, c = canvas(W, H), g = c.getContext('2d'), t3 = tex(c); let key = '';
  const draw = (t) => {
    const S = swipeAt(t, o), k = (o.screen || 'feed') + S.n.toFixed(4) + clockNow(t, o, S.i) + Math.floor(t * 30); if (k === key) return; key = k;
    g.setTransform(1, 0, 0, 1, 0, 0); g.clearRect(0, 0, W, H); drawPhoneScreen(g, W, H, t, o); t3.needsUpdate = true;
  };
  return { canvas: c, texture: t3, draw };
}

// ---------- dien thoai 3D (than + man hinh canvas). o: screen args. Man hinh hoi sang hon de sau hau ky (ACES) van dung mau
export function phoneMesh(o = {}) {
  const g = new THREE.Group(), w = 0.074, h = 0.158;
  const body = new THREE.Mesh(new THREE.BoxGeometry(w, h, 0.009), mat('#15161b')); body.castShadow = true; g.add(body);
  const scr = phoneScreen(o), m = new THREE.MeshBasicMaterial({ map: scr.texture, fog: false, toneMapped: false }); m.color.setScalar(o.screenK ?? 1.35);
  const face = new THREE.Mesh(new THREE.PlaneGeometry(w * 0.9, h * 0.94), m); face.position.z = 0.0047; g.add(face);
  return { group: g, screen: scr, w, h, face };
}

// ---------- dong ho so 7 doan: doan tat van hien mo (ghost), doan sang mau do, glow co gioi han
const SEG = { 0: 'abcdef', 1: 'bc', 2: 'abged', 3: 'abgcd', 4: 'fgbc', 5: 'afgcd', 6: 'afgedc', 7: 'abc', 8: 'abcdefg', 9: 'abfgcd' };
function seg7(g, ch, x, y, h, on, off) {
  const w = h * 0.55, th = h * 0.12, P = {
    a: [x + th, y, w - 2 * th, th], d: [x + th, y + h - th, w - 2 * th, th], g: [x + th, y + h / 2 - th / 2, w - 2 * th, th],
    f: [x, y + th * 0.6, th, h / 2 - th * 1.1], b: [x + w - th, y + th * 0.6, th, h / 2 - th * 1.1], e: [x, y + h / 2 + th * 0.5, th, h / 2 - th * 1.1], c: [x + w - th, y + h / 2 + th * 0.5, th, h / 2 - th * 1.1],
  };
  for (const k of 'abcdefg') { const lit = (SEG[ch] || '').includes(k); g.fillStyle = lit ? on : off; g.shadowBlur = lit ? h * 0.08 : 0; g.shadowColor = on; const [px, py, pw, ph] = P[k]; rr(g, px, py, pw, ph, th * 0.45); g.fill(); }
  return w;
}
export function clockFace(o = {}) {
  const W = 512, H = 200, c = canvas(W, H), g = c.getContext('2d'), t3 = tex(c); let key = '';
  const draw = (t) => {
    let v = o.time || '2:14'; for (const [s, x] of o.timeAt || []) if (t >= s) v = x;
    const blinkOff = o.blink && Math.floor(t * 2) % 2 === 1, k = v + blinkOff; if (k === key) return; key = k;
    g.setTransform(1, 0, 0, 1, 0, 0); g.fillStyle = '#0a0a0c'; g.fillRect(0, 0, W, H);
    const on = o.color || '#ff3b30', off = 'rgba(255,60,48,0.07)', s = String(v).padStart(5, ' ');
    const hh = 130, cw = hh * 0.55 + 18; let x = (W - (cw * 4 + 30)) / 2;
    for (const ch of s) {
      if (ch === ':') { g.fillStyle = blinkOff ? off : on; g.shadowBlur = 6; g.shadowColor = on; g.beginPath(); g.arc(x + 9, 70, 8, 0, 7); g.arc(x + 9, 132, 8, 0, 7); g.fill(); x += 30; continue; }
      seg7(g, ch === ' ' ? '8' : ch, x, 35, hh, ch === ' ' ? off : on, off); x += cw;
    }
    g.shadowBlur = 0; t3.needsUpdate = true;
  };
  return { canvas: c, texture: t3, draw };
}
export function clockMesh(o = {}) {
  const g = new THREE.Group(), body = new THREE.Mesh(new THREE.BoxGeometry(0.22, 0.1, 0.08), mat('#141418')); body.castShadow = true; g.add(body);
  const f = clockFace(o), face = new THREE.Mesh(new THREE.PlaneGeometry(0.19, 0.074), new THREE.MeshBasicMaterial({ map: f.texture, fog: false, toneMapped: false })); face.material.color.setScalar(1.25); face.position.z = 0.0405; g.add(face);
  return { group: g, face: f };
}

// ---------- poster / lich (noi dung: packs/phim/screens.js poster()), canvas 1024 x 1400 lam texture
// o: { title, month, cells (35), from, to, mode: 'x' | 'fill', at, dur, reset: { at }, color, seed }
export function posterTex(o = {}) {
  const W = 1024, H = 1400, c = canvas(W, H), g = c.getContext('2d'), t3 = tex(c), P = poster({ ...o, color: o.color || accent() }); let key = '';
  const draw = (t) => { const k = P.key(t); if (k === key) return; key = k; g.setTransform(1, 0, 0, 1, 0, 0); P.draw(g, W, H, t); t3.needsUpdate = true; };
  return { canvas: c, texture: t3, draw, pen: P.pen, aspect: W / H };
}
// poster 3D: giay (vet gap lom nhe), 2 ghim, bong do mem len tuong. w = rong (m)
export function posterMesh(o = {}, w = 0.62) {
  const P = posterTex(o), h = w / P.aspect, g = new THREE.Group();
  const geo = new THREE.PlaneGeometry(w, h, 2, 1), pos = geo.attributes.position; for (let i = 0; i < pos.count; i++) if (Math.abs(pos.getX(i)) < 1e-4) pos.setZ(i, 0.006); geo.computeVertexNormals();
  const paper = new THREE.Mesh(geo, mat('#ffffff', { look: 'soft', map: P.texture })); paper.position.z = 0.01; paper.receiveShadow = true; g.add(paper);
  const sc = canvas(64, 64), sg = sc.getContext('2d'), gr = sg.createRadialGradient(32, 32, 10, 32, 32, 32); gr.addColorStop(0, 'rgba(0,0,0,0.55)'); gr.addColorStop(1, 'rgba(0,0,0,0)'); sg.fillStyle = gr; sg.fillRect(0, 0, 64, 64);
  const sh = new THREE.Mesh(new THREE.PlaneGeometry(w * 1.08, h * 1.06), new THREE.MeshBasicMaterial({ map: tex(sc), transparent: true, depthWrite: false })); sh.position.set(0.012, -0.016, 0.002); g.add(sh);
  for (const [x, c] of [[-w * 0.42, '#d64545'], [w * 0.42, '#3e6ea8']]) { const pin = new THREE.Mesh(new THREE.SphereGeometry(0.012, 12, 8), mat(c)); pin.position.set(x, h * 0.46, 0.02); pin.castShadow = true; g.add(pin); }
  return { group: g, tex: P, w, h };
}
