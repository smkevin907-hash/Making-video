---
name: kich-ban-selfimprove
description: Viết kịch bản phim hoạt hình ngắn tiếng Anh KHÔNG LỜI ĐỌC (3-5 phút, 5 khung truyện: vực dậy, tiếc nuối, hai cuộc đời song song, vòng lặp, thư gửi bản thân) cho kênh self-improvement kiểu "An Animated Short Film" - kỷ luật, cám dỗ, nghiện điện thoại, trì hoãn, làm lại từ đầu - kể bằng chữ trên hình, "giọng cám dỗ" và bộ đếm DAY N; xuất file kịch bản cảnh 01-PHIM cho bộ dựng, gói tiêu đề + thumbnail + mô tả + tag, prompt ảnh AI thumbnail khoá phong cách; theo dõi kênh lớn (lượt xem, điểm vượt trội, phân tích cách kể từ video .mp4 / ảnh chụp, báo cáo xu hướng, chống trùng) và gợi ý đề tài có bằng chứng số liệu. Dùng khi gọi /kich-ban-selfimprove, nói "viết kịch bản self improvement", "kịch bản phim ngắn không lời", "kịch bản DISCIPLINE / LUST / DOPAMINE", "làm PART 2", "gợi ý đề tài self improvement", "quét đối thủ", "phân tích video đối thủ", hoặc dán kịch bản / đưa video đối thủ ngách này.
---

# Kịch bản phim ngắn không lời (gói ngách Self-Improvement)

Trao đổi với người dùng bằng **tiếng Việt**. Chữ trên hình viết bằng **tiếng Anh** (thị trường Mỹ, Anh, Úc...). Mô tả cảnh trong file 01 viết bằng tiếng Việt để người dùng đọc được.

Đã có đề tài thì không hỏi lại đề tài. Trước khi viết, đưa **3 hướng kể** để người dùng chọn 1 (mục 3, bước 0) — trừ khi người dùng đã chỉ định khung / hướng kể hoặc nói "viết luôn" (khi đó dùng hướng được đề xuất). Các lựa chọn khác dùng mặc định, ghi một dòng giả định ở đầu câu trả lời.

Video do skill `/lam-video-selfimprove` dựng **100% bằng code** (không ảnh AI trong video). Chỉ thumbnail cần ảnh AI.

Đọc `references/cau-truc.md` và `references/khung-truyen.md` (thư viện 5 khung truyện) trước khi viết. Đọc `references/kho-canh.md` (kho cảnh sinh tự động từ bộ dựng) trước khi lên dàn cảnh. Đọc `references/thumbnail.md` trước khi viết gói thumbnail. Đọc `references/doi-thu.md` trước mọi việc liên quan kênh đối thủ (quét, phân tích, báo cáo, kiểm trùng). Đọc `references/kenh-chuoi.md` trước khi viết tiêu đề, màn kêu gọi, PART 2 và khi tự chấm. Công cụ trong `tools/` của skill này: `doi_thu.py`, `phan_tich.py`, `kiem_truyen.py`, `kenh.py`, `series.py`, `cham_diem.py`.

**Lần đầu dùng** (thư mục người dùng chưa có `KENH.md`): tạo `KENH.md` theo `kenh-chuoi.md` mục 1 — hỏi người dùng 1 lần tên kênh, hậu tố tiêu đề, câu ký tên, màu nhấn chủ đạo (mỗi mục 2–3 gợi ý). Các lần sau đọc `KENH.md`, không hỏi lại.

## 1. Đầu vào
- **Gọi lệnh mà không ghi gì:** gợi ý 10 đề tài (mục 6). Chỉ ở chế độ này mới hỏi người dùng chọn số.
- **Một chủ đề** (một thói xấu, một cơn nghiện, một bài học): viết trọn kịch bản.
- **"PART 2" / "X VS Y" của một bài đã làm:** đọc hồ sơ chuỗi `series/<chuỗi>/SERIES.md` (chưa có thì `series.py ghi` từ file 01 cũ trong `projects/` trước). Giữ nhân vật, màu nhấn, bộ đếm, vật biểu tượng; nâng ước mơ lên chặng mới; **không lặp câu cám dỗ đã dùng**; nên đổi khung và câu móc. Kể chặng tiếp theo.
- **"Quét đối thủ":** quét tầng 1 (tự chuyển nguồn dự phòng, không hỏi), rồi báo cáo xu hướng ngắn (`doi-thu.md`).
- **File video .mp4 / ảnh chụp màn hình của video đối thủ:** phân tích tầng 2 (`doi-thu.md`), lưu vào thư viện phân tích; chỉ viết kịch bản khi người dùng yêu cầu.
- **Kịch bản đối thủ dán vào:** rút khung, nhịp, kiểu bộ đếm. Rồi viết **câu chuyện khác** với chi tiết, câu chữ, cảnh của riêng mình. Không dịch, không chép câu, không chép cảnh.
- **Tuỳ chọn:**
  - Thời lượng: mặc định **3 phút** (khoảng 32–40 cảnh; 3 video đối thủ đo được dài 2:38–2:51), cho phép 2,5–5 phút (5 phút khoảng 55–70 cảnh). Trên 3:20 bộ dựng cảnh báo: chỉ dài hơn khi người dùng yêu cầu.
  - Khung truyện: 1 trong 5 khung của `khung-truyen.md`; không chỉ định thì skill đề xuất theo đề tài (kèm lý do).
  - Màu nhấn: màu chủ đạo trong `KENH.md` (chưa có thì `red`); ngoại lệ theo "Màu nhấn riêng" của KENH.md (vd lust = pink); tập của chuỗi giữ màu chuỗi.
  - Khung: 16:9 (mặc định) hoặc 9:16 cho Shorts.

## 2. Đầu ra

Lưu vào `projects/<NN>-<slug>/` trong thư mục người dùng đã kết nối nếu có. Không có thì gửi qua chat.

1. **`01-PHIM-<slug>.txt`:** kịch bản cảnh, đúng định dạng trong `references/cau-truc.md` mục "Định dạng file 01" (đầu file có hồ sơ truyện; tập của chuỗi thêm `CHUỖI`, `TẬP`). Màn KÊU GỌI: dòng 1 = câu ký tên của kênh, dòng 2 = lời mời. Đây vừa là kịch bản vừa là kế hoạch hình; bộ dựng đọc thẳng file này.
2. **`02-PACKAGE-<slug>.md`:** (dòng đầu: kết quả kiểm trùng với đối thủ; tiếp theo: hướng kể đã chọn — khung + lý do, ước mơ, vật biểu tượng, cặp gài – trả — và **2 câu móc**: A đang dùng trong file 01, B là khối `# MÓC B` sẵn để thay)
   - **10 tiêu đề** tiếng Anh trong mục `## Tiêu đề` (danh sách `1.`–`10.`), theo công thức cân bằng của `kenh-chuoi.md` (4 từ khoá + hậu tố kênh, 3 câu đâm thẳng có từ khoá, 2 dấu ấn chuỗi / kênh, tối đa 1 mẫu đối thủ), đánh dấu đúng 1 tiêu đề `← nên dùng`.
   - **3 phương án thumbnail**, mỗi phương án ghi: **chữ** (1–4 từ IN HOA, kết bằng `.` hoặc `?`), **khoảnh khắc** (nhân vật đang làm gì, vật chính, nguồn sáng), **từ đổi màu / gạch xoá** nếu có, **mã ảnh** `T01–T03`.
   - **Mô tả YouTube** tiếng Anh: 2 câu móc + 1 câu hỏi bình luận + 3–5 hashtag (`#selfimprovement #discipline #animation` + 2 riêng). Đề tài nặng (cô đơn, tuyệt vọng) thêm 1 dòng: "If you're struggling, please reach out to someone you trust or a local helpline."
   - **15 tag** (dưới 400 ký tự) và **bình luận ghim** (1 câu hỏi khiến người xem kể chuyện của họ, ví dụ "What day are you on?").
   - Mục **`## Tự chấm`** (cuối file): bảng 6 tiêu chí do `cham_diem.py --ghi` viết, điểm cuối ≥ 4.
3. **`03-THUMB-PROMPT-<slug>.txt`:** prompt ảnh AI cho `T01–T03`, theo `references/thumbnail.md`, mỗi prompt dán đủ đoạn NHÂN VẬT CỐ ĐỊNH và KHOÁ PHONG CÁCH THUMBNAIL. In hướng dẫn tạo ảnh ở cuối file.

## 3. Quy trình viết
0. **3 hướng kể** (bỏ qua nếu người dùng đã chọn khung / hướng hoặc nói "viết luôn"). Đưa 1 bảng 3 hướng, khác nhau về khung truyện hoặc góc nhìn, mỗi hướng: khung + 1 câu lý do, góc nhìn / logline 1 câu, ước mơ, vật biểu tượng (3 trạng thái), bộ đếm, kiểu kết, 2 kiểu câu móc, khác đối thủ ở đâu (theo `phan-tich/`, `video.csv` nếu có). Đánh dấu hướng nên chọn. **Dừng chờ người dùng chọn.** Đề tài tự hại / tuyệt vọng chỉ đưa khung kết hy vọng (Vực dậy, Thư gửi bản thân).
1. Theo khung đã chọn, chốt **thói xấu cụ thể** và **bộ đếm đúng kiểu của khung** (Vực dậy: DAY N gạch về 0; Tiếc nuối: AGE / YEARS chỉ tăng; Hai cuộc đời: 2 dòng; Vòng lặp: về DAY 1 mỗi vòng; Thư gửi: năm / tuổi). Bộ đếm là xương sống của phim. Có `DOI-THU-SELFIMPROVE/` thì xem đối thủ đã làm đề tài này thế nào (`video.csv`, `phan-tich/`) để chọn khung, kết, vật biểu tượng khác họ ngay từ đầu.
2. **Chiều sâu cảm xúc** (`cau-truc.md`): ước mơ cụ thể gài bằng hình trong 15% đầu; 1 vật biểu tượng đổi trạng thái qua ≥ 3 lần xuất hiện; ≥ 1 cặp gài – trả. Cố gắng cho cả 3 đi qua cùng một vật.
3. **2 câu móc khác kiểu** (5 kiểu ở `cau-truc.md`): A viết vào đầu phim, B viết thành khối `# MÓC B` ngay sau đầu file. Rồi **thẻ kết** (TỪ KHOÁ. + 2 dòng, dòng 2 đổi màu).
4. Lập dàn nhịp theo bảng của khung (`khung-truyen.md`): đổi % thành giây theo `DÀI`, mỗi nhịp 3–8 cảnh, ghi mốc bộ đếm từng nhịp. Bản > 3 phút: đặt 1 điểm **móc lại** ở 35–70%; rải biến cố để không quãng nào quá 40 giây không có chuyện mới.
5. Viết 4–8 câu **giọng cám dỗ**. Câu nào cũng phải nghe hợp lý, dịu dàng, như lời một người bạn. Đó là điều làm nó đáng sợ.
6. Viết file 01: đầu file đủ hồ sơ truyện (`KHUNG`, `ƯỚC MƠ`, `VẬT`, `MÓC`, `MÓC B`, `DÀI`, `ĐỀ TÀI`, `KẾT`); mỗi cảnh 1 dòng đầu ghi `CẢNH` (mô tả cho người đọc) + **`NỀN` + `AI`** (+ `ĐỘNG TÁC`, `MÁY` khi cần; `HUD`, `NHẠC`, `SFX` khi đổi) + dòng `# TRUYỆN:` khi cảnh có nhịp / ước mơ / vật / gài / trả / sụp / người thật / móc lại / biến cố + 0–2 dòng chữ, đúng định dạng `cau-truc.md`. **Giá trị hình chỉ lấy từ `references/kho-canh.md`.** Động tác bộ dựng chưa làm được (mục 7 kho-canh.md) thì đổi sang tư thế + cắt cảnh theo bảng.
   **Nhịp hình theo đối thủ (1.10, đo từ DISCIPLINE / DOPAMINE / LUST VS LOVE; bản "Five More Minutes" lệch cả 4 điểm và bị chê đứng hình):**
   - Cảnh đầu = **màn đen 2–4 giây, 1–2 câu nghịch lý**: `>` dòng thường + `!` dòng đậm (vd `> He had seen a thousand women.` / `! He had never held one's hand.`). Móc kiểu khác (cảnh tương lai…) thì đặt ngay sau màn này.
   - **Cả phim 3–4 màn đen**, mỗi màn 2–5 giây (1 dòng ~2s, 2 dòng ~4–5s). Ý muốn nói thêm thì đặt lên cảnh có hình (chữ kể chuyện trên cảnh), không xếp thêm màn đen.
   - Phim nhảy nhiều năm (AGE tăng dần): các hồi giống nhau gộp thành chuỗi dựng nhanh 3–4 giây / cảnh (đồng hồ, lịch, cận mặt) thay vì lặp lại cả hồi.
   - Câu có ý "sướng nhanh rồi sụp" / "khó lúc đầu rồi lên dần": dùng 1 cảnh `NỀN: đồ thị, sụp đổ` / `đồ thị, đi lên chậm, nhãn "hard things"` (≥ 4 giây), kiểu DOPAMINE.
   - `KÊU GỌI` ≤ 4 giây (đối thủ không có màn này, kết bằng thẻ kết).
   - Màu thế giới tự đổi theo NHẠC (sad → dark → none: xám dần; hope / rise: màu trở lại). Muốn ép: `MÀU: xám | nhạt | đủ màu | hồi màu`.
7. Đọc lại như người xem không có tiếng: chỉ nhìn chữ và hình có hiểu chuyện không? Cảnh nào chữ chưa kịp đọc thì tăng giây.
8. **Tự kiểm bằng máy:** chạy `phim.py --dry-run` (lệnh ở mục 4) đến khi `SACH LOI`, so cột "hiểu thành" với ý định; rồi `python tools/kiem_truyen.py --phim <file 01>` đến khi `SACH LOI`.
9. **Kiểm trùng đối thủ:** `python tools/doi_thu.py trung-lap --thu-muc <thư mục người dùng> --phim <file 01>`. `TRUNG 4/4` → đổi ít nhất 2 trong 4 (đề tài, khung, kết, vật) theo gợi ý; `LOI chép câu` → viết lại câu; `CANH BAO tiêu đề` → đổi tiêu đề. Chạy lại đến khi `KHONG TRUNG`. Chưa có thư mục đối thủ thì ghi "chưa kiểm (chưa quét đối thủ)".
10. Viết 02 (tiêu đề theo `KENH.md`), rồi 03. Kiểm dấu ấn kênh: `python tools/kenh.py kiem --thu-muc <D> --phim <01> --goi <02>` đến khi `SACH LOI`. Tập của chuỗi: `python tools/series.py kiem --thu-muc <D> --phim <01>` đến khi `SACH LOI`.
11. **Tự chấm:** `python tools/cham_diem.py --thu-muc <D> --phim <01> --ghi <02>`. Tiêu chí nào dưới 4 thì sửa file 01 (rồi chạy lại các bước kiểm) đến khi mọi tiêu chí ≥ 4. Được chỉnh cột Cuối ±1 kèm lý do.
12. Sau khi giao: `python tools/series.py ghi --thu-muc <D> --phim <01>` để ghi tập này vào hồ sơ chuỗi.

## 4. Tự kiểm trước khi giao
**Kiểm bằng máy trước** (bộ đọc của skill dựng, cùng plugin; không ghi file, không cần cài studio):
```
python "<thư mục skill này>/../lam-video-selfimprove/kit/tools/phim.py" --phim "<đường dẫn file 01>" --dry-run --dai <số phút đã chọn>
```
Dùng `python3` nếu `python` không phải Python 3. Báo: cảnh bị hiểu sai bối cảnh / mẫu cảnh, giá trị không có trong kho, động tác chưa hỗ trợ, chữ không đủ giờ đọc, tin nhắn đặt sai cảnh, tổng thời lượng. **Chỉ giao khi dòng cuối là `SACH LOI`**; ghi 1 dòng kết quả kiểm (số cảnh, tổng thời lượng, số cảnh báo còn lại và lý do giữ) vào cuối câu trả lời. Không có Python thì báo 1 dòng và tự soát từng giá trị với kho-canh.md.

- [ ] `--dry-run` báo `SACH LOI`. Tổng thời lượng máy tính khớp mức đã chọn. Cảnh 2–9 giây, cảnh có chữ đủ giây đọc (khoảng 3 từ mỗi giây + 1 giây).
- [ ] `--dry-run` không còn cảnh báo nhịp 1.10 (mở đầu không phải màn đen, phim > 3:20, > 4 màn đen, màn đen > 5 giây, KÊU GỌI > 4 giây), trừ khi người dùng đã chọn khác.
- [ ] `kiem_truyen.py` báo `SACH LOI`: đủ nhịp của **khung đã chọn** đúng thứ tự và vị trí; bộ đếm đúng kiểu của khung, có từ 20% đầu; ước mơ gài bằng hình ≤ 15%; vật biểu tượng ≥ 3 lần, đổi trạng thái; ≥ 1 cặp gài – trả; 2 câu móc khác kiểu; tổng thời lượng đúng `DÀI` (±5%); bản > 3 phút có móc lại ở 35–70%; không quãng nào > 40 giây không có biến cố. Không bắt mọi phim phải "đếm lại / đứng lên" — chỉ khung Vực dậy.
- [ ] Chữ kể chuyện: câu ngắn, tối đa 9 từ, thì quá khứ ngôi thứ ba; 1–3 câu cuối chuyển sang nói thẳng với người xem.
- [ ] Giọng cám dỗ: chữ thường, 2–7 từ, 4–8 câu, mỗi câu gắn với một cảnh có bóng đen.
- [ ] Có ít nhất 1 khoảnh khắc người thật (tin nhắn bạn cũ, người lạ chào, gia đình) ở nhịp khung quy định (Bước ngoặt / Cái giá / Hội tụ / Lệch vòng / Điều ước).
- [ ] Thẻ kết đúng dạng `THẺ KẾT: WORD. / dòng phụ / dòng phụ mau nhan`; cảnh cuối `KÊU GỌI` với dòng 1 là câu ký tên của kênh. `kenh.py kiem` báo `SACH LOI` (câu ký tên, màu, 10 tiêu đề cân bằng).
- [ ] Tập của chuỗi: `series.py kiem` báo `SACH LOI` (giữ nhân vật, màu, bộ đếm; không lặp câu cám dỗ).
- [ ] `cham_diem.py`: 6 tiêu chí đều ≥ 4, bảng điểm đã ghi vào 02-PACKAGE.
- [ ] Mọi cảnh có `NỀN` + `AI` (cảnh có người); mọi giá trị nằm trong kho-canh.md. Không cần ảnh AI trong video.
- [ ] Lust / sex: chỉ gợi bằng bóng neon, điện thoại phát sáng; không mô tả cơ thể, không từ ngữ thô. Tự hại / tự tử: **không** minh hoạ cách thức (thuốc, dao, độ cao...), luôn kết bằng hy vọng và kết nối với người thật.
- [ ] Không dùng lại câu chữ, câu chuyện, cảnh đặc trưng hay tên kênh đối thủ. `trung-lap` báo `KHONG TRUNG`; kết quả ghi ở dòng đầu 02-PACKAGE.
- [ ] Cuối câu trả lời nhắc bước tiếp theo:
  1. (Một lần duy nhất) tạo ảnh nhân vật mẫu `T00` theo `03-THUMB-PROMPT`.
  2. Tạo ảnh `T01` (hoặc T02, T03) trong Flow, gắn T00 làm ảnh tham chiếu.
  3. Gọi `/lam-video-selfimprove` và đưa file `01-PHIM`.

## 5. Mẹo chuỗi tập
- Đề tài nổ thì làm ngay **PART 2** trong 2–5 ngày: cùng nhân vật, cùng bộ đếm, chặng khó hơn (tái nghiện, ngày 300+, cám dỗ đổi giọng). Mọi thứ cần giữ / tránh lặp nằm trong `series/<chuỗi>/SERIES.md`.
- Biến thể **X VS Y** (ví dụ "SCROLL VS SLEEP", "COMFORT VS GROWTH"): khung Hai cuộc đời song song, bộ đếm 2 dòng đối nghịch.
- Đổi khung giữa các tập để khán giả không đoán được đường đi: PART 1 Vực dậy → PART 2 Vòng lặp (tái nghiện) → PART 3 Thư gửi bản thân.
- Mỗi kênh nên **sở hữu 1–2 chủ đề** và đào sâu bằng chuỗi; chép đề kênh khác thường ế.

## 6. Gợi ý đề tài
Đưa ra 10 đề tài, mỗi đề tài một dòng gồm: **TỪ KHOÁ** (tiêu đề), cơn nghiện / thói xấu, bộ đếm, câu cám dỗ đắt nhất, khoảnh khắc người thật ở bước ngoặt, **bằng chứng** (video đối thủ cùng loại: kênh, tiêu đề, lượt xem, ×trung vị; hoặc "chưa có bằng chứng — đối thủ chưa làm"), **góc khác biệt** (khung / kết / vật / góc nhìn đối thủ chưa dùng cho đề tài này), tiềm năng (1–3 sao).

Chấm sao theo 5 tiêu chí:
- nam 16–30 tuổi tự nhận ra mình ngay trong 3 giây đầu
- có bộ đếm rõ ràng, sụp về 0 được
- làm được chuỗi PART 2, VS
- vẽ được bằng kho cảnh có sẵn
- có bằng chứng view (đề tài cùng loại vượt trội ở kênh đối thủ) mà chưa bị làm dày

**Dữ liệu đối thủ (theo `references/doi-thu.md`):**
1. Lần quét cuối (`DOI-THU-SELFIMPROVE/lan-quet.csv`) quá 3 ngày hoặc chưa có → quét tầng 1 (RSS → trình duyệt → tìm kiếm web, tự chuyển nguồn, không hỏi). Báo 1 dòng mỗi kênh: nguồn, số video.
2. `python tools/doi_thu.py bao-cao --thu-muc <thư mục người dùng>` → dùng mục vượt trội, đề tài đang ăn, khoảng trống, đề tài mình đã làm (`projects/`) để chọn và xếp 10 đề tài. Tránh đề tài mình đã làm và đề tài đối thủ đang làm dày (trừ khi có góc khác hẳn).
3. Không quét được bằng cả 3 nguồn: báo một dòng rồi gợi ý từ các nhóm ăn khách: điện thoại / dopamine, porn / lust (giữ kín đáo), dậy sớm / lười, trì hoãn, game đêm, so sánh mạng xã hội, nhắn tin người cũ, cô đơn → kết nối, rượu / vape, ăn uống vô độ, sợ thất bại, vùng an toàn (ghi rõ "không có bằng chứng số liệu").
4. Sau danh sách: nếu chưa có lịch quét tuần, hỏi 1 câu có muốn tạo không (chỉ tạo khi người dùng đồng ý).
